"""Local container entry point using the worker's actual admission pipeline.

The local dedup corpus is explicitly empty. Server originality, signatures and
reward eligibility remain server decisions; no model or backend is contacted.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import pathlib
import sys
import tempfile
from importlib.metadata import version

from .admission import admit_package
from .authoring import build_package, record_reference
from .base import TaskSourceError
from .fingerprint import INDEX_VERSION
from .package import package_digest, read_json, write_json
from .runtime import get_profile, run_admission

ADMISSION_VERSION = "task-source-miner/1"
SOURCE_CONFIG = {"sources": {"axis": {"factory": "task_source.axis:AxisSource", "options": {}}}}


def describe():
    from openroboto_protocol.scene_contract import task_profile_catalog

    policy = pathlib.Path(__file__).parent / "data/admission_profiles.json"
    return {
        "runtime_version": version("openroboto-task-runtime"),
        "protocol_version": version("openroboto-protocol"),
        "admission_version": ADMISSION_VERSION,
        "admission_policy_sha256": hashlib.sha256(policy.read_bytes()).hexdigest(),
        "execution_profiles": [
            p["execution_profile"]
            for p in task_profile_catalog(include_development=True)
            if p["id"] in {"panda-tabletop-v1", "panda-tabletop-v2"}
        ],
        "timeout_s": get_profile("axis-cpu")["runtime"]["timeout_s"],
    }


def check_package(package, *, execution_profile, source, static_only=False):
    """Keep check names, kinds and details identical to worker admission."""
    from .profile_dispatch import validate_package
    from .package import load_package

    loaded = load_package(package)
    if loaded.source != source:
        raise TaskSourceError(f"task source mismatch: expected {source}, got {loaded.source}")
    validate_package(loaded, expected_execution_profile=execution_profile)
    config = json.loads(json.dumps(SOURCE_CONFIG))
    config["sources"]["axis"]["options"]["expected_execution_profile"] = execution_profile
    if static_only:
        result = admit_package(package, config=config).to_dict()
    else:
        profile = get_profile("axis-cpu")
        profile["expected_execution_profile"] = execution_profile
        # Use the exact runtime pipeline, with an explicit isolated local corpus.
        with tempfile.TemporaryDirectory(prefix="miner-dedup-") as temporary:
            index = pathlib.Path(temporary) / "index.json"
            write_json(index, {"schema_version": INDEX_VERSION, "fingerprints": []})
            profile["dedup"] = {"index": str(index)}
            result = run_admission(package, config=config, profile=profile).to_dict()
    result.update(describe())
    result["package_digest"] = package_digest(package)
    result["scope"] = "local static/physics; empty local dedup corpus; server admission not run"
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("describe")
    build = commands.add_parser("build")
    build.add_argument("--definition", type=pathlib.Path, required=True)
    build.add_argument("--output", type=pathlib.Path, required=True)
    build.add_argument("--task-id", default="authored-tabletop-task")
    build.add_argument("--title", default="Authored tabletop task")
    build.add_argument("--public-summary", type=pathlib.Path)
    record = commands.add_parser("record-reference")
    record.add_argument("package", type=pathlib.Path)
    solve = record.add_mutually_exclusive_group(required=True)
    solve.add_argument("--script", type=pathlib.Path)
    solve.add_argument("--example", action="store_true")
    for name in ("admit-static", "self-test"):
        check = commands.add_parser(name)
        check.add_argument("package", type=pathlib.Path)
        check.add_argument("--execution-profile", required=True, type=json.loads)
        check.add_argument("--source", required=True, choices=["axis"])
    args = parser.parse_args(argv)
    try:
        if args.command == "describe":
            result = describe()
        elif args.command == "build":
            result = build_package(
                args.definition,
                args.output,
                task_id=args.task_id,
                title=args.title,
                public_summary=read_json(args.public_summary) if args.public_summary else None,
            )
        elif args.command == "record-reference":
            from .tabletop import DATA

            document = read_json(args.package / "task.json")
            if args.example and document["execution_profile"]["id"] != "panda-tabletop-v1":
                raise TaskSourceError(
                    "--example solves only the v1 one-cube template; provide solve.py for this profile"
                )
            with contextlib.redirect_stdout(sys.stderr):
                result = record_reference(
                    args.package, DATA.parent / "tabletop_reference.py" if args.example else args.script
                )
        else:
            result = check_package(
                args.package,
                execution_profile=args.execution_profile,
                source=args.source,
                static_only=args.command == "admit-static",
            )
    except (TaskSourceError, ValueError, OSError) as exc:
        result = {"accepted": False, "error": str(exc), "checks": [], **describe()}
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if result.get("accepted", True) else 1


if __name__ == "__main__":
    raise SystemExit(main())
