"""Exact local scene-runtime registry and TaskSpec bridge; no private-root I/O."""

from __future__ import annotations

import hashlib
import importlib.metadata
import platform
from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING

from openroboto_protocol import scene_contract
from openroboto_protocol.tabletop_assets import canonical_digest

from .base import InstanceSpec, TaskSourceError, TaskSpec, UnknownTask

if TYPE_CHECKING:
    from .runtime import Verdict
    from .scene_admission import SceneAdmissionCaller
    from .scene_views import AdmissionView, ExecutionView

RUNTIME_VERSION = "0.3.18"
ENVIRONMENT_VERSION = "ope238-scene-runtime-0.3.18-r1"

# Reviewed source checkpoints, not operator registration or deployment claims.
SOURCE_CHECKPOINTS = {
    "protocol": "73175b4a20476717a436695853b53b722baea3ed",
    "scene_import": "b0cbb84d812740bcc59c33118952744b224b7d1b",
    "scene_views": "ae4a075f533fcb6f8578833ad154bb2202c0e357",
    "scene_review": "1918400971eea977983fe1235ac328f1be11f1b9",
    "scene_transport": "0ec9d8f5106b19834528b5f86dd0bb52a074a8c6",
    "scene_instruction": "54b9b46ff8afac70d7a347f707bc4bc8caa49915",
    "joint_integration": "89da4efe438304d7904a892a193c48219a53bacb",
    "scene_native_environment": "256587bd1a002f15d3818324fdd2d1f8a39a4f69",
    "worker_packaging": "0a67ca21a3a8146cf79d9dbbba9aa6875bc97400",
    "scene_provider": "89da4efe438304d7904a892a193c48219a53bacb",
    "scene_admission_attempt": "fba2cd010596beadfd94780a2d2c955467bcde38",
}


def run_scene_admission(view: AdmissionView, *, context: SceneAdmissionCaller) -> Verdict:
    """Registered native admission; signing stays in the credential-owning parent."""
    from .scene_admission import run_scene_admission as run

    return run(view, context=context)


def build_scene_admission_config(*, runtime, profile, corpus):
    """Pure configuration preimage for explicit operator registration."""
    from .scene_admission import build_config

    return build_config(runtime=runtime, profile=profile, corpus=corpus)


def prepare_scene_episode(view: ExecutionView, *, context) -> dict:
    """Pure P08 panel spec integration. This is not the execution gateway."""
    from .scene_panel import prepare_scene_episode as prepare

    return prepare(view, context=context)


def validate_scene_episode_context(view: ExecutionView, *, context):
    """Pure saved-spec binding gate before P08 writes any started marker."""
    from .scene_episode_delegate import prepare_delegate_request

    return prepare_delegate_request(view, context=context)


def execute_scene_episode(view: ExecutionView, *, context):
    """One prepared request through P03; missing deployment fails unavailable."""
    from .scene_episode_delegate import execute_scene_episode as execute

    return execute(view, context=context)


def is_scene(reference):
    return isinstance(reference, dict) and reference.get("id") == "panda-open-scene-v1"


def registry_document():
    from agent_harness.manifest import agent_binding, harness_code_digest
    from .scene_import.platform import registry_document as importer_registry
    from .scene_observation import policy_identity
    from .scene_instruction_runtime import policy_identity as instruction_identity
    from .scene_admission import policy_identity as admission_identity
    from .scene_views.episode_gateway import gateway_factory_identity
    from .scene_views.episode_watchdog import MEMORY_EVIDENCE_MODES, MEMORY_PEAK_REQUIRED

    document = importer_registry()
    base = Path(__file__).resolve().parent
    sources = {
        path.relative_to(base).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(base.rglob("*.py"))
        if "__pycache__" not in path.parts
    }
    document.update(
        version=ENVIRONMENT_VERSION,
        adapter="openroboto-scene-runtime/" + RUNTIME_VERSION,
        runtime={
            "version": RUNTIME_VERSION,
            "source_digest": canonical_digest(sources),
            "source_checkpoints": dict(SOURCE_CHECKPOINTS),
            "recovery_checkpoint_schema_sha256": hashlib.sha256(
                (base / "data/scene_recovery_checkpoint_v1.schema.json").read_bytes()
            ).hexdigest(),
            "protocol_version": importlib.metadata.version("openroboto-protocol"),
            "python_version": platform.python_version(),
            "dependencies": {
                name: importlib.metadata.version(name)
                for name in ("mujoco", "numpy", "pydantic", "pillow", "cryptography", "pyyaml", "huggingface_hub")
            },
            "execution_profile": scene_contract.profile_ref(),
            "agent": agent_binding(),
            "harness_code_digest": harness_code_digest(),
            "control_period_s": 0.2,
            "physics_step_s": 0.002,
            "reference_schema_version": 1,
            "observation_admission_policy": policy_identity(),
            "instruction_admission_policy": instruction_identity(),
            "scene_admission_policy": admission_identity(),
            "scene_episode": {
                "api": "scene-runtime-episode/1",
                "p03_commit": SOURCE_CHECKPOINTS["scene_views"],
                "a_gateway_factory": gateway_factory_identity(),
                "memory_evidence": {
                    "default": MEMORY_PEAK_REQUIRED,
                    "supported": list(MEMORY_EVIDENCE_MODES),
                    "selection": "registered-operator-policy",
                    "unsupported_peak": None,
                },
                "deployment": "unverified; actual dedicated Linux parent/resources required",
            },
            "control_semantics": {
                "id": "scene-gripper-command-state/1",
                "scope": scene_contract.profile_ref(),
                "interpolation_start": "two last applied native finger actuator targets",
                "measurement": "unchanged actual joint feedback",
                "direct_step_and_reset": "read actual ctrl; no planner command cache",
                "legacy_v1_controlled_v2": "unchanged",
                "tool_schema_and_joint_mapping": "unchanged",
            },
        },
    )
    return document


def import_context():
    from .scene_import import SceneImportContext

    return SceneImportContext(registry_document=registry_document())


def registry_refs():
    return import_context().registry_refs()


def validated_definition(imported):
    """One validated AST projection for BOTH monitor and checker.

    JSON 0 and 0.0 have equal contract values but different raw hashes. The
    closed SceneTask normalizes coordinates and enforces integral counts; use
    that same projection on both sides. Original E/checker bytes stay frozen
    and separately content-addressed, never reserialized or written back.
    """
    return imported.task.task_definition.model_dump(mode="json")


def validate_package(package, *, expected_execution_profile=None):
    from agent_harness.manifest import verify_agent_binding
    from .scene_import import ScenePackage
    from .scene_import.errors import reject

    if not isinstance(package, ScenePackage):
        reject("scene_package_required", "task", "Use the schema3 native importer")
    task = package.imported_scene.task
    expected = scene_contract.profile_ref()
    if package.task.get("execution_profile") != expected or expected_execution_profile not in (None, expected):
        reject("execution_profile_mismatch", "execution_profile", "Exact scene profile required")
    environment = task.environment.model_dump()
    registered = registry_refs()["environment"]
    # Identity is (id, version): the digest covers every task_source source file,
    # so a package built before an unrelated worker fix must still run on the
    # sealed worker that is the registered environment.
    if environment.get("id") != registered["id"] or environment.get("version") != registered["version"]:
        reject(
            "environment_unsupported", "environment", "Installed scene runtime identity differs", status="unsupported"
        )
    errors = verify_agent_binding(dict(task.execution_contract["agent"]))
    if errors:
        reject("harness_identity_mismatch", "execution_contract.agent", "; ".join(errors), status="unsupported")
    return {
        "execution_profile": expected,
        "observation_contract": task.task_definition.observation,
        "resource_profile": task.task_definition.resource_profile,
        "environment": task.environment.model_dump(),
        "execution_contract": scene_contract.parse_execution_contract(task.execution_contract),
        "scene_import_digest": package.imported_scene.digest,
        "execution_package_digest": package.imported_scene.manifest["execution_package_digest"],
        "original_checker_digest": canonical_digest(package.task["checker"]),
        "program_definition_digest": canonical_digest(validated_definition(package.imported_scene)),
    }


def make_task(package, *, instance=None, reference=None):
    from .axis import ACTION_SPACE, OBSERVATION_SPACE

    imported = package.imported_scene
    summary = validate_package(package)
    instances = []
    for number, initial in enumerate(imported.task.scene.initial_states):
        native = imported.initial_states[initial.id]
        state = {
            "positions": {k: v["position_m"] for k, v in native["bodies"].items()},
            "orientations": {k: v["quaternion_xyzw"] for k, v in native["bodies"].items()},
            "qpos": native["qpos"],
            "qvel": native["qvel"],
        }
        seed = (
            int(
                canonical_digest({
                    "domain": "openroboto-scene-noise/1",
                    "task_id": package.task_id,
                    "state_id": initial.id,
                })[:8],
                16,
            )
            & 0x7FFFFFFF
        )
        instances.append(
            InstanceSpec(
                instance=number,
                initial_state=state,
                initial_state_sha256=canonical_digest(state),
                seed=seed,
                checker_sha256=canonical_digest(package.task["checker"]),
                metadata={"scene_state_id": initial.id},
            )
        )
    total = len(instances)
    if instance is not None:
        instances = [value for value in instances if value.instance == int(instance)]
        if not instances:
            raise UnknownTask(f"scene has no instance {instance}")
    definition = validated_definition(imported)
    return TaskSpec(
        task_id=package.task_id,
        source="axis",
        instruction=package.instruction,
        package_dir=str(package.directory),
        action_space=ACTION_SPACE,
        observation_space=OBSERVATION_SPACE,
        checker_config=package.task["checker"],
        instances=tuple(instances),
        reference=reference,
        metadata={
            **summary,
            "package": package,
            "imported_scene": imported,
            "instance_count": total,
            "runtime": {
                "control_period_s": 0.2,
                "camera": imported.bindings["camera"]["name"],
                "observation_joint_order": imported.bindings["robot"]["joint_order"],
                "scene_definition": definition,
            },
        },
    )


def static_checks(task):
    contract = task.metadata["execution_contract"]
    issues = []
    if task.reference is not None:
        if task.reference.get("schema_version") != 1 or str(task.reference.get("task_id")) != task.task_id:
            issues.append({"code": "reference_identity"})
        for instance in task.instances:
            row = task.reference_for(instance.instance)
            if not isinstance(row, dict) or row.get("state_id") != instance.metadata["scene_state_id"]:
                issues.append({"instance": instance.instance, "code": "reference_state_id"})
                continue
            actions = row.get("actions")
            if not isinstance(actions, list) or not actions or len(actions) > contract["budget"]["max_steps"]:
                issues.append({"instance": instance.instance, "code": "reference_steps"})
                continue
            import math

            if any(
                not isinstance(a, list)
                or len(a) != 9
                or any(type(v) not in (int, float) or not math.isfinite(v) for v in a)
                for a in actions
            ):
                issues.append({"instance": instance.instance, "code": "reference_action"})
    return [
        ("scene.exact_identity", True, {"environment": task.metadata["environment"]}),
        ("scene.initial_states", bool(task.instances), {"count": len(task.instances)}),
        ("scene.reference_contract", not issues, {"issues": issues, "reference_present": task.reference is not None}),
    ]


def kinematic_environment(task, instance, *, deadline=float("inf")):
    """Private FK/IK data, not a simulated episode or a program reset."""
    imported = task.metadata["imported_scene"]
    match = next((row for row in task.instances if row.instance == instance), None)
    if match is None:
        raise TaskSourceError(f"unknown scene instance {instance}")
    robot = imported.bindings["robot"]
    import time
    from .scene_env import SceneDeadlineExceeded

    def check_deadline():
        if time.monotonic() >= deadline:
            raise SceneDeadlineExceeded("scene kinematic replay deadline exceeded")

    check_deadline()
    return SimpleNamespace(
        model=imported.model,
        data=imported.reset(match.metadata["scene_state_id"]),
        joint_ids=tuple(robot["joint_ids"]),
        qpos_indices=tuple(robot["qpos_addresses"]),
        runtime=task.metadata["runtime"],
        check_deadline=check_deadline,
    )
