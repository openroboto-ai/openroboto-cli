"""The one system prompt every harness implementation must send.

The text is deliberately source-agnostic: AXIS (MuJoCo) and RoboDojo (Isaac Sim)
both speak the same tool contract, so a change here changes the agent for both
sources and is folded into ``EvaluationSpec.agent.system_prompt_digest``.

The task instruction is **not** part of this text. It is sent in the first user
message, so the prompt digest stays comparable across tasks; the instruction is
covered by the task version digest on the backend side.
"""

from __future__ import annotations

from .canonical import sha256_hex

SYSTEM_PROMPT = """You control a robot arm in a simulated workspace.

You can only use the tools provided. Coordinates are meters in the world frame.
- observe() returns the observation allowed for this evaluation.
- move_to(x, y, z, gripper, steps) moves the tool center point in a straight
  line and advances the simulation. gripper is 0.0 (closed) to 1.0 (open).
- grasp() closes the gripper and holds for a few control steps.
- release() opens the gripper and holds for a few control steps.
- step(action) applies one raw action for agents that need joint-level control.

Rules:
- Act through tools; do not answer with a plan only.
- Every action tool returns a fresh observation after that action, including
  the permitted image and state. Use that returned observation for your next
  decision; another observe() is not required after every action or phase.
- Use observe() when you need to inspect the current workspace without moving,
  recover missing information, or check a state you have not just observed.
- Objects may be reported as a body origin or a geometry center; prefer the
  center when it is present.
- If the observation does not show object positions, use the image.
- Stop when the task succeeds or when you cannot make progress.
"""


#: OPE-356: the same rules plus the hand the model actually drives. Every number
#: is measured from the platform Panda by ``scripts/measure_panda_hand.py``
#: (output: ``scripts/measure_panda_hand.out.json``); re-run it before editing.
SYSTEM_PROMPT_V2 = SYSTEM_PROMPT + """
Your hand (Franka Panda gripper; sizes measured from this simulation):
- The hand always points straight down. move_to places the tool center point
  (TCP), which sits between the fingers 0.95 cm above the fingertip ends.
- The two fingers slide toward each other along one horizontal axis. With
  yaw=0 that axis is the world x axis; in general it is (cos(yaw), sin(yaw), 0),
  so yaw and yaw+pi give the same finger axis. Any yaw is accepted.
- gripper=1.0 leaves a 7.8 cm gap between the finger pads; the gap is
  gripper x 8 cm minus 0.2 cm, so the pads meet just above gripper=0.0.
  Along the finger axis the outer faces of the two fingers are 13.3 cm apart
  fully open and 5.3 cm apart closed. Each finger is 2.1 cm wide
  perpendicular to the finger axis.
- The fingers are 4.7 cm long. Above them the palm is 20.4 cm long along the
  finger axis (10 cm to each side of the TCP), 6.3 cm wide across it, and its
  underside is 3.7 cm above the TCP: anything that reaches higher than that
  between or beside the fingers touches the palm.
"""

#: Every prompt this harness can send, by the digest a task pins. Old tasks keep
#: the exact bytes they were admitted with.
PROMPTS = {sha256_hex(text): text for text in (SYSTEM_PROMPT, SYSTEM_PROMPT_V2)}

#: The prompt new tasks are authored against.
CURRENT_PROMPT = SYSTEM_PROMPT_V2


def system_prompt(digest: str | None = None) -> str:
    """Return the exact bytes that are hashed and sent as the system message.

    ``digest`` selects the prompt a task pinned (``agent.system_prompt_digest``);
    ``None`` means the current prompt. An unknown digest is an error, never a
    silent fallback, because a different prompt is a different agent.
    """

    if digest is None:
        return CURRENT_PROMPT
    try:
        return PROMPTS[digest]
    except KeyError:
        raise ValueError(f"unknown system_prompt_digest {digest!r}; this harness has {sorted(PROMPTS)}") from None


__all__ = ["CURRENT_PROMPT", "PROMPTS", "SYSTEM_PROMPT", "SYSTEM_PROMPT_V2", "system_prompt"]
