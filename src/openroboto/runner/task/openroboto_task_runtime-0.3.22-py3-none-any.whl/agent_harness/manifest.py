"""Frozen harness identity: version, code digest, prompt digest, tool digest.

These three values are what ``EvaluationSpec.agent`` carries:

    agent.harness_commit     40 hex, identity of the harness code
    agent.system_prompt_digest  sha256 of the exact system prompt
    agent.tools_digest          sha256 of the canonical tool manifest

A miner cannot supply its own values: :func:`agent_harness.run` compares the
spec against what this process actually loaded and rejects a mismatch.

``harness_commit`` is a *content* digest, not necessarily a git sha. Deployment
sets ``AGENT_HARNESS_COMMIT`` to the 40-char git sha of the image build so the
spec is traceable to a commit; locally we derive a deterministic 40-hex value
from the source files. Both are 40 lowercase hex, which is what the backend
validator enforces.
"""

from __future__ import annotations

import os
import pathlib
import re
from collections.abc import Mapping

from .canonical import canonical_sha256, sha256_hex
from .prompts import PROMPTS, system_prompt
from .tools import tools_digest

HARNESS_NAME = "agent-harness"
HARNESS_VERSION = "1"

GIT_SHA_RE = re.compile(r"\A[0-9a-f]{40}\Z")
_COMMIT_ENV = "AGENT_HARNESS_COMMIT"

_PACKAGE_DIR = pathlib.Path(__file__).resolve().parent


#: Everything that can change agent behaviour. The Pi extension is included so
#: a changed tool bridge is a different harness commit, not just code drift.
_HARNESS_SUFFIXES = {".py", ".ts", ".json"}


def harness_files() -> dict[str, str]:
    """Map harness sources/assets -> sha256, sorted by relative path."""

    files: dict[str, str] = {}
    for path in sorted(_PACKAGE_DIR.rglob("*")):
        if not path.is_file() or path.suffix not in _HARNESS_SUFFIXES:
            continue
        if "__pycache__" in path.parts:
            continue
        files[path.relative_to(_PACKAGE_DIR).as_posix()] = sha256_hex(path.read_text(encoding="utf-8"))
    return files


def harness_code_digest() -> str:
    """Deterministic 40-hex identity of the harness source."""

    return canonical_sha256({"name": HARNESS_NAME, "files": harness_files()})[:40]


def harness_commit() -> str:
    """Deployment git sha when set, otherwise the content digest."""

    override = os.environ.get(_COMMIT_ENV, "").strip().lower()
    if override:
        if not GIT_SHA_RE.match(override):
            raise ValueError(f"{_COMMIT_ENV} must be a 40-char lowercase git sha, got {override!r}")
        return override
    return harness_code_digest()


def system_prompt_digest(digest: str | None = None) -> str:
    """Digest of the prompt ``digest`` selects (``None`` = the current prompt)."""

    return sha256_hex(system_prompt(digest))


def agent_binding(prompt_digest: str | None = None) -> dict[str, str]:
    """The block that goes into ``EvaluationSpec.agent``.

    ``prompt_digest`` is the prompt a task pinned (OPE-356): an episode of an
    old task runs this harness code with the old prompt, and its spec and
    ``run_start.agent`` say so. ``None`` is this harness's own identity.
    """

    return {
        "harness_commit": harness_commit(),
        "system_prompt_digest": system_prompt_digest(prompt_digest),
        "tools_digest": tools_digest(),
    }


def binding() -> dict[str, object]:
    """Everything the execution layer needs to freeze for a run."""

    return {
        "agent": agent_binding(),
        "harness": {"name": HARNESS_NAME, "version": HARNESS_VERSION},
    }


#: Earlier harness bindings this harness still runs. A task or panel config
#: pinned to one of these runs on the current harness; the binding actually
#: used is recorded per episode in ``run_start.agent``. Append the old binding
#: whenever harness code changes, so admitted tasks keep being evaluated.
#: ponytail: a flat allowlist; drop the pin entirely if nothing reads it (OPE-323).
COMPATIBLE_BINDINGS: tuple[dict[str, str], ...] = (
    {
        # 0.3.18–0.3.20 runtimes; model never told its step/turn budget.
        "harness_commit": "71c038ebabb77411ca306a14e72eb41a0b412710",
        "system_prompt_digest": "0d6db8fbfca8ad568d387528ccbc38fd5dc031b10eff1c41a22029b65ea1668c",
        "tools_digest": "2ef160b4647a5c9cbd0fc5f85efca224abda3298ea7811a66f8ed55ce202de32",
    },
    {
        # 0.3.21 runtime (OPE-356 item 4): budget disclosed, original prompt.
        "harness_commit": "eb03a5ceeaac73e4156b6959ddd62567f9b6a455",
        "system_prompt_digest": "0d6db8fbfca8ad568d387528ccbc38fd5dc031b10eff1c41a22029b65ea1668c",
        "tools_digest": "2ef160b4647a5c9cbd0fc5f85efca224abda3298ea7811a66f8ed55ce202de32",
    },
)


def accepts_binding(pinned: object, running: object = None) -> bool:
    """True when a pinned ``agent`` block may run on the ``running`` harness.

    ``running`` defaults to this process's :func:`agent_binding`; callers that
    hold a measured image binding pass that instead.
    """

    running = agent_binding() if running is None else running
    if not isinstance(pinned, Mapping) or not isinstance(running, Mapping):
        return False
    pinned = dict(pinned)
    if pinned in COMPATIBLE_BINDINGS:
        return True
    # Same harness code and tools; the prompt may be any one this harness can
    # send (OPE-356), and the episode then sends exactly that prompt.
    return (
        set(pinned) == set(running)
        and pinned.get("harness_commit") == running.get("harness_commit")
        and pinned.get("tools_digest") == running.get("tools_digest")
        and pinned.get("system_prompt_digest") in PROMPTS
    )


def verify_agent_binding(agent: object) -> list[str]:
    """Return human-readable mismatches; empty means the spec matches this code."""

    if not isinstance(agent, dict):
        return ["agent block is missing; freeze EvaluationSpec.agent first"]
    if accepts_binding(agent):
        return []
    expected = agent_binding()
    problems = []
    for field, value in expected.items():
        actual = str(agent.get(field) or "").lower()
        if actual != value:
            problems.append(f"agent.{field}={agent.get(field)!r} does not match this harness ({value})")
    return problems


def describe() -> dict[str, object]:
    return {
        "name": HARNESS_NAME,
        "version": HARNESS_VERSION,
        "commit": harness_commit(),
        "code_digest": harness_code_digest(),
        "system_prompt_digest": system_prompt_digest(),
        "tools_digest": tools_digest(),
        "files": harness_files(),
    }


__all__ = [
    "HARNESS_NAME",
    "HARNESS_VERSION",
    "COMPATIBLE_BINDINGS",
    "accepts_binding",
    "agent_binding",
    "binding",
    "describe",
    "harness_code_digest",
    "harness_commit",
    "harness_files",
    "system_prompt_digest",
    "verify_agent_binding",
]
