"""准入节点把本题静态近重复证据签名上报；不决定准入、计奖或隔离。

证据是静态特征与私有索引的逐项对比，签名身份就是该题的准入节点。后端按已验签
回执自行判定放行，本模块只保证「送到的是一份完整、可复算的文档」。
"""

from __future__ import annotations

from openroboto_protocol.tabletop_assets import canonical_digest

from .scene_transport import SceneTransportError

PAGE_LIMIT = 50
MAX_PAGES = 200


class SceneReviewSubmissionError(Exception):
    """稳定内部分类；重试与否由调用方决定，不夹带服务端原始诊断。"""

    def __init__(self, code: str, *, retryable: bool = False):
        self.code, self.retryable = code, retryable
        super().__init__(code)


def corpus(transport, task_id):
    """完整私有索引；游标必须前进，页数有上限，绝不静默截断。"""
    entries, after = [], 0
    for _ in range(MAX_PAGES):
        page, cursor = transport.review_corpus(task_id, after=after, limit=PAGE_LIMIT)
        entries.extend(page)
        if cursor is None:
            return entries
        if cursor <= after:
            raise SceneReviewSubmissionError("scene_review_corpus_cursor_invalid")
        after = cursor
    raise SceneReviewSubmissionError("scene_review_corpus_incomplete")


def submit(transport, view, *, task_id, runtime):
    """拉完整索引 → 本节点签名 → 提交；返回文档摘要供幂等判断。"""
    try:
        candidates = corpus(transport, task_id)
        document = transport.review_document(
            view,
            task_id=task_id,
            runtime=runtime,
            candidates=candidates,
        )
        transport.submit_review(document)
    except SceneTransportError as exc:
        raise SceneReviewSubmissionError(exc.code, retryable=exc.retryable) from None
    except (ValueError, KeyError, TypeError):
        raise SceneReviewSubmissionError("scene_review_document_invalid") from None
    return canonical_digest(document)


__all__ = ["MAX_PAGES", "PAGE_LIMIT", "SceneReviewSubmissionError", "corpus", "submit"]
