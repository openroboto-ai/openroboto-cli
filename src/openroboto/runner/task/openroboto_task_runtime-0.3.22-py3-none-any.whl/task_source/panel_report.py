"""Build a signed A report only from complete original per-episode artifacts."""

from __future__ import annotations
import json
from decimal import Decimal, localcontext
from pathlib import Path
from agent_evidence import verify_chain
from agent_evidence.signing import TrustStore
from agent_evidence import verify_root
from benchmark_worker.reference_panel.manifest import build_manifest, canonical_sha256, sign_manifest


class PanelEvidenceError(ValueError):
    pass


def signed_wall_ms(events):
    if len(events) < 2:
        raise PanelEvidenceError("episode lacks signed clock span")
    clocks = []
    for event in events:
        value = event.get("ts_monotonic")
        if type(value) not in (int, float):
            raise PanelEvidenceError("episode signed clock must be numeric")
        clock = Decimal(str(value))
        if not clock.is_finite() or clock < 0 or (clocks and clock < clocks[-1]):
            raise PanelEvidenceError("episode signed clock must be finite, nonnegative and monotonic")
        clocks.append(clock)
    with localcontext() as context:
        integer_places = max(clock.adjusted() for clock in clocks)
        fractional_places = -min(clock.as_tuple().exponent for clock in clocks)
        context.prec = max(28, integer_places + fractional_places + 5)
        return int(round((clocks[-1] - clocks[0]) * 1000))


def episode_row(spec: dict, result: dict, signer) -> dict:
    path = Path(spec["evidence"]["path"])
    events = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    wall_ms = signed_wall_ms(events)
    root = json.loads(Path(str(path) + ".root.json").read_text())
    trust = TrustStore()
    trust.add("executor", signer.key_id, signer.public_key_hex)
    checked = verify_chain(
        events,
        expected_root=root["root"],
        party="executor",
        job_id=spec["binding"]["job_id"],
        attempt_id=spec["attempt_id"],
        episode=spec["episode"],
        job_nonce=spec["binding"]["nonce"],
        require_payload=True,
    )
    if not checked.ok or not verify_root(root, trust).ok:
        raise PanelEvidenceError("episode chain or root signature invalid")
    if root.get("job_digest") != spec["evidence"]["job_digest"]:
        raise PanelEvidenceError("episode root spec binding differs")
    if not events or events[0].get("type") != "run_start" or events[-1].get("type") != "run_end":
        raise PanelEvidenceError("episode lacks ordered terminal evidence")
    terminal = events[-1]["payload"]
    start = events[0]["payload"]
    for key in ("task_id", "package_digest", "config_version", "config_digest", "panel", "member", "trial"):
        expected = spec["task"]["task_id"] if key == "task_id" else spec["panel_binding"][key]
        if start.get(key) != expected:
            raise PanelEvidenceError(f"episode {key} binding differs")
    if type(terminal.get("success")) is not bool or type(terminal.get("steps")) is not int:
        raise PanelEvidenceError("invalid terminal types")
    if result.get("success") != terminal["success"] or result.get("steps") != terminal["steps"]:
        raise PanelEvidenceError("result conflicts with terminal")
    if "error" not in terminal:
        raise PanelEvidenceError("terminal error missing")
    return {
        "trial": spec["panel_binding"]["trial"],
        "success": terminal["success"],
        "steps": terminal["steps"],
        "model_calls": sum(e.get("type") == "model_call" for e in events),
        "wall_ms": wall_ms,
        "child_root": root["root"],
        "error": terminal["error"],
        "instance": spec["task"]["instance"],
        "events": events,
        "events_digest": canonical_sha256(events),
    }


def planned_trials(work: dict, members=None) -> list[tuple[str, int]]:
    """(member_id, trial) pairs this run evaluates, trial-major like the full grid.

    A retrial claim (OPE-321) carries ``trials: {member_id: [trial, ...]}``;
    without it every settlement member runs range(trials_per_member).
    ``members`` is the parsed settlement members; omitted, the raw claim config is read.
    Raises ValueError("CLAIM_TRIALS_INVALID") on a malformed list.
    """
    if members is None:
        config = work["config"]
        ids = [member["id"] for member in config["panels"][config["settlement_panel"]]["members"]]
    else:
        ids = [member.id for member in members]
    n = work["trials_per_member"]
    wanted = work.get("trials")
    if wanted is None:
        return [(member, trial) for trial in range(n) for member in ids]
    if (
        type(wanted) is not dict
        or not set(wanted) <= set(ids)
        or any(
            type(trials) is not list
            or len(set(trials)) != len(trials)
            or any(type(trial) is not int or not 0 <= trial < n for trial in trials)
            for trials in wanted.values()
        )
        or not any(wanted.values())
    ):
        raise ValueError("CLAIM_TRIALS_INVALID")
    return [(member, trial) for trial in range(n) for member in ids if trial in wanted.get(member, ())]


def build_report(work: dict, config, directory: Path, signer, node_id: str) -> dict:
    panel = config.settlement
    plan = planned_trials(work, panel.members)
    members = []
    for member in panel.members:
        rows = []
        # A retrial reports only its planned trials; a member with none keeps
        # an empty list because the backend requires every registered member.
        for trial in (t for m, t in plan if m == member.id):
            stem = f"{member.id}-{trial}"
            spec = json.loads((directory / "specs" / f"{stem}.json").read_text())
            result = json.loads((directory / "results" / f"{stem}.json").read_text())
            rows.append(episode_row(spec, result, signer))
        members.append({"member": member.id, "member_kind": member.kind, "trials": rows})
    task = work["task"]
    body = {
        "task_id": task["task_id"],
        "run_id": work["run_id"],
        "panel": config.settlement_panel,
        "task_source": task["source"],
        "package_digest": task["package_digest"],
        "roles": dict(panel.roles),
        "members": members,
        "config_version": config.version,
        "config_digest": config.digest,
        "node_id": node_id,
    }
    manifest = build_manifest(
        task_id=task["task_id"],
        run_id=work["run_id"],
        package_digest=task["package_digest"],
        config_version=config.version,
        config_digest=config.digest,
        panel=config.settlement_panel,
        settlement=True,
        node_id=node_id,
        key_id=signer.key_id,
        roles=panel.roles,
        members=members,
    )
    body["manifest"] = sign_manifest(manifest, signer.seed)
    return body


#: run_start payload keys the backend's same-conditions check reads
#: (``validate_model_conditions``); the rest (scene startup/binding, ~9 KB per
#: episode) would push a 40-episode result past the API body limit.
_START_KEYS = (
    "execution_contract",
    "execution_contract_digest",
    "runtime",
    "execution_runtime",
    "agent",
    "harness",
    "mode",
    "sensors",
    "max_turns",
    "max_steps",
    "wall_seconds",
)


def _start_event(event: dict) -> dict:
    payload = event.get("payload")
    if not isinstance(payload, dict):
        return event
    return {**event, "payload": {k: payload[k] for k in _START_KEYS if k in payload}}


def episode_facts(events: list) -> dict:
    """What the backend still needs from one episode's events (OPE-351)."""
    return {
        "first_event": _start_event(events[0]),
        "last_event": events[-1],
        "model_call_count": sum(e.get("type") == "model_call" for e in events),
        "observation_count": 1
        + sum(
            e.get("type") == "tool_result" and (e.get("payload") or {}).get("observation_sha256") is not None
            for e in events
        ),
    }


def small_result(report: dict) -> dict:
    """The full report with each trial's ``events`` swapped for ``facts``.

    Sent as ``result`` in report/commit so the backend never reads the archived
    report. Manifest, roles and every other field stay byte-for-byte the same;
    the signature binds ``events_digest``, not the events themselves.
    """

    def row(trial):
        out = {key: value for key, value in trial.items() if key != "events"}
        if trial.get("events"):
            out["facts"] = episode_facts(trial["events"])
        return out

    return {
        **report,
        "members": [{**member, "trials": [row(t) for t in member["trials"]]} for member in report["members"]],
    }
