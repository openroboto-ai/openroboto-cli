"""Scene A evidence keeps each model-input screenshot once, by reference (OPE-348).

Every scene ``model_call`` event snapshots the complete ``input_messages`` it
sent, so a 40-call episode used to re-store all earlier screenshots on every
call (quadratic: 61 MB per episode, past the 64 MiB output limit). The model
still receives the original messages; only the evidence copy changes:

    {"type": "base64", "media_type": M, "data": B64}
 -> {"type": "image_ref", "media_type": M, "sha256": H, "bytes": N}

``H``/``N`` are the sha256 and length of the decoded image bytes, which are
written once to ``<evidence>.images/<H>``. ``messages_sha256`` is unchanged: it
is still the canonical digest of the complete original messages, so
``restore_messages`` must reproduce them exactly before any check uses them.
Only canonical base64 is referenced; anything else stays inline.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import os
import pathlib
from typing import Any, Callable, Mapping

from agent_harness.events import EventStream

REF = "image_ref"
_SOURCE_KEYS = {"type", "media_type", "data"}
_REF_KEYS = {"type", "media_type", "sha256", "bytes"}


def images_directory(evidence_path: str | os.PathLike) -> pathlib.Path:
    return pathlib.Path(str(evidence_path) + ".images")


def _map_sources(messages: Any, change: Callable[[Mapping[str, Any]], Mapping[str, Any]]) -> Any:
    """Copy ``messages`` with every image block's ``source`` passed through ``change``."""
    if type(messages) is not list:
        return messages
    out = []
    for message in messages:
        content = message.get("content") if type(message) is dict else None
        if type(content) is not list:
            out.append(message)
            continue
        blocks = []
        for block in content:
            if type(block) is dict and block.get("type") == "image" and type(block.get("source")) is dict:
                block = {**block, "source": change(block["source"])}
            blocks.append(block)
        out.append({**message, "content": blocks})
    return out


class ImageStore:
    """``<evidence>.images/<sha256>``: decoded image bytes, each written once."""

    def __init__(self, directory: str | os.PathLike):
        self.directory = pathlib.Path(directory)
        self.known: set[str] = set()

    def ref(self, source: Mapping[str, Any]) -> Mapping[str, Any]:
        data = source.get("data")
        if set(source) != _SOURCE_KEYS or source.get("type") != "base64" or type(data) is not str:
            return source
        try:
            raw = base64.b64decode(data, validate=True)
        except (binascii.Error, ValueError):
            return source
        if base64.b64encode(raw).decode("ascii") != data:
            return source  # not canonical: a re-encode would not restore the same digest
        digest = hashlib.sha256(raw).hexdigest()
        if digest not in self.known:
            self.directory.mkdir(mode=0o755, exist_ok=True)
            path = self.directory / digest
            try:
                fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
            except FileExistsError:
                pass  # same content address; restore re-checks the digest
            else:
                with os.fdopen(fd, "wb") as handle:
                    handle.write(raw)
            self.known.add(digest)
        return {"type": REF, "media_type": source["media_type"], "sha256": digest, "bytes": len(raw)}

    def compact(self, messages: Any) -> Any:
        return _map_sources(messages, self.ref)


def directory_loader(directory: str | os.PathLike) -> Callable[[str], bytes]:
    root = pathlib.Path(directory)
    return lambda digest: (root / digest).read_bytes()


def restore_messages(messages: Any, load: Callable[[str], bytes]) -> Any:
    """Inverse of :meth:`ImageStore.compact`; every blob is checked against its ref.

    ``load(sha256) -> bytes``. A missing or altered blob raises ``ValueError``.
    """

    def restore(source: Mapping[str, Any]) -> Mapping[str, Any]:
        if source.get("type") != REF:
            return source
        digest = source.get("sha256")
        if set(source) != _REF_KEYS or type(digest) is not str or len(digest) != 64:
            raise ValueError("image_ref_invalid")
        try:
            raw = load(digest)
        except (OSError, KeyError) as exc:
            raise ValueError("image_ref_missing") from exc
        if type(raw) is not bytes or len(raw) != source["bytes"] or hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError("image_ref_mismatch")
        return {"type": "base64", "media_type": source["media_type"], "data": base64.b64encode(raw).decode("ascii")}

    return _map_sources(messages, restore)


class SceneEventStream(EventStream):
    """The harness event stream with model_call inputs stored by image reference."""

    def __init__(self, *args: Any, images: ImageStore, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self.images = images

    def append(self, kind, payload=None, *, correlation_id=None):
        if kind == "model_call" and payload and "input_messages" in payload:
            payload = {**payload, "input_messages": self.images.compact(payload["input_messages"])}
        return super().append(kind, payload, correlation_id=correlation_id)


__all__ = ["ImageStore", "SceneEventStream", "directory_loader", "images_directory", "restore_messages"]
