"""Download a submission straight from Hugging Face's CDN using the backend's file list.

This machine cannot reach ``huggingface.co`` and the mirror strips the
Authorization header, so gated repositories are not downloadable here. The
backend (``GET /api/v1/benchmark/task/{task_id}/files``) resolves every LFS
file to a short-lived CDN URL with its read-only token and inlines the small
non-LFS files. We never hold a Hugging Face token, and the CDN (``*.hf.co``)
is reachable directly. ``HTTPS_PROXY`` is honoured if a host needs one.

Every LFS file is checked against its sha256 before it is moved into place;
files already present with the right size and hash are kept, and a partial
``.part`` file resumes with a Range request.
"""

from __future__ import annotations

import base64
import fnmatch
import hashlib
import os
import pathlib
import urllib.error
import urllib.request
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor

from benchmark_worker.backend_client import BackendClient
from libero_eval.download import DownloadError, DownloadInterrupted

CHUNK = 8 * 1024 * 1024
TIMEOUT_S = 60
#: Parallel files. Each CDN stream measured 16-26 MB/s from the evaluation box.
WORKERS = 4


class CdnUnavailable(Exception):
    """This path cannot serve the model; the caller falls back to the mirror strategies."""


def download_from_cdn(
    client: BackendClient,
    task_id: str,
    model_dir: pathlib.Path,
    *,
    max_total_bytes: int | None,
    optional_patterns: list[str],
    should_stop: Callable[[], bool],
    log=print,
) -> None:
    listing = _listing(client, task_id)
    files = listing["files"]
    total = sum(int(f["size"]) for f in files)
    if max_total_bytes is not None and total > max_total_bytes:
        raise DownloadError(
            f"{listing['hf_repo_id']}@{listing['hf_commit']} is {total} bytes, over the {max_total_bytes} limit",
            permanent=True,
        )
    wanted = [f for f in files if not any(fnmatch.fnmatch(f["path"], p) for p in optional_patterns)]
    log(f"[download] cdn: {len(wanted)} files, {total} bytes for {listing['hf_repo_id']}@{listing['hf_commit'][:12]}")
    model_dir.mkdir(parents=True, exist_ok=True)

    def fetch(entry: dict) -> None:
        dest = _inside(model_dir, entry["path"])
        dest.parent.mkdir(parents=True, exist_ok=True)
        if entry.get("content_b64") is not None:
            dest.write_bytes(base64.b64decode(entry["content_b64"]))
            return
        if _complete(dest, entry):
            return
        try:
            _stream(entry["url"], dest, entry, should_stop)
        except urllib.error.HTTPError as exc:
            if exc.code not in (401, 403):
                raise
            # The signed URL expired; ask the backend for a fresh one.
            fresh = {f["path"]: f for f in _listing(client, task_id)["files"]}[entry["path"]]
            _stream(fresh["url"], dest, fresh, should_stop)

    with ThreadPoolExecutor(WORKERS) as pool:
        for future in [pool.submit(fetch, entry) for entry in wanted]:
            try:
                future.result()
            except (DownloadInterrupted, DownloadError):
                raise
            except Exception as exc:  # network / CDN trouble: let the caller fall back
                raise CdnUnavailable(f"{type(exc).__name__}: {exc}") from exc
    log(f"[download] cdn: {listing['hf_repo_id']}@{listing['hf_commit'][:12]} complete and verified")


def _listing(client: BackendClient, task_id: str) -> dict:
    try:
        listing = client.fetch_model_files(task_id)
    except Exception as exc:
        raise CdnUnavailable(f"no file list from the backend: {exc}") from exc
    if not isinstance(listing, dict) or not isinstance(listing.get("files"), list):
        raise CdnUnavailable("invalid file list from the backend")
    return listing


def _inside(root: pathlib.Path, relative: str) -> pathlib.Path:
    dest = (root / relative).resolve()
    if root.resolve() not in dest.parents:
        raise DownloadError(f"refusing to write outside the model directory: {relative!r}", permanent=True)
    return dest


def _complete(dest: pathlib.Path, entry: dict) -> bool:
    if not dest.is_file() or dest.stat().st_size != int(entry["size"]):
        return False
    return entry.get("sha256") is None or _sha256(dest) == entry["sha256"]


def _sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while block := fh.read(CHUNK):
            digest.update(block)
    return digest.hexdigest()


def _stream(url: str, dest: pathlib.Path, entry: dict, should_stop: Callable[[], bool]) -> None:
    part = dest.with_name(dest.name + ".part")
    size = int(entry["size"])
    have = part.stat().st_size if part.exists() else 0
    if have > size:
        part.unlink()
        have = 0
    if have < size:
        request = urllib.request.Request(url, headers={"Range": f"bytes={have}-"} if have else {})
        with urllib.request.urlopen(request, timeout=TIMEOUT_S) as response:
            if have and response.status != 206:
                have = 0  # the CDN ignored the range; start over
            with part.open("ab" if have else "wb") as out:
                while block := response.read(CHUNK):
                    if should_stop():
                        raise DownloadInterrupted(f"stopped while downloading {entry['path']}")
                    out.write(block)
    if part.stat().st_size != size:
        raise CdnUnavailable(f"{entry['path']}: got {part.stat().st_size} of {size} bytes")
    if entry.get("sha256") is not None and _sha256(part) != entry["sha256"]:
        part.unlink()
        raise CdnUnavailable(f"{entry['path']}: sha256 mismatch")
    os.replace(part, dest)
