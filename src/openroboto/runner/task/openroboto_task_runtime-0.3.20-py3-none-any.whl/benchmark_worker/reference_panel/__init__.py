"""出题赛事的参照组（panel）与区分度打分 —— OPE-115。

入口只有一个：:func:`benchmark_worker.reference_panel.evaluate.run_reference_panel`。
内部执行时它自己调 runner；将来改成「发 job 等矿工交回结果」只换实现，
算 D 的调用方不动。

分层：

``stats``     纯函数：Wilson 95% 区间、``D = max(0, L_a − U_b)``、五类分档；
``config``    panel / 成员 / 预登记 roles、锁定字段、公开名单、配置摘要；
``runners``   ``vla`` 与 ``agent`` 两种 kind，同一个 ``act(observation) -> action``；
``evaluate``  ``run_reference_panel(spec)``，串行执行、落 ``task_scores``、记账；
``recheck``   参照组变更后的全池重考与 ``rechecked_at`` 标记；
``evidence``  与 B 赛道 job 交付同形状的 events 链 / ``root``；
``store``     ``task_scores`` 与成本账本（JSONL）。
"""

from .config import (
    ConfigError,
    MemberSpec,
    PanelSpec,
    ReferencePanelConfig,
    RoleAssignment,
    parse_config,
    public_view,
    role_evidence,
    select_roles,
)
from .evaluate import (
    DEFAULT_OUTPUT_ROOT,
    PanelRunSpec,
    TaskRef,
    default_env_factory,
    load_result,
    run_reference_panel,
)
from .recheck import (
    DEFAULT_MIN_INTERVAL_DAYS,
    RecheckReport,
    RecheckState,
    bulk_recheck,
    recheck_state_path,
    should_recheck,
)
from .runners import (
    AgentRunner,
    EpisodeOutcome,
    EpisodeRequest,
    MemberRunner,
    RunnerUnavailable,
    VlaRunner,
    build_runner,
    run_act_loop,
)
from .stats import (
    CATEGORIES,
    DEFAULT_TRIALS,
    DISPOSITIONS,
    EASY_P,
    FRONTIER_P,
    MIN_TRIALS,
    WILSON_Z_95,
    Classification,
    Discrimination,
    bonferroni_z,
    classify_task,
    discrimination,
    group_variance,
    wilson_interval,
)
from .store import TaskScoreStore, UsageLedger

__all__ = [
    "CATEGORIES",
    "DEFAULT_MIN_INTERVAL_DAYS",
    "DEFAULT_OUTPUT_ROOT",
    "DEFAULT_TRIALS",
    "DISPOSITIONS",
    "EASY_P",
    "FRONTIER_P",
    "MIN_TRIALS",
    "WILSON_Z_95",
    "AgentRunner",
    "Classification",
    "ConfigError",
    "Discrimination",
    "EpisodeOutcome",
    "EpisodeRequest",
    "MemberRunner",
    "MemberSpec",
    "PanelRunSpec",
    "PanelSpec",
    "RecheckReport",
    "RecheckState",
    "ReferencePanelConfig",
    "RoleAssignment",
    "RunnerUnavailable",
    "TaskRef",
    "TaskScoreStore",
    "UsageLedger",
    "VlaRunner",
    "bonferroni_z",
    "build_runner",
    "bulk_recheck",
    "classify_task",
    "default_env_factory",
    "discrimination",
    "group_variance",
    "load_result",
    "parse_config",
    "public_view",
    "recheck_state_path",
    "role_evidence",
    "run_act_loop",
    "run_reference_panel",
    "select_roles",
    "should_recheck",
    "wilson_interval",
]
