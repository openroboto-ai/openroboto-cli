"""参照组内部跑的事件链。

结果形状要和 B 赛道 job 交付对齐（OPE-115「执行方式」）：``events`` 链、
``root``、摘要、``evidence_quality``——不要为「内部跑」发明一套更简单的
结构，否则将来改成「发 job 给矿工跑」时对不上。

哈希公式与 ``agent_evidence/events.py``（OPE-126）一致::

    hash = sha256(prev || canonical_json(event without "hash"))

因此同一份 JSONL 不需要任何 validator 状态就能从头复算；等 OPE-126 合并后，
同一条链可以直接被它的 ``verify_chain`` 读。

**这里不引用 ``eval_jobs`` 表。** 内部跑没有 job 行；``job_id`` 暂时用本次
``run_id`` 顶上，将来外层 dispatcher 发单时换成真实 job id 即可。
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import secrets
import time
from typing import Any, Iterator, Mapping

GENESIS = "0" * 64
EVENT_VERSION = 1
NONCE_HEX_CHARS = 32


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def sha256_hex(data: str | bytes) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def canonical_sha256(value: Any) -> str:
    return sha256_hex(canonical_json(value))


def _isoformat(value: _dt.datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=_dt.timezone.utc)
    return value.astimezone(_dt.timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


class EventChain:
    """一条 append-only 的哈希链。

    只保留参照组评测需要的字段：没有签名方（内部跑单方记录），但保留
    ``party`` / ``recorder`` 两列，将来发单时执行方与记录方可以分开。
    """

    def __init__(
        self,
        *,
        job_id: str,
        attempt_id: str | None = None,
        run_id: str | None = None,
        episode: int | None = None,
        party: str = "validator",
        recorder: str = "validator:reference-panel",
        clock=None,
        wall_clock=None,
        nonce_factory=None,
    ) -> None:
        if not isinstance(job_id, str) or not job_id.strip():
            raise ValueError("job_id must be a non-empty string")
        self.job_id = job_id
        self.attempt_id = attempt_id
        self.run_id = run_id
        #: OPE-126 的 ``verify_chain`` 要求事件带 ``episode``；参照组整次评测
        #: 没有单一 episode（每题多局），所以顶层链为 None，局链填局号。
        self.episode = episode
        self.party = party
        self.recorder = recorder
        self.job_nonce = (nonce_factory or (lambda: secrets.token_hex(16)))()
        if len(self.job_nonce) != NONCE_HEX_CHARS or not all(c in "0123456789abcdef" for c in self.job_nonce):
            raise ValueError(f"job_nonce must be {NONCE_HEX_CHARS} lowercase hex chars")
        self._clock = clock or time.monotonic
        self._wall_clock = wall_clock or _utcnow
        self._nonce_factory = nonce_factory or (lambda: secrets.token_hex(16))
        self._started = self._clock()
        self._prev = GENESIS
        self._events: list[dict[str, Any]] = []

    @property
    def events(self) -> tuple[dict[str, Any], ...]:
        return tuple(dict(event) for event in self._events)

    @property
    def root(self) -> str:
        return self._prev

    @property
    def event_count(self) -> int:
        return len(self._events)

    def __iter__(self) -> Iterator[dict[str, Any]]:
        return iter(self.events)

    def __len__(self) -> int:
        return len(self._events)

    def append(self, kind: str, payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        if not isinstance(kind, str) or not kind.strip():
            raise ValueError("event type must be a non-empty string")
        body = dict(payload or {})
        event: dict[str, Any] = {
            "v": EVENT_VERSION,
            "job_id": self.job_id,
            "attempt_id": self.attempt_id,
            "run_id": self.run_id,
            "episode": self.episode,
            "party": self.party,
            "recorder": self.recorder,
            "seq": len(self._events),
            "nonce": self._nonce_factory(),
            "job_nonce": self.job_nonce,
            "ts_monotonic": round(max(0.0, self._clock() - self._started), 6),
            "recorded_at": _isoformat(self._wall_clock()),
            "type": kind,
            "payload_sha256": canonical_sha256(body),
            "payload": body,
            "prev": self._prev,
        }
        event["hash"] = sha256_hex(self._prev + canonical_json(event))
        self._prev = event["hash"]
        self._events.append(event)
        return dict(event)

    def to_jsonl(self) -> str:
        """整条链的 JSONL 文本（每行一条事件，便于落盘与后续验链）。"""
        return "".join(canonical_json(event) + "\n" for event in self._events)


def verify_chain(events: list[Mapping[str, Any]] | tuple[Mapping[str, Any], ...]) -> dict[str, Any]:
    """从 genesis 重算整条链。返回 ``{"ok": bool, "errors": [...], "root": str}``。

    内部跑也要能自证：写坏一条事件、改一个 payload，重算就能发现。
    """
    errors: list[str] = []
    prev = GENESIS
    seen = 0
    for index, event in enumerate(events):
        if not isinstance(event, Mapping):
            errors.append(f"event {index}: not an object")
            continue
        body = dict(event)
        claimed = body.pop("hash", None)
        if body.get("seq") != index:
            errors.append(f"event {index}: seq is {body.get('seq')!r}")
        if body.get("prev") != prev:
            errors.append(f"event {index}: prev does not chain")
        if body.get("payload_sha256") != canonical_sha256(body.get("payload") or {}):
            errors.append(f"event {index}: payload_sha256 mismatch")
        recomputed = sha256_hex(prev + canonical_json(body))
        if claimed != recomputed:
            errors.append(f"event {index}: hash mismatch")
        prev = str(claimed or prev)
        seen += 1
    return {"ok": not errors, "errors": errors, "root": prev, "events": seen}


def _utcnow() -> _dt.datetime:
    return _dt.datetime.now(_dt.timezone.utc)
