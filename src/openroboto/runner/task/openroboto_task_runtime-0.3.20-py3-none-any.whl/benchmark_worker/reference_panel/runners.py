"""参照组成员：两种 kind，同一个 ``act(observation) -> action``。

``vla``   一次前向出关节动作（走 policy client），成本 ~一次推理；
``agent`` LLM + harness + 工具，工具再出动作，成本 ~几十次模型调用。

两者对上层完全一样：D 只看每局的成败，不看动作是谁产生的。所以
:class:`MemberRunner` 只规定两件事——``act`` 与 ``run_episode``；后者默认
用同一个 :func:`run_act_loop`，只有 agent 的生产路径会换成整集执行器
（``agent_harness.run(spec)``），因为 harness 的公开契约就是整集执行。

本模块不在顶层 import ``agent_harness`` / ``task_source``：它们在
``feat/agent-robotics`` 上，尚未合进 main。用到时延迟导入；缺失时抛
:class:`RunnerUnavailable`，错误信息直接指向 OPE-123。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Protocol, runtime_checkable

from .config import MemberSpec
from .evidence import EventChain, canonical_sha256


class RunnerUnavailable(RuntimeError):
    """本机/本分支没有执行这个成员所需的运行时。属于基础设施问题，不是结论。"""


@dataclass(frozen=True)
class EpisodeRequest:
    """一局评测需要的一切：谁、哪道题的哪个实例、第几局。"""

    run_id: str
    panel: str
    member: MemberSpec
    task_id: str
    source: str
    instance: int
    trial: int
    seed: int
    instruction: str = ""
    max_steps: int = 200
    evidence_path: str | None = None
    #: A 收分契约：题包摘要、参照组配置版本/摘要、这一 panel 是否结算。
    #: `package_digest` 必须与 `version_digest` 相同 —— 它们是同一份题包全部
    #: 文件的 canonical 摘要，不允许一个声明、另一个执行。
    package_digest: str = ""
    config_version: str = ""
    config_digest: str = ""
    settlement: bool = False
    #: 197 冻结题包的内容摘要与合法定位。A harness 必须拿到它并让执行器
    #: 真加载同一份内容；不能用 `package_digest` 声明代替。
    version_digest: str = ""
    package_root: str | None = None
    package_repo: str | None = None
    package_commit: str | None = None
    #: 权限模式（agent_harness 的 frozen spec 字段）；A 内部评测显式声明。
    permission_mode: str = "privileged"
    execution_profile: Mapping[str, Any] | None = None
    execution_contract: Mapping[str, Any] | None = None
    extra: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "panel": self.panel,
            "member": self.member.id,
            "kind": self.member.kind,
            "source": self.source,
            "task_id": self.task_id,
            "instance": self.instance,
            "trial": self.trial,
            "seed": self.seed,
            "max_steps": self.max_steps,
            "package_digest": self.package_digest,
            "config_version": self.config_version,
            "config_digest": self.config_digest,
            "settlement": self.settlement,
        }


@dataclass(frozen=True)
class EpisodeOutcome:
    """一局的结果。字段与 B 赛道 job 交付的 episode 对齐。"""

    success: bool
    steps: int
    model_calls: int
    wall_s: float
    events: tuple[dict[str, Any], ...] = ()
    root: str = ""
    summary: Mapping[str, Any] = field(default_factory=dict)
    evidence_quality: Mapping[str, Any] = field(default_factory=dict)
    error: str = ""

    @property
    def scored(self) -> bool:
        """这一局能不能计入样本。基础设施错误不计入（不是模型的成绩）。"""
        return not self.error

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "steps": self.steps,
            "model_calls": self.model_calls,
            "wall_s": round(self.wall_s, 3),
            "events": len(self.events),
            "root": self.root,
            "summary": dict(self.summary),
            "evidence_quality": dict(self.evidence_quality),
            "error": self.error,
        }


@runtime_checkable
class CheckerLike(Protocol):
    def evaluate(self, state: Mapping[str, Any]): ...


@runtime_checkable
class EnvLike(Protocol):
    def reset(self) -> Mapping[str, Any]: ...

    def step(self, action: Any) -> Mapping[str, Any]: ...

    def state(self) -> Mapping[str, Any]: ...

    def close(self) -> None: ...


def _result_passed(result: Any) -> tuple[bool, Mapping[str, Any]]:
    """``CheckResult`` / ``{"passed": ...}`` / 裸 bool 都接受，别让题源形状泄漏进来。"""
    if isinstance(result, bool):
        return result, {}
    passed = getattr(result, "passed", None)
    if passed is None and isinstance(result, Mapping):
        passed = result.get("passed")
    detail = getattr(result, "detail", None)
    if detail is None and isinstance(result, Mapping):
        detail = result.get("detail")
    return bool(passed), dict(detail or {})


class MemberRunner:
    """所有参照组成员的公共实现。"""

    kind = ""

    def __init__(self, member: MemberSpec):
        self.member = member
        self.model_calls = 0

    def act(self, observation: Mapping[str, Any]) -> Any:
        raise NotImplementedError

    def run_episode(
        self, request: EpisodeRequest, *, env: EnvLike | None = None, checker: CheckerLike | None = None
    ) -> EpisodeOutcome:
        if env is None or checker is None:
            raise RunnerUnavailable(
                f"{type(self).__name__} needs env/checker (or an episode runner) to execute a trial"
            )
        return run_act_loop(self, request, env=env, checker=checker)

    def close(self) -> None:
        return None


def run_act_loop(
    runner: MemberRunner,
    request: EpisodeRequest,
    *,
    env: EnvLike,
    checker: CheckerLike,
    clock: Callable[[], float] = time.monotonic,
) -> EpisodeOutcome:
    """两种 kind 共用的整集循环：``act`` → ``env.step`` → checker。

    中途成功即停（和 harness 的早停一致）；跑满 ``max_steps`` 再判一次。
    基础设施异常退回 ``EpisodeOutcome.error``，这一局不计入样本。
    """
    started = clock()
    chain = EventChain(
        job_id=request.run_id,
        attempt_id=f"{request.panel}:{request.member.id}:{request.task_id}:{request.instance}:{request.trial}",
        run_id=request.run_id,
        episode=request.trial,
        party=f"runner:{request.member.kind}",
    )
    chain.append("episode_start", request.to_dict())
    steps = 0
    success = False
    detail: Mapping[str, Any] = {}
    error = ""
    try:
        observation = env.reset()
        chain.append("reset", {"state_sha256": canonical_sha256(observation)})
        while steps < request.max_steps:
            action = runner.act(observation)
            observation = env.step(action)
            steps += 1
            state = observation if isinstance(observation, Mapping) else env.state()
            passed, detail = _result_passed(checker.evaluate(state))
            chain.append(
                "step",
                {
                    "step": steps,
                    "action_sha256": canonical_sha256(action),
                    "state_sha256": canonical_sha256(observation),
                    "passed": passed,
                },
            )
            if passed:
                success = True
                break
    except RunnerUnavailable:
        raise
    except Exception as exc:  # noqa: BLE001 - infra failure is recorded, not scored
        error = f"{type(exc).__name__}: {exc}"
        chain.append("error", {"error": error, "step": steps})
    finally:
        try:
            env.close()
        except Exception:  # noqa: BLE001 - closing must not mask the outcome
            pass

    wall_s = clock() - started
    chain.append(
        "episode_end",
        {"success": success, "steps": steps, "detail": dict(detail), "error": error, "wall_s": round(wall_s, 3)},
    )
    events = chain.events
    quality = evidence_quality(events, episode_count=1, failed=1 if error else 0)
    return EpisodeOutcome(
        success=success,
        steps=steps,
        model_calls=runner.model_calls,
        wall_s=wall_s,
        events=events,
        root=chain.root,
        summary={
            "success": success,
            "steps": steps,
            "detail": dict(detail),
            "max_steps": request.max_steps,
            "source": request.source,
            "task_id": request.task_id,
            "instance": request.instance,
            "trial": request.trial,
        },
        evidence_quality=quality,
        error=error,
    )


def _call_policy(policy: Any, observation: Mapping[str, Any]) -> Any:
    """policy 可以是 ``act(obs)`` 对象，也可以直接是 callable。"""
    act = getattr(policy, "act", None)
    if callable(act):
        return act(observation)
    if callable(policy):
        return policy(observation)
    raise RunnerUnavailable(
        f"vla member {getattr(policy, 'id', '?')!r}: policy client must be callable or expose act(observation)"
    )


class VlaRunner(MemberRunner):
    """``vla``：一次前向出动作。policy client 由调用方注入（首版 vla panel 不启用）。"""

    kind = "vla"

    def __init__(self, member: MemberSpec, policy: Any):
        super().__init__(member)
        if policy is None:
            raise RunnerUnavailable(
                f"vla member {member.id!r}: a policy client is required "
                "(the vla panel is reserved for a future release; see OPE-115 comments)"
            )
        self.policy = policy

    def act(self, observation: Mapping[str, Any]) -> Any:
        self.model_calls += 1
        return _call_policy(self.policy, observation)


class AgentRunner(MemberRunner):
    """``agent``：LLM + harness + 工具。

    两种执行方式，``act`` 接口对两者都在：

    * ``run_episode`` 优先用注入的 ``episode_runner``（生产：包装
      ``agent_harness.run(spec)``），这是 OPE-115 指定的执行方式；
    * 没有整集执行器时，用与 vla 相同的 ``run_act_loop``，前提是注入了
      ``decide``（一次模型决策 → 动作）。测试和单步调试走这条。

    默认的 ``episode_runner`` 延迟导入 ``agent_harness``；本分支还没有它时
    抛 :class:`RunnerUnavailable`，错误信息指向 OPE-123。
    """

    kind = "agent"

    def __init__(
        self,
        member: MemberSpec,
        *,
        decide: Callable[[Mapping[str, Any]], Any] | None = None,
        episode_runner: Callable[[EpisodeRequest], Any] | None = None,
    ):
        super().__init__(member)
        self._decide = decide
        self._episode_runner = episode_runner

    def act(self, observation: Mapping[str, Any]) -> Any:
        if self._decide is None:
            raise RunnerUnavailable(
                f"agent member {self.member.id!r}: single-step act() needs a 'decide' callback; "
                "the harness contract is whole-episode run(spec) (OPE-123)"
            )
        self.model_calls += 1
        return self._decide(observation)

    def run_episode(
        self, request: EpisodeRequest, *, env: EnvLike | None = None, checker: CheckerLike | None = None
    ) -> EpisodeOutcome:
        if self._episode_runner is not None:
            return _outcome_from_harness(self, request, self._episode_runner(request))
        if env is not None and checker is not None and self._decide is not None:
            return run_act_loop(self, request, env=env, checker=checker)
        return _outcome_from_harness(self, request, run_agent_harness(request, self.member))


def _outcome_from_harness(runner: AgentRunner, request: EpisodeRequest, result: Any) -> EpisodeOutcome:
    """``agent_harness.RunResult`` → 参照组的 EpisodeOutcome。

    ``RunResult`` 已经带了 events 链、root、摘要；这里只补记账字段
    （``model_calls`` 从 ``model_call`` 事件数出来）。
    """
    if isinstance(result, EpisodeOutcome):
        # 注入的 episode_runner 已经交了参照组的最终形状：不要二次包装。
        # 二次包装会丢掉 ``error``（EpisodeOutcome 没有 ``status``），把基础设施
        # 错误当成模型失败计进分母。
        return result
    if isinstance(result, Mapping):
        events = tuple(result.get("events") or ())
        success = bool(result.get("success"))
        steps = int(result.get("steps") or 0)
        root = str(result.get("root") or "")
        summary = result
        error = str(result.get("error") or "")
        wall_s = float(result.get("wall_s") or 0.0)
        model_calls = sum(1 for event in events if event.get("type") == "model_call")
    else:
        events = tuple(getattr(result, "events", ()) or ())
        success = bool(getattr(result, "success", False))
        steps = int(getattr(result, "steps", 0) or 0)
        root = str(getattr(result, "root", "") or "")
        to_dict = getattr(result, "to_dict", None)
        summary = to_dict() if callable(to_dict) else {}
        status = str(getattr(result, "status", "ok") or "ok")
        error = "" if status == "ok" else str(getattr(result, "reason", status))
        wall_s = float(summary.get("wall_s") or 0.0)
        model_calls = sum(1 for event in events if event.get("type") == "model_call")
    if request.package_digest:
        # A 的终态与 harness 的 run_end 必须逐字一致；以事件里的 error 为准，
        # 不用 reason/status 再翻译一次（两者可能不同）。
        end = next(
            (event for event in reversed(events) if event.get("type") in ("episode_end", "run_end")),
            None,
        )
        payload = end.get("payload") if isinstance(end, Mapping) else None
        if isinstance(payload, Mapping):
            error = str(payload.get("error") or "")
    quality = evidence_quality(events, episode_count=1, failed=1 if error else 0)
    return EpisodeOutcome(
        success=success,
        steps=steps,
        model_calls=model_calls,
        wall_s=wall_s,
        events=events,
        root=root,
        summary=dict(summary),
        evidence_quality=quality,
        error=error,
    )


def run_agent_harness(
    request: EpisodeRequest,
    member: MemberSpec,
    *,
    chat_fn: Any = None,
    runtime_override: str | None = None,
) -> Any:
    """生产路径：``agent_harness.run(spec)``。延迟导入，缺依赖时给明确出路。

    A 必须从已验证上下文提供 `version_digest` 和合法包定位（本地已验证包
    用 `package_root`，否则 `package_repo` + `package_commit`）；缺失直接
    拒绝，不默认走本地旁路。`package_digest` 与 `version_digest` 必须是
    同一份题包摘要；不一致时在加载包 / 调用模型之前拒绝。
    `chat_fn` / `runtime_override` 只给 smoke 注入模型 / 仿真边界，入口与
    结果转换仍走真实实现。
    """
    try:
        import agent_harness  # noqa: F401 - imported lazily, see module docstring
        from agent_harness.manifest import agent_binding
    except ImportError as e:  # pragma: no cover - depends on the branch layout
        raise RunnerUnavailable(
            "agent execution needs agent_harness (OPE-123), which is not in this checkout; "
            "either merge feat/agent-robotics or inject an episode runner"
        ) from e

    if not request.version_digest:
        raise RunnerUnavailable(
            "A reference-panel harness needs the frozen task.version_digest; "
            "put it in TaskRef.metadata and do not fall back to a same-named package"
        )
    if not request.package_digest:
        raise RunnerUnavailable(
            "A reference-panel harness needs package_digest equal to version_digest; "
            "the report cannot declare a different package than the one loaded"
        )
    if request.package_digest != request.version_digest:
        raise RunnerUnavailable(
            "A reference-panel harness refuses to run: package_digest "
            f"{request.package_digest!r} != version_digest "
            f"{request.version_digest!r}; they must identify the same package"
        )
    if not request.package_root and not (request.package_repo and request.package_commit):
        raise RunnerUnavailable(
            "A reference-panel harness needs a frozen package locator: "
            "package_root (verified local package) or package_repo + package_commit"
        )
    local_mode = bool(request.package_root)

    task: dict[str, Any] = {
        "source": request.source,
        "task_id": request.task_id,
        "instance": request.instance,
        "version_digest": request.version_digest,
    }
    if request.execution_profile is not None:
        task["execution_profile"] = dict(request.execution_profile)
    if request.package_root:
        task["package_root"] = request.package_root
    else:
        task["package_repo"] = request.package_repo
        task["package_commit"] = request.package_commit

    binding = agent_binding()
    spec = {
        "run_id": request.run_id,
        "attempt_id": f"{request.panel}:{member.id}:{request.trial}",
        "episode": request.trial,
        "task": task,
        "model": member.model_config(),
        "agent": binding,
        "harness": {"name": member.harness},
        "permissions": {"mode": request.permission_mode},
        "evidence": {"path": request.evidence_path} if request.evidence_path else {},
        "instruction": request.instruction or None,
        "panel_binding": {
            "run_id": request.run_id,
            "panel": request.panel,
            "member": member.id,
            "kind": member.kind,
            "trial": request.trial,
            "package_digest": request.version_digest,
            "version_digest": request.version_digest,
            "config_version": request.config_version,
            "config_digest": request.config_digest,
            "settlement": request.settlement,
        },
    }
    if request.execution_contract is not None:
        from task_source.execution_contract import execution_contract_digest, parse_execution_contract

        try:
            contract = parse_execution_contract(request.execution_contract)
        except ValueError as exc:
            raise RunnerUnavailable(str(exc)) from exc
        if contract["agent"] != binding or contract["harness"]["name"] != member.harness:
            raise RunnerUnavailable("execution_contract does not match the loaded harness identity")
        if request.permission_mode != contract["permissions"]["mode"]:
            raise RunnerUnavailable("execution_contract permission mode differs from the request")
        spec["permissions"] = dict(contract["permissions"])
        spec["budget"] = dict(contract["budget"])
        spec["timing"] = dict(contract["timing"])
        spec["panel_binding"]["execution_contract"] = contract
        spec["panel_binding"]["execution_contract_digest"] = execution_contract_digest(contract)
    return agent_harness.run(
        spec,
        chat_fn=chat_fn,
        runtime_override=runtime_override,
        local_mode=local_mode,
    )


def build_runner(
    member: MemberSpec,
    *,
    policy: Any = None,
    decide: Callable[[Mapping[str, Any]], Any] | None = None,
    episode_runner: Callable[[EpisodeRequest], Any] | None = None,
) -> MemberRunner:
    """按成员 kind 建 runner。未知 kind 在配置层已经被拒绝。"""
    if member.kind == "vla":
        return VlaRunner(member, policy)
    if member.kind == "agent":
        return AgentRunner(member, decide=decide, episode_runner=episode_runner)
    raise RunnerUnavailable(f"member {member.id!r}: unsupported kind {member.kind!r}")


def evidence_quality(
    events: tuple[dict[str, Any], ...] | list[dict[str, Any]], *, episode_count: int, failed: int = 0
) -> dict[str, Any]:
    """证据质量（0..1），与 B 赛道结算用的 ``evidence_quality`` 同一个语义。

    内部跑也保留这个字段：将来发 job 时它直接参与
    ``delivered × quoted × evidence_quality``，不能等到那时才补。
    """
    total = len(events)
    has_start = any(event.get("type") in ("episode_start", "run_start") for event in events)
    has_end = any(event.get("type") in ("episode_end", "run_end", "run_finish") for event in events)
    hashed = sum(1 for event in events if event.get("hash"))
    if episode_count <= 0:
        score = 0.0
    elif total == 0:
        score = 0.0
    else:
        score = min(1.0, (0.4 if has_start else 0.0) + (0.4 if has_end else 0.0) + 0.2 * (hashed / total))
        if failed:
            score *= max(0.0, 1.0 - failed / max(episode_count, 1))
    return {
        "score": round(score, 6),
        "events": total,
        "hashed_events": hashed,
        "has_start": has_start,
        "has_end": has_end,
        "episodes": episode_count,
        "failed_episodes": failed,
    }
