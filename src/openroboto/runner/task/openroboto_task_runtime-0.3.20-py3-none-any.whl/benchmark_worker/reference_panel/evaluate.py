"""``run_reference_panel(spec)`` —— 参照组评测的唯一执行入口。

现在内部执行：每个 panel 成员 × 每题 ``trials`` 局，串行入队。将来改成
「发 job 给矿工跑」时**只换这个函数的实现**（或它注入的 runner / episode
runner），算 D 的调用方不动；结果形状已经按 B 赛道 job 交付对齐：events 链、
``root``、摘要、``evidence_quality``。

不引用 ``eval_jobs`` 表：内部跑没有 job 行。将来发单时由外层 dispatcher
建 job，再把结果喂给同一套 :func:`assemble_result`。
"""

from __future__ import annotations

import json
import pathlib
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from .config import MemberSpec, ReferencePanelConfig
from .evidence import EventChain, verify_chain
from .runners import (
    EpisodeOutcome,
    EpisodeRequest,
    MemberRunner,
    RunnerUnavailable,
    build_runner,
    evidence_quality,
)
from .stats import DEFAULT_TRIALS, discrimination, group_variance, MIN_TRIALS
from .stats import classify_task
from .store import TaskScoreStore, UsageLedger, now_iso

VALIDATOR_ROOT = pathlib.Path(__file__).resolve().parents[2]
DEFAULT_OUTPUT_ROOT = VALIDATOR_ROOT / "reference_panel_runs"


@dataclass(frozen=True)
class TaskRef:
    """一道已入库的题。``instances`` 为真机/多实例题源保留。"""

    task_id: str
    source: str
    instruction: str = ""
    instances: tuple[int, ...] = (0,)
    package_dir: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "source": self.source,
            "instruction": self.instruction,
            "instances": list(self.instances),
            "package_dir": self.package_dir,
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True)
class PanelRunSpec:
    """一次参照组评测的输入。

    ``runner_factory`` / ``env_factory`` 都是注入点，和 ``agent_harness.run``
    的 ``runtime`` / ``chat_fn`` 是同一个思路：生产用默认实现，测试和将来的
    job 执行层换掉它们，而算 D 的代码一行不改。
    """

    run_id: str
    task: TaskRef
    config: ReferencePanelConfig
    trials: int = DEFAULT_TRIALS
    max_steps: int = 200
    seed: int = 0
    #: 成员跨题总分。缺省时退回配置里的 ``baseline_score``（那是预登记依据）。
    member_totals: Mapping[str, float] | None = None
    output_dir: str | pathlib.Path | None = None
    #: 哪些 panel 要跑；缺省 = 全部。结算 panel 必须在内。
    panels: tuple[str, ...] | None = None
    #: 重考标记（由 recheck 层传入），随结果一起落盘。
    rechecked_at: str | None = None
    config_digest: str | None = None
    #: A 收分契约：这道题准入时的题包摘要（= 后端 `tasks.package_digest`）。
    #: 没给时退回 `task.metadata["package_digest"]`。
    package_digest: str = ""
    #: 注入点（见类文档）。
    runner_factory: Callable[[MemberSpec], MemberRunner] | None = None
    env_factory: Callable[[EpisodeRequest], tuple[Any, Any]] | None = None
    policy_factory: Callable[[MemberSpec], Any] | None = None
    decide_factory: Callable[[MemberSpec], Callable[[Mapping[str, Any]], Any]] | None = None
    episode_runner_factory: Callable[[MemberSpec], Callable[[EpisodeRequest], Any]] | None = None

    @property
    def effective_max_steps(self) -> int:
        contract = self.config.execution_contract
        return int(contract["budget"]["max_steps"]) if contract is not None else self.max_steps

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "task": self.task.to_dict(),
            "trials": self.trials,
            "max_steps": self.effective_max_steps,
            "seed": self.seed,
            "panels": list(self.panels) if self.panels else None,
            "rechecked_at": self.rechecked_at,
            "config_version": self.config.version,
            "config_digest": self.config_digest or self.config.digest,
            "package_digest": self.package_digest or str(self.task.metadata.get("package_digest") or ""),
        }


def _resolve_panels(spec: PanelRunSpec) -> list[str]:
    names = list(spec.panels) if spec.panels else list(spec.config.panels)
    for name in names:
        if name not in spec.config.panels:
            raise ValueError(f"unknown panel {name!r}; configured: {sorted(spec.config.panels)}")
    if spec.config.settlement_panel not in names:
        raise ValueError(
            f"settlement panel {spec.config.settlement_panel!r} must be evaluated; "
            "diagnostic panels never substitute for it"
        )
    return names


def _ability(spec: PanelRunSpec) -> dict[str, float]:
    totals: dict[str, float] = {}
    for panel in spec.config.panels.values():
        for member in panel.members:
            if member.baseline_score is not None:
                totals[member.id] = float(member.baseline_score)
    if spec.member_totals:
        totals.update({key: float(value) for key, value in spec.member_totals.items()})
    return totals


def _discrimination_summary(
    best_successes: int, best_trials: int, worst_successes: int, worst_trials: int
) -> dict[str, Any]:
    """Keep an unmeasured panel distinct from a measured zero discrimination.

    The statistical function still requires positive denominators. Errors can
    consume every scheduled trial, so aggregation must retain that evidence and
    finish as pending recheck rather than inventing trials or a D=0 result.
    """
    if best_trials == 0 or worst_trials == 0:
        for successes, trials in ((best_successes, best_trials), (worst_successes, worst_trials)):
            if trials < 0 or not 0 <= successes <= trials:
                raise ValueError("successes must satisfy 0 <= successes <= trials")
        return {
            "d": None,
            "lower_best": None,
            "upper_worst": None,
            "settleable": False,
            "reason": "insufficient_trials",
            "needs_recheck": True,
            "best_rate": round(best_successes / best_trials, 6) if best_trials else None,
            "worst_rate": round(worst_successes / worst_trials, 6) if worst_trials else None,
            "z": None,
            "pairs": 1,
        }
    return discrimination(best_successes, best_trials, worst_successes, worst_trials, pairs=1).to_dict()


def run_reference_panel(
    spec: PanelRunSpec,
    *,
    runner_factory: Callable[[MemberSpec], MemberRunner] | None = None,
    env_factory: Callable[[EpisodeRequest], tuple[Any, Any]] | None = None,
    clock: Callable[[], float] = time.monotonic,
) -> dict[str, Any]:
    """跑完一组 panel，落 ``task_scores`` 与成本账，返回完整结果。

    串行执行：panel → member → trial。顺序固定让同一份输入的产出可复现，
    也避免 agent 几十次模型调用彼此抢 GPU/网关。
    """
    if spec.trials < 1:
        raise ValueError("trials must be >= 1")
    run_started = clock()
    config_digest = spec.config_digest or spec.config.digest
    output_dir = pathlib.Path(spec.output_dir or DEFAULT_OUTPUT_ROOT / spec.run_id).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    # agent harness 的 evidence_path 直接落这里，先把目录建好。
    (output_dir / "episodes").mkdir(exist_ok=True)

    score_store = TaskScoreStore(output_dir / "task_scores.jsonl")
    usage_ledger = UsageLedger(output_dir / "usage.jsonl")

    chain = EventChain(job_id=spec.run_id, run_id=spec.run_id, clock=clock)
    chain.append(
        "run_start",
        {
            "mode": "internal",
            "task": spec.task.to_dict(),
            "trials": spec.trials,
            "max_steps": spec.effective_max_steps,
            "seed": spec.seed,
            "config_version": spec.config.version,
            "config_digest": config_digest,
            "settlement_panel": spec.config.settlement_panel,
            "panels": _resolve_panels(spec),
            "rechecked_at": spec.rechecked_at,
        },
    )

    factory = runner_factory or spec.runner_factory or _default_runner_factory(spec)
    env_builder = env_factory or spec.env_factory

    panel_results: dict[str, dict[str, Any]] = {}
    member_scores: dict[str, dict[str, tuple[int, int]]] = {}
    usage_rows: list[dict[str, Any]] = []

    for panel_name in _resolve_panels(spec):
        panel = spec.config.panels[panel_name]
        chain.append("panel_start", {"panel": panel_name, "roles": dict(panel.roles), "members": len(panel.members)})
        scores: dict[str, tuple[int, int]] = {}
        members_out: dict[str, dict[str, Any]] = {}

        for member in panel.members:
            runner = factory(member)
            successes = scored = failed = 0
            steps_total = calls_total = 0
            wall_total = 0.0
            member_started = clock()
            try:
                for trial in range(spec.trials):
                    request = EpisodeRequest(
                        run_id=spec.run_id,
                        panel=panel_name,
                        member=member,
                        task_id=spec.task.task_id,
                        source=spec.task.source,
                        instance=spec.task.instances[trial % len(spec.task.instances)],
                        trial=trial,
                        seed=spec.seed + trial,
                        instruction=spec.task.instruction,
                        max_steps=spec.effective_max_steps,
                        execution_profile=spec.task.metadata.get("execution_profile"),
                        execution_contract=spec.config.execution_contract,
                        evidence_path=str(output_dir / "episodes" / f"{panel_name}-{member.id}-{trial}.jsonl"),
                        package_digest=spec.package_digest or str(spec.task.metadata.get("package_digest") or ""),
                        config_version=spec.config.version,
                        config_digest=config_digest,
                        settlement=(panel_name == spec.config.settlement_panel),
                        version_digest=str(spec.task.metadata.get("version_digest") or ""),
                        package_root=spec.task.package_dir or spec.task.metadata.get("package_root"),
                        package_repo=str(spec.task.metadata.get("package_repo") or "") or None,
                        package_commit=str(spec.task.metadata.get("package_commit") or "") or None,
                        permission_mode=str(spec.task.metadata.get("permission_mode") or "privileged"),
                    )
                    env, checker = env_builder(request) if env_builder else (None, None)
                    outcome = runner.run_episode(request, env=env, checker=checker)
                    if not isinstance(outcome, EpisodeOutcome):
                        outcome = _coerce_outcome(outcome)
                    steps_total += outcome.steps
                    calls_total += outcome.model_calls
                    wall_total += outcome.wall_s
                    if outcome.scored:
                        scored += 1
                        successes += 1 if outcome.success else 0
                    else:
                        failed += 1
                    score_store.record_trial(
                        run_id=spec.run_id,
                        panel=panel_name,
                        member=member.id,
                        member_kind=member.kind,
                        task_id=spec.task.task_id,
                        task_source=spec.task.source,
                        trial=trial,
                        instance=request.instance,
                        success=outcome.success,
                        steps=outcome.steps,
                        model_calls=outcome.model_calls,
                        wall_s=outcome.wall_s,
                        config_version=spec.config.version,
                        config_digest=config_digest,
                        child_root=outcome.root,
                        error=outcome.error,
                    )
                    chain.append(
                        "episode",
                        {
                            "panel": panel_name,
                            "member": member.id,
                            "trial": trial,
                            "instance": request.instance,
                            "success": outcome.success,
                            "scored": outcome.scored,
                            "steps": outcome.steps,
                            "model_calls": outcome.model_calls,
                            "wall_s": round(outcome.wall_s, 3),
                            "child_root": outcome.root,
                            "evidence_quality": dict(outcome.evidence_quality),
                            "error": outcome.error,
                        },
                    )
            finally:
                runner.close()

            scores[member.id] = (successes, scored)
            if member.id == panel.roles["best"]:
                role = "best"
            elif member.id == panel.roles["worst"]:
                role = "worst"
            else:
                role = "auxiliary"
            members_out[member.id] = {
                "id": member.id,
                "kind": member.kind,
                "role": role,
                "trials": spec.trials,
                "scored_trials": scored,
                "successes": successes,
                "failed_trials": failed,
                "rate": round(successes / scored, 6) if scored else None,
                "steps": steps_total,
                "model_calls": calls_total,
                "wall_s": round(wall_total, 3),
                "member_wall_s": round(clock() - member_started, 3),
                "baseline_score": member.baseline_score,
                "binding": member.binding(),
            }
            score_store.record_summary(
                run_id=spec.run_id,
                panel=panel_name,
                member=member.id,
                member_kind=member.kind,
                task_id=spec.task.task_id,
                task_source=spec.task.source,
                trials=spec.trials,
                scored_trials=scored,
                successes=successes,
                failed_trials=failed,
                steps=steps_total,
                model_calls=calls_total,
                wall_s=wall_total,
                config_version=spec.config.version,
                config_digest=config_digest,
            )
            usage_rows.append({
                "panel": panel_name,
                "member": member.id,
                "member_kind": member.kind,
                "trials": spec.trials,
                "scored_trials": scored,
                "steps": steps_total,
                "model_calls": calls_total,
                "wall_s": wall_total,
            })

        member_scores[panel_name] = scores
        panel_results[panel_name] = {"members": members_out}

    settlement_name = spec.config.settlement_panel
    ability = _ability(spec)

    # --- 每个 panel 单独算 D，绝不跨 panel 做 best/worst -------------------
    for panel_name, scores in member_scores.items():
        panel = spec.config.panels[panel_name]
        best_successes, best_trials = scores[panel.roles["best"]]
        worst_successes, worst_trials = scores[panel.roles["worst"]]
        disc = _discrimination_summary(best_successes, best_trials, worst_successes, worst_trials)
        rates = [scores[member.id][0] / scores[member.id][1] for member in panel.members if scores[member.id][1]]
        trials = [scores[member.id][1] for member in panel.members if scores[member.id][1]]
        variance = group_variance(rates, trials)
        panel_results[panel_name].update({
            "settlement": panel_name == settlement_name,
            # 诊断 panel 的 D 也照算，但永远不会进 classification / 分钱。
            "d": disc,
            "variance": {key: round(value, 6) for key, value in variance.items()},
            "variance_enabled": len(panel.members) >= 3,
        })
        chain.append(
            "panel_summary",
            {
                "panel": panel_name,
                "settlement": panel_name == settlement_name,
                "d": disc,
                "variance": {key: round(value, 6) for key, value in variance.items()},
            },
        )

    # --- 五类分档只用 settlement_panel ------------------------------------
    settlement = spec.config.settlement
    settlement_scores = member_scores[settlement_name]
    classification = classify_task(
        settlement_scores,
        best=settlement.roles["best"],
        worst=settlement.roles["worst"],
        ability=ability or None,
        min_trials=MIN_TRIALS,
    )
    settlement_d = panel_results[settlement_name]["d"]

    # 「结算」只指 D 进收益（in_pool）。退役/前沿/可疑/待补测都记账，但不发钱。
    usage_settled = classification.disposition == "in_pool"
    for row in usage_rows:
        usage_ledger.record(
            run_id=spec.run_id,
            panel=row["panel"],
            member=row["member"],
            member_kind=row["member_kind"],
            task_id=spec.task.task_id,
            task_source=spec.task.source,
            trials=row["trials"],
            settled=bool(usage_settled and row["panel"] == settlement_name),
            steps=row["steps"],
            model_calls=row["model_calls"],
            wall_s=row["wall_s"],
            discrimination=settlement_d["d"] if row["panel"] == settlement_name else None,
            category=classification.category,
        )

    result = assemble_result(
        spec=spec,
        chain=chain,
        panel_results=panel_results,
        classification=classification.to_dict(),
        config_digest=config_digest,
        wall_s=clock() - run_started,
        output_dir=output_dir,
    )

    (output_dir / "events.jsonl").write_text(chain.to_jsonl(), encoding="utf-8")
    (output_dir / "result.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False, sort_keys=True), encoding="utf-8"
    )
    return result


def _coerce_outcome(value: Any) -> EpisodeOutcome:
    """允许注入的 episode runner 直接返回 dict（发 job 后从矿工手里收结果）。"""
    if isinstance(value, EpisodeOutcome):
        return value
    if not isinstance(value, Mapping):
        raise TypeError(f"episode runner returned {type(value).__name__}, expected EpisodeOutcome or mapping")
    return EpisodeOutcome(
        success=bool(value.get("success")),
        steps=int(value.get("steps") or 0),
        model_calls=int(value.get("model_calls") or 0),
        wall_s=float(value.get("wall_s") or 0.0),
        events=tuple(value.get("events") or ()),
        root=str(value.get("root") or ""),
        summary=dict(value.get("summary") or {}),
        evidence_quality=dict(value.get("evidence_quality") or {}),
        error=str(value.get("error") or ""),
    )


def _default_runner_factory(spec: PanelRunSpec) -> Callable[[MemberSpec], MemberRunner]:
    def make(member: MemberSpec) -> MemberRunner:
        return build_runner(
            member,
            policy=spec.policy_factory(member) if spec.policy_factory else None,
            decide=spec.decide_factory(member) if spec.decide_factory else None,
            episode_runner=spec.episode_runner_factory(member) if spec.episode_runner_factory else None,
        )

    return make


def assemble_result(
    *,
    spec: PanelRunSpec,
    chain: EventChain,
    panel_results: dict[str, dict[str, Any]],
    classification: dict[str, Any],
    config_digest: str,
    wall_s: float,
    output_dir: pathlib.Path,
) -> dict[str, Any]:
    """把一次执行拼成「B 赛道 job 交付」同形状的结果。

    将来发单时矿工交回来的也是这个形状；:func:`run_reference_panel` 换成
    「等 job 结果」之后，这里不需要动。
    """
    settlement_name = spec.config.settlement_panel
    chain.append(
        "run_end",
        {
            "settlement_panel": settlement_name,
            "classification": classification,
            "wall_s": round(wall_s, 3),
        },
    )
    events = chain.events
    episodes = sum(len(panel.members) for panel in spec.config.panels.values()) * spec.trials
    quality = evidence_quality(events, episode_count=episodes)
    verification = verify_chain(events)
    quality = {**quality, "chain_verified": verification["ok"], "chain_errors": verification["errors"]}

    summary = {
        "run_id": spec.run_id,
        "task": spec.task.to_dict(),
        "trials": spec.trials,
        "config_version": spec.config.version,
        "config_digest": config_digest,
        "settlement_panel": settlement_name,
        "settlement": {
            "panel": settlement_name,
            "roles": dict(spec.config.settlement.roles),
            "d": panel_results[settlement_name]["d"],
            "classification": classification,
        },
        "diagnostics": {
            name: {
                "roles": dict(panel.roles),
                "d": panel_results[name]["d"],
                "variance": panel_results[name].get("variance", {}),
                "members": {
                    member_id: {"rate": row["rate"], "scored_trials": row["scored_trials"]}
                    for member_id, row in panel_results[name]["members"].items()
                },
            }
            for name, panel in spec.config.panels.items()
            if name != settlement_name
        },
        "panels": {
            name: {
                "settlement": data["settlement"],
                "roles": dict(spec.config.panels[name].roles),
                "d": data["d"],
                "variance": data.get("variance", {}),
                "variance_enabled": data.get("variance_enabled", False),
                "members": data["members"],
            }
            for name, data in panel_results.items()
        },
        "wall_s": round(wall_s, 3),
        "rechecked_at": spec.rechecked_at,
    }
    return {
        "run_id": spec.run_id,
        "job_id": chain.job_id,
        "attempt_id": chain.attempt_id,
        "mode": "internal",
        "task": spec.task.to_dict(),
        "config_version": spec.config.version,
        "config_digest": config_digest,
        "settlement_panel": settlement_name,
        "settlement": summary["settlement"],
        "diagnostics": summary["diagnostics"],
        "panels": summary["panels"],
        "events": events,
        "root": chain.root,
        "summary": summary,
        "evidence_quality": quality,
        "task_scores_path": str(output_dir / "task_scores.jsonl"),
        "usage_path": str(output_dir / "usage.jsonl"),
        "events_path": str(output_dir / "events.jsonl"),
        "rechecked_at": spec.rechecked_at,
        "recorded_at": now_iso(),
    }


def load_result(path: str | pathlib.Path) -> dict[str, Any]:
    return json.loads(pathlib.Path(path).expanduser().read_text(encoding="utf-8"))


def default_env_factory(request: EpisodeRequest) -> tuple[Any, Any]:
    """生产环境工厂：按题源 ``make_env`` + ``checker``。

    延迟导入 ``task_source``（OPE-100，在 ``feat/agent-robotics`` 上）。本分支
    单独跑时给明确错误，而不是假装跑过。
    """
    try:
        from task_source.registry import get_source  # type: ignore
    except ImportError as e:  # pragma: no cover - depends on the branch layout
        raise RunnerUnavailable(
            "reference panel execution needs task_source (OPE-100); inject env_factory or merge feat/agent-robotics"
        ) from e

    source = get_source(request.source)
    task = source.load_task(request.task_id, instance=request.instance)
    return source.make_env(task, request.instance), source.checker(task)
