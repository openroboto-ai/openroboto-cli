"""参照组配置：成员、panel、预登记的 best / worst。

配置形状见 OPE-115（2026-10-29 定）：:

    {
      "version": "v2026-10-29",
      "settlement_panel": "agent",
      "panels": {
        "agent": {
          "members": [
            {"id": "a1", "kind": "agent", "provider": "anthropic", "model": "...",
             "harness": "headless", "harness_commit": "<40 hex>", "baseline_score": 0.42},
            ...
          ],
          "roles": {"best": "a1", "worst": "a2"},
          "roles_as_of": "2026-10-29"
        }
      }
    }

三条规则落在这里：

1. **每个 panel 单独算 D**，best / worst 只能取自同一 panel；
2. **只有一个 ``settlement_panel`` 参与结算**，其余 panel 只做诊断；
3. **roles 预登记在配置里**——运行时没有任何参数能覆盖它。要换 best/worst
   只能改配置行、升 ``version``，然后触发全池重考。

成员按 ``commit``（vla 的模型）/ ``harness_commit``（agent 的 harness）锁定；
换成员 = 换配置行 + 重考，不改代码。

DeepSeek agent 成员可显式声明 ``thinking: enabled|disabled``；它参与锁定
字段和配置摘要。缺省不发送该参数，也不改变未声明此字段的历史配置摘要。
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from typing import Any, Mapping

from task_source.execution_contract import parse_execution_contract

#: 40 位小写 hex，与 worker 的 ``COMMIT_HASH_RE`` 同一口径。
COMMIT_HASH_RE = re.compile(r"^[0-9a-f]{40}$")

SUPPORTED_KINDS = ("vla", "agent")
SUPPORTED_EFFORTS = ("low", "medium", "high", "xhigh", "max")
EFFORT_PARAM = "reasoning_effort"

#: 结算 panel 至少两个成员——只有一个成员时 D 恒为 0，结算没有意义。
MIN_SETTLEMENT_MEMBERS = 2


class ConfigError(ValueError):
    """参照组配置不可用（缺字段、锁定字段不合法、roles 越界……）。"""


def canonical_json(value: Any) -> str:
    """确定性 JSON：键排序、紧凑分隔符、禁止 NaN/Infinity。

    与证据链（``agent_evidence.canonical``）同一规则，配置摘要才能跨进程复算。
    """
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _require_text(raw: Mapping[str, Any], key: str, *, where: str) -> str:
    value = raw.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"{where}: {key!r} must be a non-empty string")
    return value.strip()


def _optional_text(raw: Mapping[str, Any], key: str) -> str | None:
    value = raw.get(key)
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"{key!r} must be a non-empty string when present")
    return value.strip()


def _commit(raw: Mapping[str, Any], key: str, *, where: str) -> str:
    value = _require_text(raw, key, where=where)
    if not COMMIT_HASH_RE.match(value):
        raise ConfigError(f"{where}: {key!r} must be the full 40-char lowercase hex commit, got {value!r}")
    return value


@dataclass(frozen=True)
class MemberSpec:
    """参照组的一个成员。``kind`` 决定谁产生动作，不改 D 的算法。"""

    id: str
    kind: str
    #: agent: provider + model + harness + harness_commit
    provider: str | None = None
    model: str | None = None
    harness: str | None = None
    harness_commit: str | None = None
    #: vla: repo + commit + model_hash
    repo: str | None = None
    commit: str | None = None
    model_hash: str | None = None
    #: 跨题基线总分。排序 best / worst 用；新增成员没跑过基线时为 None。
    baseline_score: float | None = None
    #: Explicit DeepSeek reasoning mode; absence preserves the provider default.
    thinking: str | None = None
    #: Registered reasoning effort and its OpenAI-compatible wire parameter.
    effort: str | None = None
    effort_param: str | None = None
    #: 原始配置行（保留未知字段，便于将来加配置不改代码）。
    raw: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.thinking is not None and (
            self.kind != "agent" or self.provider != "deepseek" or self.thinking not in ("enabled", "disabled")
        ):
            raise ConfigError("thinking requires a DeepSeek agent and 'enabled' or 'disabled'")
        if self.effort is not None and (self.kind != "agent" or self.effort not in SUPPORTED_EFFORTS):
            raise ConfigError(f"effort requires an agent and one of {SUPPORTED_EFFORTS}")
        if self.effort_param is not None and (self.effort is None or self.effort_param != EFFORT_PARAM):
            raise ConfigError("effort_param requires effort and must be 'reasoning_effort'")

    def model_config(self) -> dict[str, Any]:
        """Use only registered model options, never arbitrary raw member fields."""
        if self.kind != "agent":
            raise ConfigError("only agent members have a model config")
        model: dict[str, Any] = {"provider": self.provider, "model": self.model}
        if self.thinking is not None:
            model["extra_body"] = {"thinking": {"type": self.thinking}}
        if self.effort is not None:
            model.update(effort=self.effort, effort_param=self.effort_param or EFFORT_PARAM)
        return model

    @property
    def hf_commit(self) -> str | None:
        """模型锁定的 commit。agent 成员没有 HF 权重（模型是 API），返回 None。"""
        return self.commit if self.kind == "vla" else None

    def binding(self) -> dict[str, Any]:
        """锁定字段：换任何一个都等于换成员，必须重考。"""
        if self.kind == "vla":
            return {"repo": self.repo, "commit": self.commit, "model_hash": self.model_hash}
        binding = {
            "provider": self.provider,
            "model": self.model,
            "harness": self.harness,
            "harness_commit": self.harness_commit,
        }
        if self.thinking is not None:
            binding["thinking"] = self.thinking
        if self.effort is not None:
            binding.update(effort=self.effort, effort_param=self.effort_param or EFFORT_PARAM)
        return binding


def _parse_member(raw: Any, *, panel: str) -> MemberSpec:
    if not isinstance(raw, Mapping):
        raise ConfigError(f"panel {panel!r}: each member must be an object, got {type(raw).__name__}")
    member_id = _require_text(raw, "id", where=f"panel {panel!r}")
    kind = _require_text(raw, "kind", where=f"panel {panel!r} member {member_id!r}")
    if kind not in SUPPORTED_KINDS:
        raise ConfigError(
            f"panel {panel!r} member {member_id!r}: unsupported kind {kind!r}; allowed: {', '.join(SUPPORTED_KINDS)}"
        )

    thinking = raw.get("thinking")
    if "thinking" in raw and (
        kind != "agent"
        or not isinstance(raw.get("provider"), str)
        or raw["provider"].strip() != "deepseek"
        or not isinstance(thinking, str)
        or thinking not in ("enabled", "disabled")
    ):
        raise ConfigError("thinking requires a DeepSeek agent and 'enabled' or 'disabled'")

    effort = raw.get("effort")
    effort_param = raw.get("effort_param")
    if "effort" in raw and (kind != "agent" or not isinstance(effort, str) or effort not in SUPPORTED_EFFORTS):
        raise ConfigError(f"effort requires an agent and one of {SUPPORTED_EFFORTS}")
    if "effort_param" in raw and (effort is None or effort_param != EFFORT_PARAM):
        raise ConfigError("effort_param requires effort and must be 'reasoning_effort'")

    baseline = raw.get("baseline_score")
    if baseline is not None:
        if isinstance(baseline, bool) or not isinstance(baseline, (int, float)):
            raise ConfigError(f"panel {panel!r} member {member_id!r}: baseline_score must be a number or null")
        if not 0.0 <= float(baseline) <= 1.0:
            raise ConfigError(f"panel {panel!r} member {member_id!r}: baseline_score must be in [0, 1]")
        baseline = float(baseline)

    if kind == "agent":
        return MemberSpec(
            id=member_id,
            kind=kind,
            provider=_require_text(raw, "provider", where=f"panel {panel!r} member {member_id!r}"),
            model=_require_text(raw, "model", where=f"panel {panel!r} member {member_id!r}"),
            harness=_require_text(raw, "harness", where=f"panel {panel!r} member {member_id!r}"),
            harness_commit=_commit(raw, "harness_commit", where=f"panel {panel!r} member {member_id!r}"),
            baseline_score=baseline,
            thinking=thinking,
            effort=effort,
            effort_param=effort_param,
            raw=dict(raw),
        )

    return MemberSpec(
        id=member_id,
        kind=kind,
        repo=_require_text(raw, "repo", where=f"panel {panel!r} member {member_id!r}"),
        commit=_commit(raw, "commit", where=f"panel {panel!r} member {member_id!r}"),
        model_hash=_require_text(raw, "model_hash", where=f"panel {panel!r} member {member_id!r}"),
        baseline_score=baseline,
        raw=dict(raw),
    )


@dataclass(frozen=True)
class PanelSpec:
    name: str
    members: tuple[MemberSpec, ...]
    #: 预登记的 best / worst。运行时**没有**任何参数能改它。
    roles: Mapping[str, str]
    roles_as_of: str | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)

    def member(self, member_id: str) -> MemberSpec:
        for candidate in self.members:
            if candidate.id == member_id:
                return candidate
        raise ConfigError(f"panel {self.name!r} has no member {member_id!r}")

    @property
    def best(self) -> MemberSpec:
        return self.member(self.roles["best"])

    @property
    def worst(self) -> MemberSpec:
        return self.member(self.roles["worst"])


@dataclass(frozen=True)
class ReferencePanelConfig:
    settlement_panel: str
    panels: Mapping[str, PanelSpec]
    version: str
    raw: Mapping[str, Any] = field(default_factory=dict)
    execution_contract: Mapping[str, Any] | None = None

    @property
    def digest(self) -> str:
        """配置摘要 = 成员 + 锁定字段 + roles + version 的 canonical sha256。

        重考队列按它判断「参照组换没换」；只改标点、不改语义的格式变化不会
        触发重考，而换 commit / 换 roles 一定会。
        """
        return canonical_sha256(self.canonical_form())

    def canonical_form(self) -> dict[str, Any]:
        canonical = {
            "version": self.version,
            "settlement_panel": self.settlement_panel,
            "panels": {
                name: {
                    "roles": dict(panel.roles),
                    "roles_as_of": panel.roles_as_of,
                    "members": [
                        {
                            "id": member.id,
                            "kind": member.kind,
                            "binding": member.binding(),
                            "baseline_score": member.baseline_score,
                        }
                        for member in panel.members
                    ],
                }
                for name, panel in self.panels.items()
            },
        }
        if self.execution_contract is not None:
            canonical["execution_contract"] = dict(self.execution_contract)
        return canonical

    @property
    def settlement(self) -> PanelSpec:
        return self.panels[self.settlement_panel]

    def diagnostic_panels(self) -> dict[str, PanelSpec]:
        """除结算 panel 外的 panel。它们出 D，但不参与分档、不参与发钱。"""
        return {name: panel for name, panel in self.panels.items() if name != self.settlement_panel}


def parse_config(raw: Any) -> ReferencePanelConfig:
    """校验并解析配置。任何一条规则不满足都直接拒绝，不做「尽力而为」。"""
    if not isinstance(raw, Mapping):
        raise ConfigError(f"config must be an object, got {type(raw).__name__}")

    version = _require_text(raw, "version", where="config")
    settlement = _require_text(raw, "settlement_panel", where="config")
    panels_raw = raw.get("panels")
    if not isinstance(panels_raw, Mapping) or not panels_raw:
        raise ConfigError("config: 'panels' must be a non-empty object")

    panels: dict[str, PanelSpec] = {}
    for name, panel_raw in panels_raw.items():
        if not isinstance(name, str) or not name.strip():
            raise ConfigError("config: panel names must be non-empty strings")
        if not isinstance(panel_raw, Mapping):
            raise ConfigError(f"panel {name!r} must be an object")
        members_raw = panel_raw.get("members")
        if not isinstance(members_raw, list) or not members_raw:
            raise ConfigError(f"panel {name!r}: 'members' must be a non-empty list")

        members = tuple(_parse_member(item, panel=name) for item in members_raw)
        ids = [member.id for member in members]
        if len(set(ids)) != len(ids):
            raise ConfigError(f"panel {name!r}: duplicate member ids {sorted(ids)}")

        roles_raw = panel_raw.get("roles")
        if not isinstance(roles_raw, Mapping):
            raise ConfigError(f"panel {name!r}: 'roles' must be a pre-registered object with best/worst")
        roles = {}
        for role in ("best", "worst"):
            member_id = roles_raw.get(role)
            if not isinstance(member_id, str) or member_id not in ids:
                raise ConfigError(f"panel {name!r}: roles.{role} must name a member of this panel, got {member_id!r}")
            roles[role] = member_id

        if len(members) >= MIN_SETTLEMENT_MEMBERS and roles["best"] == roles["worst"]:
            raise ConfigError(f"panel {name!r}: best and worst must be different members when the panel has >= 2")

        roles_as_of = _optional_text(panel_raw, "roles_as_of")
        panels[name] = PanelSpec(
            name=name,
            members=members,
            roles=roles,
            roles_as_of=roles_as_of,
            raw=dict(panel_raw),
        )

    if settlement not in panels:
        raise ConfigError(f"config: settlement_panel {settlement!r} is not one of {sorted(panels)}")
    if len(panels[settlement].members) < MIN_SETTLEMENT_MEMBERS:
        raise ConfigError(
            f"config: settlement panel {settlement!r} needs at least {MIN_SETTLEMENT_MEMBERS} members "
            "(a single member makes D identically zero)"
        )

    contract = None
    if "execution_contract" in raw:
        try:
            contract = parse_execution_contract(raw["execution_contract"])
        except ValueError as exc:
            raise ConfigError(str(exc)) from exc
        for member in panels[settlement].members:
            binding = member.binding()
            if (
                member.kind != "agent"
                or binding.get("harness") != "headless"
                or binding.get("harness_commit") != contract["agent"]["harness_commit"]
            ):
                raise ConfigError("execution_contract must match every settlement member's headless harness")

    config = ReferencePanelConfig(
        settlement_panel=settlement,
        panels=panels,
        version=version,
        raw=dict(raw),
        execution_contract=contract,
    )
    # 早失败：digest 在构造时就该算得出来（unknown 字段里的 NaN 会在这里暴露）。
    _ = config.digest
    return config


# ---------------------------------------------------------------------------
# best / worst 的选定与依据
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RoleAssignment:
    """一次 best / worst 选定：结果 + 依据（总分、日期、配置版本）。"""

    panel: str
    best: str
    worst: str
    selection: str
    as_of: str
    config_version: str
    basis: tuple[Mapping[str, Any], ...]

    def to_dict(self) -> dict:
        return {
            "panel": self.panel,
            "best": self.best,
            "worst": self.worst,
            "selection": self.selection,
            "as_of": self.as_of,
            "config_version": self.config_version,
            "basis": [dict(row) for row in self.basis],
        }


def select_roles(panel: PanelSpec, *, as_of: str, config_version: str) -> RoleAssignment:
    """按成员 ``baseline_score`` 生成预登记的 best / worst。

    规则（OPE-115）：

    * 初始两名成员：best = 总分最高，worst = 总分最低且非 0；只有两个时就是
      这两个；
    * 扩 auxiliary：按总分排序取最高 / 最低。**新增成员必须先跑一轮基线总分**
      ——缺 ``baseline_score`` 的成员进不了排序，直接拒绝，而不是拿单题成绩
      临时顶替。
    * 选出来的结果要写回配置的 ``roles``；本函数只生成，不修改配置对象。
    """
    missing = [member.id for member in panel.members if member.baseline_score is None]
    if missing:
        raise ConfigError(
            f"panel {panel.name!r}: members {missing} have no baseline_score; "
            "run a baseline round before they can enter the best/worst ranking"
        )

    ranked = sorted(panel.members, key=lambda member: (-float(member.baseline_score), member.id))
    best = ranked[0]
    if len(panel.members) == 2:
        worst = ranked[1]
        selection = "two_member_panel"
    else:
        non_zero = [member for member in reversed(ranked) if float(member.baseline_score) > 0.0]
        worst = non_zero[0] if non_zero else ranked[-1]
        selection = "lowest_nonzero_total"

    basis = tuple(
        {
            "member": member.id,
            "kind": member.kind,
            "baseline_score": member.baseline_score,
            "rank": index + 1,
            "selected": member.id in (best.id, worst.id),
        }
        for index, member in enumerate(ranked)
    )
    return RoleAssignment(
        panel=panel.name,
        best=best.id,
        worst=worst.id,
        selection=selection,
        as_of=as_of,
        config_version=config_version,
        basis=basis,
    )


def role_evidence(config: ReferencePanelConfig) -> dict[str, Any]:
    """赛事页/审计用的「best / worst 是怎么来的」。

    每条都带总分、选定日期、配置版本与摘要——换过人之后还能回答「当时为什么
    是这两个」。
    """
    panels = {}
    for name, panel in config.panels.items():
        ranked = sorted(
            panel.members,
            key=lambda member: (
                member.baseline_score is None,
                -(member.baseline_score or 0.0),
                member.id,
            ),
        )
        panels[name] = {
            "roles": dict(panel.roles),
            "roles_as_of": panel.roles_as_of,
            "config_version": config.version,
            "config_digest": config.digest,
            "members": [
                {
                    "id": member.id,
                    "kind": member.kind,
                    "baseline_score": member.baseline_score,
                }
                for member in ranked
            ],
        }
    return {"settlement_panel": config.settlement_panel, "panels": panels}


def public_view(config: ReferencePanelConfig) -> dict[str, Any]:
    """赛事页公开的参照组名单。

    只有身份与锁定字段，没有 API key、网关地址等运行期凭据——成员配置行里
    本来也不该有这些（凭据走环境变量）。
    """
    return {
        "version": config.version,
        "config_digest": config.digest,
        **({"execution_contract": dict(config.execution_contract)} if config.execution_contract is not None else {}),
        "settlement_panel": config.settlement_panel,
        "roles": {
            name: {
                "best": panel.roles["best"],
                "worst": panel.roles["worst"],
                "roles_as_of": panel.roles_as_of,
                "settlement": name == config.settlement_panel,
            }
            for name, panel in config.panels.items()
        },
        "panels": {
            name: {
                "members": [
                    {
                        "id": member.id,
                        "kind": member.kind,
                        **member.binding(),
                        "hf_commit": member.hf_commit,
                        "baseline_score": member.baseline_score,
                    }
                    for member in panel.members
                ],
            }
            for name, panel in config.panels.items()
        },
    }
