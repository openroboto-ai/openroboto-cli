"""参照组评测的落盘：``task_scores`` 与成本账。

两类账本，都是 append-only 的 JSONL（崩溃不会留下半截 JSON，也不依赖
数据库；后端还没有 ``task_scores`` 表——那是 OPE-116 之后的迁移，本 issue
按「panel × member × task × trials」先落本地，字段与将来的表对齐）：

* :class:`TaskScoreStore` —— 每局一行 ``row_type="trial"``，每个
  (panel, member, task) 再落一行 ``row_type="summary"``；
* :class:`UsageLedger` —— **每次评测一行**：步数、模型调用次数、wall time。
  哪怕这一题不结算（证据不足、被退役）也记，将来发 job 定价得有数据。
"""

from __future__ import annotations

import datetime
import json
import pathlib
from typing import Iterable

from .evidence import canonical_json


def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


class JsonlStore:
    """单文件追加账本。读的时候坏行跳过并计数，不让一行坏数据埋掉整本账。"""

    def __init__(self, path: str | pathlib.Path):
        self.path = pathlib.Path(path).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, row: dict) -> dict:
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(canonical_json(row) + "\n")
            handle.flush()
        return row

    def read(self) -> list[dict]:
        return [row for row, _ in self.read_with_errors()]

    def read_with_errors(self) -> list[tuple[dict, str]]:
        if not self.path.exists():
            return []
        rows: list[tuple[dict, str]] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as e:
                rows.append(({"_raw": line, "_error": f"invalid JSON: {e}"}, f"invalid JSON: {e}"))
                continue
            if not isinstance(value, dict):
                rows.append(({"_raw": line, "_error": "not a JSON object"}, "not a JSON object"))
                continue
            rows.append((value, ""))
        return rows


class TaskScoreStore(JsonlStore):
    """``panel × member × task × trial`` 的成绩账本。"""

    def record_trial(
        self,
        *,
        run_id: str,
        panel: str,
        member: str,
        member_kind: str,
        task_id: str,
        task_source: str,
        trial: int,
        instance: int,
        success: bool,
        steps: int,
        model_calls: int,
        wall_s: float,
        config_version: str,
        config_digest: str,
        child_root: str = "",
        error: str = "",
    ) -> dict:
        return self.append({
            "row_type": "trial",
            "run_id": run_id,
            "panel": panel,
            "member": member,
            "member_kind": member_kind,
            "task_id": task_id,
            "task_source": task_source,
            "trial": trial,
            "instance": int(instance),
            "success": bool(success),
            "steps": int(steps),
            "model_calls": int(model_calls),
            "wall_s": round(float(wall_s), 3),
            "child_root": child_root,
            "error": error,
            "config_version": config_version,
            "config_digest": config_digest,
            "recorded_at": now_iso(),
        })

    def record_summary(
        self,
        *,
        run_id: str,
        panel: str,
        member: str,
        member_kind: str,
        task_id: str,
        task_source: str,
        trials: int,
        scored_trials: int,
        successes: int,
        failed_trials: int,
        steps: int,
        model_calls: int,
        wall_s: float,
        config_version: str,
        config_digest: str,
    ) -> dict:
        return self.append({
            "row_type": "summary",
            "run_id": run_id,
            "panel": panel,
            "member": member,
            "member_kind": member_kind,
            "task_id": task_id,
            "task_source": task_source,
            "trials": int(trials),
            "scored_trials": int(scored_trials),
            "successes": int(successes),
            "rate": round(successes / scored_trials, 6) if scored_trials else None,
            "failed_trials": int(failed_trials),
            "steps": int(steps),
            "model_calls": int(model_calls),
            "wall_s": round(float(wall_s), 3),
            "config_version": config_version,
            "config_digest": config_digest,
            "recorded_at": now_iso(),
        })

    def summaries_for(self, task_id: str) -> list[dict]:
        return [row for row in self.read() if row.get("row_type") == "summary" and row.get("task_id") == task_id]


class UsageLedger(JsonlStore):
    """参照组评测的算力账：每次评测一行，结算与否都记。"""

    def record(
        self,
        *,
        run_id: str,
        panel: str,
        member: str,
        member_kind: str,
        task_id: str,
        task_source: str,
        trials: int,
        settled: bool,
        steps: int,
        model_calls: int,
        wall_s: float,
        discrimination: float | None,
        category: str | None,
    ) -> dict:
        return self.append({
            "run_id": run_id,
            "panel": panel,
            "member": member,
            "member_kind": member_kind,
            "task_id": task_id,
            "task_source": task_source,
            "trials": int(trials),
            "settled": bool(settled),
            "steps": int(steps),
            "model_calls": int(model_calls),
            "wall_s": round(float(wall_s), 3),
            "discrimination": None if discrimination is None else round(float(discrimination), 6),
            "category": category,
            "recorded_at": now_iso(),
        })

    def rows_for_run(self, run_id: str) -> list[dict]:
        return [row for row in self.read() if row.get("run_id") == run_id]


def aggregate_trials(rows: Iterable[dict]) -> dict[str, dict]:
    """trial 行 → ``{member: {"successes", "trials", "steps", "model_calls", "wall_s", "failed"}}``。"""
    totals: dict[str, dict] = {}
    for row in rows:
        member = row.get("member")
        if not isinstance(member, str):
            continue
        bucket = totals.setdefault(
            member, {"successes": 0, "trials": 0, "steps": 0, "model_calls": 0, "wall_s": 0.0, "failed": 0}
        )
        bucket["trials"] += 1
        bucket["successes"] += 1 if row.get("success") else 0
        bucket["steps"] += int(row.get("steps") or 0)
        bucket["model_calls"] += int(row.get("model_calls") or 0)
        bucket["wall_s"] += float(row.get("wall_s") or 0.0)
        if row.get("error"):
            bucket["failed"] += 1
    return totals
