"""参照组更新后的全池重考。

规则（OPE-115「重考节奏」）：

* 参照组成员变更（换 best/worst、加 auxiliary、换 kind、换 commit）→ **全池
  重考**；
* 最小间隔按月（``min_interval_days`` 可配置），防止一天里改两次配置把全池
  的 GPU 时间烧完；
* 每次重考在状态文件里标记 ``rechecked_at``，题池页/审计可查「上一次重考是
  什么时候、用的哪版配置」。

配置变没变用 ``config.digest`` 判断（成员 + 锁定字段 + roles + version 的
canonical sha256）——只改格式不触发，换 commit / 换 roles 一定触发。
"""

from __future__ import annotations

import datetime
import json
import pathlib
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping

from .config import ReferencePanelConfig
from .evaluate import PanelRunSpec, TaskRef, run_reference_panel

DEFAULT_MIN_INTERVAL_DAYS = 30
STATE_FILENAME = "reference_panel_recheck.json"


def _parse_time(value: Any) -> datetime.datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=datetime.timezone.utc)
    return parsed


@dataclass(frozen=True)
class RecheckDecision:
    required: bool
    due: bool
    reason: str
    config_digest: str
    previous_digest: str | None
    last_recheck_at: str | None
    next_due_at: str | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "required": self.required,
            "due": self.due,
            "reason": self.reason,
            "config_digest": self.config_digest,
            "previous_digest": self.previous_digest,
            "last_recheck_at": self.last_recheck_at,
            "next_due_at": self.next_due_at,
        }


def should_recheck(
    state: Mapping[str, Any] | None,
    config: ReferencePanelConfig,
    *,
    now: datetime.datetime | None = None,
    min_interval_days: int = DEFAULT_MIN_INTERVAL_DAYS,
) -> RecheckDecision:
    """判断是否该重考，以及最小间隔是否已过。

    ``required`` 只回答「参照组变了没」；``due`` 回答「间隔够不够」。调用方
    通常要求 ``required and due``，运维可以 ``force`` 跳过间隔（配置改错了
    要立刻纠正时）。
    """
    if min_interval_days < 0:
        raise ValueError("min_interval_days must be >= 0")
    now = now or datetime.datetime.now(datetime.timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=datetime.timezone.utc)

    digest = config.digest
    if not state:
        return RecheckDecision(
            required=True,
            due=True,
            reason="no previous panel run",
            config_digest=digest,
            previous_digest=None,
            last_recheck_at=None,
            next_due_at=None,
        )

    previous_digest = state.get("config_digest")
    last_raw = state.get("last_recheck_at")
    last = _parse_time(last_raw)
    next_due = last + datetime.timedelta(days=min_interval_days) if last else None
    due = next_due is None or now >= next_due
    next_due_text = next_due.isoformat(timespec="seconds") if next_due else None

    if previous_digest != digest:
        reason = "panel configuration changed"
        if previous_digest is None:
            reason = "no panel configuration recorded"
        return RecheckDecision(
            required=True,
            due=due,
            reason=reason,
            config_digest=digest,
            previous_digest=previous_digest,
            last_recheck_at=last_raw,
            next_due_at=next_due_text,
        )

    return RecheckDecision(
        required=False,
        due=due,
        reason="panel configuration unchanged",
        config_digest=digest,
        previous_digest=previous_digest,
        last_recheck_at=last_raw,
        next_due_at=next_due_text,
    )


class RecheckState:
    """重考状态账本（单 JSON 文件，原子替换写入）。

    形状::

        {
          "config_digest": "...",              # 上次重考用的配置
          "last_recheck_at": "...",            # UTC ISO
          "tasks": {"<task_id>": {"rechecked_at": "...", "run_id": "...",
                                  "config_digest": "...", "category": "...",
                                  "discrimination": 0.12, "disposition": "in_pool"}}
        }
    """

    def __init__(self, path: str | pathlib.Path):
        self.path = pathlib.Path(path).expanduser()
        self._data: dict[str, Any] = {"tasks": {}}
        if self.path.exists():
            text = self.path.read_text(encoding="utf-8")
            if text.strip():
                loaded = json.loads(text)
                if not isinstance(loaded, dict):
                    raise ValueError(f"recheck state {self.path} must be a JSON object")
                self._data = loaded
                self._data.setdefault("tasks", {})

    def as_dict(self) -> dict[str, Any]:
        return json.loads(json.dumps(self._data))

    def mark_task(
        self,
        task_id: str,
        *,
        rechecked_at: str,
        run_id: str,
        config_digest: str,
        category: str | None,
        discrimination: float | None,
        disposition: str | None,
    ) -> dict[str, Any]:
        row = {
            "rechecked_at": rechecked_at,
            "run_id": run_id,
            "config_digest": config_digest,
            "category": category,
            "discrimination": discrimination,
            "disposition": disposition,
        }
        self._data["tasks"][task_id] = row
        self._save()
        return row

    def mark_run(self, *, config_digest: str, rechecked_at: str) -> None:
        self._data["config_digest"] = config_digest
        self._data["last_recheck_at"] = rechecked_at
        self._save()

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(json.dumps(self._data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)


@dataclass
class RecheckReport:
    decision: Mapping[str, Any]
    rechecked_at: str | None
    tasks: list[dict[str, Any]] = field(default_factory=list)
    skipped_reason: str = ""

    @property
    def ran(self) -> bool:
        return bool(self.tasks) and not self.skipped_reason

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": dict(self.decision),
            "rechecked_at": self.rechecked_at,
            "tasks": [dict(row) for row in self.tasks],
            "skipped_reason": self.skipped_reason,
        }


def bulk_recheck(
    task_refs: Iterable[TaskRef],
    *,
    config: ReferencePanelConfig,
    spec_factory: Callable[[TaskRef, str, str], PanelRunSpec],
    state: RecheckState,
    now: datetime.datetime | None = None,
    min_interval_days: int = DEFAULT_MIN_INTERVAL_DAYS,
    force: bool = False,
    run: Callable[..., dict[str, Any]] = run_reference_panel,
) -> RecheckReport:
    """对全池题批量重考，并给每道题打上 ``rechecked_at``。

    ``spec_factory(task, run_id, rechecked_at) -> PanelRunSpec`` 由调用方提供，
    它决定每道题跑哪些 panel、几局、产物落哪。这样本模块不认识题目内容，也
    不绑定某一种 runner。
    """
    decision = should_recheck(state.as_dict(), config, now=now, min_interval_days=min_interval_days)
    if not decision.required:
        return RecheckReport(decision=decision.to_dict(), rechecked_at=None, skipped_reason=decision.reason)
    if not decision.due and not force:
        return RecheckReport(
            decision=decision.to_dict(),
            rechecked_at=None,
            skipped_reason=f"minimum interval not reached (next due {decision.next_due_at})",
        )

    rechecked_at = (now or datetime.datetime.now(datetime.timezone.utc)).isoformat(timespec="seconds")
    report = RecheckReport(decision=decision.to_dict(), rechecked_at=rechecked_at)
    for index, task in enumerate(task_refs):
        run_id = f"recheck-{rechecked_at.replace(':', '').replace('+', '')}-{task.task_id}-{index}"
        spec = spec_factory(task, run_id, rechecked_at)
        result = run(spec)
        settlement = result.get("settlement") or {}
        classification = settlement.get("classification") or {}
        state.mark_task(
            task.task_id,
            rechecked_at=rechecked_at,
            run_id=result.get("run_id", run_id),
            config_digest=result.get("config_digest") or config.digest,
            category=classification.get("category"),
            discrimination=classification.get("discrimination"),
            disposition=classification.get("disposition"),
        )
        report.tasks.append({
            "task_id": task.task_id,
            "run_id": result.get("run_id", run_id),
            "category": classification.get("category"),
            "disposition": classification.get("disposition"),
            "discrimination": classification.get("discrimination"),
            "rechecked_at": rechecked_at,
        })
    state.mark_run(config_digest=config.digest, rechecked_at=rechecked_at)
    return report


def recheck_state_path(output_root: str | pathlib.Path) -> pathlib.Path:
    return pathlib.Path(output_root).expanduser() / STATE_FILENAME
