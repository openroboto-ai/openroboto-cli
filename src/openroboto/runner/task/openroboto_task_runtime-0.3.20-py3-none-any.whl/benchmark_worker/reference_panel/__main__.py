"""参照组配置的运维入口（不做实际评测）。

    python -m benchmark_worker.reference_panel --config panel.json --show    # 赛事页公开名单
    python -m benchmark_worker.reference_panel --config panel.json --roles   # best/worst 的依据
    python -m benchmark_worker.reference_panel --config panel.json --validate
    python -m benchmark_worker.reference_panel --config panel.json \
        --recheck-state recheck.json --now 2026-11-01T00:00:00Z

真正的评测从 :func:`benchmark_worker.reference_panel.evaluate.run_reference_panel`
进入（需要 GPU / 题源运行时，不在这个 CLI 里）。
"""

from __future__ import annotations

import argparse
import datetime
import json
import pathlib
import sys
from typing import Sequence

from .config import ConfigError, parse_config, public_view, role_evidence
from .recheck import should_recheck


def _parse_now(text: str | None) -> datetime.datetime | None:
    if not text:
        return None
    return datetime.datetime.fromisoformat(text.replace("Z", "+00:00"))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m benchmark_worker.reference_panel", description=__doc__)
    parser.add_argument("--config", required=True, help="参照组配置 JSON")
    parser.add_argument("--show", action="store_true", help="输出赛事页公开名单")
    parser.add_argument("--roles", action="store_true", help="输出 best/worst 的选定依据")
    parser.add_argument("--validate", action="store_true", help="只校验配置")
    parser.add_argument("--recheck-state", default=None, help="读出重考状态并回答是否该重考")
    parser.add_argument("--now", default=None, help="重考判断用的当前时间（ISO-8601）")
    parser.add_argument("--min-interval-days", type=int, default=30)
    return parser


def run(argv: Sequence[str] | None = None, out=None) -> int:
    args = build_parser().parse_args(argv)
    out = out or sys.stdout
    try:
        config = parse_config(json.loads(pathlib.Path(args.config).expanduser().read_text(encoding="utf-8")))
    except (OSError, json.JSONDecodeError, ConfigError) as e:
        print(f"invalid panel config: {e}", file=sys.stderr)
        return 2

    payload = None
    if args.recheck_state:
        state_path = pathlib.Path(args.recheck_state).expanduser()
        state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else None
        payload = should_recheck(
            state, config, now=_parse_now(args.now), min_interval_days=args.min_interval_days
        ).to_dict()
    elif args.roles:
        payload = role_evidence(config)
    elif args.show:
        payload = public_view(config)
    elif args.validate:
        payload = {
            "ok": True,
            "version": config.version,
            "config_digest": config.digest,
            "settlement_panel": config.settlement_panel,
            "panels": {name: len(panel.members) for name, panel in config.panels.items()},
        }
    else:
        print("nothing to do: pass --show, --roles, --validate or --recheck-state", file=sys.stderr)
        return 2

    print(json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True), file=out)
    return 0


def main() -> None:
    raise SystemExit(run())


if __name__ == "__main__":
    main()
