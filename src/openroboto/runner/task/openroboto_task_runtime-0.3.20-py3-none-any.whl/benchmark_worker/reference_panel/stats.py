"""区分度 D 与五类分档的纯函数。

口径见 OPE-115 / 《Agent Robotics 双赛道子网》v1.2 §5.2：

    D = max(0, L_a − U_b)

``a`` / ``b`` 是预登记的 best / worst；``L_a`` 是 a 的成功率**下**置信界，
``U_b`` 是 b 的**上**置信界，区间用 Wilson score interval（95%）。
每题每模型 50 局，少于 20 局标「证据不足」并且**不结算 D**；样本够但两个
区间仍重叠时同样 ``D = 0``、证据不足、进补测队列。

这里只做算术：不读配置、不碰 I/O、不认识 runner。reference panel 的执行层
只负责把每局的成败数出来，换成 ``(successes, trials)`` 再调进来。
"""

from __future__ import annotations

import math
import statistics
from dataclasses import dataclass, field
from typing import Mapping, Sequence

#: 95% 双侧标准正态分位。写成常数而不是每次算，是为了让结果逐位稳定。
WILSON_Z_95 = 1.959963984540054

#: 低于这个局数就标「证据不足」，不结算 D。
MIN_TRIALS = 20

#: 每题每模型的目标局数（配置里的 trials 默认值）。
DEFAULT_TRIALS = 50

#: 五类分档的阈值（v1.2 §5.2）。
EASY_P = 0.9
FRONTIER_P = 0.1

#: 后端 ``tasks.category`` 的白名单（0029_task_track 迁移）。分档结果必须落
#: 在这几个词里，前端和状态机都按它筛。
CATEGORIES = ("too_easy", "frontier", "noise", "suspicious", "discriminative")

#: 分档结论落到题状态机的去向（OPE-113）。``pending_recheck`` 不是终态：
#: 这题还要补测，补测前既不计分也不退役。
DISPOSITIONS = ("retired", "frontier", "suspicious", "in_pool", "pending_recheck")


def wilson_interval(successes: int, trials: int, z: float = WILSON_Z_95) -> tuple[float, float]:
    """Wilson score interval（默认 95%）。

    比「p ± z·sqrt(p(1-p)/n)」适合小样本和 p 接近 0/1 的情形——参照组每题
    只有 50 局，正是这两种情形。返回值夹在 [0, 1]。
    """
    if trials <= 0:
        raise ValueError("trials must be positive")
    if successes < 0 or successes > trials:
        raise ValueError(f"successes must be in [0, trials], got {successes}/{trials}")
    if z <= 0:
        raise ValueError("z must be positive")

    p = successes / trials
    z2 = z * z
    denominator = 1.0 + z2 / trials
    center = (p + z2 / (2.0 * trials)) / denominator
    half = z * math.sqrt(p * (1.0 - p) / trials + z2 / (4.0 * trials * trials)) / denominator
    return (max(0.0, center - half), min(1.0, center + half))


def bonferroni_z(pairs: int, alpha: float = 0.05) -> float:
    """``pairs`` 对同时比较时的单对置信界（Bonferroni 校正）。

    预登记固定一对（``pairs=1``）时就是普通的 95% 分位。只有调用方临时比多
    对才需要传更大的 ``pairs``；结果里会记下用了哪个 z，便于复算。
    """
    if pairs < 1:
        raise ValueError("pairs must be >= 1")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must be in (0, 1)")
    if pairs == 1:
        return WILSON_Z_95
    return statistics.NormalDist().inv_cdf(1.0 - alpha / (2.0 * pairs))


@dataclass(frozen=True)
class Discrimination:
    """一道题在一对 (best, worst) 上的区分度。

    ``settleable=False`` 时 ``d`` 一律为 0，且 ``needs_recheck=True``：
    * ``insufficient_trials`` —— 任一方少于 ``min_trials`` 局；
    * ``intervals_overlap`` —— 样本够，但 ``L_a <= U_b``。
    """

    d: float
    lower_best: float
    upper_worst: float
    settleable: bool
    reason: str
    needs_recheck: bool
    best_rate: float
    worst_rate: float
    z: float
    pairs: int

    def to_dict(self) -> dict:
        return {
            "d": round(self.d, 6),
            "lower_best": round(self.lower_best, 6),
            "upper_worst": round(self.upper_worst, 6),
            "settleable": self.settleable,
            "reason": self.reason,
            "needs_recheck": self.needs_recheck,
            "best_rate": round(self.best_rate, 6),
            "worst_rate": round(self.worst_rate, 6),
            "z": round(self.z, 6),
            "pairs": self.pairs,
        }


def discrimination(
    best_successes: int,
    best_trials: int,
    worst_successes: int,
    worst_trials: int,
    *,
    min_trials: int = MIN_TRIALS,
    pairs: int = 1,
    alpha: float = 0.05,
) -> Discrimination:
    """``D = max(0, L_a − U_b)``。

    局数不足、或区间重叠时 ``D = 0`` 且 ``settleable=False``；此时调用方
    **不能**把 0 当成「测过了、没区分度」去发钱——它只是「还没测出来」。
    """
    if best_trials <= 0 or worst_trials <= 0:
        raise ValueError("trials must be positive")
    z = bonferroni_z(pairs, alpha=alpha)
    best_rate = best_successes / best_trials
    worst_rate = worst_successes / worst_trials

    if best_trials < min_trials or worst_trials < min_trials:
        return Discrimination(
            d=0.0,
            lower_best=0.0,
            upper_worst=0.0,
            settleable=False,
            reason="insufficient_trials",
            needs_recheck=True,
            best_rate=best_rate,
            worst_rate=worst_rate,
            z=z,
            pairs=pairs,
        )

    lower_best = wilson_interval(best_successes, best_trials, z)[0]
    upper_worst = wilson_interval(worst_successes, worst_trials, z)[1]
    if lower_best <= upper_worst:
        return Discrimination(
            d=0.0,
            lower_best=lower_best,
            upper_worst=upper_worst,
            settleable=False,
            reason="intervals_overlap",
            needs_recheck=True,
            best_rate=best_rate,
            worst_rate=worst_rate,
            z=z,
            pairs=pairs,
        )

    return Discrimination(
        d=max(0.0, lower_best - upper_worst),
        lower_best=lower_best,
        upper_worst=upper_worst,
        settleable=True,
        reason="",
        needs_recheck=False,
        best_rate=best_rate,
        worst_rate=worst_rate,
        z=z,
        pairs=pairs,
    )


def group_variance(rates: Sequence[float], trials: Sequence[int]) -> dict:
    """扣掉二项抽样噪声后的成员间标准差（**只用于分档和诊断**）。

    ``value = sqrt(max(0, var(p_i) − noise))``，``noise`` 取
    ``mean(p_i(1-p_i)/(n_i-1))``。它不替代 ``D``、也不进结算公式——
    OPE-116 只认 ``D``。这里存在的唯一理由是区分「噪声题」（大家一样烂或
    一样好，只是抛硬币）和「还没测出来」（区间重叠但成员间确有差异）。
    """
    if len(rates) != len(trials):
        raise ValueError("rates and trials must have the same length")
    if not rates:
        return {"observed": 0.0, "noise": 0.0, "value": 0.0}
    if len(rates) == 1:
        return {"observed": 0.0, "noise": 0.0, "value": 0.0}

    observed = statistics.pvariance(rates)
    noise_terms = []
    for p, n in zip(rates, trials):
        if n > 1:
            noise_terms.append(p * (1.0 - p) / (n - 1))
    noise = statistics.fmean(noise_terms) if noise_terms else 0.0
    return {
        "observed": observed,
        "noise": noise,
        "value": math.sqrt(max(0.0, observed - noise)),
    }


def pearson(xs: Sequence[float], ys: Sequence[float]) -> float | None:
    """皮尔逊相关系数；样本 < 3 或任一侧方差为 0 时返回 ``None``。

    2 个成员时相关系数只能是 ±1，没有信息量，所以「可疑」需要至少 3 个
    成员——这也是全组方差启用的同一个门槛。
    """
    if len(xs) != len(ys):
        raise ValueError("xs and ys must have the same length")
    n = len(xs)
    if n < 3:
        return None
    mx = statistics.fmean(xs)
    my = statistics.fmean(ys)
    dx = [x - mx for x in xs]
    dy = [y - my for y in ys]
    sx = math.sqrt(sum(v * v for v in dx))
    sy = math.sqrt(sum(v * v for v in dy))
    if sx == 0.0 or sy == 0.0:
        return None
    return sum(a * b for a, b in zip(dx, dy)) / (sx * sy)


@dataclass(frozen=True)
class Classification:
    """一道题按 ``settlement_panel`` 的 D 和 p 得到的分类。

    ``category`` 是后端 ``tasks.category`` 的取值；``None`` = 证据不足，
    分类暂时写不出来（不是「没问题」，是「还不知道」）。
    """

    category: str | None
    disposition: str
    needs_recheck: bool
    reason: str
    discrimination: float | None
    rates: Mapping[str, float] = field(default_factory=dict)
    variance: Mapping[str, float] = field(default_factory=dict)
    retired_candidate: bool = False

    def to_dict(self) -> dict:
        return {
            "category": self.category,
            "disposition": self.disposition,
            "needs_recheck": self.needs_recheck,
            "reason": self.reason,
            "discrimination": None if self.discrimination is None else round(self.discrimination, 6),
            "rates": {k: round(v, 6) for k, v in self.rates.items()},
            "variance": {k: round(v, 6) for k, v in self.variance.items()},
            "retired_candidate": self.retired_candidate,
        }


def classify_task(
    member_scores: Mapping[str, tuple[int, int]],
    *,
    best: str,
    worst: str,
    ability: Mapping[str, float] | None = None,
    min_trials: int = MIN_TRIALS,
    easy: float = EASY_P,
    frontier: float = FRONTIER_P,
    variance_epsilon: float = 1e-9,
    pairs: int = 1,
) -> Classification:
    """五类分档（只用结算 panel 的成绩）。

    分档语义为 panel-min-success/v2；后端 policy_version 同时绑定算法语义与参数。

    ``member_scores`` 是 ``{member_id: (successes, trials)}``，``ability`` 是
    成员跨题的**总分**（判「可疑」用）。判定顺序：

    1. 证据不足（任一结算成员少于 ``min_trials``）→ 不分类，进补测；
    2. 太简单（结算 panel 最低 p ≥ 0.9）→ ``too_easy`` / ``retired``；
    3. 前沿池（所有成员 p ≤ 0.1）→ ``frontier`` / ``frontier``；
    4. 可疑（≥ 3 成员且本题成绩与成员总分负相关）→ ``suspicious``；
    5. ``D > 0`` → ``discriminative`` / ``in_pool``；
    6. ``D = 0`` 且全组方差 ≈ 0 → ``noise`` / ``retired``；
    7. 其余（区间重叠，但成员间有差异）→ 证据不足，进补测。

    「太简单」先于「前沿池」：两者不会同时成立（best 不可能既 ≥0.9 又 ≤0.1）。
    """
    if best not in member_scores:
        raise ValueError(f"unknown best member {best!r}")
    if worst not in member_scores:
        raise ValueError(f"unknown worst member {worst!r}")
    if not member_scores:
        raise ValueError("member_scores is empty")

    trials = {name: int(t) for name, (_, t) in member_scores.items()}
    rates = {name: (s / t if t > 0 else 0.0) for name, (s, t) in member_scores.items()}
    variance = group_variance(list(rates.values()), list(trials.values()))

    # 1. 证据不足：连太简单都判不了。别把「没跑够」写成任何一类的结论。
    if any(n < min_trials for n in trials.values()):
        return Classification(
            category=None,
            disposition="pending_recheck",
            needs_recheck=True,
            reason="insufficient_trials",
            discrimination=None,
            rates=rates,
            variance=variance,
        )

    # 2. 太简单：结算 panel 的所有成员均已达到门槛，才可称为普遍做会。
    if min(rates.values()) >= easy:
        return Classification(
            category="too_easy",
            disposition="retired",
            needs_recheck=False,
            reason=f"min panel rate {min(rates.values()):.3f} >= {easy}",
            discrimination=0.0,
            rates=rates,
            variance=variance,
            retired_candidate=True,
        )

    # 3. 前沿池：所有成员都 ≤ 0.1。题目留着，等更强的模型出现再补发。
    if all(rate <= frontier for rate in rates.values()):
        return Classification(
            category="frontier",
            disposition="frontier",
            needs_recheck=False,
            reason=f"all rates <= {frontier}",
            discrimination=0.0,
            rates=rates,
            variance=variance,
        )

    best_s, best_n = member_scores[best]
    worst_s, worst_n = member_scores[worst]
    disc = discrimination(best_s, best_n, worst_s, worst_n, min_trials=min_trials, pairs=pairs)

    if disc.settleable:
        # 4. 可疑：强模型反而做得差（与成员总分负相关）。至少 3 个成员才算
        #    得出相关系数；2 个成员时它恒为 ±1，没有意义。
        correlation = None
        if ability is not None and len(member_scores) >= 3 and set(ability) >= set(member_scores):
            correlation = pearson(
                [rates[name] for name in member_scores],
                [ability[name] for name in member_scores],
            )
        if correlation is not None and correlation < 0:
            return Classification(
                category="suspicious",
                disposition="suspicious",
                needs_recheck=False,
                reason=f"rates correlate with member totals at {correlation:.3f}",
                discrimination=disc.d,
                rates=rates,
                variance=variance,
            )

        # 5. 有区分度。
        return Classification(
            category="discriminative",
            disposition="in_pool",
            needs_recheck=False,
            reason=f"D={disc.d:.3f}",
            discrimination=disc.d,
            rates=rates,
            variance=variance,
        )

    # 6. 噪声题：谁都做不对/都做对，差异全在抽样噪声里。方差只在这里参与
    #    分档，不参与结算（结算只认 D）。
    if disc.reason == "intervals_overlap" and variance["value"] <= variance_epsilon:
        return Classification(
            category="noise",
            disposition="retired",
            needs_recheck=False,
            reason="D=0 and group variance is within sampling noise",
            discrimination=0.0,
            rates=rates,
            variance=variance,
            retired_candidate=True,
        )

    # 7. 区间重叠但成员间确有差异：证据不足，进补测队列。
    return Classification(
        category=None,
        disposition="pending_recheck",
        needs_recheck=True,
        reason=disc.reason,
        discrimination=None,
        rates=rates,
        variance=variance,
    )
