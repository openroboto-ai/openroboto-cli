"""A reference-panel run manifest: the envelope the backend verifies.

The backend (`openroboto-backend` `app.domain.reference_panel`) recomputes
the same canonical JSON and `trials_digest`; this module is the validator
half of that contract. It deliberately does not import backend code.

`trials_digest` covers every trial field that affects scoring, including
`child_root`, `instance`, `error` and `events_digest`. Raw episode events are
not repeated here (the backend receives them in the report body), but their
digest is bound by this signature.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from typing import Any

from agent_evidence.ed25519 import sign as ed25519_sign
from agent_evidence.ed25519 import verify as ed25519_verify

PANEL_MANIFEST_VERSION = 1

_TRIAL_FIELDS = (
    "trial",
    "success",
    "steps",
    "model_calls",
    "wall_ms",
    "child_root",
    "error",
    "instance",
    "events_digest",
)


def canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def trials_digest(members: Sequence[Mapping[str, Any]]) -> str:
    """Digest of the full trial rows, including evidence bindings."""
    payload = [
        {
            "member": member["member"],
            "member_kind": member["member_kind"],
            "trials": [
                {field: row.get(field) for field in _TRIAL_FIELDS}
                for row in member["trials"]
            ],
        }
        for member in members
    ]
    return canonical_sha256(payload)


def manifest_payload(manifest: Mapping[str, Any]) -> bytes:
    body = {key: value for key, value in manifest.items() if key != "signature"}
    return canonical_json(body).encode("utf-8")


def manifest_hash(manifest: Mapping[str, Any]) -> str:
    return hashlib.sha256(manifest_payload(manifest)).hexdigest()


def build_manifest(
    *,
    task_id: str,
    run_id: str,
    package_digest: str,
    config_version: str,
    config_digest: str,
    panel: str,
    settlement: bool,
    node_id: str,
    key_id: str,
    roles: Mapping[str, str],
    members: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    return {
        "version": PANEL_MANIFEST_VERSION,
        "task_id": task_id,
        "run_id": run_id,
        "package_digest": package_digest,
        "config_version": config_version,
        "config_digest": config_digest,
        "panel": panel,
        "settlement": bool(settlement),
        "node_id": node_id,
        "key_id": key_id,
        "algorithm": "ed25519",
        "roles": dict(roles),
        "members": [
            {"member": member["member"], "member_kind": member["member_kind"]}
            for member in members
        ],
        "trials_digest": trials_digest(members),
    }


def sign_manifest(manifest: Mapping[str, Any], seed: bytes) -> dict[str, Any]:
    """用 32 字节 Ed25519 seed 签名；与 validator 证据根同一实现。"""
    body = dict(manifest)
    body["signature"] = ed25519_sign(seed, manifest_payload(body)).hex()
    return body


def verify_manifest(manifest: Mapping[str, Any], public_key_hex: str) -> bool:
    signature = str(manifest.get("signature") or "")
    try:
        return ed25519_verify(
            bytes.fromhex(public_key_hex),
            manifest_payload(manifest),
            bytes.fromhex(signature),
        )
    except ValueError:
        return False


__all__ = [
    "PANEL_MANIFEST_VERSION",
    "build_manifest",
    "canonical_json",
    "canonical_sha256",
    "manifest_hash",
    "manifest_payload",
    "sign_manifest",
    "trials_digest",
    "verify_manifest",
]
