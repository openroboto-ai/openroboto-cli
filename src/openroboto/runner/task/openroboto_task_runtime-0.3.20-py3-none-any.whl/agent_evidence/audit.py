"""抽查审计日志 | Append-only audit log for sampling decisions and reviews.

抽查结论不能只留在某次进程的内存里。这里用一条哈希链把
``sampling.audit`` / ``sampling.finding`` / ``sampling.review`` 串起来:

    hash = sha256(prev || canonical_json(record without hash))

日志本身不签名(签名根属于各 party 的证据链);它解决的是**可追溯**:
第几条决定、谁在哪一刻写了什么、后来有没有被改过。日志损坏时拒绝继续
追加,避免把新结论接在一条坏链上。
"""

from __future__ import annotations

import copy
import json
import pathlib
from typing import Any, Iterable, Mapping

from .canonical import canonical_json, isoformat, parse_isoformat, sha256_hex, utcnow
from .events import GENESIS
from .result import CheckResult

AUDIT_VERSION = 1


class AuditLogError(ValueError):
    pass


class AuditLog:
    def __init__(self, path: str | pathlib.Path, *, create: bool = True) -> None:
        self.path = pathlib.Path(path).expanduser()
        self._records: list[dict[str, Any]] = []
        if self.path.exists() and self.path.stat().st_size:
            self._records = self._load()
            check = verify_audit_log(self._records)
            if not check.ok:
                raise AuditLogError(
                    "existing audit log failed verification; refusing to append: "
                    + "; ".join(check.errors[:3])
                )
        elif create:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text("", encoding="utf-8")

    def _load(self) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        for line_number, line in enumerate(self.path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except ValueError as exc:
                raise AuditLogError(f"{self.path}:{line_number}: not JSON: {exc}") from exc
            if not isinstance(record, dict):
                raise AuditLogError(f"{self.path}:{line_number}: record must be an object")
            records.append(record)
        return records

    @property
    def records(self) -> tuple[dict[str, Any], ...]:
        return tuple(copy.deepcopy(record) for record in self._records)

    def append(
        self,
        kind: str,
        payload: Mapping[str, Any] | None = None,
        *,
        at: str | None = None,
    ) -> dict[str, Any]:
        if not isinstance(kind, str) or not kind:
            raise AuditLogError("kind must be a non-empty string")
        if payload is not None and not isinstance(payload, Mapping):
            raise AuditLogError("payload must be an object")
        at_text = at or isoformat(utcnow())
        try:
            parse_isoformat(at_text)
        except ValueError as exc:
            raise AuditLogError("at is not ISO-8601") from exc

        previous = self._records[-1]["hash"] if self._records else GENESIS
        record: dict[str, Any] = {
            "v": AUDIT_VERSION,
            "seq": len(self._records),
            "at": at_text,
            "kind": kind,
            "payload": dict(payload or {}),
            "prev": previous,
        }
        record["hash"] = sha256_hex(previous + canonical_json(record))
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(canonical_json(record) + "\n")
            handle.flush()
        self._records.append(record)
        return copy.deepcopy(record)


def verify_audit_log(records: Iterable[Mapping[str, Any]]) -> CheckResult:
    result = CheckResult()
    items = [dict(record) for record in records]
    if not items:
        result.add_warning("audit log is empty")
        return result
    previous = GENESIS
    for expected_seq, record in enumerate(items):
        where = f"audit seq {record.get('seq')!r}"
        if record.get("v") != AUDIT_VERSION:
            result.add_error(f"{where}: unsupported version")
        if record.get("seq") != expected_seq:
            result.add_error(f"{where}: expected seq {expected_seq}")
        if record.get("prev") != previous:
            result.add_error(f"{where}: prev mismatch")
        if not isinstance(record.get("kind"), str) or not record.get("kind"):
            result.add_error(f"{where}: kind must be a non-empty string")
        if not isinstance(record.get("payload"), Mapping):
            result.add_error(f"{where}: payload must be an object")
        try:
            parse_isoformat(str(record.get("at")))
        except ValueError:
            result.add_error(f"{where}: at is not ISO-8601")
        body = {key: value for key, value in record.items() if key != "hash"}
        computed = sha256_hex(previous + canonical_json(body))
        if record.get("hash") != computed:
            result.add_error(f"{where}: hash mismatch")
        previous = str(record.get("hash") or computed)
    result.details.update({"records": len(items), "root": previous})
    return result


__all__ = ["AUDIT_VERSION", "AuditLog", "AuditLogError", "verify_audit_log"]
