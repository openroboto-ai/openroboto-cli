"""L0–L3 抽查与不可预测选择 | Sampling with commit–reveal.

核心约束:**矿工在提交前不能知道自己会不会被抽中**。

做法是提交/揭示两段:

1. **提交**:记录 ``commitment = sha256(canonical({run_id, job_id, chain_root,
   cohort, anomaly, submitted_at...}))``。此刻抽查 secret 还不存在。
2. **揭示**:epoch 关闭时才生成 32 字节 secret,并对每条 commitment 计算
   ``HMAC-SHA256(secret, "<level>|<commitment>")``。取前 8 字节除以 ``2^64``
   与层比例比较,小于比例即抽中。

secret 在 ``close()`` 前不存在于对象里,所以提交阶段无法预判;关闭后 secret
写进审计记录,任何人可以用同一份 commitment 重算出同样的结论。

L0 100% 覆盖;L1 按新矿工 100% / 成熟代单 10%;L2 随机 + 异常;L3 是周期性
红队活动,按 run 抽样不适用。L1/L2 发现异常只冻结结算并进复核,**不自动判
作弊**。
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
from dataclasses import dataclass
from typing import Any, Mapping

from .canonical import canonical_sha256, iso_plus_days, isoformat, parse_isoformat, utcnow
from .policy import EvidencePolicy
from .result import CheckResult

COHORTS = ("new_miner", "mature")
LEVELS = ("L0", "L1", "L2", "L3")
FINDING_LEVELS = ("L1", "L2", "L3")
SECRET_BYTES = 32
_COMMITMENT_FIELDS = ("run_id", "job_id", "chain_root", "cohort", "anomaly", "anomaly_codes", "submitted_at")


class SamplingError(ValueError):
    pass


def _check_hex64(value: Any, name: str) -> str:
    if not isinstance(value, str) or len(value) != 64 or any(ch not in "0123456789abcdef" for ch in value):
        raise SamplingError(f"{name} must be a 64-char lowercase sha256 hex")
    return value


def _policy_snapshot(policy: EvidencePolicy) -> dict[str, Any]:
    return {
        "version": policy.version,
        "l1_new_miner_rate": policy.l1_new_miner_rate,
        "l1_mature_generation_rate": policy.l1_mature_generation_rate,
        "l2_random_rate": policy.l2_random_rate,
        "sampling_audit_days": policy.sampling_audit_days,
        "freeze_on_finding": policy.freeze_on_finding,
        "auto_cheat_verdict": policy.auto_cheat_verdict,
    }


def _score(secret: bytes, level: str, commitment: str) -> str:
    return hmac.new(secret, f"{level}|{commitment}".encode(), hashlib.sha256).hexdigest()


def _selected(score_hex: str, rate: float) -> bool:
    if rate >= 1.0:
        return True
    if rate <= 0.0:
        return False
    numerator = int(score_hex[:16], 16)
    return numerator / float(2**64) < rate


def _decide(
    *,
    secret: bytes,
    commitment: str,
    cohort: str,
    anomaly: bool,
    anomaly_codes: list[str],
    policy: Mapping[str, Any],
) -> dict[str, Any]:
    l1_score = _score(secret, "L1", commitment)
    l2_score = _score(secret, "L2", commitment)
    l1_rate = float(policy["l1_new_miner_rate"] if cohort == "new_miner" else policy["l1_mature_generation_rate"])
    l2_rate = float(policy["l2_random_rate"])
    l1_selected = _selected(l1_score, l1_rate)
    l2_random = _selected(l2_score, l2_rate)
    l2_selected = bool(anomaly or l2_random)

    if cohort == "new_miner":
        l1_reason = f"new miner: {l1_rate:.0%} sample"
    else:
        l1_reason = f"mature generation: {l1_rate:.0%} sample"
    l1_reason += "; selected" if l1_selected else "; not selected"

    if anomaly:
        l2_reason = "anomaly flag: " + (", ".join(anomaly_codes) or "unspecified")
    elif l2_selected:
        l2_reason = f"random: {l2_rate:.2%} sample; selected"
    else:
        l2_reason = f"random: {l2_rate:.2%} sample; not selected"

    return {
        "decisions": {"L0": True, "L1": l1_selected, "L2": l2_selected, "L3": False},
        "scores": {"L0": None, "L1": l1_score, "L2": l2_score, "L3": None},
        "reasons": {
            "L0": "100% coverage",
            "L1": l1_reason,
            "L2": l2_reason,
            "L3": "periodic red-team campaign (not per-record)",
        },
    }


def _commitment(record: Mapping[str, Any]) -> str:
    basis = {field: record.get(field) for field in _COMMITMENT_FIELDS}
    return canonical_sha256(basis)


@dataclass
class SamplingEpoch:
    """一个抽样 epoch。提交阶段拿不到 secret,只能记录 commitment。"""

    epoch_id: str
    policy: EvidencePolicy
    opened_at: str | None = None

    def __post_init__(self) -> None:
        if not self.epoch_id:
            raise SamplingError("epoch_id must not be empty")
        self._opened_at = self.opened_at or isoformat(utcnow())
        self._records: list[dict[str, Any]] = []
        self._secret: bytes | None = None
        self._closed = False

    @property
    def closed(self) -> bool:
        return self._closed

    @property
    def secret_available(self) -> bool:
        """关闭前恒为 False;抽查结论不可能在提交阶段算出来。"""

        return self._secret is not None

    def commit(
        self,
        run_id: str,
        chain_root: str,
        *,
        cohort: str = "mature",
        anomaly: bool = False,
        job_id: str | None = None,
        submitted_at: str | None = None,
    ) -> dict[str, Any]:
        if self._closed:
            raise SamplingError("epoch is already closed")
        if not isinstance(run_id, str) or not run_id:
            raise SamplingError("run_id must be a non-empty string")
        if any(record["run_id"] == run_id for record in self._records):
            raise SamplingError(f"run_id {run_id!r} already committed in this epoch")
        _check_hex64(chain_root, "chain_root")
        if cohort not in COHORTS:
            raise SamplingError(f"cohort must be one of {COHORTS}")
        record = {
            "run_id": run_id,
            "job_id": job_id,
            "chain_root": chain_root,
            "cohort": cohort,
            "anomaly": bool(anomaly),
            "anomaly_codes": [],
            "submitted_at": submitted_at or isoformat(utcnow()),
        }
        record["commitment"] = _commitment(record)
        self._records.append(record)
        return dict(record)

    def flag_anomaly(self, run_id: str, code: str, *additional_codes: str) -> dict[str, Any]:
        """关闭前登记异常,强制 L2;commitment 会随异常码重算。"""

        if self._closed:
            raise SamplingError("epoch is already closed")
        codes = [code, *additional_codes]
        if not all(isinstance(item, str) and item for item in codes):
            raise SamplingError("anomaly codes must be non-empty strings")
        for record in self._records:
            if record["run_id"] != run_id:
                continue
            record["anomaly"] = True
            for item in codes:
                if item not in record["anomaly_codes"]:
                    record["anomaly_codes"].append(item)
            record["commitment"] = _commitment(record)
            return dict(record)
        raise SamplingError(f"unknown run_id {run_id!r}")

    def close(self, *, secret: bytes | str | None = None, closed_at: str | None = None) -> dict[str, Any]:
        if self._closed:
            raise SamplingError("epoch is already closed")
        if secret is None:
            secret_bytes = secrets.token_bytes(SECRET_BYTES)
        elif isinstance(secret, str):
            try:
                secret_bytes = bytes.fromhex(secret)
            except ValueError as exc:
                raise SamplingError("secret is not hex") from exc
        else:
            secret_bytes = bytes(secret)
        if len(secret_bytes) != SECRET_BYTES:
            raise SamplingError(f"secret must be {SECRET_BYTES} bytes")

        closed_at_text = closed_at or isoformat(utcnow())
        try:
            closed_dt = parse_isoformat(closed_at_text)
        except ValueError as exc:
            raise SamplingError("closed_at is not ISO-8601") from exc

        snapshot = _policy_snapshot(self.policy)
        records: list[dict[str, Any]] = []
        for record in self._records:
            outcome = _decide(
                secret=secret_bytes,
                commitment=record["commitment"],
                cohort=record["cohort"],
                anomaly=record["anomaly"],
                anomaly_codes=list(record["anomaly_codes"]),
                policy=snapshot,
            )
            records.append(
                {
                    **record,
                    **outcome,
                    "outcome": "pending",
                    "freeze_settlement": False,
                    "retain_until": iso_plus_days(closed_dt, self.policy.sampling_audit_days),
                }
            )

        audit: dict[str, Any] = {
            "version": 1,
            "kind": "sampling.audit",
            "epoch_id": self.epoch_id,
            "opened_at": self._opened_at,
            "closed_at": closed_at_text,
            "commitment_algorithm": "sha256(canonical_json({" + ",".join(_COMMITMENT_FIELDS) + "}))",
            "decision_algorithm": "HMAC-SHA256(secret, '<level>|<commitment>')[0:8] / 2^64 < rate",
            "policy": snapshot,
            "secret": secret_bytes.hex(),
            "records": records,
            "retain_until": iso_plus_days(closed_dt, self.policy.sampling_audit_days),
            "finding_policy": {"freeze_settlement": True, "auto_cheat_verdict": False},
        }
        audit["audit_hash"] = canonical_sha256(audit)
        self._secret = secret_bytes
        self._closed = True
        return audit


def verify_sampling_audit(
    audit: Mapping[str, Any],
    *,
    policy: EvidencePolicy | None = None,
) -> CheckResult:
    """重算审计哈希、每条 commitment、每个抽样结论与保留期。"""

    result = CheckResult()
    try:
        audit_version = int(audit.get("version", 0))
    except (TypeError, ValueError):
        audit_version = -1
    if audit_version != 1:
        result.add_error(f"unsupported audit version {audit.get('version')!r}")
    required = ("epoch_id", "opened_at", "closed_at", "policy", "secret", "records", "audit_hash")
    missing = [field for field in required if field not in audit]
    if missing:
        result.add_error(f"audit missing fields: {', '.join(missing)}")
        return result

    body = {key: value for key, value in audit.items() if key != "audit_hash"}
    try:
        computed_audit_hash = canonical_sha256(body)
    except (TypeError, ValueError):
        result.add_error("audit record is not canonical-JSON serializable")
        return result
    if audit.get("audit_hash") != computed_audit_hash:
        result.add_error("audit_hash mismatch (audit record modified)")

    try:
        secret = bytes.fromhex(str(audit["secret"]))
    except ValueError:
        result.add_error("secret is not hex")
        return result
    if len(secret) != SECRET_BYTES:
        result.add_error(f"secret must be {SECRET_BYTES} bytes")
        return result

    snapshot = audit.get("policy")
    if not isinstance(snapshot, Mapping):
        result.add_error("audit.policy must be an object")
        return result
    snapshot_ok = True
    for key in ("l1_new_miner_rate", "l1_mature_generation_rate", "l2_random_rate"):
        value = snapshot.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0.0 <= float(value) <= 1.0:
            result.add_error(f"audit policy {key} must be a rate in [0,1]")
            snapshot_ok = False
    audit_days = snapshot.get("sampling_audit_days")
    if isinstance(audit_days, bool) or not isinstance(audit_days, int) or audit_days < 1:
        result.add_error("audit policy sampling_audit_days must be an integer >= 1")
        snapshot_ok = False
    if not snapshot_ok:
        return result
    if policy is not None:
        expected = _policy_snapshot(policy)
        for key, value in expected.items():
            if snapshot.get(key) != value:
                result.add_error(f"audit policy {key}={snapshot.get(key)!r} != current {value!r}")

    try:
        closed_dt = parse_isoformat(str(audit["closed_at"]))
    except ValueError:
        result.add_error("closed_at is not ISO-8601")
        return result

    records = audit.get("records")
    if not isinstance(records, list):
        result.add_error("audit.records must be a list")
        return result

    counts = {"L0": 0, "L1": 0, "L2": 0, "L3": 0}
    for index, record in enumerate(records):
        if not isinstance(record, Mapping):
            result.add_error(f"records[{index}] must be an object")
            continue
        where = f"records[{index}] run_id={record.get('run_id')!r}"
        missing_fields = [field for field in _COMMITMENT_FIELDS if field not in record]
        if missing_fields:
            result.add_error(f"{where}: missing {', '.join(missing_fields)}")
            continue
        if record.get("cohort") not in COHORTS:
            result.add_error(f"{where}: unknown cohort {record.get('cohort')!r}")
            continue
        if not isinstance(record.get("anomaly_codes"), list):
            result.add_error(f"{where}: anomaly_codes must be a list")
            continue
        try:
            expected_commitment = _commitment(record)
        except (TypeError, ValueError):
            result.add_error(f"{where}: record is not canonical-JSON serializable")
            continue
        if record.get("commitment") != expected_commitment:
            result.add_error(f"{where}: commitment mismatch")
        outcome = _decide(
            secret=secret,
            commitment=expected_commitment,
            cohort=str(record.get("cohort")),
            anomaly=bool(record.get("anomaly")),
            anomaly_codes=[str(item) for item in record.get("anomaly_codes") or []],
            policy=snapshot,
        )
        if record.get("decisions") != outcome["decisions"]:
            result.add_error(f"{where}: decisions mismatch")
        if record.get("scores") != outcome["scores"]:
            result.add_error(f"{where}: scores mismatch")
        if record.get("reasons") != outcome["reasons"]:
            result.add_error(f"{where}: reasons mismatch")
        expected_retain = iso_plus_days(closed_dt, audit_days)
        if record.get("retain_until") != expected_retain:
            result.add_error(f"{where}: retain_until mismatch")
        decisions = record.get("decisions")
        if isinstance(decisions, Mapping):
            for level in LEVELS:
                if decisions.get(level) is True:
                    counts[level] += 1

    if audit.get("retain_until") != iso_plus_days(closed_dt, audit_days):
        result.add_error("audit.retain_until mismatch")

    result.details.update(
        {
            "epoch_id": audit.get("epoch_id"),
            "records": len(records),
            "selected": counts,
            "secret_hex_length": len(secret) * 2,
        }
    )
    return result


def record_finding(
    *,
    run_id: str,
    level: str,
    code: str,
    detail: Mapping[str, Any] | None = None,
    found_at: str | None = None,
    evidence_root: str | None = None,
    policy: EvidencePolicy,
) -> dict[str, Any]:
    """登记 L1/L2/L3 发现:冻结结算、进复核,**不**自动判作弊。"""

    if level not in FINDING_LEVELS:
        raise SamplingError(f"level must be one of {FINDING_LEVELS}")
    if not run_id or not code:
        raise SamplingError("run_id and code must not be empty")
    found_at_text = found_at or isoformat(utcnow())
    try:
        found_dt = parse_isoformat(found_at_text)
    except ValueError as exc:
        raise SamplingError("found_at is not ISO-8601") from exc
    if evidence_root is not None:
        _check_hex64(evidence_root, "evidence_root")
    if not policy.freeze_on_finding or policy.auto_cheat_verdict:
        raise SamplingError("policy must freeze settlements and must not auto-judge cheating")
    return {
        "version": 1,
        "kind": "sampling.finding",
        "run_id": run_id,
        "level": level,
        "code": code,
        "detail": dict(detail or {}),
        "found_at": found_at_text,
        "evidence_root": evidence_root,
        "action": "freeze_and_review",
        "freeze_settlement": True,
        "review_required": True,
        "cheating_verdict": None,
        "retain_until": iso_plus_days(found_dt, policy.sampling_audit_days),
    }


def resolve_finding(
    finding: Mapping[str, Any],
    *,
    reviewer: str,
    conclusion: str,
    notes: str | None = None,
    at: str | None = None,
    policy: EvidencePolicy,
) -> dict[str, Any]:
    """人工复核结论。``conclusion`` 由人给定,这里只记录,不做推断。"""

    if conclusion not in ("cleared", "confirmed_issue", "inconclusive"):
        raise SamplingError("conclusion must be cleared / confirmed_issue / inconclusive")
    if not reviewer:
        raise SamplingError("reviewer must not be empty")
    at_text = at or isoformat(utcnow())
    try:
        at_dt = parse_isoformat(at_text)
    except ValueError as exc:
        raise SamplingError("at is not ISO-8601") from exc
    return {
        "version": 1,
        "kind": "sampling.review",
        "run_id": finding.get("run_id"),
        "source_finding_code": finding.get("code"),
        "source_finding_at": finding.get("found_at"),
        "reviewer": reviewer,
        "conclusion": conclusion,
        "notes": notes,
        "reviewed_at": at_text,
        "freeze_settlement": conclusion == "inconclusive",
        "retain_until": iso_plus_days(at_dt, policy.sampling_audit_days),
    }


__all__ = [
    "COHORTS",
    "FINDING_LEVELS",
    "LEVELS",
    "SECRET_BYTES",
    "SamplingEpoch",
    "SamplingError",
    "record_finding",
    "resolve_finding",
    "verify_sampling_audit",
]
