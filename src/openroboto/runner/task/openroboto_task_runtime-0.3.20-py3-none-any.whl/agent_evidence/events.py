"""可复算的证据链 | Append-only, hash-chained evidence events.

每条事件满足 OPE-126 的字段要求::

    job_id / attempt_id / episode   作业、尝试、episode(可为 null)
    nonce                           事件级 128-bit 随机数(32 hex)
    job_nonce                       整条 job 共享的 128-bit nonce
    seq                             从 0 开始、连续
    ts_monotonic                    链内单调秒(相对链启动)
    recorded_at                     UTC 墙钟,只作审计锚点
    type                            事件类型
    payload_sha256                  payload 的 canonical JSON sha256
    payload                        原始 payload(保留期内);摘要模式可省略
    recorder                        记录者(谁写的这条事件)
    party                           签名方(执行者 / 网关 / 仿真服务)
    prev / hash                     前一条哈希与本条哈希

哈希公式与 ``agent_harness/events.py`` 一致::

    hash = sha256(prev || canonical_json(event without "hash"))

因此同一份 JSONL 不需要任何 validator 内部状态就能从头复算。
"""

from __future__ import annotations

import copy
import datetime as _dt
import json
import pathlib
import secrets
import time
from typing import Any, Callable, Iterable, Mapping

from .canonical import canonical_json, canonical_sha256, isoformat, parse_isoformat, sha256_hex

GENESIS = "0" * 64
EVENT_VERSION = 1
NONCE_HEX_CHARS = 32

#: 验链时必须存在的字段。``payload`` 在摘要模式下可以不在。
REQUIRED_EVENT_FIELDS = (
    "v",
    "job_id",
    "attempt_id",
    "episode",
    "party",
    "recorder",
    "seq",
    "nonce",
    "job_nonce",
    "ts_monotonic",
    "type",
    "payload_sha256",
    "prev",
    "hash",
)

Clock = Callable[[], float]
WallClock = Callable[[], _dt.datetime]
NonceFactory = Callable[[], str]


def _default_nonce() -> str:
    return secrets.token_hex(16)


def new_nonce() -> str:
    return _default_nonce()


def is_nonce(value: Any) -> bool:
    """事件级 nonce:32 位小写 hex。"""

    return (
        isinstance(value, str)
        and len(value) == NONCE_HEX_CHARS
        and all(ch in "0123456789abcdef" for ch in value)
    )


def is_job_nonce(value: Any) -> bool:
    """job 级 nonce:后端 ``binding.nonce`` 原样使用,只要非空。

    事件 nonce 由执行侧随机生成、固定 32 hex;job nonce 来自发单绑定,
    形状由 backend 决定,不在 validator 侧重新定义。
    """

    return isinstance(value, str) and bool(value.strip())


class EvidenceChain:
    """一条 party 在某个 job/attempt/episode 上写入的事件链。"""

    def __init__(
        self,
        *,
        job_id: str,
        attempt_id: str,
        party: str,
        episode: int | None = None,
        run_id: str | None = None,
        recorder: str | None = None,
        job_nonce: str | None = None,
        clock: Clock | None = None,
        wall_clock: WallClock | None = None,
        nonce_factory: NonceFactory | None = None,
        persist_path: str | pathlib.Path | None = None,
    ) -> None:
        for name, value in (("job_id", job_id), ("attempt_id", attempt_id), ("party", party)):
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string")
        if episode is not None and not isinstance(episode, int):
            raise ValueError("episode must be an int or None")
        if job_nonce is not None and not is_job_nonce(job_nonce):
            raise ValueError("job_nonce must be a non-empty string")

        self.job_id = job_id
        self.attempt_id = attempt_id
        self.party = party
        self.episode = episode
        self.run_id = run_id
        self.recorder = recorder or party
        self.job_nonce = job_nonce or _default_nonce()
        self._clock = clock or time.monotonic
        self._wall_clock = wall_clock or _dt.datetime.now
        self._nonce_factory = nonce_factory or _default_nonce
        self._started = self._clock()
        self._wall_anchor = self._as_utc(self._wall_clock())
        self._prev = GENESIS
        self._events: list[dict[str, Any]] = []
        self.persist_path = pathlib.Path(persist_path).expanduser() if persist_path else None
        if self.persist_path is not None:
            self.persist_path.parent.mkdir(parents=True, exist_ok=True)
            self.persist_path.write_text("", encoding="utf-8")

    # -- metadata ---------------------------------------------------------
    @staticmethod
    def _as_utc(value: _dt.datetime) -> _dt.datetime:
        if not isinstance(value, _dt.datetime):
            raise TypeError("wall_clock must return a datetime")
        if value.tzinfo is None:
            return value.replace(tzinfo=_dt.timezone.utc)
        return value.astimezone(_dt.timezone.utc)

    @property
    def wall_anchor(self) -> _dt.datetime:
        return self._wall_anchor

    @property
    def events(self) -> tuple[dict[str, Any], ...]:
        return tuple(copy.deepcopy(event) for event in self._events)

    @property
    def root(self) -> str:
        return self._prev

    @property
    def event_count(self) -> int:
        return len(self._events)

    def __iter__(self):
        """让 ``verify_chain(chain)`` / ``cross_check`` 直接接受链对象。"""

        return iter(self.events)

    def __len__(self) -> int:
        return len(self._events)

    def last_event(self) -> dict[str, Any] | None:
        return copy.deepcopy(self._events[-1]) if self._events else None

    # -- append -----------------------------------------------------------
    def append(
        self,
        kind: str,
        payload: Mapping[str, Any] | None = None,
        *,
        recorder: str | None = None,
        correlation_id: str | None = None,
        ts_monotonic: float | None = None,
        recorded_at: str | _dt.datetime | None = None,
        nonce: str | None = None,
        store_payload: bool = True,
    ) -> dict[str, Any]:
        """追加一条事件并返回其副本。

        ``store_payload=False`` 只落 payload hash(摘要模式);链仍然可验,
        但无法再重算 payload hash,只能依赖签名根与事件哈希。
        """

        if not isinstance(kind, str) or not kind.strip():
            raise ValueError("type must be a non-empty string")
        if payload is not None and not isinstance(payload, Mapping):
            raise ValueError("payload must be a mapping or None")
        body_payload = dict(payload or {})

        if ts_monotonic is None:
            ts_monotonic = round(self._clock() - self._started, 6)
        if not isinstance(ts_monotonic, (int, float)) or ts_monotonic < 0:
            raise ValueError("ts_monotonic must be a non-negative number")
        if recorded_at is None:
            recorded_at_text = isoformat(self._as_utc(self._wall_clock()))
        elif isinstance(recorded_at, _dt.datetime):
            recorded_at_text = isoformat(self._as_utc(recorded_at))
        else:
            recorded_at_text = isoformat(parse_isoformat(recorded_at))

        event_nonce = nonce or self._nonce_factory()
        if not is_nonce(event_nonce):
            raise ValueError(f"nonce must be {NONCE_HEX_CHARS} lowercase hex chars")

        event: dict[str, Any] = {
            "v": EVENT_VERSION,
            "job_id": self.job_id,
            "attempt_id": self.attempt_id,
            "episode": self.episode,
            "run_id": self.run_id,
            "party": self.party,
            "recorder": recorder or self.recorder,
            "seq": len(self._events),
            "nonce": event_nonce,
            "job_nonce": self.job_nonce,
            "ts_monotonic": ts_monotonic,
            "recorded_at": recorded_at_text,
            "type": kind,
            "payload_sha256": canonical_sha256(body_payload),
            "prev": self._prev,
        }
        if correlation_id is not None:
            event["correlation_id"] = str(correlation_id)
        if store_payload:
            event["payload"] = body_payload
        event["hash"] = sha256_hex(self._prev + canonical_json(event))

        self._prev = event["hash"]
        self._events.append(event)
        if self.persist_path is not None:
            with self.persist_path.open("a", encoding="utf-8") as handle:
                handle.write(canonical_json(event) + "\n")
                handle.flush()
        return copy.deepcopy(event)

    def to_jsonl(self, path: str | pathlib.Path) -> pathlib.Path:
        target = pathlib.Path(path).expanduser()
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", encoding="utf-8") as handle:
            for event in self._events:
                handle.write(canonical_json(event) + "\n")
        return target

    def metadata(self) -> dict[str, Any]:
        return {
            "job_id": self.job_id,
            "attempt_id": self.attempt_id,
            "episode": self.episode,
            "run_id": self.run_id,
            "party": self.party,
            "recorder": self.recorder,
            "job_nonce": self.job_nonce,
            "root": self.root,
            "event_count": self.event_count,
        }


def load_events(path: str | pathlib.Path) -> list[dict[str, Any]]:
    """读取 JSONL;空行忽略,格式错误带行号。"""

    source = pathlib.Path(path).expanduser()
    events: list[dict[str, Any]] = []
    for line_number, line in enumerate(source.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except ValueError as exc:
            raise ValueError(f"{source}:{line_number}: not JSON: {exc}") from exc
        if not isinstance(event, dict):
            raise ValueError(f"{source}:{line_number}: event must be a JSON object")
        events.append(event)
    return events


def events_to_jsonl(events: Iterable[Mapping[str, Any]], path: str | pathlib.Path) -> pathlib.Path:
    target = pathlib.Path(path).expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        for event in events:
            handle.write(canonical_json(dict(event)) + "\n")
    return target


# ---------------------------------------------------------------------------
# 与 agent_harness/events.py 的兼容
# ---------------------------------------------------------------------------
_LEGACY_CORRELATION_KEYS = ("call_id", "tool_call_id", "request_id")


def legacy_correlation_id(event: Mapping[str, Any]) -> str | None:
    """从 harness 事件里找一个跨 party 共享的关联 ID。

    ``tool_call`` / ``tool_result`` 用 ``call_id``;``model_call`` 用
    ``provider_meta.request_id``;其余返回 ``None``。新的 emitter 应在写入
    envelope 时显式传 ``correlation_id``,这个函数只用于迁移旧记录。
    """

    payload = event.get("payload") or {}
    if not isinstance(payload, Mapping):
        return None
    for key in _LEGACY_CORRELATION_KEYS:
        value = payload.get(key)
        if isinstance(value, str) and value:
            return value
    provider_meta = payload.get("provider_meta")
    if isinstance(provider_meta, Mapping):
        value = provider_meta.get("request_id")
        if isinstance(value, str) and value:
            return value
    # success_check 一类事件没有 call_id;同一 step 在 executor / simulator
    # 两侧是同一个动作,用 step 作关联键。model_call 兜底用 turn。
    for key in ("step", "turn"):
        value = payload.get(key)
        if isinstance(value, int) and not isinstance(value, bool):
            return f"{key}:{value}"
    return None


def append_legacy_event(
    chain: EvidenceChain,
    legacy_event: Mapping[str, Any],
    *,
    recorder: str | None = None,
) -> dict[str, Any]:
    """把一条 harness 事件包进新证据链。

    旧事件作为 ``payload["agent_harness_event"]`` 原样提交,所以内层链的任何
    改动都会改变外层 ``payload_sha256``。墙钟按链锚点 + 旧事件 ``ts`` 推出,
    保证 L0 的时钟检查不会把迁移记录误判成跳变。
    """

    if not isinstance(legacy_event, Mapping):
        raise ValueError("legacy event must be a mapping")
    kind = legacy_event.get("type")
    if not isinstance(kind, str) or not kind:
        raise ValueError("legacy event needs a non-empty type")
    legacy_ts = legacy_event.get("ts", 0.0)
    try:
        ts = float(legacy_ts)
    except (TypeError, ValueError):
        ts = 0.0
    recorded_at = chain.wall_anchor + _dt.timedelta(seconds=max(ts, 0.0))
    return chain.append(
        kind,
        {"agent_harness_event": dict(legacy_event)},
        recorder=recorder,
        correlation_id=legacy_correlation_id(legacy_event),
        ts_monotonic=max(ts, 0.0),
        recorded_at=recorded_at,
    )


def adapt_legacy_events(
    legacy_events: Iterable[Mapping[str, Any]],
    *,
    job_id: str,
    attempt_id: str,
    party: str,
    episode: int | None = None,
    run_id: str | None = None,
    job_nonce: str | None = None,
    recorder: str | None = None,
    clock: Clock | None = None,
    wall_clock: WallClock | None = None,
    nonce_factory: NonceFactory | None = None,
    persist_path: str | pathlib.Path | None = None,
) -> EvidenceChain:
    """把一条 harness 旧链整体升格为带 job/nonce/recorder 的新链。"""

    chain = EvidenceChain(
        job_id=job_id,
        attempt_id=attempt_id,
        party=party,
        episode=episode,
        run_id=run_id,
        recorder=recorder,
        job_nonce=job_nonce,
        clock=clock,
        wall_clock=wall_clock,
        nonce_factory=nonce_factory,
        persist_path=persist_path,
    )
    for event in legacy_events:
        append_legacy_event(chain, event)
    return chain


__all__ = [
    "GENESIS",
    "EVENT_VERSION",
    "NONCE_HEX_CHARS",
    "REQUIRED_EVENT_FIELDS",
    "EvidenceChain",
    "adapt_legacy_events",
    "append_legacy_event",
    "events_to_jsonl",
    "is_job_nonce",
    "is_nonce",
    "legacy_correlation_id",
    "load_events",
    "new_nonce",
]
