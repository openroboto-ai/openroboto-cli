"""规范化 JSON 与哈希 | Canonical JSON and hashing.

证据链的哈希必须跨语言、跨进程可复算,因此对象先转成**唯一**的字节序列再
哈希:键排序、无多余空白、禁止 NaN/Infinity。空串和空对象都有确定结果。

所有哈希一律小写 hex。时间一律 UTC ISO-8601(微秒精度,``Z`` 结尾)。
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
from typing import Any


def canonical_json(value: Any) -> str:
    """返回确定性的 JSON 文本(键排序、紧凑分隔符、UTF-8 原文)。"""

    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def sha256_hex(data: str | bytes) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def canonical_sha256(value: Any) -> str:
    """对象 canonical JSON 的 sha256。"""

    return sha256_hex(canonical_json(value))


def utcnow() -> _dt.datetime:
    return _dt.datetime.now(_dt.timezone.utc)


def isoformat(value: _dt.datetime) -> str:
    """UTC、微秒精度、``Z`` 结尾。"""

    if value.tzinfo is None:
        raise ValueError("datetime must be timezone-aware")
    return value.astimezone(_dt.timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def parse_isoformat(text: str) -> _dt.datetime:
    if not isinstance(text, str) or not text:
        raise ValueError("expected an ISO-8601 timestamp")
    return _dt.datetime.fromisoformat(text.replace("Z", "+00:00"))


def iso_plus_days(value: _dt.datetime, days: int) -> str:
    return isoformat(value + _dt.timedelta(days=days))
