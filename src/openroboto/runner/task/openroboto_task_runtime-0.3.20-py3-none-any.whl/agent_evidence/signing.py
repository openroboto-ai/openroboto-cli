"""三方签名根 | Per-party signed roots and job binding.

执行者(executor)、模型网关(gateway)、仿真服务(simulator)各自维护一条
证据链,并对自己的 **根哈希** 签名。根里绑定 ``job_id`` / ``job_nonce`` /
``job_digest``,validator 只要拿到三份根就能确认:

1. 三份根签的是同一个 job(同 id、同 nonce、同冻结配置摘要);
2. 每份签名都由该 party 登记的密钥签出;
3. 根哈希等于该 party 事件链的最后一个 ``hash``(可选,拿到链时做)。

测试网允许 ``mode="single"``:只有执行者签根,网关/仿真根缺失只告警不失败;
字段和校验逻辑与三方模式相同,上线时改 policy 开关即可,不用改代码。
"""

from __future__ import annotations

import json
import pathlib
import re
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from . import ed25519
from .canonical import canonical_json, isoformat, parse_isoformat, utcnow
from .events import GENESIS, EvidenceChain, is_job_nonce
from .result import CheckResult

PARTIES = ("executor", "gateway", "simulator")
SIGNING_MODES = ("single", "three_party")
ROOT_VERSION = 1
_HEX64 = re.compile(r"^[0-9a-f]{64}$")


class SigningError(ValueError):
    pass


@dataclass(frozen=True)
class Signer:
    """一个 party 的签名身份。``seed`` 是 32 字节私钥 seed。"""

    party: str
    key_id: str
    seed: bytes
    algorithm: str = "ed25519"

    def __post_init__(self) -> None:
        if not self.party:
            raise SigningError("party must not be empty")
        if not self.key_id:
            raise SigningError("key_id must not be empty")
        if self.algorithm != "ed25519":
            raise SigningError(f"unsupported algorithm {self.algorithm!r}")
        if len(self.seed) != ed25519.SEED_BYTES:
            raise SigningError(f"seed must be {ed25519.SEED_BYTES} bytes")

    @classmethod
    def generate(cls, party: str, key_id: str | None = None) -> Signer:
        key_id = key_id or f"{party}-{ed25519.generate_seed()[:4].hex()}"
        return cls(party=party, key_id=key_id, seed=ed25519.generate_seed())

    @classmethod
    def from_keyfile(cls, path: str | pathlib.Path) -> Signer:
        data = json.loads(pathlib.Path(path).expanduser().read_text(encoding="utf-8"))
        return cls(
            party=str(data["party"]),
            key_id=str(data["key_id"]),
            seed=bytes.fromhex(str(data["seed"])),
            algorithm=str(data.get("algorithm", "ed25519")),
        )

    @property
    def public_key(self) -> bytes:
        return ed25519.public_key_from_seed(self.seed)

    @property
    def public_key_hex(self) -> str:
        return self.public_key.hex()

    def sign(self, message: bytes) -> bytes:
        return ed25519.sign(self.seed, message)

    def sign_hex(self, message: bytes) -> str:
        return self.sign(message).hex()

    def keyfile(self) -> dict[str, Any]:
        return {
            "version": 1,
            "party": self.party,
            "key_id": self.key_id,
            "algorithm": self.algorithm,
            "seed": self.seed.hex(),
            "public_key": self.public_key_hex,
        }

    def write_keyfile(self, path: str | pathlib.Path) -> pathlib.Path:
        """写私钥文件(权限 0600)。生产应改用 HSM,不要落盘。"""

        target = pathlib.Path(path).expanduser()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(self.keyfile(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
        target.chmod(0o600)
        return target


class TrustStore:
    """party -> key_id -> 公钥。支持轮换:同名 party 可有多把历史密钥。"""

    def __init__(self, keys: Mapping[str, Mapping[str, Mapping[str, Any]]] | None = None) -> None:
        self._keys: dict[str, dict[str, dict[str, Any]]] = {}
        for party, party_keys in (keys or {}).items():
            for key_id, entry in party_keys.items():
                self.add(
                    party,
                    key_id,
                    str(entry["public_key"]),
                    algorithm=str(entry.get("algorithm", "ed25519")),
                )

    @classmethod
    def from_file(cls, path: str | pathlib.Path) -> TrustStore:
        data = json.loads(pathlib.Path(path).expanduser().read_text(encoding="utf-8"))
        return cls(data.get("keys") or {})

    def add(
        self,
        party: str,
        key_id: str,
        public_key_hex: str,
        *,
        algorithm: str = "ed25519",
    ) -> None:
        if algorithm != "ed25519":
            raise SigningError(f"unsupported algorithm {algorithm!r}")
        public_key = bytes.fromhex(public_key_hex)
        if len(public_key) != ed25519.PUBLIC_KEY_BYTES:
            raise SigningError(f"public_key must be {ed25519.PUBLIC_KEY_BYTES} bytes")
        self._keys.setdefault(party, {})[key_id] = {
            "algorithm": algorithm,
            "public_key": public_key_hex.lower(),
        }

    def public_key_hex(self, party: str, key_id: str) -> str | None:
        entry = self._keys.get(party, {}).get(key_id)
        return None if entry is None else str(entry["public_key"])

    def verify(
        self,
        party: str,
        key_id: str,
        algorithm: str,
        message: bytes,
        signature: bytes,
    ) -> tuple[bool, str]:
        entry = self._keys.get(party, {}).get(key_id)
        if entry is None:
            return False, f"unknown key: party={party!r} key_id={key_id!r}"
        if str(entry["algorithm"]) != algorithm:
            return False, f"algorithm mismatch for party={party!r} key_id={key_id!r}"
        public_key = bytes.fromhex(str(entry["public_key"]))
        if not ed25519.verify(public_key, message, signature):
            return False, f"bad signature for party={party!r} key_id={key_id!r}"
        return True, "ok"

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": 1,
            "keys": {
                party: {key_id: dict(entry) for key_id, entry in sorted(keys.items())}
                for party, keys in sorted(self._keys.items())
            },
        }

    def write(self, path: str | pathlib.Path) -> pathlib.Path:
        target = pathlib.Path(path).expanduser()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return target


def _chain_parts(
    chain_or_events: EvidenceChain | Iterable[Mapping[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if isinstance(chain_or_events, EvidenceChain):
        events = list(chain_or_events.events)
        metadata = chain_or_events.metadata()
    else:
        events = [dict(event) for event in chain_or_events]
        if not events:
            raise SigningError("cannot sign an empty event list")
        first = events[0]
        metadata = {
            "job_id": first.get("job_id"),
            "attempt_id": first.get("attempt_id"),
            "episode": first.get("episode"),
            "run_id": first.get("run_id"),
            "party": first.get("party"),
            "job_nonce": first.get("job_nonce"),
            "root": str(events[-1].get("hash") or GENESIS),
            "event_count": len(events),
        }
    return events, metadata


def sign_root(
    chain_or_events: EvidenceChain | Iterable[Mapping[str, Any]],
    signer: Signer,
    *,
    job_digest: str,
    job_nonce: str | None = None,
    attempt_id: str | None = None,
    episode: int | None = None,
    run_id: str | None = None,
    signed_at: str | None = None,
    policy_version: int = 1,
) -> dict[str, Any]:
    """对一条链的根签名,返回可直接 JSON 序列化的根。"""

    if signer.party not in PARTIES:
        raise SigningError(f"unknown party {signer.party!r}; expected one of {PARTIES}")
    if not _HEX64.match(job_digest or ""):
        raise SigningError("job_digest must be a 64-char lowercase sha256 hex")
    events, metadata = _chain_parts(chain_or_events)
    if not events:
        raise SigningError("cannot sign an empty chain")
    chain_party = metadata.get("party")
    if chain_party is not None and chain_party != signer.party:
        raise SigningError(f"signer party {signer.party!r} != chain party {chain_party!r}")

    resolved_nonce = job_nonce or metadata.get("job_nonce")
    if not resolved_nonce:
        raise SigningError("job_nonce is required")
    if not is_job_nonce(resolved_nonce):
        raise SigningError("job_nonce must be a non-empty string")
    first = events[0]
    if first.get("job_nonce") is not None and first.get("job_nonce") != resolved_nonce:
        raise SigningError("job_nonce does not match the chain")

    payload: dict[str, Any] = {
        "v": ROOT_VERSION,
        "job_id": metadata.get("job_id"),
        "job_nonce": resolved_nonce,
        "job_digest": job_digest,
        "attempt_id": attempt_id if attempt_id is not None else metadata.get("attempt_id"),
        "episode": episode if episode is not None else metadata.get("episode"),
        "run_id": run_id if run_id is not None else metadata.get("run_id"),
        "party": signer.party,
        "key_id": signer.key_id,
        "algorithm": signer.algorithm,
        "root": metadata.get("root") or str(events[-1]["hash"]),
        "event_count": len(events),
        "first_seq": int(events[0]["seq"]),
        "last_seq": int(events[-1]["seq"]),
        "signed_at": signed_at or isoformat(utcnow()),
        "policy_version": policy_version,
    }
    signature = signer.sign(canonical_json(payload).encode("utf-8")).hex()
    return {**payload, "signature": signature}


def verify_root(root: Mapping[str, Any], trust_store: TrustStore) -> CheckResult:
    result = CheckResult()
    required = (
        "v",
        "job_id",
        "job_nonce",
        "job_digest",
        "attempt_id",
        "party",
        "key_id",
        "algorithm",
        "root",
        "event_count",
        "first_seq",
        "last_seq",
        "signed_at",
        "signature",
    )
    missing = [key for key in required if key not in root]
    if missing:
        result.add_error(f"root missing fields: {', '.join(missing)}")
        return result
    try:
        version = int(root.get("v", 0))
    except (TypeError, ValueError):
        version = -1
    if version != ROOT_VERSION:
        result.add_error(f"unsupported root version {root.get('v')!r}")
    party = str(root["party"])
    if party not in PARTIES:
        result.add_error(f"unknown party {party!r}")
    if root["algorithm"] != "ed25519":
        result.add_error(f"unsupported signature algorithm {root['algorithm']!r}")
    if not isinstance(root.get("job_id"), str) or not root.get("job_id"):
        result.add_error("job_id must be a non-empty string")
    if not isinstance(root.get("attempt_id"), str) or not root.get("attempt_id"):
        result.add_error("attempt_id must be a non-empty string")
    if not is_job_nonce(root.get("job_nonce")):
        result.add_error("job_nonce must be a non-empty string")
    if not _HEX64.match(str(root["root"])):
        result.add_error("root must be a 64-char lowercase sha256 hex")
    if not _HEX64.match(str(root["job_digest"])):
        result.add_error("job_digest must be a 64-char lowercase sha256 hex")
    try:
        parse_isoformat(str(root["signed_at"]))
    except ValueError:
        result.add_error("signed_at is not ISO-8601")
    try:
        event_count = int(root["event_count"])
        first_seq = int(root["first_seq"])
        last_seq = int(root["last_seq"])
        if event_count < 1:
            result.add_error("a signed root must cover at least one event")
        elif first_seq != 0 or last_seq != event_count - 1:
            result.add_error(
                f"root seq range [{first_seq},{last_seq}] does not match event_count {event_count}"
            )
    except (TypeError, ValueError):
        result.add_error("event_count / first_seq / last_seq must be integers")

    try:
        signature = bytes.fromhex(str(root["signature"]))
    except ValueError:
        result.add_error("signature is not hex")
        return result
    body = {key: value for key, value in root.items() if key != "signature"}
    ok, reason = trust_store.verify(
        party,
        str(root["key_id"]),
        str(root["algorithm"]),
        canonical_json(body).encode("utf-8"),
        signature,
    )
    if not ok:
        result.add_error(reason)
    result.details.update(
        {
            "party": party,
            "key_id": root.get("key_id"),
            "root": root.get("root"),
            "event_count": root.get("event_count"),
        }
    )
    return result


def build_bundle(
    roots: Iterable[Mapping[str, Any]],
    *,
    mode: str | None = None,
) -> dict[str, Any]:
    """把各 party 的根收成一个 bundle。``mode`` 可显式指定以保留降级证据。"""

    ordered = sorted((dict(root) for root in roots), key=lambda item: str(item.get("party")))
    if not ordered:
        raise SigningError("bundle needs at least one root")
    job_id = ordered[0].get("job_id")
    job_nonce = ordered[0].get("job_nonce")
    job_digest = ordered[0].get("job_digest")
    for root in ordered:
        if (root.get("job_id"), root.get("job_nonce"), root.get("job_digest")) != (
            job_id,
            job_nonce,
            job_digest,
        ):
            raise SigningError("all roots must bind the same job_id / job_nonce / job_digest")
    parties = {str(root.get("party")) for root in ordered}
    if mode is None:
        mode = "three_party" if set(PARTIES).issubset(parties) else "single"
    if mode not in SIGNING_MODES:
        raise SigningError(f"mode must be one of {SIGNING_MODES}")
    if mode == "three_party" and not set(PARTIES).issubset(parties):
        raise SigningError(f"three_party bundle is missing roots for {sorted(set(PARTIES) - parties)}")
    return {
        "version": 1,
        "mode": mode,
        "job_id": job_id,
        "job_nonce": job_nonce,
        "job_digest": job_digest,
        "roots": ordered,
    }


def verify_bundle(
    bundle: Mapping[str, Any],
    *,
    trust_store: TrustStore,
    chains: Mapping[str, EvidenceChain | Iterable[Mapping[str, Any]]] | None = None,
    mode: str | None = None,
    expected_job_id: str | None = None,
    expected_job_digest: str | None = None,
    expected_attempt_id: str | None = None,
    expected_episode: int | None = None,
) -> CheckResult:
    """复算三方根:签名、job 绑定、可选地与各自的链对齐。"""

    result = CheckResult()
    bundle_mode = mode or str(bundle.get("mode") or "single")
    if bundle_mode not in SIGNING_MODES:
        result.add_error(f"unknown signing mode {bundle_mode!r}")
        return result
    try:
        bundle_version = int(bundle.get("version", 0))
    except (TypeError, ValueError):
        bundle_version = -1
    if bundle_version != 1:
        result.add_error(f"unsupported bundle version {bundle.get('version')!r}")

    roots = bundle.get("roots")
    if not isinstance(roots, list) or not roots:
        result.add_error("bundle.roots must be a non-empty list")
        return result

    by_party: dict[str, dict[str, Any]] = {}
    for root in roots:
        if not isinstance(root, Mapping):
            result.add_error("bundle root must be an object")
            continue
        party = str(root.get("party") or "")
        if party in by_party:
            result.add_error(f"duplicate root for party {party!r}")
            continue
        by_party[party] = dict(root)

    required = set(PARTIES) if bundle_mode == "three_party" else {"executor"}
    missing = required - set(by_party)
    if missing:
        result.add_error(f"missing required roots: {', '.join(sorted(missing))}")
    optional_missing = (set(PARTIES) - required) - set(by_party)
    if optional_missing:
        result.add_warning(
            "signing mode=single; missing roots: "
            + ", ".join(sorted(optional_missing))
            + " (testnet degradation, fields reserved)"
        )

    top_job = (bundle.get("job_id"), bundle.get("job_nonce"), bundle.get("job_digest"))
    for party, root in sorted(by_party.items()):
        if (root.get("job_id"), root.get("job_nonce"), root.get("job_digest")) != top_job:
            result.add_error(f"party {party!r} root does not bind the bundle job")
        if expected_job_id is not None and root.get("job_id") != expected_job_id:
            result.add_error(f"party {party!r} job_id {root.get('job_id')!r} != expected {expected_job_id!r}")
        if expected_job_digest is not None and root.get("job_digest") != expected_job_digest:
            result.add_error(
                f"party {party!r} job_digest {root.get('job_digest')!r} != expected {expected_job_digest!r}"
            )
        if expected_attempt_id is not None and root.get("attempt_id") != expected_attempt_id:
            result.add_error(
                f"party {party!r} attempt_id {root.get('attempt_id')!r} != expected {expected_attempt_id!r}"
            )
        if expected_episode is not None and root.get("episode") != expected_episode:
            result.add_error(f"party {party!r} episode {root.get('episode')!r} != expected {expected_episode!r}")
        root_check = verify_root(root, trust_store)
        result.merge(root_check, prefix=f"{party}: ")

    if chains:
        for party, chain_ref in chains.items():
            root = by_party.get(party)
            if root is None:
                result.add_warning(f"chain supplied for {party!r} but no root in bundle")
                continue
            events = list(chain_ref.events) if isinstance(chain_ref, EvidenceChain) else [dict(e) for e in chain_ref]
            if not events:
                result.add_error(f"{party}: chain is empty")
                continue
            last_hash = str(events[-1].get("hash"))
            if root.get("root") != last_hash:
                result.add_error(f"{party}: root {root.get('root')!r} != chain tail {last_hash!r}")
            try:
                root_count = int(root.get("event_count", -1))
            except (TypeError, ValueError):
                root_count = -1
            if root_count != len(events):
                result.add_error(f"{party}: root event_count {root.get('event_count')!r} != chain length {len(events)}")
            first = events[0]
            for field in ("job_id", "job_nonce", "attempt_id", "episode", "run_id"):
                expected = root.get(field)
                actual = first.get(field)
                if expected is not None and actual is not None and expected != actual:
                    result.add_error(f"{party}: root {field} {expected!r} != chain {actual!r}")
            try:
                root_first_seq = int(root.get("first_seq", -1))
                chain_first_seq = int(first.get("seq", -2))
            except (TypeError, ValueError):
                result.add_error(f"{party}: root first_seq / chain seq is not an integer")
            else:
                if root_first_seq != chain_first_seq:
                    result.add_error(f"{party}: root first_seq does not match chain")

    result.details.update(
        {
            "mode": bundle_mode,
            "job_id": bundle.get("job_id"),
            "job_digest": bundle.get("job_digest"),
            "parties": sorted(by_party),
        }
    )
    return result


__all__ = [
    "PARTIES",
    "SIGNING_MODES",
    "SigningError",
    "Signer",
    "TrustStore",
    "build_bundle",
    "sign_root",
    "verify_bundle",
    "verify_root",
]
