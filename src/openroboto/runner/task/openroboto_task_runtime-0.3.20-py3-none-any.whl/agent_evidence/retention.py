"""保留期 | Retention: raw 90 days, digest 1 year, sampling audit 90 days.

两类产物:

- **原始证据(raw)**:完整 JSONL(含 payload)。保留 ``retention.raw_days``
  (默认 90 天),到期可删。
- **摘要(digest)**:不含 payload 的链条摘要 + 各 party 签名根。保留
  ``retention.digest_days``(默认 365 天)。摘要本身也带哈希,可校验是否被改。

``plan_retention`` 只出计划,不删文件;``apply_retention_plan`` 默认 dry-run。
"""

from __future__ import annotations

import datetime as _dt
import pathlib
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

from .canonical import canonical_sha256, isoformat, parse_isoformat, utcnow
from .policy import EvidencePolicy
from .result import CheckResult

RETENTION_KINDS = ("raw", "digest", "sampling_audit")
DIGEST_VERSION = 1
RUN_DIGEST_VERSION = 1


def _hex64(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(ch in "0123456789abcdef" for ch in value)


@dataclass(frozen=True)
class EvidenceArtifact:
    path: str
    kind: str
    created_at: str
    run_id: str | None = None

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> EvidenceArtifact:
        return cls(
            path=str(data["path"]),
            kind=str(data["kind"]),
            created_at=str(data["created_at"]),
            run_id=None if data.get("run_id") is None else str(data["run_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "kind": self.kind,
            "created_at": self.created_at,
            "run_id": self.run_id,
        }


@dataclass
class RetentionPlan:
    now: str
    policy_version: int
    delete: list[dict[str, Any]] = field(default_factory=list)
    keep: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "now": self.now,
            "policy_version": self.policy_version,
            "delete": list(self.delete),
            "keep": list(self.keep),
            "delete_count": len(self.delete),
            "keep_count": len(self.keep),
        }


def plan_retention(
    artifacts: Iterable[EvidenceArtifact | Mapping[str, Any]],
    policy: EvidencePolicy,
    *,
    now: str | _dt.datetime | None = None,
) -> RetentionPlan:
    if now is None:
        now_dt = utcnow()
    elif isinstance(now, _dt.datetime):
        now_dt = now if now.tzinfo else now.replace(tzinfo=_dt.timezone.utc)
    else:
        now_dt = parse_isoformat(now)
    plan = RetentionPlan(now=isoformat(now_dt), policy_version=policy.version)

    for item in artifacts:
        artifact = item if isinstance(item, EvidenceArtifact) else EvidenceArtifact.from_dict(item)
        if artifact.kind not in RETENTION_KINDS:
            raise ValueError(f"unknown evidence kind {artifact.kind!r}; expected {list(RETENTION_KINDS)}")
        created = parse_isoformat(artifact.created_at)
        days = policy.retention_days(artifact.kind)
        expires = created + _dt.timedelta(days=days)
        entry = {
            **artifact.to_dict(),
            "retention_days": days,
            "expires_at": isoformat(expires),
            "expired": now_dt >= expires,
        }
        (plan.delete if entry["expired"] else plan.keep).append(entry)
    return plan


def apply_retention_plan(plan: RetentionPlan, *, dry_run: bool = True) -> list[str]:
    """按计划删文件。返回会被/已被删除的路径;默认只演练。"""

    removed: list[str] = []
    for entry in plan.delete:
        path = pathlib.Path(str(entry["path"])).expanduser()
        removed.append(str(path))
        if not dry_run and path.exists():
            path.unlink()
    return removed


def build_chain_digest(
    events: Sequence[Mapping[str, Any]],
    *,
    roots: Sequence[Mapping[str, Any]] | None = None,
    created_at: str | None = None,
) -> dict[str, Any]:
    """构造 1 年期的单链摘要(不含 payload)。"""

    items = [dict(event) for event in events]
    if not items:
        raise ValueError("cannot digest an empty chain")
    first, last = items[0], items[-1]
    type_counts: dict[str, int] = {}
    for event in items:
        kind = str(event.get("type"))
        type_counts[kind] = type_counts.get(kind, 0) + 1
    first_ts = first.get("ts_monotonic")
    last_ts = last.get("ts_monotonic")
    span = None
    if isinstance(first_ts, (int, float)) and isinstance(last_ts, (int, float)):
        span = round(float(last_ts) - float(first_ts), 6)
    digest: dict[str, Any] = {
        "v": DIGEST_VERSION,
        "kind": "evidence.digest",
        "job_id": first.get("job_id"),
        "attempt_id": first.get("attempt_id"),
        "episode": first.get("episode"),
        "run_id": first.get("run_id"),
        "party": first.get("party"),
        "job_nonce": first.get("job_nonce"),
        "event_count": len(items),
        "root": last.get("hash"),
        "first_seq": first.get("seq"),
        "last_seq": last.get("seq"),
        "first_type": first.get("type"),
        "last_type": last.get("type"),
        "type_counts": type_counts,
        "first_recorded_at": first.get("recorded_at"),
        "last_recorded_at": last.get("recorded_at"),
        "monotonic_span_s": span,
        "roots": [dict(root) for root in (roots or [])],
        "created_at": created_at or isoformat(utcnow()),
    }
    digest["digest_sha256"] = canonical_sha256(digest)
    return digest


def verify_chain_digest(digest: Mapping[str, Any]) -> CheckResult:
    result = CheckResult()
    if int(digest.get("v", 0)) != DIGEST_VERSION:
        result.add_error(f"unsupported digest version {digest.get('v')!r}")
    required = (
        "job_id",
        "attempt_id",
        "party",
        "event_count",
        "root",
        "first_seq",
        "last_seq",
        "type_counts",
        "created_at",
        "digest_sha256",
    )
    missing = [key for key in required if key not in digest]
    if missing:
        result.add_error(f"digest missing fields: {', '.join(missing)}")
        return result
    if not _hex64(digest.get("root")):
        result.add_error("digest root must be a 64-char sha256 hex")
    try:
        count = int(digest["event_count"])
        first_seq = int(digest["first_seq"])
        last_seq = int(digest["last_seq"])
        if count < 1 or first_seq != 0 or last_seq != count - 1:
            result.add_error("digest seq range does not match event_count")
    except (TypeError, ValueError):
        result.add_error("digest event_count/seq must be integers")
    counts = digest.get("type_counts")
    if not isinstance(counts, Mapping):
        result.add_error("digest type_counts must be an object")
    else:
        try:
            total = sum(int(value) for value in counts.values())
        except (TypeError, ValueError):
            result.add_error("digest type_counts values must be integers")
        else:
            if total != digest.get("event_count"):
                result.add_error("digest type_counts do not sum to event_count")
    try:
        parse_isoformat(str(digest.get("created_at")))
    except ValueError:
        result.add_error("digest created_at is not ISO-8601")
    span = digest.get("monotonic_span_s")
    if span is not None and (not isinstance(span, (int, float)) or span < 0):
        result.add_error("digest monotonic_span_s must be non-negative")
    body = {key: value for key, value in digest.items() if key != "digest_sha256"}
    try:
        computed = canonical_sha256(body)
    except (TypeError, ValueError):
        result.add_error("digest is not canonical-JSON serializable")
    else:
        if digest.get("digest_sha256") != computed:
            result.add_error("digest_sha256 mismatch (summary modified)")
    result.details.update(
        {
            "job_id": digest.get("job_id"),
            "party": digest.get("party"),
            "event_count": digest.get("event_count"),
            "root": digest.get("root"),
        }
    )
    return result


def build_run_digest(
    chains: Mapping[str, Sequence[Mapping[str, Any]]],
    *,
    bundle: Mapping[str, Any] | None = None,
    created_at: str | None = None,
) -> dict[str, Any]:
    """把一个 job/attempt 下各 party 的摘要收成一条 run 摘要。"""

    if not chains:
        raise ValueError("run digest needs at least one chain")
    party_digests = {
        party: build_chain_digest(events, created_at=created_at)
        for party, events in sorted(chains.items())
    }
    first_digest = next(iter(party_digests.values()))
    run_digest: dict[str, Any] = {
        "v": RUN_DIGEST_VERSION,
        "kind": "evidence.run_digest",
        "job_id": first_digest.get("job_id"),
        "attempt_id": first_digest.get("attempt_id"),
        "episode": first_digest.get("episode"),
        "run_id": first_digest.get("run_id"),
        "job_nonce": first_digest.get("job_nonce"),
        "job_digest": (bundle or {}).get("job_digest"),
        "signing_mode": (bundle or {}).get("mode"),
        "parties": party_digests,
        "bundle_hash": canonical_sha256(bundle) if bundle is not None else None,
        "created_at": created_at or isoformat(utcnow()),
    }
    run_digest["digest_sha256"] = canonical_sha256(run_digest)
    return run_digest


def verify_run_digest(digest: Mapping[str, Any]) -> CheckResult:
    result = CheckResult()
    try:
        version = int(digest.get("v", 0))
    except (TypeError, ValueError):
        version = -1
    if version != RUN_DIGEST_VERSION:
        result.add_error(f"unsupported run digest version {digest.get('v')!r}")
    parties = digest.get("parties")
    if not isinstance(parties, Mapping) or not parties:
        result.add_error("run digest parties must be a non-empty object")
        return result
    for party, party_digest in parties.items():
        if not isinstance(party_digest, Mapping):
            result.add_error(f"{party}: digest must be an object")
            continue
        result.merge(verify_chain_digest(party_digest), prefix=f"{party}: ")
        if party_digest.get("party") != party:
            result.add_error(f"{party}: digest party field mismatch")
    body = {key: value for key, value in digest.items() if key != "digest_sha256"}
    try:
        computed = canonical_sha256(body)
    except (TypeError, ValueError):
        result.add_error("run digest is not canonical-JSON serializable")
    else:
        if digest.get("digest_sha256") != computed:
            result.add_error("run digest_sha256 mismatch")
    result.details.update({"parties": sorted(parties), "job_id": digest.get("job_id")})
    return result


__all__ = [
    "DIGEST_VERSION",
    "RETENTION_KINDS",
    "RUN_DIGEST_VERSION",
    "EvidenceArtifact",
    "RetentionPlan",
    "apply_retention_plan",
    "build_chain_digest",
    "build_run_digest",
    "plan_retention",
    "verify_chain_digest",
    "verify_run_digest",
]
