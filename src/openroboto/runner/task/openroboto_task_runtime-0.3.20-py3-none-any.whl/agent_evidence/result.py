"""校验结果容器 | Shared result object for every evidence check."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class CheckResult:
    """一次校验的结论。

    ``ok`` 只看 ``errors``:没有错误即通过。``warnings`` 用于单方签名等
    **允许但降级**的情况,不阻断流程,但必须写进审计结论。
    """

    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.errors

    def add_error(self, message: str) -> None:
        self.errors.append(message)

    def add_warning(self, message: str) -> None:
        self.warnings.append(message)

    def merge(self, other: CheckResult, *, prefix: str = "") -> None:
        for error in other.errors:
            self.errors.append(f"{prefix}{error}" if prefix else error)
        for warning in other.warnings:
            self.warnings.append(f"{prefix}{warning}" if prefix else warning)
        if other.details:
            self.details.setdefault("parts", {})[prefix or "part"] = other.details

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "details": self.details,
        }


__all__ = ["CheckResult"]
