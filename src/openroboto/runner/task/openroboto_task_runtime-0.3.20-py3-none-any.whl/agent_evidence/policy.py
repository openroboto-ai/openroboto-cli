"""证据策略 | Evidence policy: signing mode, retention, L0–L3 sampling.

策略是**配置**,不是代码。测试网/上线切换签名模式和抽样率只改
``configs/evidence_policy.json``(或用 ``EVIDENCE_POLICY_PATH`` 指向另一份),
不需要改实现。

``load_policy()`` 会校验:四层 L0–L3 都在、比例在 [0,1]、保留期为正、
发现异常只冻结复核而不自动判作弊。
"""

from __future__ import annotations

import json
import os
import pathlib
from dataclasses import dataclass
from typing import Any, Mapping

from .signing import PARTIES, SIGNING_MODES

DEFAULT_POLICY_PATH = pathlib.Path(__file__).resolve().parent.parent / "configs" / "evidence_policy.json"
POLICY_ENV = "EVIDENCE_POLICY_PATH"

L0_REQUIRED_CHECKS = ("signature", "config_match", "event_continuity", "budget", "nonce", "clock")


class PolicyError(ValueError):
    pass


def _require_number(value: Any, name: str, *, minimum: float = 0.0, maximum: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise PolicyError(f"{name} must be a number")
    number = float(value)
    if number < minimum or (maximum is not None and number > maximum):
        raise PolicyError(f"{name} must be in [{minimum}, {maximum}]")
    return number


def _require_int(value: Any, name: str, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise PolicyError(f"{name} must be an integer >= {minimum}")
    return value


@dataclass(frozen=True)
class EvidencePolicy:
    version: int
    signing_mode: str
    required_parties: tuple[str, ...]
    raw_days: int
    digest_days: int
    sampling_audit_days: int
    l1_new_miner_rate: float
    l1_mature_generation_rate: float
    l2_random_rate: float
    l3_cadence_days: int
    l3_scenarios: tuple[str, ...]
    max_clock_drift_s: float
    freeze_on_finding: bool
    auto_cheat_verdict: bool
    cross_check_rules: tuple[dict[str, Any], ...]
    raw: dict[str, Any]

    @classmethod
    def load(cls, path: str | pathlib.Path | None = None) -> EvidencePolicy:
        policy_path = pathlib.Path(path) if path is not None else pathlib.Path(
            os.environ.get(POLICY_ENV) or DEFAULT_POLICY_PATH
        )
        data = json.loads(pathlib.Path(policy_path).expanduser().read_text(encoding="utf-8"))
        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> EvidencePolicy:
        if not isinstance(data, Mapping):
            raise PolicyError("policy must be a JSON object")
        version = _require_int(data.get("version"), "version", minimum=1)

        signing = data.get("signing")
        if not isinstance(signing, Mapping):
            raise PolicyError("policy.signing must be an object")
        mode = str(signing.get("mode") or "")
        if mode not in SIGNING_MODES:
            raise PolicyError(f"policy.signing.mode must be one of {SIGNING_MODES}")
        required_parties = tuple(str(party) for party in signing.get("required_parties") or PARTIES)
        if not set(PARTIES).issubset(required_parties):
            raise PolicyError(f"policy.signing.required_parties must include {list(PARTIES)}")
        if mode == "single":
            # 单方是测试网降级;required_parties 仍保留三方字段,上线切换不改结构。
            pass

        retention = data.get("retention")
        if not isinstance(retention, Mapping):
            raise PolicyError("policy.retention must be an object")
        raw_days = _require_int(retention.get("raw_days"), "retention.raw_days", minimum=1)
        digest_days = _require_int(retention.get("digest_days"), "retention.digest_days", minimum=1)
        sampling_audit_days = _require_int(
            retention.get("sampling_audit_days"), "retention.sampling_audit_days", minimum=1
        )
        if raw_days > digest_days:
            raise PolicyError("retention.raw_days must not exceed retention.digest_days")

        levels = data.get("levels")
        if not isinstance(levels, Mapping):
            raise PolicyError("policy.levels must be an object")
        for level in ("L0", "L1", "L2", "L3"):
            if not isinstance(levels.get(level), Mapping):
                raise PolicyError(f"policy.levels.{level} is required")
        l0_checks = set(levels["L0"].get("checks") or [])
        missing_checks = set(L0_REQUIRED_CHECKS) - l0_checks
        if missing_checks:
            raise PolicyError(f"policy.levels.L0.checks missing: {sorted(missing_checks)}")

        l1 = levels["L1"]
        new_rate = _require_number(l1.get("new_miner_rate"), "levels.L1.new_miner_rate", maximum=1.0)
        mature_rate = _require_number(
            l1.get("mature_generation_rate"), "levels.L1.mature_generation_rate", maximum=1.0
        )
        l2 = levels["L2"]
        l2_rate = _require_number(l2.get("random_rate"), "levels.L2.random_rate", maximum=1.0)
        l3 = levels["L3"]
        cadence = _require_int(l3.get("cadence_days"), "levels.L3.cadence_days", minimum=1)
        scenarios = tuple(str(item) for item in (l3.get("scenarios") or []))
        if not scenarios:
            raise PolicyError("levels.L3.scenarios must not be empty")

        clock = data.get("clock") or {}
        drift = _require_number(clock.get("max_drift_s"), "clock.max_drift_s", minimum=1.0)

        findings = data.get("findings") or {}
        freeze = findings.get("freeze_settlement")
        auto_cheat = findings.get("auto_cheat_verdict")
        if freeze is not True:
            raise PolicyError("findings.freeze_settlement must be true")
        if auto_cheat is not False:
            raise PolicyError("findings.auto_cheat_verdict must be false (异常只进复核,不自动判作弊)")

        rules = data.get("cross_check") or []
        if not isinstance(rules, list):
            raise PolicyError("policy.cross_check must be a list")
        normalized_rules: list[dict[str, Any]] = []
        for index, rule in enumerate(rules):
            if not isinstance(rule, Mapping):
                raise PolicyError(f"policy.cross_check[{index}] must be an object")
            parties = rule.get("parties")
            if not isinstance(parties, list) or not parties:
                raise PolicyError(f"policy.cross_check[{index}].parties must be a non-empty list")
            if not set(parties).issubset(PARTIES):
                raise PolicyError(f"policy.cross_check[{index}] has unknown party")
            if not rule.get("type"):
                raise PolicyError(f"policy.cross_check[{index}].type is required")
            if str(rule.get("match") or "correlation_id") not in ("correlation_id", "payload_sha256"):
                raise PolicyError(f"policy.cross_check[{index}].match is invalid")
            normalized_rules.append(dict(rule))

        return cls(
            version=version,
            signing_mode=mode,
            required_parties=required_parties,
            raw_days=raw_days,
            digest_days=digest_days,
            sampling_audit_days=sampling_audit_days,
            l1_new_miner_rate=new_rate,
            l1_mature_generation_rate=mature_rate,
            l2_random_rate=l2_rate,
            l3_cadence_days=cadence,
            l3_scenarios=scenarios,
            max_clock_drift_s=drift,
            freeze_on_finding=freeze,
            auto_cheat_verdict=auto_cheat,
            cross_check_rules=tuple(normalized_rules),
            raw=dict(data),
        )

    def sampling_rate(self, cohort: str) -> float:
        if cohort == "new_miner":
            return self.l1_new_miner_rate
        if cohort == "mature":
            return self.l1_mature_generation_rate
        raise PolicyError(f"unknown cohort {cohort!r}; expected 'new_miner' or 'mature'")

    def retention_days(self, kind: str) -> int:
        if kind == "raw":
            return self.raw_days
        if kind == "digest":
            return self.digest_days
        if kind == "sampling_audit":
            return self.sampling_audit_days
        raise PolicyError(f"unknown evidence kind {kind!r}")


def load_policy(path: str | pathlib.Path | None = None) -> EvidencePolicy:
    return EvidencePolicy.load(path)


__all__ = [
    "DEFAULT_POLICY_PATH",
    "L0_REQUIRED_CHECKS",
    "POLICY_ENV",
    "EvidencePolicy",
    "PolicyError",
    "load_policy",
]
