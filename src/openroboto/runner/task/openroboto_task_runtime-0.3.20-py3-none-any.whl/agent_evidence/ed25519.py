"""纯 Python Ed25519(RFC 8032) | Minimal Ed25519 for signed evidence roots.

为什么不用第三方库:validator 仓库的主体是标准库脚本,证据链的签名根必须在
没有 ``cryptography`` 的部署环境里也能验。实现只覆盖 **签名与验签**,不做
密钥交换/加密。

安全边界(务必读):

- 这是参考实现,大整数运算**不是常数时间**。适合离线审计、测试网和验签;
  生产环境的签名私钥应放在 HSM / 受保护进程里,不要在多租户进程内直接调用。
- 只接受 32 字节 seed、64 字节签名、32 字节公钥,长度不对一律拒绝。
- ``verify`` 返回布尔值,不抛异常;调用方应把验签失败当作**硬失败**。

测试用 RFC 8032 §7.1 的 TEST 1/2/3 向量(见 ``tests/test_evidence_ed25519.py``)。
"""

from __future__ import annotations

import hashlib
import os

P = 2**255 - 19
L = 2**252 + 27742317777372353535851937790883648493
D = (-121665 * pow(121666, P - 2, P)) % P
SQRT_M1 = pow(2, (P - 1) // 4, P)

SEED_BYTES = 32
PUBLIC_KEY_BYTES = 32
SIGNATURE_BYTES = 64


class Ed25519Error(ValueError):
    """密钥/签名格式错误。"""


# ---------------------------------------------------------------------------
# 扩展扭曲爱德华兹曲线:点用 (X, Y, Z, T),x = X/Z,y = Y/Z,xy = T/Z
# ---------------------------------------------------------------------------
Point = tuple[int, int, int, int]

IDENTITY: Point = (0, 1, 1, 0)


def _recover_x(y: int, sign: int) -> int | None:
    if y >= P:
        return None
    x2 = (y * y - 1) * pow(D * y * y + 1, P - 2, P) % P
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (P + 3) // 8, P)
    if (x * x - x2) % P != 0:
        x = x * SQRT_M1 % P
    if (x * x - x2) % P != 0:
        return None
    if (x & 1) != sign:
        x = P - x
    return x


def _point_add(left: Point, right: Point) -> Point:
    x1, y1, z1, t1 = left
    x2, y2, z2, t2 = right
    a = (y1 - x1) * (y2 - x2) % P
    b = (y1 + x1) * (y2 + x2) % P
    c = t1 * 2 * D % P * t2 % P
    d = z1 * 2 * z2 % P
    e = (b - a) % P
    f = (d - c) % P
    g = (d + c) % P
    h = (b + a) % P
    return (e * f % P, g * h % P, f * g % P, e * h % P)


def _point_double(point: Point) -> Point:
    x1, y1, z1, _t1 = point
    a = x1 * x1 % P
    b = y1 * y1 % P
    c = 2 * z1 * z1 % P
    d = -a % P
    e = ((x1 + y1) ** 2 - a - b) % P
    g = (d + b) % P
    f = (g - c) % P
    h = (d - b) % P
    return (e * f % P, g * h % P, f * g % P, e * h % P)


def _scalar_mult(scalar: int, point: Point) -> Point:
    result = IDENTITY
    addend = point
    while scalar:
        if scalar & 1:
            result = _point_add(result, addend)
        addend = _point_double(addend)
        scalar >>= 1
    return result


def _encode_point(point: Point) -> bytes:
    x, y, z, _t = point
    z_inv = pow(z, P - 2, P)
    x = x * z_inv % P
    y = y * z_inv % P
    return (y | ((x & 1) << 255)).to_bytes(PUBLIC_KEY_BYTES, "little")


def _decode_point(encoded: bytes) -> Point | None:
    if len(encoded) != PUBLIC_KEY_BYTES:
        return None
    value = int.from_bytes(encoded, "little")
    sign = value >> 255
    y = value & ((1 << 255) - 1)
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % P)


def _base_point() -> Point:
    y = 4 * pow(5, P - 2, P) % P
    x = _recover_x(y, 0)
    assert x is not None
    return (x, y, 1, x * y % P)


BASE_POINT = _base_point()


def _expand_seed(seed: bytes) -> tuple[int, bytes]:
    if len(seed) != SEED_BYTES:
        raise Ed25519Error(f"seed must be {SEED_BYTES} bytes, got {len(seed)}")
    digest = hashlib.sha512(seed).digest()
    scalar = int.from_bytes(digest[:32], "little")
    scalar &= (1 << 254) - 8
    scalar |= 1 << 254
    return scalar, digest[32:]


def public_key_from_seed(seed: bytes) -> bytes:
    """由 32 字节 seed 推导 32 字节公钥。"""

    scalar, _prefix = _expand_seed(seed)
    return _encode_point(_scalar_mult(scalar, BASE_POINT))


def sign(seed: bytes, message: bytes) -> bytes:
    """对 ``message`` 签名,返回 64 字节 (R || S)。"""

    if not isinstance(message, (bytes, bytearray)):
        raise Ed25519Error("message must be bytes")
    scalar, prefix = _expand_seed(seed)
    public_key = _encode_point(_scalar_mult(scalar, BASE_POINT))
    nonce = int.from_bytes(hashlib.sha512(prefix + bytes(message)).digest(), "little") % L
    encoded_r = _encode_point(_scalar_mult(nonce, BASE_POINT))
    challenge = int.from_bytes(
        hashlib.sha512(encoded_r + public_key + bytes(message)).digest(), "little"
    ) % L
    s = (nonce + challenge * scalar) % L
    return encoded_r + s.to_bytes(32, "little")


def verify(public_key: bytes, message: bytes, signature: bytes) -> bool:
    """验签;任何格式/数学错误都返回 ``False``。"""

    if not isinstance(public_key, (bytes, bytearray)) or len(public_key) != PUBLIC_KEY_BYTES:
        return False
    if not isinstance(signature, (bytes, bytearray)) or len(signature) != SIGNATURE_BYTES:
        return False
    if not isinstance(message, (bytes, bytearray)):
        return False

    public_point = _decode_point(bytes(public_key))
    if public_point is None or _encode_point(public_point) == _encode_point(IDENTITY):
        return False

    encoded_r = bytes(signature[:32])
    s = int.from_bytes(signature[32:], "little")
    if s >= L:
        return False
    r_point = _decode_point(encoded_r)
    if r_point is None:
        return False

    challenge = int.from_bytes(
        hashlib.sha512(encoded_r + bytes(public_key) + bytes(message)).digest(), "little"
    ) % L
    left = _scalar_mult(s, BASE_POINT)
    right = _point_add(r_point, _scalar_mult(challenge, public_point))
    return _encode_point(left) == _encode_point(right)


def generate_seed() -> bytes:
    return os.urandom(SEED_BYTES)


def public_key_hex(seed: bytes) -> str:
    return public_key_from_seed(seed).hex()


__all__ = [
    "Ed25519Error",
    "SEED_BYTES",
    "PUBLIC_KEY_BYTES",
    "SIGNATURE_BYTES",
    "generate_seed",
    "public_key_from_seed",
    "public_key_hex",
    "sign",
    "verify",
]
