"""命令行 | ``python -m agent_evidence <command>``.

所有命令都只读文件、输出 JSON,失败返回非零退出码。审计方不需要启动后端
或 validator,拿到 JSONL / 根 / 审计记录即可独立复算。
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
from typing import Any, Iterable, Mapping

from .audit import AuditLog, verify_audit_log
from .events import load_events
from .policy import load_policy
from .retention import (
    EvidenceArtifact,
    apply_retention_plan,
    build_chain_digest,
    plan_retention,
    verify_chain_digest,
)
from .sampling import verify_sampling_audit
from .signing import Signer, TrustStore, build_bundle, sign_root, verify_bundle
from .verify import cross_check, l0_check, verify_chain, verify_legacy_events


def _load_json(path: str) -> Any:
    return json.loads(pathlib.Path(path).expanduser().read_text(encoding="utf-8"))


def _dump(data: Any) -> None:
    json.dump(data, sys.stdout, indent=2, sort_keys=True, ensure_ascii=False)
    sys.stdout.write("\n")


def _emit(command: str, result: Any, *, extra: Mapping[str, Any] | None = None) -> int:
    payload = result.to_dict() if hasattr(result, "to_dict") else result
    body = {"command": command, "result": payload}
    if extra:
        body.update(extra)
    _dump(body)
    ok = bool(payload.get("ok", True)) if isinstance(payload, Mapping) else True
    return 0 if ok else 1


def _pairs(values: Iterable[str]) -> dict[str, str]:
    pairs: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise SystemExit(f"--chain expects PARTY=PATH, got {value!r}")
        party, path = value.split("=", 1)
        pairs[party] = path
    return pairs


def _chains(values: Iterable[str]) -> dict[str, list[dict[str, Any]]]:
    return {party: load_events(path) for party, path in _pairs(values).items()}


def _add_chain_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--chain", action="append", default=[], metavar="PARTY=PATH")


def _cmd_verify_chain(args: argparse.Namespace) -> int:
    kwargs: dict[str, Any] = {}
    if args.episode is not None:
        kwargs["episode"] = args.episode
    result = verify_chain(
        load_events(args.events),
        expected_root=args.root,
        party=args.party,
        job_id=args.job_id,
        attempt_id=args.attempt_id,
        job_nonce=args.job_nonce,
        require_payload=args.require_payload,
        **kwargs,
    )
    return _emit("verify-chain", result, extra={"path": args.events})


def _cmd_verify_harness(args: argparse.Namespace) -> int:
    return _emit(
        "verify-harness",
        verify_legacy_events(load_events(args.events), expected_root=args.root),
        extra={"path": args.events},
    )


def _cmd_verify_bundle(args: argparse.Namespace) -> int:
    bundle = _load_json(args.bundle)
    trust = TrustStore.from_file(args.trust)
    chains = _chains(args.chain) if args.chain else None
    result = verify_bundle(
        bundle,
        trust_store=trust,
        chains=chains,
        mode=args.mode,
        expected_job_id=args.job_id,
        expected_job_digest=args.job_digest,
        expected_attempt_id=args.attempt_id,
        expected_episode=args.episode,
    )
    return _emit("verify-bundle", result)


def _cmd_cross_check(args: argparse.Namespace) -> int:
    policy = load_policy(args.policy)
    chains = _chains(args.chain)
    trust = TrustStore.from_file(args.trust) if args.trust else None
    bundle = _load_json(args.bundle) if args.bundle else None
    result = cross_check(chains, policy.cross_check_rules, trust_store=trust, bundle=bundle)
    return _emit("cross-check", result)


def _cmd_l0(args: argparse.Namespace) -> int:
    policy = load_policy(args.policy)
    result = l0_check(
        _chains(args.chain),
        bundle=_load_json(args.bundle),
        trust_store=TrustStore.from_file(args.trust),
        policy=policy,
        expected_job_id=args.job_id,
        expected_job_digest=args.job_digest,
        expected_attempt_id=args.attempt_id,
        expected_episode=args.episode,
    )
    return _emit("l0", result)


def _cmd_sign_root(args: argparse.Namespace) -> int:
    signer = Signer.from_keyfile(args.key)
    if args.party and signer.party != args.party:
        raise SystemExit(f"key is for party {signer.party!r}, not {args.party!r}")
    root = sign_root(
        load_events(args.events),
        signer,
        job_digest=args.job_digest,
        job_nonce=args.job_nonce,
        attempt_id=args.attempt_id,
        episode=args.episode,
        run_id=args.run_id,
        policy_version=args.policy_version,
    )
    if args.out:
        pathlib.Path(args.out).expanduser().write_text(
            json.dumps(root, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
    _dump(root)
    return 0


def _cmd_make_bundle(args: argparse.Namespace) -> int:
    roots = [_load_json(path) for path in args.root]
    bundle = build_bundle(roots, mode=args.mode)
    if args.out:
        pathlib.Path(args.out).expanduser().write_text(
            json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
    _dump(bundle)
    return 0


def _cmd_verify_sampling(args: argparse.Namespace) -> int:
    policy = load_policy(args.policy) if args.policy else None
    return _emit("verify-sampling", verify_sampling_audit(_load_json(args.audit), policy=policy))


def _cmd_digest(args: argparse.Namespace) -> int:
    roots = _load_json(args.roots) if args.roots else None
    if isinstance(roots, Mapping):
        roots = roots.get("roots")
    digest = build_chain_digest(load_events(args.events), roots=roots, created_at=args.created_at)
    result = verify_chain_digest(digest)
    if args.out:
        pathlib.Path(args.out).expanduser().write_text(
            json.dumps(digest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
    return _emit("digest", result, extra={"digest": digest})


def _cmd_retention_plan(args: argparse.Namespace) -> int:
    policy = load_policy(args.policy)
    data = _load_json(args.artifacts)
    if isinstance(data, Mapping):
        data = data.get("artifacts") or []
    artifacts = [EvidenceArtifact.from_dict(item) for item in data]
    plan = plan_retention(artifacts, policy, now=args.now)
    removed = None
    if args.apply:
        if not args.yes:
            raise SystemExit("--apply also needs --yes (this deletes files)")
        removed = apply_retention_plan(plan, dry_run=False)
    _dump({"command": "retention-plan", "plan": plan.to_dict(), "removed": removed})
    return 0


def _cmd_audit_append(args: argparse.Namespace) -> int:
    log = AuditLog(args.log)
    payload = _load_json(args.payload)
    record = log.append(args.kind, payload, at=args.at)
    _dump({"command": "audit-append", "record": record})
    return 0


def _cmd_audit_verify(args: argparse.Namespace) -> int:
    log = AuditLog(args.log, create=False)
    return _emit("audit-verify", verify_audit_log(log.records), extra={"path": args.log})


def _cmd_policy(args: argparse.Namespace) -> int:
    policy = load_policy(args.policy)
    _dump(
        {
            "command": "policy",
            "version": policy.version,
            "signing_mode": policy.signing_mode,
            "retention": {
                "raw_days": policy.raw_days,
                "digest_days": policy.digest_days,
                "sampling_audit_days": policy.sampling_audit_days,
            },
            "sampling": {
                "l1_new_miner_rate": policy.l1_new_miner_rate,
                "l1_mature_generation_rate": policy.l1_mature_generation_rate,
                "l2_random_rate": policy.l2_random_rate,
                "l3_cadence_days": policy.l3_cadence_days,
                "l3_scenarios": list(policy.l3_scenarios),
            },
            "cross_check_rules": list(policy.cross_check_rules),
        }
    )
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m agent_evidence", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("verify-chain", help="从头复算一条证据链")
    p.add_argument("events")
    p.add_argument("--root")
    p.add_argument("--party")
    p.add_argument("--job-id")
    p.add_argument("--attempt-id")
    p.add_argument("--episode", type=int)
    p.add_argument("--job-nonce")
    p.add_argument("--require-payload", action="store_true")
    p.set_defaults(func=_cmd_verify_chain)

    p = sub.add_parser("verify-harness", help="验 agent_harness 旧格式链")
    p.add_argument("events")
    p.add_argument("--root")
    p.set_defaults(func=_cmd_verify_harness)

    p = sub.add_parser("verify-bundle", help="验三方签名根")
    p.add_argument("bundle")
    p.add_argument("--trust", required=True)
    _add_chain_args(p)
    p.add_argument("--mode", choices=("single", "three_party"))
    p.add_argument("--job-id")
    p.add_argument("--job-digest")
    p.add_argument("--attempt-id")
    p.add_argument("--episode", type=int)
    p.set_defaults(func=_cmd_verify_bundle)

    p = sub.add_parser("cross-check", help="按政策交叉核对多 party 链")
    _add_chain_args(p)
    p.add_argument("--policy")
    p.add_argument("--trust")
    p.add_argument("--bundle")
    p.set_defaults(func=_cmd_cross_check)

    p = sub.add_parser("l0", help="L0:验签 + 配置 + 连续性 + 预算 + nonce + 时钟")
    _add_chain_args(p)
    p.add_argument("--bundle", required=True)
    p.add_argument("--trust", required=True)
    p.add_argument("--policy")
    p.add_argument("--job-id")
    p.add_argument("--job-digest")
    p.add_argument("--attempt-id")
    p.add_argument("--episode", type=int)
    p.set_defaults(func=_cmd_l0)

    p = sub.add_parser("sign-root", help="对一条链的根签名")
    p.add_argument("events")
    p.add_argument("--key", required=True)
    p.add_argument("--party")
    p.add_argument("--job-digest", required=True)
    p.add_argument("--job-nonce")
    p.add_argument("--attempt-id")
    p.add_argument("--episode", type=int)
    p.add_argument("--run-id")
    p.add_argument("--policy-version", type=int, default=1)
    p.add_argument("--out")
    p.set_defaults(func=_cmd_sign_root)

    p = sub.add_parser("make-bundle", help="收集多个根为 bundle")
    p.add_argument("--root", action="append", required=True, metavar="PATH")
    p.add_argument("--mode", choices=("single", "three_party"))
    p.add_argument("--out")
    p.set_defaults(func=_cmd_make_bundle)

    p = sub.add_parser("verify-sampling", help="重算抽查审计")
    p.add_argument("audit")
    p.add_argument("--policy")
    p.set_defaults(func=_cmd_verify_sampling)

    p = sub.add_parser("digest", help="生成 1 年期链条摘要")
    p.add_argument("events")
    p.add_argument("--roots")
    p.add_argument("--created-at")
    p.add_argument("--out")
    p.set_defaults(func=_cmd_digest)

    p = sub.add_parser("retention-plan", help="按保留期列出待删/保留文件")
    p.add_argument("artifacts")
    p.add_argument("--policy")
    p.add_argument("--now")
    p.add_argument("--apply", action="store_true")
    p.add_argument("--yes", action="store_true")
    p.set_defaults(func=_cmd_retention_plan)

    p = sub.add_parser("audit-append", help="向抽查审计日志追加一条记录")
    p.add_argument("log")
    p.add_argument("--kind", required=True)
    p.add_argument("--payload", required=True)
    p.add_argument("--at")
    p.set_defaults(func=_cmd_audit_append)

    p = sub.add_parser("audit-verify", help="验抽查审计日志哈希链")
    p.add_argument("log")
    p.set_defaults(func=_cmd_audit_verify)

    p = sub.add_parser("policy", help="打印当前证据策略")
    p.add_argument("--policy")
    p.set_defaults(func=_cmd_policy)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
