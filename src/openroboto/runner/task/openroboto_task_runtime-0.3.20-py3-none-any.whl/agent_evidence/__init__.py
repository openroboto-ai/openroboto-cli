"""B-07 事件链与签名 | Auditable, signed, three-party evidence.

OPE-126 的实现包。与 ``agent_harness`` 的分工:

- ``agent_harness/events.py`` 负责**写** B-07 链(每条事件带 job/attempt/
  episode、nonce、recorded 时间、party/recorder),``loop.py`` 给工具事件加
  correlation_id,``sign_run_evidence()`` 在 run 结束后签 executor 根;
- ``agent_evidence`` 负责签名根、三方 cross-check、L0–L3 抽查和保留期。
  旧 harness JSONL 也能用 ``adapt_legacy_events()`` 升格。

最小用法::

    from agent_evidence import EvidenceChain, Signer, sign_root, build_bundle

    chain = EvidenceChain(job_id="job-1", attempt_id="att-1", party="executor")
    chain.append("job.assigned", {"spec_sha256": job_digest})
    root = sign_root(chain, Signer.generate("executor"), job_digest=job_digest)
    bundle = build_bundle([root])

独立复算(不需要本进程的任何状态)::

    python -m agent_evidence verify-chain events.jsonl
"""

from __future__ import annotations

from .audit import AuditLog, AuditLogError, verify_audit_log
from .canonical import canonical_json, canonical_sha256, isoformat, parse_isoformat, sha256_hex, utcnow
from .ed25519 import Ed25519Error, generate_seed, public_key_from_seed, sign, verify
from .events import (
    GENESIS,
    EvidenceChain,
    adapt_legacy_events,
    append_legacy_event,
    events_to_jsonl,
    load_events,
)
from .policy import DEFAULT_POLICY_PATH, EvidencePolicy, PolicyError, load_policy
from .retention import (
    EvidenceArtifact,
    apply_retention_plan,
    build_chain_digest,
    build_run_digest,
    plan_retention,
    verify_chain_digest,
    verify_run_digest,
)
from .sampling import (
    SamplingEpoch,
    SamplingError,
    record_finding,
    resolve_finding,
    verify_sampling_audit,
)
from .signing import (
    PARTIES,
    Signer,
    SigningError,
    TrustStore,
    build_bundle,
    sign_root,
    verify_bundle,
    verify_root,
)
from .verify import cross_check, l0_check, verify_chain, verify_legacy_events

__version__ = "0.1.0"

__all__ = [
    "GENESIS",
    "PARTIES",
    "AuditLog",
    "AuditLogError",
    "DEFAULT_POLICY_PATH",
    "Ed25519Error",
    "EvidenceArtifact",
    "EvidenceChain",
    "EvidencePolicy",
    "PolicyError",
    "SamplingEpoch",
    "SamplingError",
    "Signer",
    "SigningError",
    "TrustStore",
    "adapt_legacy_events",
    "append_legacy_event",
    "apply_retention_plan",
    "build_bundle",
    "build_chain_digest",
    "build_run_digest",
    "canonical_json",
    "canonical_sha256",
    "cross_check",
    "events_to_jsonl",
    "generate_seed",
    "isoformat",
    "l0_check",
    "load_events",
    "load_policy",
    "parse_isoformat",
    "plan_retention",
    "public_key_from_seed",
    "record_finding",
    "resolve_finding",
    "sha256_hex",
    "sign",
    "sign_root",
    "utcnow",
    "verify",
    "verify_audit_log",
    "verify_bundle",
    "verify_chain",
    "verify_chain_digest",
    "verify_legacy_events",
    "verify_root",
    "verify_run_digest",
    "verify_sampling_audit",
]
