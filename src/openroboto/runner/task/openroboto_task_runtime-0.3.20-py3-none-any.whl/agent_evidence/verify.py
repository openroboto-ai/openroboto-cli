"""链复算、交叉核对与 L0 检查 | Recompute, cross-check, and L0.

三条命令覆盖验收要求:

- :func:`verify_chain` —— 不需要任何 validator 状态,从 genesis 重算任意一条
  链;改任何一个字段都会在 ``seq`` / ``prev`` / ``payload_sha256`` / ``hash``
  四层中的某一层被发现。
- :func:`cross_check` —— 按 ``correlation_id`` 把不同 party 记录的同一动作
  对齐,比较 payload 哈希或指定字段;缺一条就是错误。
- :func:`l0_check` —— 100% 覆盖的 L0:验签、配置匹配、事件连续性、预算、
  nonce、时钟。
"""

from __future__ import annotations

import re
from typing import Any, Iterable, Mapping, Sequence

from .canonical import canonical_json, canonical_sha256, parse_isoformat, sha256_hex
from .events import GENESIS, REQUIRED_EVENT_FIELDS, is_job_nonce, is_nonce
from .result import CheckResult
from .signing import PARTIES, TrustStore, verify_bundle

_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_UNSET = object()


def _is_hex64(value: Any) -> bool:
    return isinstance(value, str) and bool(_HEX64.match(value))


def _payload_of(event: Mapping[str, Any]) -> Mapping[str, Any]:
    payload = event.get("payload")
    return payload if isinstance(payload, Mapping) else {}


def _effective_payload(event: Mapping[str, Any]) -> Mapping[str, Any]:
    """兼容 ``agent_harness_event`` 包装:取出真正的事件 payload。"""

    payload = _payload_of(event)
    legacy = payload.get("agent_harness_event")
    if isinstance(legacy, Mapping):
        legacy_payload = legacy.get("payload")
        return legacy_payload if isinstance(legacy_payload, Mapping) else {}
    return payload


def _as_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    return None


def verify_chain(
    events: Iterable[Mapping[str, Any]],
    *,
    expected_root: str | None = None,
    party: str | None = None,
    job_id: str | None = None,
    attempt_id: str | None = None,
    episode: Any = _UNSET,
    job_nonce: str | None = None,
    require_payload: bool = False,
) -> CheckResult:
    """从头复算一条证据链。

    ``require_payload=False`` 允许摘要模式(payload 已按保留期删除):事件哈希
    仍能验,payload 哈希只能靠事件里已提交的 ``payload_sha256``。返回结果里会
    带一条 warning 说明有多少条是摘要态。
    """

    result = CheckResult()
    items = [dict(event) for event in events]
    if not items:
        result.add_error("chain is empty")
        return result

    prev = GENESIS
    expected_seq = 0
    previous_ts: float | None = None
    seen_nonces: set[str] = set()
    chain_job: Any = _UNSET
    chain_attempt: Any = _UNSET
    chain_episode: Any = _UNSET
    chain_job_nonce: Any = _UNSET
    chain_party: Any = _UNSET
    digest_only = 0
    type_counts: dict[str, int] = {}

    for position, event in enumerate(items):
        seq = event.get("seq")
        where = f"seq {seq!r}" if seq is not None else f"position {position}"
        missing = [field for field in REQUIRED_EVENT_FIELDS if field not in event]
        if missing:
            result.add_error(f"{where}: missing fields: {', '.join(missing)}")
            # 缺字段时仍尽量推进 prev,避免后续全部报同一处错误。
            prev = str(event.get("hash") or prev)
            expected_seq += 1
            continue

        if event.get("v") != 1:
            result.add_error(f"{where}: unsupported event version {event.get('v')!r}")
        if seq != expected_seq:
            result.add_error(f"{where}: expected seq {expected_seq}, got {seq!r}")
        if event.get("prev") != prev:
            result.add_error(f"{where}: prev {event.get('prev')!r} != computed {prev!r}")

        # 链级元数据必须一致。
        for field, chain_value in (
            ("job_id", chain_job),
            ("attempt_id", chain_attempt),
            ("episode", chain_episode),
            ("job_nonce", chain_job_nonce),
            ("party", chain_party),
        ):
            value = event.get(field)
            if chain_value is _UNSET:
                if field == "job_id":
                    chain_job = value
                elif field == "attempt_id":
                    chain_attempt = value
                elif field == "episode":
                    chain_episode = value
                elif field == "job_nonce":
                    chain_job_nonce = value
                else:
                    chain_party = value
            elif value != chain_value:
                result.add_error(f"{where}: {field} {value!r} != chain {chain_value!r}")

        recorder = event.get("recorder")
        if not isinstance(recorder, str) or not recorder:
            result.add_error(f"{where}: recorder must be a non-empty string")
        if not isinstance(event.get("type"), str) or not event.get("type"):
            result.add_error(f"{where}: type must be a non-empty string")
        else:
            type_counts[str(event["type"])] = type_counts.get(str(event["type"]), 0) + 1

        nonce = event.get("nonce")
        if not is_nonce(nonce):
            result.add_error(f"{where}: nonce must be 32 lowercase hex chars")
        elif nonce in seen_nonces:
            result.add_error(f"{where}: duplicate nonce {nonce!r}")
        else:
            seen_nonces.add(str(nonce))
        if not is_job_nonce(event.get("job_nonce")):
            result.add_error(f"{where}: job_nonce must be a non-empty string")

        ts = event.get("ts_monotonic")
        if isinstance(ts, bool) or not isinstance(ts, (int, float)) or ts < 0:
            result.add_error(f"{where}: ts_monotonic must be a non-negative number")
        else:
            if previous_ts is not None and float(ts) < previous_ts:
                result.add_error(f"{where}: monotonic time regressed ({ts} < {previous_ts})")
            previous_ts = float(ts)

        try:
            parse_isoformat(str(event.get("recorded_at")))
        except ValueError:
            result.add_error(f"{where}: recorded_at is not ISO-8601")

        if not _is_hex64(event.get("payload_sha256")):
            result.add_error(f"{where}: payload_sha256 must be a 64-char lowercase sha256 hex")
        payload = event.get("payload")
        if payload is None:
            digest_only += 1
            if require_payload:
                result.add_error(f"{where}: payload is missing (digest-only record)")
        elif not isinstance(payload, Mapping):
            result.add_error(f"{where}: payload must be an object")
        else:
            try:
                payload_hash = canonical_sha256(dict(payload))
            except (TypeError, ValueError):
                result.add_error(f"{where}: payload is not canonical-JSON serializable")
            else:
                if event.get("payload_sha256") != payload_hash:
                    result.add_error(f"{where}: payload hash mismatch")

        if "correlation_id" in event and not isinstance(event.get("correlation_id"), str):
            result.add_error(f"{where}: correlation_id must be a string")

        body = {key: value for key, value in event.items() if key != "hash"}
        try:
            computed = sha256_hex(prev + canonical_json(body))
        except (TypeError, ValueError):
            result.add_error(f"{where}: event is not canonical-JSON serializable")
            computed = str(event.get("hash") or prev)
        else:
            if event.get("hash") != computed:
                result.add_error(f"{where}: hash mismatch (event modified or chain broken)")
        prev = str(event.get("hash") or computed)
        expected_seq += 1

    if expected_root is not None and prev != expected_root:
        result.add_error(f"root mismatch: computed {prev!r}, expected {expected_root!r}")
    if party is not None and chain_party != party:
        result.add_error(f"chain party {chain_party!r} != expected {party!r}")
    if job_id is not None and chain_job != job_id:
        result.add_error(f"chain job_id {chain_job!r} != expected {job_id!r}")
    if attempt_id is not None and chain_attempt != attempt_id:
        result.add_error(f"chain attempt_id {chain_attempt!r} != expected {attempt_id!r}")
    if episode is not _UNSET and chain_episode != episode:
        result.add_error(f"chain episode {chain_episode!r} != expected {episode!r}")
    if job_nonce is not None and chain_job_nonce != job_nonce:
        result.add_error(f"chain job_nonce {chain_job_nonce!r} != expected {job_nonce!r}")
    if digest_only:
        result.add_warning(f"{digest_only}/{len(items)} events are digest-only (payload removed by retention)")

    result.details.update(
        {
            "event_count": len(items),
            "root": prev,
            "party": None if chain_party is _UNSET else chain_party,
            "job_id": None if chain_job is _UNSET else chain_job,
            "attempt_id": None if chain_attempt is _UNSET else chain_attempt,
            "episode": None if chain_episode is _UNSET else chain_episode,
            "job_nonce": None if chain_job_nonce is _UNSET else chain_job_nonce,
            "type_counts": type_counts,
        }
    )
    return result


def verify_legacy_events(
    events: Iterable[Mapping[str, Any]],
    *,
    expected_root: str | None = None,
) -> CheckResult:
    """验 ``agent_harness/events.py`` 的旧格式(无 nonce/job/recorder)。

    只用于迁移期确认旧链没被改过;新记录应写成 :class:`EvidenceChain` 格式。
    """

    result = CheckResult()
    items = [dict(event) for event in events]
    if not items:
        result.add_error("legacy chain is empty")
        return result
    prev = GENESIS
    previous_ts: float | None = None
    for position, event in enumerate(items):
        seq = event.get("seq")
        where = f"seq {seq!r}" if seq is not None else f"position {position}"
        if seq != position:
            result.add_error(f"{where}: seq must be {position}")
        if event.get("prev") != prev:
            result.add_error(f"{where}: prev mismatch")
        if not _is_hex64(event.get("payload_sha256")):
            result.add_error(f"{where}: payload_sha256 missing")
        payload = event.get("payload")
        if isinstance(payload, Mapping):
            try:
                if event.get("payload_sha256") != canonical_sha256(dict(payload)):
                    result.add_error(f"{where}: payload hash mismatch")
            except (TypeError, ValueError):
                result.add_error(f"{where}: payload is not canonical-JSON serializable")
        ts = event.get("ts")
        if isinstance(ts, bool) or not isinstance(ts, (int, float)) or ts < 0:
            result.add_error(f"{where}: ts must be a non-negative number")
        else:
            if previous_ts is not None and float(ts) < previous_ts:
                result.add_error(f"{where}: monotonic time regressed")
            previous_ts = float(ts)
        body = {key: value for key, value in event.items() if key != "hash"}
        try:
            computed = sha256_hex(prev + canonical_json(body))
        except (TypeError, ValueError):
            result.add_error(f"{where}: event is not canonical-JSON serializable")
            computed = str(event.get("hash") or prev)
        else:
            if event.get("hash") != computed:
                result.add_error(f"{where}: hash mismatch")
        prev = str(event.get("hash") or computed)
    if expected_root is not None and prev != expected_root:
        result.add_error(f"root mismatch: computed {prev!r}, expected {expected_root!r}")
    result.details.update({"event_count": len(items), "root": prev, "format": "legacy-agent-harness"})
    return result


def _dig(payload: Mapping[str, Any], dotted: str) -> Any:
    current: Any = payload
    for part in dotted.split("."):
        if not isinstance(current, Mapping) or part not in current:
            return _UNSET
        current = current[part]
    return current


def cross_check(
    chains: Mapping[str, Sequence[Mapping[str, Any]]],
    rules: Sequence[Mapping[str, Any]],
    *,
    verify: bool = True,
    trust_store: TrustStore | None = None,
    bundle: Mapping[str, Any] | None = None,
) -> CheckResult:
    """按相关性规则核对多个 party 的链。

    规则字段::

        {"type": "model_call", "parties": ["executor", "gateway"],
         "match": "correlation_id",          # 或 "payload_sha256"
         "compare": ["provider_meta.request_id"]}   # 可选,逐字段比较

    ``match="correlation_id"`` 要求事件带 envelope 级 ``correlation_id``;
    ``compare`` 里缺失字段按错误处理,不做静默跳过。
    """

    result = CheckResult()
    normalized: dict[str, list[dict[str, Any]]] = {
        party: [dict(event) for event in events] for party, events in chains.items()
    }
    if verify:
        for party, events in sorted(normalized.items()):
            chain_result = verify_chain(events, party=party)
            result.merge(chain_result, prefix=f"{party}: ")
    if bundle is not None:
        if trust_store is None:
            result.add_error("bundle verification needs a trust_store")
        else:
            result.merge(verify_bundle(bundle, trust_store=trust_store, chains=normalized), prefix="bundle: ")

    if not rules:
        result.add_warning("no cross-check rules supplied")
        return result

    matched = 0
    for rule in rules:
        event_type = rule.get("type")
        parties = list(rule.get("parties") or [])
        match_on = str(rule.get("match") or "correlation_id")
        compare = list(rule.get("compare") or [])
        if not event_type or not parties:
            result.add_error(f"invalid cross-check rule: {rule!r}")
            continue
        if match_on not in ("correlation_id", "payload_sha256"):
            result.add_error(f"rule {event_type!r}: unsupported match {match_on!r}")
            continue
        missing_chains = set(parties) - set(normalized)
        if missing_chains:
            # 单方测试网可能没有 gateway/simulator 链;根校验(verify_bundle)
            # 负责判断该模式是否允许缺失,这里只跳过无法做的交叉核对。
            result.add_warning(
                f"rule {event_type!r}: skipped, no chain for {sorted(missing_chains)}"
            )
            continue

        indexes: dict[str, dict[str, dict[str, Any]]] = {}
        for party in parties:
            index: dict[str, dict[str, Any]] = {}
            for event in normalized[party]:
                if event.get("type") != event_type:
                    continue
                key = event.get("correlation_id") if match_on == "correlation_id" else event.get("payload_sha256")
                if not isinstance(key, str) or not key:
                    result.add_error(f"{party}: {event_type!r} event at seq {event.get('seq')!r} has no {match_on}")
                    continue
                if key in index:
                    result.add_error(f"{party}: duplicate {event_type!r} {match_on} {key!r}")
                    continue
                index[key] = event
            indexes[party] = index

        all_keys = set().union(*(set(index) for index in indexes.values()))
        for key in sorted(all_keys):
            present = {party: indexes[party][key] for party in parties if key in indexes[party]}
            missing = [party for party in parties if party not in present]
            if missing:
                result.add_error(
                    f"{event_type!r} {match_on}={key!r}: missing in {', '.join(missing)}"
                )
                continue
            if compare:
                reference_party = parties[0]
                reference = present[reference_party]
                for party in parties[1:]:
                    for path in compare:
                        left = _dig(_effective_payload(reference), path)
                        right = _dig(_effective_payload(present[party]), path)
                        if left is _UNSET or right is _UNSET:
                            result.add_error(
                                f"{event_type!r} {key!r}: compare field {path!r} missing "
                                f"({reference_party if left is _UNSET else party})"
                            )
                        else:
                            try:
                                same = canonical_json(left) == canonical_json(right)
                            except (TypeError, ValueError):
                                result.add_error(
                                    f"{event_type!r} {key!r}: field {path!r} is not canonical-JSON serializable"
                                )
                            else:
                                if not same:
                                    result.add_error(
                                        f"{event_type!r} {key!r}: field {path!r} differs between "
                                        f"{reference_party} and {party}"
                                    )
            matched += 1

    result.details.update(
        {
            "rules": len(rules),
            "matched_events": matched,
            "parties": sorted(normalized),
        }
    )
    return result


def _budget_snapshot(payload: Mapping[str, Any]) -> tuple[int | None, int | None]:
    budget = payload.get("budget")
    if not isinstance(budget, Mapping):
        return None, None
    max_calls = _as_int(budget.get("max_calls"))
    max_tokens = _as_int(budget.get("max_total_tokens"))
    if max_tokens is None:
        max_tokens = _as_int(budget.get("max_tokens"))
    return max_calls, max_tokens


def _usage_tokens(payload: Mapping[str, Any]) -> int | None:
    usage = payload.get("usage")
    if not isinstance(usage, Mapping):
        return None
    for key in ("total_tokens", "totalTokens", "total"):
        value = _as_int(usage.get(key))
        if value is not None:
            return value
    prompt = _as_int(usage.get("prompt_tokens"))
    if prompt is None:
        prompt = _as_int(usage.get("input_tokens"))
    completion = _as_int(usage.get("completion_tokens"))
    if completion is None:
        completion = _as_int(usage.get("output_tokens"))
    if prompt is not None and completion is not None:
        return prompt + completion
    return None


def _check_budget(chains: Mapping[str, Sequence[Mapping[str, Any]]]) -> CheckResult:
    result = CheckResult()
    summaries: dict[str, dict[str, Any]] = {}
    for party, events in sorted(chains.items()):
        max_calls: int | None = None
        max_tokens: int | None = None
        calls = 0
        tokens = 0
        tokens_seen = 0
        for event in events:
            payload = _effective_payload(event)
            event_max_calls, event_max_tokens = _budget_snapshot(payload)
            if event_max_calls is not None:
                max_calls = event_max_calls
            if event_max_tokens is not None:
                max_tokens = event_max_tokens
            if event.get("type") == "model_call":
                calls += 1
                total = _usage_tokens(payload)
                if total is not None:
                    tokens += total
                    tokens_seen += 1
        if calls and max_calls is None and max_tokens is None:
            result.add_warning(f"{party}: model calls recorded but no budget snapshot; budget not enforced")
        if max_calls is not None and calls > max_calls:
            result.add_error(f"{party}: model calls {calls} exceed budget.max_calls {max_calls}")
        if max_tokens is not None and tokens > max_tokens:
            result.add_error(f"{party}: tokens {tokens} exceed budget.max_total_tokens {max_tokens}")
        if calls and tokens_seen != calls:
            missing = calls - tokens_seen
            result.add_warning(
                f"{party}: {missing} model call(s) without usage; token total is a lower bound"
            )
        summaries[party] = {
            "model_calls": calls,
            "tokens": tokens,
            "max_calls": max_calls,
            "max_total_tokens": max_tokens,
        }
    result.details["budget"] = summaries
    return result


def _check_clock(
    chains: Mapping[str, Sequence[Mapping[str, Any]]],
    *,
    max_drift_s: float,
) -> CheckResult:
    """墙钟只作锚点;这里抓两种异常:墙钟倒退、墙钟与单调时间差超阈值。"""

    result = CheckResult()
    summaries: dict[str, Any] = {}
    for party, events in sorted(chains.items()):
        previous_wall = None
        previous_mono = None
        max_seen = 0.0
        for event in events:
            if "recorded_at" not in event or "ts_monotonic" not in event:
                continue
            try:
                wall = parse_isoformat(str(event["recorded_at"])).timestamp()
            except ValueError:
                continue
            mono = event.get("ts_monotonic")
            if not isinstance(mono, (int, float)):
                continue
            if previous_wall is not None and previous_mono is not None:
                wall_delta = wall - previous_wall
                mono_delta = float(mono) - previous_mono
                if wall_delta < -1e-6:
                    result.add_error(f"{party}: wall clock regressed at seq {event.get('seq')!r}")
                drift = abs(wall_delta - mono_delta)
                max_seen = max(max_seen, drift)
                if drift > max_drift_s:
                    result.add_error(
                        f"{party}: wall/monotonic drift {drift:.3f}s exceeds {max_drift_s}s "
                        f"at seq {event.get('seq')!r}"
                    )
            previous_wall = wall
            previous_mono = float(mono)
        summaries[party] = {
            "max_drift_s": round(max_seen, 6),
            "anchor": events[0].get("recorded_at") if events else None,
        }
    result.details["clock"] = summaries
    return result


def l0_check(
    chains: Mapping[str, Sequence[Mapping[str, Any]]],
    *,
    bundle: Mapping[str, Any],
    trust_store: TrustStore,
    policy: Any,
    expected_job_id: str | None = None,
    expected_job_digest: str | None = None,
    expected_attempt_id: str | None = None,
    expected_episode: int | None = None,
) -> CheckResult:
    """L0:100% 覆盖。验签、配置匹配、连续性、预算、nonce、时钟。"""

    result = CheckResult()
    if not chains:
        result.add_error("no chains supplied")
        return result
    # 公开 API 同时接受 list[event] 和 EvidenceChain;内部统一成 list。
    chains = {party: [dict(event) for event in events] for party, events in chains.items()}

    bundle_mode = str(bundle.get("mode") or "single")
    required_parties = set(PARTIES) if bundle_mode == "three_party" else {"executor"}
    missing_chains = required_parties - set(chains)
    if missing_chains:
        result.add_error(
            f"missing chains for signing mode {bundle_mode}: {', '.join(sorted(missing_chains))}"
        )

    for party, events in sorted(chains.items()):
        chain_result = verify_chain(events, party=party)
        result.merge(chain_result, prefix=f"chain.{party}: ")

    bundle_result = verify_bundle(
        bundle,
        trust_store=trust_store,
        chains=chains,
        expected_job_id=expected_job_id,
        expected_job_digest=expected_job_digest,
        expected_attempt_id=expected_attempt_id,
        expected_episode=expected_episode,
    )
    result.merge(bundle_result, prefix="bundle: ")

    rules = getattr(policy, "cross_check_rules", [])
    cross = cross_check(chains, rules, verify=False, trust_store=trust_store, bundle=bundle)
    result.merge(cross, prefix="cross_check: ")

    result.merge(_check_budget(chains), prefix="budget: ")
    result.merge(
        _check_clock(chains, max_drift_s=float(getattr(policy, "max_clock_drift_s", 5.0))),
        prefix="clock: ",
    )
    result.details.update(
        {
            "l0_checks": [
                "signature",
                "config_match",
                "event_continuity",
                "budget",
                "nonce",
                "clock",
            ],
            "chains": {party: len(events) for party, events in chains.items()},
        }
    )
    return result


__all__ = ["cross_check", "l0_check", "verify_chain", "verify_legacy_events"]
