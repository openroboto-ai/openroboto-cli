"""交付证据打包：把 executor / simulator 的原文链与签名根装进后端请求。

本模块只做**纯函数**的搬运、复算与绑定校验，不跑模型、不跑仿真、不签名，
也不构造 gateway 证据：

- executor 的链与根由 harness 产生（:mod:`agent_harness.loop`），本模块只读取
  ``RunResult.events`` 与 ``RunResult.extra["signing"]["root_record"]``；
- simulator 的链与根由独立的 simulator 主体产生（OPE-203），本模块只消费它
  交出来的**原文**；缺失或不合法就 fail-closed，绝不从 executor 事件反推、
  也绝不代签；
- gateway 证据由后端从自己的 ``model_gateway_calls`` / ``model_gateway_roots``
  读取（OPE-191），请求里不上传、本模块也不接受。

后端的真实契约见 ``openroboto-backend@713b17f``：

- ``app/api/routes/eval_results.py``：``EpisodeResultIn.chains`` /
  ``events`` / ``roots``，以及「executor 出现在 ``chains`` 时旧形状必须为空」；
- ``app/domain/delivery_evidence.py``：三方签名模式、simulator 工具调用按
  ``(correlation_id, name, args_sha256)`` 与 executor 逐条对齐；
- ``app/domain/evidence_chain.py``：从 genesis 复算链、根绑定
  ``job_id/attempt_id/episode/job_nonce/job_digest/root/event_count/seq``。

这里的校验是**执行层提前 fail-closed**，最终计奖判定仍由后端完成；两边都不
存在「缺证据默认质量 1」的路径。本地验签只证明根与调用方提供的 simulator
公钥一致，**真正的信任根是后端登记的运营公钥**（以及网关自己落库的链）；
本地公钥配置错误不能让一份伪造证据在后端计奖。

## 冻结配置摘要不是本地可证明的

`job_digest` 的**真实性**只能由后端拿发单时落库的 `spec_digest` 判定。执行层
收到的 spec 是后端配置的一个**执行视图**：它可能缺少 `evidence`/部分
`delivery`/`budget` 字段，`agent_harness.parse_spec()` 在缺显式值时会算一个
兜底摘要。那个兜底值只说明「这份输入算出来是什么」，不证明它就是发单时
冻结的那份配置。因此 `three_party` 打包要求调用方显式提供
`frozen_job_digest`（来源应是后端已认证的 job/spec 响应），并且：
executor 根、simulator 根都必须绑定它；缺失时 fail-closed，而不是把
`parse_spec()` 的兜底值或 spec 里自报的 `evidence.job_digest` 当成可信摘要。
"""

from __future__ import annotations

import hashlib
import json
import pathlib
import re
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from agent_evidence.signing import TrustStore, verify_root
from agent_evidence.verify import verify_chain

from .canonical import canonical_json

__all__ = [
    "DELIVERY_PARTIES",
    "DeliveryEvidenceError",
    "SimulatorEvidence",
    "pack_evidence_chains",
    "load_simulator_evidence",
    "validate_executor_evidence",
    "validate_simulator_evidence",
]

#: 执行层能提交的证据主体。gateway 永远由后端落库，不从请求取。
DELIVERY_PARTIES: tuple[str, ...] = ("executor", "simulator")

#: 稳定原因码。执行层日志 / issue 对账按它分支；detail 给人看。
REASON_UNKNOWN_MODE = "DELIVERY_EVIDENCE_UNKNOWN_MODE"
REASON_EXECUTOR_MISSING = "DELIVERY_EVIDENCE_EXECUTOR_MISSING"
REASON_EXECUTOR_CHAIN = "DELIVERY_EVIDENCE_EXECUTOR_CHAIN_INVALID"
REASON_EXECUTOR_ROOT = "DELIVERY_EVIDENCE_EXECUTOR_ROOT_INVALID"
REASON_SIMULATOR_MISSING = "DELIVERY_EVIDENCE_SIMULATOR_MISSING"
REASON_SIMULATOR_CHAIN = "DELIVERY_EVIDENCE_SIMULATOR_CHAIN_INVALID"
REASON_SIMULATOR_ROOT = "DELIVERY_EVIDENCE_SIMULATOR_ROOT_INVALID"
REASON_SIMULATOR_UNVERIFIED = "DELIVERY_EVIDENCE_SIMULATOR_UNVERIFIED"
REASON_SIMULATOR_PARTY = "DELIVERY_EVIDENCE_SIMULATOR_PARTY_MISMATCH"
REASON_TOOL_MISMATCH = "DELIVERY_EVIDENCE_TOOL_MISMATCH"
REASON_BINDING = "DELIVERY_EVIDENCE_BINDING_MISMATCH"
#: three_party 交付没有**独立来源**的冻结 config 摘要（不能拿 parse_spec
#: 的兜底摘要或 spec 里自报的 evidence.job_digest 当作真实性证明）。
REASON_FROZEN_DIGEST_MISSING = "DELIVERY_EVIDENCE_FROZEN_DIGEST_MISSING"
REASON_GATEWAY_REJECTED = "DELIVERY_EVIDENCE_GATEWAY_REJECTED"

_HEX64 = re.compile(r"\A[0-9a-f]{64}\Z")
_SIGNING_MODES = ("single", "three_party")

#: 这些交付分类表示「运行跑完了」。只有它们才需要完整的可计奖证据；
#: 基建失败 / 超时的交付本来就不会产生点数，且可能确实没有 simulator 链。
_DELIVERED_STATUSES = frozenset(
    {"task_success", "task_failure", "agent_budget_exhausted", "agent_invalid_action"}
)


class DeliveryEvidenceError(ValueError):
    """交付证据不成立。``reason_code`` 是稳定词表，``detail`` 可改措辞。"""

    def __init__(self, reason_code: str, detail: str) -> None:
        super().__init__(f"{reason_code}: {detail}")
        self.reason_code = reason_code
        self.detail = detail


@dataclass(frozen=True, slots=True)
class SimulatorEvidence:
    """simulator 主体交出的原文证据。本模块只读不改。"""

    events: tuple[Mapping[str, Any], ...]
    root: Mapping[str, Any]
    party: str = "simulator"


def _as_events(value: Any, *, what: str) -> tuple[Mapping[str, Any], ...]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
        raise DeliveryEvidenceError(REASON_SIMULATOR_CHAIN, f"{what} 必须是事件列表")
    events: list[Mapping[str, Any]] = []
    for position, item in enumerate(value):
        if not isinstance(item, Mapping):
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_CHAIN, f"{what} 第 {position} 项不是对象"
            )
        events.append(item)
    return tuple(events)


def _read_json(path: pathlib.Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise DeliveryEvidenceError(
            REASON_SIMULATOR_MISSING, f"读不到 simulator 证据 {path}: {exc}"
        ) from exc


def _read_jsonl(path: pathlib.Path) -> tuple[Mapping[str, Any], ...]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise DeliveryEvidenceError(
            REASON_SIMULATOR_MISSING, f"读不到 simulator 事件链 {path}: {exc}"
        ) from exc
    events: list[Mapping[str, Any]] = []
    for line_number, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except ValueError as exc:
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_CHAIN,
                f"{path} 第 {line_number} 行不是 JSON: {exc}",
            ) from exc
        if not isinstance(value, Mapping):
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_CHAIN, f"{path} 第 {line_number} 行不是对象"
            )
        events.append(value)
    return tuple(events)


def _root_path_for(events_path: pathlib.Path) -> pathlib.Path:
    name = events_path.name
    if name.endswith(".simulator.events.jsonl"):
        return events_path.with_name(name.replace(".simulator.events.jsonl", ".simulator.root.json"))
    if name.endswith(".jsonl"):
        return events_path.with_suffix(".root.json")
    return events_path.with_name(events_path.stem + ".root.json")


def load_simulator_evidence(source: Any) -> SimulatorEvidence:
    """读取 simulator 证据。

    接受：

    - :class:`SimulatorEvidence`（原样返回）；
    - 带 ``events`` + ``root``（或 ``root_record``）的 mapping / 对象；
    - 单个 JSON 文件 ``{"events": [...], "root": {...}}``；
    - 事件 JSONL 路径：同目录下按 ``*.simulator.events.jsonl`` →
      ``*.simulator.root.json``（或 ``.jsonl`` → ``.root.json``）找根。
    """

    if isinstance(source, SimulatorEvidence):
        return source

    if isinstance(source, Mapping) or (
        not isinstance(source, (str, bytes, pathlib.Path))
        and hasattr(source, "events")
        and (hasattr(source, "root") or hasattr(source, "root_record"))
    ):
        events_value = (
            source.get("events") if isinstance(source, Mapping) else getattr(source, "events")
        )
        root_value = (
            (source.get("root") or source.get("root_record"))
            if isinstance(source, Mapping)
            else (getattr(source, "root", None) or getattr(source, "root_record", None))
        )
        party = (
            source.get("party") if isinstance(source, Mapping) else getattr(source, "party", "simulator")
        ) or "simulator"
        if party == "gateway":
            raise DeliveryEvidenceError(
                REASON_GATEWAY_REJECTED,
                "gateway 证据必须由后端从 model_gateway_calls / "
                "model_gateway_roots 读取，不能从请求上传",
            )
        if party != "simulator":
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_PARTY,
                f"只接受 simulator 主体的证据，收到 party={party!r}",
            )
        if not isinstance(root_value, Mapping):
            raise DeliveryEvidenceError(REASON_SIMULATOR_ROOT, "simulator 证据缺签名根")
        return SimulatorEvidence(
            events=_as_events(events_value, what="simulator.events"),
            root=dict(root_value),
            party="simulator",
        )

    if not isinstance(source, (str, pathlib.Path)):
        raise DeliveryEvidenceError(
            REASON_SIMULATOR_MISSING,
            f"simulator 证据必须是对象 / JSON / JSONL 路径，收到 {type(source).__name__}",
        )
    path = pathlib.Path(source).expanduser()
    if path.is_dir():
        raise DeliveryEvidenceError(
            REASON_SIMULATOR_MISSING, f"simulator 证据要指向文件，不是目录：{path}"
        )
    if not path.exists():
        raise DeliveryEvidenceError(REASON_SIMULATOR_MISSING, f"simulator 证据不存在：{path}")

    if path.suffix == ".jsonl":
        events = _read_jsonl(path)
        root_path = _root_path_for(path)
        if not root_path.exists():
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_ROOT, f"simulator 根文件不存在：{root_path}"
            )
        root = _read_json(root_path)
    else:
        value = _read_json(path)
        if not isinstance(value, Mapping):
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_CHAIN, f"simulator 证据文件不是对象：{path}"
            )
        return load_simulator_evidence(value)

    if not isinstance(root, Mapping):
        raise DeliveryEvidenceError(REASON_SIMULATOR_ROOT, f"simulator 根不是对象：{root_path}")
    return SimulatorEvidence(events=events, root=dict(root), party="simulator")


def _chain_errors(
    party: str,
    events: Sequence[Mapping[str, Any]],
    *,
    expected: Mapping[str, Any],
) -> list[str]:
    """从 genesis 复算一条链，并核对链级绑定。"""

    result = verify_chain(
        events,
        party=party,
        job_id=expected.get("job_id"),
        attempt_id=expected.get("attempt_id"),
        episode=expected.get("episode"),
        job_nonce=expected.get("job_nonce"),
        require_payload=True,
    )
    return list(result.errors)


def _root_errors(
    root: Mapping[str, Any],
    *,
    party: str,
    chain_root: str,
    event_count: int,
    expected: Mapping[str, Any],
    job_digest: str | None,
    trust_store: TrustStore | None,
) -> tuple[list[str], str | None]:
    """根字段形状 + 链/运行绑定 + （可选）验签。返回 ``(errors, reason)``。"""

    errors: list[str] = []
    if root.get("party") != party:
        errors.append(f"根的 party {root.get('party')!r} 不是 {party!r}")
    if root.get("root") != chain_root:
        errors.append("根哈希与链尾不一致")
    if root.get("event_count") != event_count:
        errors.append("根的 event_count 与事件数不一致")
    if root.get("first_seq") != 0:
        errors.append("根的 first_seq 不是 0")
    count, last = root.get("event_count"), root.get("last_seq")
    if (
        isinstance(count, bool)
        or not isinstance(count, int)
        or isinstance(last, bool)
        or not isinstance(last, int)
        or count < 1
        or count != last + 1
    ):
        errors.append("根的 event_count / last_seq 对不上")
    for field in ("job_id", "attempt_id", "episode", "job_nonce"):
        if root.get(field) != expected.get(field):
            errors.append(f"根的 {field} 与本次运行不一致")
    if job_digest is not None and root.get("job_digest") != job_digest:
        errors.append("根的 job_digest 与冻结配置不一致")
    if not _HEX64.match(str(root.get("job_digest") or "")):
        errors.append("根的 job_digest 不是 64 位小写 hex")

    verified = False
    if trust_store is not None:
        result = verify_root(root, trust_store)
        errors.extend(result.errors)
        verified = result.ok
    return errors, "verified" if verified else None


def _tool_index(
    events: Iterable[Mapping[str, Any]],
    *,
    party: str,
    require_args: bool,
) -> tuple[dict[str, tuple[str, str]], list[str]]:
    """``tool_call`` → ``{correlation: (name, args_sha256)}``，与后端同语义。"""

    index: dict[str, tuple[str, str]] = {}
    errors: list[str] = []
    for event in events:
        if event.get("type") != "tool_call":
            continue
        correlation = event.get("correlation_id")
        if not isinstance(correlation, str) or not correlation:
            errors.append(f"{party}: tool_call 缺 correlation_id")
            continue
        if correlation in index:
            errors.append(f"{party}: tool_call 的 correlation_id 重复：{correlation}")
            continue
        payload = event.get("payload")
        payload = payload if isinstance(payload, Mapping) else {}
        name = payload.get("name")
        args_sha = payload.get("args_sha256")
        if not isinstance(name, str) or not name:
            errors.append(f"{party}: tool_call {correlation} 没有工具名")
            continue
        if not isinstance(args_sha, str) or not _HEX64.match(args_sha):
            errors.append(f"{party}: tool_call {correlation} 没有 args_sha256")
            continue

        if "args" not in payload:
            if require_args:
                errors.append(
                    f"{party}: tool_call {correlation} 没有原始 args，无法复算 args_sha256"
                )
                continue
        else:
            args = payload.get("args")
            if not isinstance(args, Mapping):
                errors.append(f"{party}: tool_call {correlation} 的 args 不是对象")
                continue
            try:
                recomputed = hashlib.sha256(
                    canonical_json(dict(args)).encode("utf-8")
                ).hexdigest()
            except (TypeError, ValueError):
                errors.append(f"{party}: tool_call {correlation} 的 args 无法规范化")
                continue
            if recomputed != args_sha:
                errors.append(
                    f"{party}: tool_call {correlation} 的 args 与 args_sha256 不一致"
                )
                continue

        index[correlation] = (name, args_sha)
    return index, errors


def _tool_pair_errors(
    executor_events: Sequence[Mapping[str, Any]],
    simulator_events: Sequence[Mapping[str, Any]],
) -> list[str]:
    """executor 与 simulator 的工具动作逐条对齐。"""

    recorded, recorded_errors = _tool_index(
        executor_events, party="executor", require_args=True
    )
    simulated, simulated_errors = _tool_index(
        simulator_events, party="simulator", require_args=False
    )
    errors = [*recorded_errors, *simulated_errors]
    if errors:
        return errors

    missing = sorted(set(recorded) - set(simulated))
    extra = sorted(set(simulated) - set(recorded))
    if missing or extra:
        return [
            f"simulator 与 executor 的执行记录对不上：缺 {missing[:3]}，多 {extra[:3]}"
        ]
    for correlation in sorted(recorded):
        if recorded[correlation] != simulated[correlation]:
            return [
                f"工具调用 {correlation} 的身份/参数不一致："
                f"executor={recorded[correlation]} simulator={simulated[correlation]}"
            ]
    return []


def _filled_binding(
    executor_events: Sequence[Mapping[str, Any]],
    expected: Mapping[str, Any],
) -> dict[str, Any]:
    """executor 链是第一手绑定来源；spec 缺 job_id/job_nonce 时从事件补。"""

    if not executor_events:
        raise DeliveryEvidenceError(REASON_EXECUTOR_MISSING, "executor 链为空")
    first = executor_events[0]
    filled = dict(expected)
    for name in ("job_id", "attempt_id", "episode", "job_nonce"):
        if filled.get(name) in (None, ""):
            value = first.get(name)
            if value in (None, ""):
                raise DeliveryEvidenceError(
                    REASON_BINDING, f"无法确定 {name}：spec 与 executor 链都没有"
                )
            filled[name] = value
    filled["episode"] = int(filled["episode"])
    return filled


def validate_executor_evidence(
    result: Any,
    *,
    expected: Mapping[str, Any],
) -> tuple[tuple[Mapping[str, Any], ...], Mapping[str, Any], dict[str, Any]]:
    """校验 executor 的原始事件链与签名根。

    链必须是 harness 真实产出的原文；根缺字段 / 绑定错 / 与链尾不一致都拒。
    返回 ``(events, root, 补全后的绑定)``。
    """

    events = tuple(dict(event) for event in getattr(result, "events", ()) or ())
    if not events:
        raise DeliveryEvidenceError(REASON_EXECUTOR_MISSING, "executor 链为空")
    expected = _filled_binding(events, expected)

    signing = getattr(result, "extra", {}).get("signing")
    root = signing.get("root_record") if isinstance(signing, Mapping) else None
    if not isinstance(root, Mapping):
        raise DeliveryEvidenceError(
            REASON_EXECUTOR_ROOT, "executor 没有签名根（未配置或未签名）"
        )

    errors = _chain_errors("executor", events, expected=expected)
    if errors:
        raise DeliveryEvidenceError(REASON_EXECUTOR_CHAIN, "; ".join(errors[:3]))

    chain_root = str(events[-1]["hash"])
    root_errors, _ = _root_errors(
        root,
        party="executor",
        chain_root=chain_root,
        event_count=len(events),
        expected=expected,
        job_digest=str(root.get("job_digest") or ""),
        trust_store=None,
    )
    if root_errors:
        raise DeliveryEvidenceError(REASON_EXECUTOR_ROOT, "; ".join(root_errors[:3]))
    return events, dict(root), expected


def validate_simulator_evidence(
    evidence: SimulatorEvidence,
    *,
    executor_events: Sequence[Mapping[str, Any]],
    expected: Mapping[str, Any],
    job_digest: str,
    trust_store: TrustStore | None,
    require_signature: bool = True,
) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    """校验 simulator 原文链 + 根，并与 executor 的工具动作逐条对齐。"""

    if evidence.party != "simulator":
        raise DeliveryEvidenceError(
            REASON_SIMULATOR_PARTY,
            f"simulator 证据 party={evidence.party!r}；不能拿别的 party 顶替",
        )
    if not evidence.events:
        raise DeliveryEvidenceError(REASON_SIMULATOR_MISSING, "simulator 链为空")

    errors = _chain_errors("simulator", evidence.events, expected=expected)
    if errors:
        raise DeliveryEvidenceError(REASON_SIMULATOR_CHAIN, "; ".join(errors[:3]))

    chain_root = str(evidence.events[-1]["hash"])
    root_errors, verified = _root_errors(
        evidence.root,
        party="simulator",
        chain_root=chain_root,
        event_count=len(evidence.events),
        expected=expected,
        job_digest=job_digest,
        trust_store=trust_store,
    )
    if root_errors:
        raise DeliveryEvidenceError(REASON_SIMULATOR_ROOT, "; ".join(root_errors[:3]))
    if require_signature and verified is None:
        raise DeliveryEvidenceError(
            REASON_SIMULATOR_UNVERIFIED,
            "没有 simulator 可信公钥，无法验证根签名；不做默认通过",
        )

    tool_errors = _tool_pair_errors(executor_events, evidence.events)
    if tool_errors:
        raise DeliveryEvidenceError(REASON_TOOL_MISMATCH, "; ".join(tool_errors[:3]))
    return dict(evidence.root), chain_root


def pack_evidence_chains(
    *,
    signing_mode: str,
    executor_events: Sequence[Mapping[str, Any]],
    executor_root: Mapping[str, Any],
    simulator_evidence: SimulatorEvidence | None,
    expected: Mapping[str, Any],
    job_digest: str,
    simulator_trust: TrustStore | None,
    delivered: bool,
) -> tuple[dict[str, Any], ...]:
    """按冻结签名模式组装 ``chains``。

    - ``single``：只交 executor 链/根，**不会**借 simulator 证据升级成三方；
    - ``three_party``：executor + simulator 各一条链、各一份根；缺一不可
      （运行本来就未交付的基建失败除外——那种交付不产生点数，也没有可签的
      complete run）。
    """

    if signing_mode not in _SIGNING_MODES:
        raise DeliveryEvidenceError(
            REASON_UNKNOWN_MODE, f"未知签名模式 {signing_mode!r}"
        )

    chains: list[dict[str, Any]] = [
        {
            "party": "executor",
            "events": [dict(event) for event in executor_events],
            "root": dict(executor_root),
        }
    ]

    if signing_mode == "single":
        # 单方联调档不因为多给一份证据就变成可计奖；也不把它塞进请求让
        # 后端误以为这是三方交付。冻结模式只由后端 spec 决定。
        return tuple(chains)

    if simulator_evidence is None:
        if delivered:
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_MISSING,
                "three_party 的已交付运行必须提交 simulator 链与根",
            )
        return tuple(chains)

    simulator_root, _ = validate_simulator_evidence(
        simulator_evidence,
        executor_events=executor_events,
        expected=expected,
        job_digest=job_digest,
        trust_store=simulator_trust,
        require_signature=True,
    )
    chains.append(
        {
            "party": "simulator",
            "events": [dict(event) for event in simulator_evidence.events],
            "root": simulator_root,
        }
    )
    return tuple(chains)


def is_delivered_status(status: str) -> bool:
    return status in _DELIVERED_STATUSES


__all__ += [
    "REASON_BINDING",
    "REASON_FROZEN_DIGEST_MISSING",
    "REASON_EXECUTOR_CHAIN",
    "REASON_EXECUTOR_MISSING",
    "REASON_EXECUTOR_ROOT",
    "REASON_GATEWAY_REJECTED",
    "REASON_SIMULATOR_CHAIN",
    "REASON_SIMULATOR_MISSING",
    "REASON_SIMULATOR_PARTY",
    "REASON_SIMULATOR_ROOT",
    "REASON_SIMULATOR_UNVERIFIED",
    "REASON_TOOL_MISMATCH",
    "REASON_UNKNOWN_MODE",
    "is_delivered_status",
]
