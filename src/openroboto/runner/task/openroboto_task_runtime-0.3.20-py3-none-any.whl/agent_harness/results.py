"""结果记录：同一题的不同模式分开落盘，不同模式不混榜。

一个 run 的结果记录至少包含：

* ``mode``：standard / realtime / privileged；
* ``permissions``：该模式**逐字段**生效的权限声明（含时钟、reset、探索、
  最终解是否冻结）；
* ``permissions_sha256``：权限声明的稳定摘要；
* ``assurance_profile`` / ``assurance``：OPE-124 隔离档位与生效的隔离属性。

隔离档位不同（``demo-no-isolation`` vs ``isolated``）的运行不进同一张榜：
测试网的宽松执行和上线后的隔离执行不是同一种成绩。

落盘路径是

    <root>/results/<source>/<task_id>-<instance>/<mode>/<run_id>.json

同一个 task 在 standard 和 privileged 下跑，会落到两个不同的目录；同一个
模式跑多次也不会互相覆盖。:func:`leaderboard_key` 把 mode 写进键里，
:func:`board_key` 还把权限摘要写进榜名 —— 即使同为 standard，只要观察白名单
不同，也不会被合并到同一张榜。:func:`ensure_single_mode` 是聚合前的硬闸。
"""

from __future__ import annotations

import json
import pathlib
import re
from typing import Any, Iterable, Mapping

from .canonical import canonical_sha256
from .result import RunResult

_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


class ModeMixError(ValueError):
    """结果缺少模式，或试图把不同模式放进同一张榜。"""


def _safe_part(value: str) -> str:
    cleaned = _UNSAFE.sub("_", str(value or "")).strip("._")
    return cleaned or "run"


def _mode_of(record: Mapping[str, Any]) -> str:
    mode = str(record.get("mode") or "").strip()
    if not mode:
        raise ModeMixError(
            "result has no mode; refusing to record or rank it (mode is part of the result key)"
        )
    return mode


def permissions_sha256(record: Mapping[str, Any]) -> str:
    permissions = record.get("permissions")
    if not isinstance(permissions, Mapping):
        raise ModeMixError("result has no permissions declaration; refusing to record it")
    return canonical_sha256(dict(permissions))


def leaderboard_key(record: Mapping[str, Any]) -> str:
    """单条结果在榜上的键：题 + 实例 + 模式。"""

    return (
        f"{record.get('source')}:{record.get('task_id')}:"
        f"{record.get('instance')}:{_mode_of(record)}"
    )


def assurance_profile_of(record: Mapping[str, Any]) -> str:
    """隔离档位；旧记录没有这个字段时按测试网档位处理，不制造第二张榜。"""

    from .assurance import DEFAULT_ASSURANCE_PROFILE

    name = str(record.get("assurance_profile") or "").strip()
    return name or DEFAULT_ASSURANCE_PROFILE


def board_key(record: Mapping[str, Any]) -> str:
    """可聚合的榜名：来源 + 模式 + 隔离档位 + 权限摘要。"""

    mode = _mode_of(record)
    digest = permissions_sha256(record)
    return f"{record.get('source')}:{mode}:{assurance_profile_of(record)}:{digest[:12]}"


def result_record(result: RunResult) -> dict[str, Any]:
    """把 RunResult 变成可落盘、可分榜的结果记录。"""

    mode = _mode_of({"mode": result.mode})
    permissions = dict(result.permissions)
    if not permissions:
        raise ModeMixError("run result has no permissions declaration")

    record: dict[str, Any] = {
        "run_id": result.run_id,
        "attempt_id": result.attempt_id,
        "source": result.source,
        "task_id": result.task_id,
        "instance": result.instance,
        "mode": mode,
        "permissions": permissions,
        "permissions_sha256": canonical_sha256(permissions),
        "assurance_profile": result.assurance_profile,
        "assurance": dict(result.assurance),
        "status": result.status,
        "success": bool(result.success),
        "reason": result.reason,
        "turns": result.turns,
        "steps": result.steps,
        "evidence_path": result.evidence_path,
        "evidence_root": result.root,
    }
    record["leaderboard_key"] = leaderboard_key(record)
    record["board"] = board_key(record)
    return record


def result_path(root: str | pathlib.Path, result: RunResult) -> pathlib.Path:
    """``<root>/results/<source>/<task>-<instance>/<mode>/<run_id>.json``。"""

    mode = _mode_of({"mode": result.mode})
    return (
        pathlib.Path(root).expanduser()
        / "results"
        / _safe_part(result.source)
        / f"{_safe_part(result.task_id)}-{int(result.instance)}"
        / _safe_part(mode)
        / f"{_safe_part(result.run_id)}.json"
    )


def write_result(root: str | pathlib.Path, result: RunResult) -> pathlib.Path:
    """写一条结果记录；路径里的 mode 保证不同模式永不覆盖。"""

    path = result_path(root, result)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(result_record(result), ensure_ascii=False, indent=1, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return path


def ensure_single_mode(records: Iterable[Mapping[str, Any]]) -> str:
    """聚合前检查：一批结果只能属于一个模式，返回该模式。"""

    modes: set[str] = set()
    for record in records:
        modes.add(_mode_of(record))
    if not modes:
        raise ModeMixError("no results to aggregate")
    if len(modes) > 1:
        raise ModeMixError(
            f"refusing to mix modes in one leaderboard: {', '.join(sorted(modes))}; "
            "rank each mode separately"
        )
    return modes.pop()


def group_by_board(records: Iterable[Mapping[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """按 ``board_key`` 分榜。模式（和权限白名单）不同的结果不会同组。"""

    boards: dict[str, list[dict[str, Any]]] = {}
    for record in records:
        boards.setdefault(board_key(record), []).append(dict(record))
    return boards


__all__ = [
    "ModeMixError",
    "assurance_profile_of",
    "board_key",
    "ensure_single_mode",
    "group_by_board",
    "leaderboard_key",
    "permissions_sha256",
    "result_path",
    "result_record",
    "write_result",
]
