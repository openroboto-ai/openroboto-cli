"""The frozen tool contract: schemas, mode whitelist and dispatch types.

Every harness implementation exposes exactly these five tools. The tool schemas
are canonical (Anthropic style) because :mod:`agent_eval` takes that shape and
converts it for OpenAI-compatible providers.

The runtime maps the neutral ``gripper`` range (0.0 closed .. 1.0 open) to the
source-specific width; the model never sees source details.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol, runtime_checkable

from .canonical import canonical_sha256
from .modes import MODE_CONFIGS, SENSOR_FIELDS, ModeError, resolve_permissions

#: Tool manifest schema version. Bump when the manifest *semantics* change in a
#: way the description alone does not capture.
TOOLS_VERSION = "2"

TOOL_NAMES = ("observe", "move_to", "grasp", "release", "step")

TOOL_SPECS: tuple[dict[str, Any], ...] = (
    {
        "name": "observe",
        "description": (
            "Return permitted sensor observations and, when authorized, aggregate success. "
            "Detailed checker diagnostics are audit-only and are never included."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "move_to",
        "description": (
            "Move the tool center point to (x, y, z) with the given gripper opening, then advance the simulation."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "x": {"type": "number"},
                "y": {"type": "number"},
                "z": {"type": "number"},
                "gripper": {
                    "type": "number",
                    "minimum": 0.0,
                    "maximum": 1.0,
                    "description": "0.0 closed .. 1.0 fully open",
                },
                "steps": {"type": "integer", "minimum": 1, "maximum": 100, "default": 10},
                "yaw": {
                    "type": "number",
                    "description": "Optional tool yaw in radians (default 0).",
                },
            },
            "required": ["x", "y", "z", "gripper"],
        },
    },
    {
        "name": "grasp",
        "description": "Close the gripper and hold for a few control steps.",
        "input_schema": {
            "type": "object",
            "properties": {"steps": {"type": "integer", "minimum": 1, "maximum": 100, "default": 5}},
            "required": [],
        },
    },
    {
        "name": "release",
        "description": "Open the gripper and hold for a few control steps.",
        "input_schema": {
            "type": "object",
            "properties": {"steps": {"type": "integer", "minimum": 1, "maximum": 100, "default": 5}},
            "required": [],
        },
    },
    {
        "name": "step",
        "description": "Apply one raw source-level action. Only use this when told to; prefer move_to/grasp/release.",
        "input_schema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "array",
                    "items": {"type": "number"},
                    "description": "Source-defined action vector.",
                },
                "steps": {"type": "integer", "minimum": 1, "maximum": 100, "default": 1},
            },
            "required": ["action"],
        },
    },
)


def tool_manifest() -> list[dict[str, Any]]:
    """The list that goes to the model and into ``agent.tools_digest``."""

    return [dict(spec) for spec in TOOL_SPECS]


def tools_digest() -> str:
    """sha256 over the canonical manifest (names + descriptions + schemas)."""

    return canonical_sha256({"version": TOOLS_VERSION, "tools": tool_manifest()})


# ---------------------------------------------------------------------------
# Permissions: which sensors a mode may see
# ---------------------------------------------------------------------------

#: Canonical sensor names. Everything a runtime can expose is one of these.
SENSORS = SENSOR_FIELDS

#: Mode -> sensors that mode is allowed to expose at all. The authoritative
#: per-field declaration lives in :mod:`agent_harness.modes`; this view exists
#: for callers that only need the whitelist.
MODE_SENSORS: Mapping[str, tuple[str, ...]] = {name: config.sensors for name, config in MODE_CONFIGS.items()}

MODES = tuple(MODE_SENSORS)


class PermissionError_(ValueError):
    """The requested permission set is not one of the declared modes."""


def resolve_sensors(mode: str, allowed_sensors: Any) -> tuple[str, ...]:
    """Validate and normalise the effective sensor set for ``mode``.

    ``allowed_sensors`` is the spec's whitelist. Empty means *nothing* is
    exposed, matching the backend contract. Unknown names and sensors the mode
    must not expose are rejected rather than silently dropped.

    This is the low-level whitelist check. Mode readiness and the clock/reset
    rules are enforced by :mod:`agent_harness.modes` when a spec is parsed.
    """

    try:
        return resolve_permissions({"mode": mode, "allowed_sensors": allowed_sensors}).sensors
    except ModeError as exc:
        raise PermissionError_(str(exc)) from None


def filter_observation(raw: Mapping[str, Any], sensors: tuple[str, ...]) -> dict[str, Any]:
    """Return only the observation fields the effective sensor set allows.

    ``step`` and ``instruction`` always pass: they are protocol metadata, not
    privileged simulator state. The success sensor exposes only the aggregate
    boolean; checker branches, distances and thresholds remain audit-only.
    """

    visible: dict[str, Any] = {
        "step": int(raw.get("step", 0)),
        "instruction": raw.get("instruction"),
    }
    if "image" in sensors:
        visible["image"] = raw.get("image")
    if "proprioception" in sensors:
        visible["proprioception"] = raw.get("proprioception")
    if "object_positions" in sensors:
        visible["objects"] = raw.get("objects")
    if "state" in sensors:
        visible["state"] = raw.get("state")
    if "success" in sensors:
        visible["success"] = bool(raw.get("success", False))
    return visible


# ---------------------------------------------------------------------------
# Runtime protocol
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ToolOutcome:
    """What a tool execution returns to the loop and the evidence chain."""

    observation: Mapping[str, Any]
    success: bool = False
    detail: Mapping[str, Any] = field(default_factory=dict)
    steps: int = 0


@runtime_checkable
class ToolRuntime(Protocol):
    """Source-side implementation of the five tools + success check."""

    source: str
    instruction: str

    def reset(self) -> Mapping[str, Any]: ...

    def observe(self) -> Mapping[str, Any]: ...

    def move_to(
        self, x: float, y: float, z: float, gripper: float, steps: int = 10, yaw: float = 0.0
    ) -> ToolOutcome: ...

    def grasp(self, steps: int = 5) -> ToolOutcome: ...

    def release(self, steps: int = 5) -> ToolOutcome: ...

    def step(self, action: Any, steps: int = 1) -> ToolOutcome: ...

    def success(self) -> tuple[bool, Mapping[str, Any]]: ...

    def close(self) -> None: ...


class UnknownTool(ValueError):
    """The model called a tool outside the frozen manifest."""


def execute_tool(runtime: ToolRuntime, name: str, args: Mapping[str, Any]) -> ToolOutcome:
    """Dispatch one tool call. The caller records both success and failure."""

    if not isinstance(args, Mapping):
        raise ValueError("tool arguments must be an object")
    args = dict(args)
    if name == "observe":
        return ToolOutcome(runtime.observe())
    if name == "move_to":
        return runtime.move_to(
            float(args["x"]),
            float(args["y"]),
            float(args["z"]),
            float(args.get("gripper", 1.0)),
            int(args.get("steps", 10)),
            float(args.get("yaw", 0.0)),
        )
    if name == "grasp":
        return runtime.grasp(int(args.get("steps", 5)))
    if name == "release":
        return runtime.release(int(args.get("steps", 5)))
    if name == "step":
        return runtime.step(args["action"], int(args.get("steps", 1)))
    raise UnknownTool(f"unknown tool {name!r}; allowed: {', '.join(TOOL_NAMES)}")


__all__ = [
    "MODES",
    "MODE_SENSORS",
    "SENSORS",
    "TOOL_NAMES",
    "TOOL_SPECS",
    "TOOLS_VERSION",
    "ToolOutcome",
    "ToolRuntime",
    "UnknownTool",
    "PermissionError_",
    "execute_tool",
    "filter_observation",
    "resolve_sensors",
    "tool_manifest",
    "tools_digest",
]
