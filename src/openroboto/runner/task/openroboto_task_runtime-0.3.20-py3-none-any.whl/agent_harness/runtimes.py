"""Tool implementations for each task source.

The harness talks to :class:`agent_harness.tools.ToolRuntime`; this module is
the only place that knows a source is MuJoCo or Isaac Sim.

* :class:`AxisToolRuntime` wraps the task-source ``MujocoAxisEnv`` and adds
  Jacobian IK, rendering and checker-based success.
* :class:`RoboDojoToolRuntime` drives an injected ``runner`` callable. The
  execution layer supplies the runner (the official client wrapper); nothing
  here pretends Isaac Sim is installed.
* :class:`ScenarioToolRuntime` is a deterministic actuator used by the smoke
  tool and tests. It exercises the real task packages and checkers but **not**
  physics; runs that use it are marked ``runtime=scenario`` in evidence.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping

from task_source.base import RuntimeUnavailable, TaskSource, TaskSpec
from task_source.frozen import ResolvedPackage, resolve_frozen_package

from .images import image_payload, placeholder, png_from_rgb
from .spec import HarnessSpec, SpecError
from .tools import ToolOutcome

Runner = Callable[[Mapping[str, Any]], Mapping[str, Any]]


class ToolActionError(RuntimeError):
    """A tool action was rejected by the source runtime."""


def _distance(a: Mapping[str, Any] | list[float], b: list[float]) -> float:
    pa = a if isinstance(a, list) else list(a)
    return math.sqrt(sum((float(x) - float(y)) ** 2 for x, y in zip(pa, b)))


def _observation(
    *,
    step: int,
    instruction: str,
    image: Mapping[str, Any] | None = None,
    proprioception: Mapping[str, Any] | None = None,
    objects: Mapping[str, Any] | None = None,
    state: Mapping[str, Any] | None = None,
    success: bool = False,
    detail: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "step": int(step),
        "instruction": instruction,
        "image": image,
        "proprioception": proprioception or {},
        "objects": objects or {},
        "state": state or {},
        "success": bool(success),
        "detail": detail or {},
    }


# ---------------------------------------------------------------------------
# Scenario runtime (deterministic, no physics)
# ---------------------------------------------------------------------------


@dataclass
class ScenarioToolRuntime:
    """Deterministic actuator fixture for smoke runs and tests."""

    instruction: str
    source: str = "axis"
    objects: Mapping[str, Any] = field(default_factory=dict)
    start: list[float] = field(default_factory=lambda: [0.5, 0.0, 0.3])
    goal: list[float] | None = None
    checker: Any = None
    initial_state: Mapping[str, Any] | None = None
    success_state: Mapping[str, Any] | None = None
    max_steps: int = 200
    step_count: int = 0
    tcp: list[float] = field(default_factory=list)
    gripper: float = 1.0
    held: str | None = None
    success_flag: bool = False
    detail: dict[str, Any] = field(default_factory=dict)
    image: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        self.tcp = list(self.start)
        self.image = placeholder()
        self.objects = {name: dict(value) for name, value in self.objects.items()}
        for name, value in self.objects.items():
            value.setdefault("center", value.get("pos") or self.start)
            value.setdefault("pos", value["center"])

    def reset(self) -> Mapping[str, Any]:
        self.step_count = 0
        self.tcp = list(self.start)
        self.gripper = 1.0
        self.held = None
        self.success_flag = False
        self.detail = {}
        return self.observe()

    def _proprio(self) -> dict[str, Any]:
        return {"tcp": [round(float(v), 6) for v in self.tcp], "gripper": self.gripper, "holding": self.held}

    def observe(self) -> Mapping[str, Any]:
        return _observation(
            step=self.step_count,
            instruction=self.instruction,
            image=self.image,
            proprioception=self._proprio(),
            objects={name: {"pos": value["pos"], "center": value["center"]} for name, value in self.objects.items()},
            state={"tcp": self.tcp, "holding": self.held},
            success=self.success_flag,
            detail=self.detail,
        )

    def sim_time_s(self) -> None:
        """确定性夹具没有物理时钟：显式未知，不用 control_step × steps 冒充。"""

        return None

    def _clamp_steps(self, steps: int) -> int:
        if self.step_count >= self.max_steps:
            return 0
        return max(1, min(int(steps), 100, self.max_steps - self.step_count))

    def move_to(self, x: float, y: float, z: float, gripper: float, steps: int = 10, yaw: float = 0.0) -> ToolOutcome:
        target = [float(x), float(y), float(z)]
        count = self._clamp_steps(steps)
        if count == 0:
            return self._outcome()
        self.tcp = target
        self.gripper = max(0.0, min(1.0, float(gripper)))
        if self.held is not None:
            self.objects[self.held]["center"] = list(target)
            self.objects[self.held]["pos"] = list(target)
        self.step_count += count
        return self._outcome()

    def grasp(self, steps: int = 5) -> ToolOutcome:
        count = self._clamp_steps(steps)
        if count == 0:
            return self._outcome()
        nearest = None
        nearest_distance = 0.06
        for name, value in self.objects.items():
            distance = _distance(value["center"], self.tcp)
            if distance <= nearest_distance:
                nearest, nearest_distance = name, distance
        if nearest is None:
            self.detail = {"grasp": "no object within 6 cm of the tool center"}
        else:
            self.held = nearest
            self.detail = {"grasp": f"holding {nearest}"}
        self.gripper = 0.0
        self.step_count += count
        return self._outcome()

    def release(self, steps: int = 5) -> ToolOutcome:
        count = self._clamp_steps(steps)
        if count == 0:
            return self._outcome()
        released = self.held
        self.gripper = 1.0
        self.held = None
        self.step_count += count
        if released is not None:
            self.objects[released]["center"] = list(self.tcp)
            self.objects[released]["pos"] = list(self.tcp)
            self._evaluate_success()
        return self._outcome()

    def step(self, action: Any, steps: int = 1) -> ToolOutcome:
        count = self._clamp_steps(steps)
        if count == 0:
            return self._outcome()
        self.step_count += count
        self.detail = {"action": "applied to the scenario actuator", "steps": count}
        return self._outcome()

    def _evaluate_success(self) -> None:
        if self.checker is not None:
            if self.source == "robodojo":
                state = {"current": {"success": True}, "initial": {"success": False}}
            else:
                current = self.success_state or self.initial_state or {}
                state = {"current": current, "initial": self.initial_state or current}
            result = self.checker.evaluate(state)
            self.success_flag = bool(result.passed)
            self.detail = dict(result.detail)
            return
        if self.goal is not None:
            self.success_flag = any(_distance(value["center"], self.goal) <= 0.05 for value in self.objects.values())
        else:
            self.success_flag = True

    def _outcome(self) -> ToolOutcome:
        return ToolOutcome(self.observe(), self.success_flag, self.detail, self.step_count)

    def success(self) -> tuple[bool, Mapping[str, Any]]:
        return self.success_flag, self.detail

    def close(self) -> None:
        return None


# ---------------------------------------------------------------------------
# AXIS / MuJoCo
# ---------------------------------------------------------------------------


class AxisToolRuntime:
    """MuJoCo implementation of the five tools.

    Construction requires the AXIS runtime (``mujoco`` + ``numpy``). Without it
    this raises ``RuntimeUnavailable`` so the job is retried as infrastructure,
    not scored as a failure.
    """

    source = "axis"

    def __init__(self, task: TaskSpec, instance: int, source: TaskSource, *, max_steps: int = 200) -> None:
        self.task = task
        self.instruction = task.instruction
        self.max_steps = max_steps
        if "imported_scene" in task.metadata:
            from task_source.scene_instruction_runtime import require_task
            from task_source.scene_observation import require_policy_scope

            self.instruction_finding = require_task(task)
            require_policy_scope(task)
        try:
            import mujoco  # noqa: F401
            import numpy  # noqa: F401
        except ImportError as exc:  # pragma: no cover - depends on the runtime machine
            raise RuntimeUnavailable(
                "AXIS harness needs MuJoCo and NumPy; install the AXIS runtime on the execution host"
            ) from exc
        self.env = source.make_env(task, instance)
        self.checker = source.checker(task)
        self._initial = dict(self.env.reset())
        self._runner = _AxisArm(self.env)
        self._renderer = None
        self._camera = str((task.metadata.get("runtime") or {}).get("camera") or "")
        self.step_count = 0

    def reset(self) -> Mapping[str, Any]:
        self._initial = dict(self.env.reset())
        self._runner = _AxisArm(self.env)
        self.step_count = 0
        return self.observe()

    def sim_time_s(self) -> float | None:
        """MuJoCo 的仿真时钟（秒）。``mj_resetData`` 后从 0 重新累计。"""

        data = getattr(self.env, "data", None)
        value = getattr(data, "time", None)
        if value is None:
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def observe(self) -> Mapping[str, Any]:
        env = self.env
        if getattr(env, "scene_contract", False):
            ok, _ = self.success()
            return scene_tool_observation(
                env,
                task=self.task,
                step=self.step_count,
                instruction=self.instruction,
                proprioception=dict(self._runner.proprioception()),
                success=ok,
            )
        state = env.state()
        objects: dict[str, Any] = {}
        for name, entry in (state.get("positions") or {}).items():
            if self._runner.is_robot_body(str(name)):
                continue
            objects[str(name)] = {
                "pos": [round(float(v), 6) for v in entry],
                "center": [round(float(v), 6) for v in self._object_center(str(name))],
            }
        ok, detail = self.success()
        definition = self.task.metadata.get("runtime", {}).get("tabletop_v2_definition")
        vision = isinstance(definition, Mapping) and definition.get("observation") == "vision"
        if isinstance(definition, Mapping):
            # The judge's trace, stage counters and diagnostics are private in
            # both v2 contracts. Vision also hides all object ground truth.
            state = {key: value for key, value in state.items() if key != "tabletop_program"}
            detail = {}
        rendered = self.render()
        if vision and rendered is None:
            raise RuntimeUnavailable("the v2 vision contract requires a real camera image; rendering is unavailable")
        return _observation(
            step=self.step_count,
            instruction=self.instruction,
            image=rendered,
            proprioception=dict(self._runner.proprioception()),
            objects={} if vision else objects,
            state={} if vision else state,
            success=ok,
            detail=detail,
        )

    def render(self) -> Mapping[str, Any] | None:
        """Best-effort render; a missing camera or GL context must not fail the run."""

        if getattr(self.env, "scene_contract", False):
            return image_payload(png_from_rgb(self.env.render_rgb()))

        try:
            import mujoco
            import numpy as np
        except ImportError:  # pragma: no cover
            return None
        camera = None
        if self._camera:
            camera_id = int(mujoco.mj_name2id(self.env.model, mujoco.mjtObj.mjOBJ_CAMERA, self._camera))
            camera = self._camera if camera_id >= 0 else None
        try:
            if self._renderer is None:
                width, height = 320, 180
                definition = self.task.metadata.get("runtime", {}).get("tabletop_v2_definition")
                if isinstance(definition, Mapping):
                    from openroboto_protocol.tabletop_v2 import profile_catalog

                    width, height = profile_catalog()["camera"]["image_size"][definition["observation"]]
                self._renderer = mujoco.Renderer(self.env.model, height, width)
            self._renderer.update_scene(self.env.data, camera=camera)
            pixels = self._renderer.render()
        except Exception:  # noqa: BLE001 - headless GL is not always available
            return None
        raw = np.asarray(pixels, dtype=np.uint8)
        return image_payload(png_from_rgb(raw))

    def _object_center(self, name: str) -> list[float]:
        if getattr(self.env, "scene_contract", False):
            return self.env.object_center(name)
        import mujoco
        import numpy as np

        model, data = self.env.model, self.env.data
        body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name)
        if body_id < 0:
            return [0.0, 0.0, 0.0]
        geoms = [g for g in range(model.ngeom) if int(model.geom_bodyid[g]) == body_id]
        if not geoms:
            return [float(v) for v in data.xpos[body_id]]
        lo = np.full(3, np.inf)
        hi = np.full(3, -np.inf)
        for geom in geoms:
            half = model.geom_aabb[geom][3:6]
            lo = np.minimum(lo, data.geom_xpos[geom] - half)
            hi = np.maximum(hi, data.geom_xpos[geom] + half)
        return [float(v) for v in (lo + hi) / 2]

    def move_to(self, x: float, y: float, z: float, gripper: float, steps: int = 10, yaw: float = 0.0) -> ToolOutcome:
        width = self._gripper_width(gripper)
        return self._apply(lambda: self._runner.move([float(x), float(y), float(z)], float(yaw), int(steps), width))

    def grasp(self, steps: int = 5) -> ToolOutcome:
        return self._apply(lambda: self._runner.hold(int(steps), self._gripper_width(0.0)))

    def release(self, steps: int = 5) -> ToolOutcome:
        return self._apply(lambda: self._runner.hold(int(steps), self._gripper_width(1.0)))

    def step(self, action: Any, steps: int = 1) -> ToolOutcome:
        if not isinstance(action, (list, tuple)):
            raise ToolActionError("axis step action must be a list of joint targets")
        return self._execute_actions(action for _ in range(max(1, int(steps))))

    def _gripper_width(self, normalized: float) -> float:
        width = float((self.task.metadata.get("runtime") or {}).get("gripper_max", 0.04))
        return max(0.0, min(1.0, float(normalized))) * width

    def _apply(self, action: Callable[[], Any]) -> ToolOutcome:
        action()
        return self._execute_actions(self._runner.drain())

    def _execute_actions(self, actions: Iterable[Any]) -> ToolOutcome:
        if self.step_count >= self.max_steps:
            raise ToolActionError("physical step budget exhausted")
        # Keep the original trajectory prefix; do not replan a shorter, faster move.
        for command in actions:
            if self.step_count >= self.max_steps:
                break
            self._advance(command)
        return self._outcome()

    def _advance(self, command: Any) -> None:
        # The physical boundary is guarded even when a tool batches many controls.
        if self.step_count >= self.max_steps:
            raise ToolActionError("physical step budget exhausted")
        # Charge before calling an environment that could advance and then raise.
        self.step_count += 1
        self.env.step(command)

    def _outcome(self) -> ToolOutcome:
        ok, detail = self.success()
        return ToolOutcome(self.observe(), ok, detail, self.step_count)

    def success(self) -> tuple[bool, Mapping[str, Any]]:
        result = self.checker.evaluate({"current": self.env.state(), "initial": self._initial})
        if isinstance(self.task.metadata.get("runtime", {}).get("tabletop_v2_definition"), Mapping):
            return bool(result.passed), {}
        return bool(result.passed), dict(result.detail)

    def close(self) -> None:
        if self._renderer is not None:
            self._renderer.close()
            self._renderer = None
        self.env.close()


def scene_tool_observation(env, *, task, step, instruction, proprioception, success):
    """One projection for formal observe and native replay's admission audit.

    No reset, step or extra sensor grant. P03 applies its model boundary again
    before sending any response to an untrusted process.
    """
    from task_source.scene_instruction_runtime import require_task
    from task_source.scene_observation import require_policy_scope

    # Actual formal output is checked; findings stay outside model sensors.
    require_policy_scope(task)
    env.instruction_finding = require_task(task, delivered_instruction=instruction)
    state = env.public_state()
    vision = env.observation_contract == "vision"
    objects = (
        {}
        if vision
        else {
            name: {
                "pos": [round(float(v), 6) for v in pos],
                "center": [round(float(v), 6) for v in env.object_center(name)],
                "rot": state["orientations"][name],
            }
            for name, pos in state["positions"].items()
        }
    )
    return _observation(
        step=step,
        instruction=instruction,
        image=image_payload(png_from_rgb(env.render_rgb())),
        proprioception=proprioception,
        objects=objects,
        state={} if vision else state,
        success=success,
        detail={},
    )


class ArmModelError(RuntimeError):
    """The scene does not expose a hand/end-effector we can drive safely."""


class _AxisArm:
    """Jacobian IK on a private ``MjData``.

    Real AXIS payloads use a Franka with ``franka/panda_hand`` and finger
    bodies. Self-contained samples only have ``franka/panda_joint1..7`` on
    ``link_*`` bodies, so the end effector is derived from the last arm joint.
    If neither route works, construction fails closed: silently using
    ``xpos[-1]`` would drive a wrong body.
    """

    FINGER_TIP = 0.045

    def __init__(self, env: Any) -> None:
        import mujoco
        import numpy as np

        self._np = np
        self._mujoco = mujoco
        self.env = env
        self.model = env.model
        self.data = mujoco.MjData(self.model)
        self.data.qpos[:] = env.data.qpos
        mujoco.mj_kinematics(self.model, self.data)

        # Tuple slicing from ``env.joint_ids`` must become a list/array; NumPy
        # treats a 7-tuple as seven index dimensions ("too many indices").
        self.joint_ids = list(env.joint_ids)
        self.arm_ids = list(self.joint_ids[2:])
        if not self.arm_ids:
            raise ArmModelError("AXIS scene has no arm joints after the two gripper joints")
        self.arm_q = list(env.qpos_indices[2:])
        self.arm_dof = [int(self.model.jnt_dofadr[joint]) for joint in self.arm_ids]
        ranges = np.asarray(self.model.jnt_range[self.arm_ids], dtype=float)
        if ranges.shape != (len(self.arm_ids), 2):
            raise ArmModelError(f"AXIS arm joints have malformed ranges: {ranges.shape}")
        self.lo, self.hi = ranges.T
        self.q = self.data.qpos[self.arm_q].copy()
        self.grip = float(env.data.qpos[int(env.qpos_indices[0])])

        self.hand = self._resolve_hand()
        self.fingers = self._resolve_fingers()
        self.robot_bodies = self._robot_body_ids()
        self.tcp = self._tcp_offset()
        self.out: list[Any] = []

    def _body_id(self, names: tuple[str, ...]) -> int:
        for name in names:
            body_id = int(self._mujoco.mj_name2id(self.model, self._mujoco.mjtObj.mjOBJ_BODY, name))
            if body_id > 0:  # 0 is the world body; -1 means "not found"
                return body_id
        return -1

    def _resolve_hand(self) -> int:
        explicit = self._body_id((
            "franka/panda_hand",
            "panda_hand",
            "hand",
            "gripper",
        ))
        if explicit > 0:
            return explicit
        # Self-contained samples: the end effector is the body owning the last
        # arm joint.
        derived = int(self.model.jnt_bodyid[self.arm_ids[-1]])
        if derived <= 0:
            last_joint = self._mujoco.mj_id2name(self.model, self._mujoco.mjtObj.mjOBJ_JOINT, self.arm_ids[-1])
            raise ArmModelError(
                "AXIS scene has no usable hand body: tried franka/panda_hand, panda_hand, "
                f"hand, gripper and the body of joint {last_joint!r}"
            )
        return derived

    def _resolve_fingers(self) -> tuple[int, int] | None:
        left = self._body_id(("franka/panda_leftfinger", "panda_leftfinger", "left_finger"))
        right = self._body_id(("franka/panda_rightfinger", "panda_rightfinger", "right_finger"))
        if left > 0 and right > 0:
            return left, right
        if left > 0 or right > 0:
            raise ArmModelError("AXIS scene has only one gripper finger body; refusing to guess the TCP")
        return None

    def _robot_body_ids(self) -> frozenset[int]:
        ids: set[int] = set()
        for joint in self.joint_ids:
            body = int(self.model.jnt_bodyid[joint])
            while body > 0 and body not in ids:
                ids.add(body)
                body = int(self.model.body_parentid[body])
        return frozenset(ids)

    def _tcp_offset(self) -> float:
        if self.fingers is None:
            runtime = getattr(self.env, "runtime", {}) or {}
            return float(runtime.get("tcp_offset", 0.0))
        left, right = self.fingers
        midpoint = self.data.xpos[[left, right]].mean(axis=0)
        z_axis = self.data.xmat[self.hand].reshape(3, 3)[:, 2]
        return float((midpoint - self.data.xpos[self.hand]) @ z_axis) + self.FINGER_TIP

    def is_robot_body(self, name: str) -> bool:
        body_id = int(self._mujoco.mj_name2id(self.model, self._mujoco.mjtObj.mjOBJ_BODY, name))
        return body_id in self.robot_bodies

    def proprioception(self) -> dict[str, Any]:
        self.sync_from_env()
        tcp, _ = self.tcp_pose()
        return {"tcp": [round(float(v), 6) for v in tcp], "gripper": round(float(self.grip), 6)}

    def sync_from_env(self) -> None:
        """Refresh the private IK sandbox from the state physically reached.

        Actuator limits and contacts can prevent a target from being reached.
        Observations and the next trajectory must start at measured joints;
        planning still happens on private data and never edits the simulation.
        """
        self.data.qpos[:] = self.env.data.qpos
        self.q = self.data.qpos[self.arm_q].copy()
        fingers = self.data.qpos[list(self.env.qpos_indices[:2])]
        self.grip = float(fingers.mean())
        self._mujoco.mj_kinematics(self.model, self.data)

    def tcp_pose(self) -> tuple[Any, Any]:
        rot = self.data.xmat[self.hand].reshape(3, 3)
        return self.data.xpos[self.hand] + rot[:, 2] * self.tcp, rot

    def ik(self, pos: Any, yaw: float, iters: int = 200) -> Any:
        np = self._np
        mujoco = self._mujoco
        down = np.array([0.0, 0.0, -1.0])
        y = np.array([np.cos(yaw), np.sin(yaw), 0.0])
        target_rot = np.stack([np.cross(y, down), y, down], axis=1)
        jacp = np.zeros((3, self.model.nv))
        jacr = np.zeros((3, self.model.nv))
        q = self.q.copy()
        check_deadline = getattr(self.env, "check_deadline", None)
        for _ in range(iters):
            if check_deadline is not None:
                check_deadline()
            self.data.qpos[self.arm_q] = q
            mujoco.mj_kinematics(self.model, self.data)
            mujoco.mj_comPos(self.model, self.data)
            position, rot = self.tcp_pose()
            error_rot = 0.5 * sum(np.cross(rot[:, i], target_rot[:, i]) for i in range(3))
            err = np.concatenate([pos - position, error_rot])
            if np.linalg.norm(err[:3]) < 1e-3 and np.linalg.norm(err[3:]) < 1e-2:
                break
            mujoco.mj_jac(self.model, self.data, jacp, jacr, position, self.hand)
            jac = np.vstack([jacp, jacr])[:, self.arm_dof]
            dq = jac.T @ np.linalg.solve(jac @ jac.T + 1e-4 * np.eye(6), err)
            q = np.clip(q + np.clip(dq, -0.2, 0.2), self.lo, self.hi)
        return q

    def move(self, pos: Any, yaw: float, steps: int, grip: float) -> None:
        np = self._np
        mujoco = self._mujoco
        self.sync_from_env()
        self.data.qpos[self.arm_q] = self.q
        mujoco.mj_kinematics(self.model, self.data)
        start, _ = self.tcp_pose()
        scene = bool(getattr(self.env, "scene_contract", False))
        # Scene contacts may block a finger while its closing target remains
        # active. Start from actual actuator commands, not the measured gap.
        # Direct step/reset updates ctrl, so no predicted/stale command cache.
        g0 = self._scene_gripper_targets() if scene else self.grip
        for k in range(1, max(1, int(steps)) + 1):
            check_deadline = getattr(self.env, "check_deadline", None)
            if check_deadline is not None:
                check_deadline()
            alpha = k / max(1, int(steps))
            self.q = self.ik(start + (np.asarray(pos) - start) * alpha, yaw)
            if scene:
                fingers = g0 + (grip - g0) * alpha
            else:
                self.grip = g0 + (grip - g0) * alpha
                fingers = [self.grip, self.grip]
            self.out.append(np.concatenate([fingers, self.q]).astype(np.float32))

    def _scene_gripper_targets(self):
        np = self._np
        try:
            targets = np.asarray(self.env.data.ctrl, dtype=float)[list(self.env.actuator_ids[:2])].copy()
            if targets.shape != (2,) or not np.isfinite(targets).all():
                raise ValueError("invalid scene finger targets")
        except (AttributeError, IndexError, TypeError, ValueError) as exc:
            raise ArmModelError("scene gripper requires its two actual actuator command targets") from exc
        return targets

    def hold(self, steps: int, grip: float) -> None:
        np = self._np
        self.sync_from_env()
        if not getattr(self.env, "scene_contract", False):
            self.grip = grip
        for _ in range(max(1, int(steps))):
            self.out.append(np.concatenate([[grip, grip], self.q]).astype(np.float32))

    def drain(self) -> list[Any]:
        actions, self.out = self.out, []
        return actions


# ---------------------------------------------------------------------------
# RoboDojo / Isaac Sim
# ---------------------------------------------------------------------------


class RoboDojoToolRuntime:
    """Isaac Sim tools through an injected runner.

    The runner is a callable ``runner(op) -> observation`` provided by the
    execution layer (a thin wrapper around the pinned official client). Ops:
    ``reset``, ``observe``, ``move_to``, ``grasp``, ``release``, ``step``,
    ``close``. It must return a JSON-safe mapping with ``success`` and, when
    available, ``image`` / ``objects`` / ``proprioception`` / ``state``.
    """

    source = "robodojo"

    def __init__(
        self,
        task: TaskSpec,
        source: TaskSource,
        runner: Runner | None,
        *,
        max_steps: int = 200,
    ) -> None:
        if runner is None:
            raise RuntimeUnavailable(
                "RoboDojo harness needs an Isaac Sim runner; run on the GPU execution host (see docs/agent-harness.md)"
            )
        self.task = task
        self.instruction = task.instruction
        self.max_steps = max_steps
        self.checker = source.checker(task)
        self.runner = runner
        self.step_count = 0
        #: 本局 reset 时的仿真钟读数；没有它就没有起点，时长未知。
        self._reset_sim_time: float | None = None
        #: **最近一次** runner 响应里的仿真钟；响应缺钟/非法时立即作废。
        self._last_sim_time: float | None = None

    def _call(self, op: str, **fields: Any) -> Mapping[str, Any]:
        response = self.runner({"op": op, **fields})
        if not isinstance(response, Mapping):
            raise ToolActionError(f"RoboDojo runner returned {type(response).__name__}, expected an object")
        self._remember_sim_time(response)
        return response

    def _remember_sim_time(self, response: Mapping[str, Any]) -> None:
        """用**这一次**响应的 ``sim_time_s`` 替换读数；缺钟/非法即刻作废。

        不能沿用上一次读数：动作可能已经推进了物理，而这次响应没有给钟，
        继续用旧值就等于把旧读数冒充成动作后的全局实测。没有物理推进的
        ``observe`` 也按同一口径处理——协议不保证 observe 没有副作用。
        """

        candidates = [response]
        meta = response.get("meta")
        if isinstance(meta, Mapping):
            candidates.append(meta)
        state = response.get("state")
        if isinstance(state, Mapping):
            candidates.append(state)
        for item in candidates:
            value = item.get("sim_time_s")
            if isinstance(value, bool) or value is None:
                continue
            try:
                value = float(value)
            except (TypeError, ValueError):
                continue
            if math.isfinite(value) and value >= 0:
                self._last_sim_time = value
                return
        self._last_sim_time = None

    def reset(self) -> Mapping[str, Any]:
        self.step_count = 0
        self._reset_sim_time = None
        self._last_sim_time = None
        observation = self._normalize(self._call("reset"))
        # 起点只认本局 reset 的读数；reset 没给钟时本局时长一直未知。
        self._reset_sim_time = self._last_sim_time
        return observation

    def observe(self) -> Mapping[str, Any]:
        return self._normalize(self._call("observe"))

    def move_to(self, x: float, y: float, z: float, gripper: float, steps: int = 10, yaw: float = 0.0) -> ToolOutcome:
        return self._tool(
            "move_to", x=float(x), y=float(y), z=float(z), gripper=float(gripper), steps=int(steps), yaw=float(yaw)
        )

    def grasp(self, steps: int = 5) -> ToolOutcome:
        return self._tool("grasp", steps=int(steps))

    def release(self, steps: int = 5) -> ToolOutcome:
        return self._tool("release", steps=int(steps))

    def step(self, action: Any, steps: int = 1) -> ToolOutcome:
        return self._tool("step", action=action, steps=int(steps))

    def _tool(self, op: str, **fields: Any) -> ToolOutcome:
        raw = self._call(op, **fields)
        self.step_count += 1
        ok, detail = self.success(raw)
        return ToolOutcome(self._normalize(raw), ok, detail, self.step_count)

    def success(self, raw: Mapping[str, Any] | None = None) -> tuple[bool, Mapping[str, Any]]:
        state = raw if raw is not None else self._call("observe")
        current = {"success": bool(state.get("success", False))}
        result = self.checker.evaluate({"current": current, "initial": {"success": False}})
        return bool(result.passed), dict(result.detail)

    def _normalize(self, raw: Mapping[str, Any]) -> dict[str, Any]:
        ok, detail = self.success(raw)
        return _observation(
            step=int(raw.get("step", self.step_count)),
            instruction=self.instruction,
            image=raw.get("image"),
            proprioception=raw.get("proprioception") or {},
            objects=raw.get("objects") or {},
            state=raw.get("state") or {},
            success=ok,
            detail=detail,
        )

    def close(self) -> None:
        try:
            self.runner({"op": "close"})
        except Exception:  # pragma: no cover - best effort teardown
            return None

    def sim_time_s(self) -> float | None:
        """本局仿真时长 = 最近有效读数 − reset 读数；缺任一端就是未知。

        终点必须是**最近一次响应**里的钟（缺钟/非法已作废），起点必须是本局
        reset 的钟。这样旧局或动作前的读数不会被拿来冒充当前局。
        """

        reset_time = getattr(self, "_reset_sim_time", None)
        last_time = getattr(self, "_last_sim_time", None)
        if reset_time is None or last_time is None:
            return None
        elapsed = last_time - reset_time
        if not math.isfinite(elapsed) or elapsed < 0:
            return None
        return elapsed


# ---------------------------------------------------------------------------
# Task loading and selection
# ---------------------------------------------------------------------------


def frozen_package(spec: HarnessSpec, *, local_mode: bool = False) -> ResolvedPackage:
    """Resolve ``spec``'s task package by its frozen digest (OPE-197).

    The returned directory is the only content this run may load. A missing or
    mismatched ``task.version_digest`` is a hard error: there is no fallback to
    a same-named sample, because that would score a different task.

    ``local_mode`` is the explicit smoke/test switch for ``package_root``. It
    is off by default and production callers never enable it; the frozen spec
    must carry ``package_repo`` + ``package_commit``.
    """

    return resolve_frozen_package(
        source=spec.source,
        task_id=spec.task_id,
        version_digest=spec.task_version_digest,
        package_root=spec.task_package_root,
        package_repo=spec.task_package_repo,
        package_commit=spec.task_package_commit,
        allow_local=local_mode,
    )


def load_task(spec: HarnessSpec, *, local_mode: bool = False) -> tuple[TaskSource, TaskSpec]:
    """Load the task only after its content matches the frozen digest."""

    from task_source.registry import get_source

    package = frozen_package(spec, local_mode=local_mode)
    expected_profile = (spec.raw.get("task") or {}).get("execution_profile")
    scene_context = None
    if expected_profile is not None:
        from task_source.package import load_package
        from task_source.profile_dispatch import validate_package as validate_tabletop

        if isinstance(expected_profile, Mapping) and expected_profile.get("id") == "panda-open-scene-v1":
            from task_source.scene_runtime import import_context

            scene_context = import_context()
        validate_tabletop(
            load_package(package.directory, scene_context=scene_context), expected_execution_profile=expected_profile
        )
    if scene_context is not None:
        if spec.source != "axis":
            raise SpecError("the frozen Panda scene requires the axis source")
        from task_source.axis import AxisSource

        # A normally installed scene runtime has no checkout-level configs/.
        # The fixed profile selects this built-in adapter with the same trusted
        # exact registry used above; authored input never supplies a factory.
        source = AxisSource({"package_root": str(package.directory), "scene_context": scene_context})
    else:
        source = get_source(spec.source, root=package.directory)
    # 后端业务 task_id（spec.task_id）与包内 task.json 的源侧 id 可能不同：
    # 由冻结摘要选中的包决定要加载哪个源侧 task，绝不拿业务 id 替换冻结值。
    task = source.load_task(package.task_id, spec.instance)
    if spec.instruction is not None and task.instruction and spec.instruction != task.instruction:
        raise SpecError("spec instruction does not match the task package; the task is frozen")
    return source, task


def _instance_spec(task: TaskSpec, instance: int) -> Any:
    for item in task.instances:
        if item.instance == int(instance):
            return item
    return task.instances[0] if task.instances else None


def _scenario_objects(task: TaskSpec, instance: int) -> dict[str, Any]:
    item = _instance_spec(task, instance)
    objects = ((item.initial_state if item is not None else {}) or {}).get("objects") or {}
    found = {
        str(name): {"pos": list(entry.get("pos") or [0.0, 0.0, 0.0])}
        for name, entry in objects.items()
        if isinstance(entry, Mapping)
    }
    if not found and task.source == "robodojo":
        # RoboDojo instances live inside the pinned simulator checkout, not in
        # the package. Give the scenario actuator one synthetic pick target so
        # the smoke run still exercises grasp -> release -> checker.
        found = {"target": {"pos": [0.5, 0.0, 0.05]}}
    return found


def build_tool_runtime(
    spec: HarnessSpec,
    *,
    override: str | None = None,
    runner: Runner | None = None,
    local_mode: bool = False,
) -> Any:
    """Build the runtime for ``spec``; ``override='scenario'`` is for smoke runs."""

    source, task = load_task(spec, local_mode=local_mode)
    mode = override or spec.runtime_override
    if "imported_scene" in task.metadata:
        import time

        contract = task.metadata["execution_contract"]
        if mode in {"scenario", "deterministic"}:
            raise SpecError("scene physical predicates cannot run in a scenario/mock runtime")
        if (
            (spec.raw.get("task") or {}).get("execution_profile") != task.metadata["execution_profile"]
            or set(spec.sensors) != set(contract["permissions"]["allowed_sensors"])
            or spec.mode != contract["permissions"]["mode"]
            or spec.max_steps != contract["budget"]["max_steps"]
            or spec.max_turns != contract["budget"]["max_api_calls"]
            or spec.wall_seconds != contract["budget"]["wall_seconds"]
            or spec.control_step_seconds != contract["timing"]["control_step_seconds"]
            or any(spec.timing[k] != contract["timing"][k] for k in ("clock_mode", "s"))
        ):
            raise SpecError("scene profile, observations, tools, timing and budget must match the frozen contract")
        if not local_mode:
            raise SpecError("scene execution requires a verified P03 execution view and registered process policy")
        source.scene_deadline = time.monotonic() + spec.wall_seconds
    definition = task.metadata.get("runtime", {}).get("tabletop_v2_definition")
    if isinstance(definition, Mapping):
        from openroboto_protocol.tabletop_v2 import profile_catalog, resource_catalog

        required = profile_catalog()["observations"][definition["observation"]]
        if (spec.raw.get("task") or {}).get("execution_profile") != task.metadata.get("execution_profile"):
            raise SpecError("v2 execution requires its exact profile reference in the signed harness spec")
        limit = resource_catalog()[definition["resource_profile"]]["max_control_steps_per_trial"]
        if set(spec.sensors) != set(required) or spec.max_steps != limit:
            raise SpecError("v2 task observation contract and resource step cap must match the frozen harness spec")
        if mode in {"scenario", "deterministic"}:
            raise SpecError("v2 physical process predicates cannot run in a scenario/mock runtime")
    if mode in {"scenario", "deterministic"}:
        objects = _scenario_objects(task, spec.instance)
        success_state = None
        reference = task.reference_for(spec.instance)
        if isinstance(reference, Mapping):
            success_state = reference.get("final_state")
        scenario = spec.raw.get("scenario") if isinstance(spec.raw.get("scenario"), Mapping) else {}
        if scenario.get("objects"):
            objects = dict(scenario["objects"])
        item = _instance_spec(task, spec.instance)
        return ScenarioToolRuntime(
            instruction=task.instruction,
            source=task.source,
            objects=objects,
            goal=list(scenario["goal"]) if scenario.get("goal") else None,
            checker=source.checker(task),
            initial_state=(item.initial_state if item is not None else {}) or {},
            success_state=success_state,
            max_steps=spec.max_steps,
            start=list(scenario.get("start") or [0.5, 0.0, 0.3]),
        )
    if mode not in {None, "task_source", "source"}:
        raise SpecError(f"unknown runtime override {mode!r}")
    if spec.source == "axis":
        return AxisToolRuntime(task, spec.instance, source, max_steps=spec.max_steps)
    if spec.source == "robodojo":
        return RoboDojoToolRuntime(task, source, runner, max_steps=spec.max_steps)
    raise SpecError(f"no tool runtime for source {spec.source!r}")


__all__ = [
    "ArmModelError",
    "AxisToolRuntime",
    "RoboDojoToolRuntime",
    "Runner",
    "ToolActionError",
    "ScenarioToolRuntime",
    "build_tool_runtime",
    "frozen_package",
    "load_task",
]
