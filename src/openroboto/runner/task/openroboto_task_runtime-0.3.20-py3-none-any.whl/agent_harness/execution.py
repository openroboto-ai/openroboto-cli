"""一次评测 attempt 的执行层入口：跑 harness → 上传帧 → 交付。

这个模块把 OPE-148 的三步接在一起，执行层（worker / 容器入口）只需要：

    client = EvalBackendClient(base_url, api_key, hotkey)
    result = execute_attempt(spec, attempt_no=1, client=client, signer=signer)

它假设 job 已经接单、attempt 处于 ``running``（后端 presign 端点会校验）。
本模块**不**取单、不推进 job 状态机。

帧上传失败不会让交付失败：:class:`agent_harness.frames.FrameCollector`
只返回实际 PUT 成功的帧，交付请求的 ``frame_uploads`` 只包含它们；后端按
``missing`` 处理没传上去的帧（钱路径只看事件链和签名）。
"""

from __future__ import annotations

import logging
import os
import re
from typing import Any, Mapping, Sequence

from .delivery import (
    DeliveryEvidenceError,
    REASON_BINDING,
    REASON_EXECUTOR_ROOT,
    REASON_FROZEN_DIGEST_MISSING,
    REASON_SIMULATOR_MISSING,
    REASON_SIMULATOR_UNVERIFIED,
    is_delivered_status,
    load_simulator_evidence,
    pack_evidence_chains,
    validate_executor_evidence,
)
from .frames import EvalBackendClient, FrameCollector, FrameManifest
from .metering import MeteringUnavailable, measure, unknown_fields
from .model_transport import (
    EVIDENCE_SIGNING_MODE_ENV,
    ModelTransportConfigError,
    build_model_transport,
    is_backend_gateway_chat,
    resolve_gateway_contract,
)
from .result import RunResult
from .spec import HarnessSpec, parse_spec

logger = logging.getLogger(__name__)

#: simulator 证据文件路径（JSON 或 ``*.simulator.events.jsonl``）。
#: 只在调用方没有显式传 ``simulator_evidence`` 时读取；私钥不经过这个变量。
SIMULATOR_EVIDENCE_ENV = "EVAL_SIMULATOR_EVIDENCE"
#: simulator 可信公钥，``party:key_id:hex`` 逗号分隔。只放公钥；用于交付前
#: fail-closed 验签，最终信任仍以后端登记为准。
SIMULATOR_PUBLIC_KEYS_ENV = "EVAL_SIMULATOR_PUBLIC_KEYS"
#: 运营 simulator 的 Unix socket。`isolated` 下它由 sandbox worker 内的
#: remote client 使用；普通路径由 eval_worker 注入 runtime。都不来自 spec。
SIMULATOR_SOCKET_ENV = "EVAL_SIMULATOR_SOCKET"
#: 生产闸门：没有 simulator 时 fail-closed，不静默退化成 single。
SIMULATOR_REQUIRED_ENV = "EVAL_SIMULATOR_REQUIRED"
#: 后端签发的冻结 config 摘要（`spec_digest` / `spec.job_digest`）。必须来自
#: 已认证的 job/spec 响应，不能由 parse_spec 兜底或 spec 自报值代替。只影响
#: 本次交付如何绑定根，不改变后端冻结配置。
FROZEN_JOB_DIGEST_ENV = "EVAL_FROZEN_JOB_DIGEST"
#: 运营选择的证据模式（``EVAL_EVIDENCE_SIGNING_MODE``）。后端 `/spec` 不向
#: 执行层下发 `evidence` 块，因此不能假设 `parse_spec()` 推断出的模式就是
#: 冻结模式；生产由运营契约注入。变量名定义在
#: :mod:`agent_harness.model_transport`，这里重新导出。

_HEX64 = re.compile(r"\A[0-9a-f]{64}\Z")


def _normalise_frozen_digest(value: Any) -> str | None:
    """后端摘要只接受 64 位小写 hex；None/空串表示没有独立来源。"""

    if value is None or value == "":
        return None
    text = str(value).strip().lower()
    if not _HEX64.match(text):
        raise DeliveryEvidenceError(
            REASON_BINDING,
            f"frozen job digest 必须是 64 位小写 hex，收到 {value!r}",
        )
    return text

#: harness 的结束原因 → 后端交付词表（`app/domain/eval_result.py`）。词表外的
#: 值不能瞎猜：后端按失败结算，猜成成功会让钱按没人定义过的规则流出去。
_STATUS_BY_REASON = {
    "success": "task_success",
    "turn_limit": "agent_budget_exhausted",
    "step_limit": "agent_budget_exhausted",
    "wall_time": "timeout",
    "model_error": "provider_5xx",
    "reset_error": "sim_infra_failure",
    "pi_exit": "executor_failure",
    "pi_error": "executor_failure",
    "prompt_rejected": "executor_failure",
}


def episode_status(result: RunResult) -> str:
    """把 harness 的 ``(status, reason, success)`` 映射成交付词表。"""

    if result.success:
        return "task_success"
    reason = str(result.reason or "")
    if reason == "simulator_fatal" or reason.startswith("simulator_fatal:"):
        # OPE-203 fatal（协议/绑定/预算/传输）是基建失败，不是任务结论；
        # 具体稳定码保留在 result.reason 与 executor 链的 error 事件里。
        return "sim_infra_failure"
    if reason in _STATUS_BY_REASON:
        return _STATUS_BY_REASON[reason]
    if result.status == "error":
        return "executor_failure"
    return "task_failure"


def _signing_roots(result: RunResult) -> list[dict[str, Any]]:
    signing = result.extra.get("signing") if isinstance(result.extra, Mapping) else None
    if not isinstance(signing, Mapping) or not signing.get("signed"):
        return []
    root = signing.get("root_record")
    return [dict(root)] if isinstance(root, Mapping) else []


def _metering_record(result: RunResult, spec: HarnessSpec | Mapping[str, Any] | None) -> Mapping[str, Any]:
    """取 harness 写下的计量；没有时按事件链重算一次（不补数字）。"""

    record = result.extra.get("metering") if isinstance(result.extra, Mapping) else None
    if isinstance(record, Mapping):
        return record
    raw = getattr(spec, "raw", spec)
    return measure(raw if isinstance(raw, Mapping) else None, result.events, None).payload()


def _explicit_job_digest(spec: HarnessSpec | Mapping[str, Any] | None) -> str | None:
    """spec 里**显式写出**的 job_digest；没有就返回 None（不算兜底值）。"""

    raw = spec.raw if isinstance(spec, HarnessSpec) else spec
    if not isinstance(raw, Mapping):
        return None
    evidence = raw.get("evidence") if isinstance(raw.get("evidence"), Mapping) else {}
    value = evidence.get("job_digest") or raw.get("job_digest")
    return _normalise_frozen_digest(value)


def _resolve_expected_digest(
    spec: HarnessSpec | Mapping[str, Any] | None,
    frozen_job_digest: str | None,
) -> str | None:
    """外部（后端已认证响应）优先，其次 spec 显式值；绝不使用 parse 兜底。"""

    external = _normalise_frozen_digest(frozen_job_digest)
    explicit = _explicit_job_digest(spec)
    if external is not None and explicit is not None and external != explicit:
        raise DeliveryEvidenceError(
            REASON_BINDING,
            "调用方给的 frozen_job_digest 与 spec 里显式 job_digest 不一致",
        )
    return external if external is not None else explicit


def _spec_evidence_view(
    result: RunResult,
    spec: HarnessSpec | Mapping[str, Any] | None,
    episode: int | None,
) -> dict[str, Any]:
    """从 spec 取交付证据需要的绑定与签名模式（不重新解释业务字段）。"""

    if isinstance(spec, HarnessSpec):
        raw = spec.raw
        resolved_episode = (
            spec.episode if episode is None and spec.episode is not None else episode
        )
        view = {
            "signing_mode": spec.signing_mode,
            "job_id": spec.job_id,
            "attempt_id": spec.attempt_id or spec.run_id or "local",
            "episode": int(resolved_episode or 0),
            "job_nonce": spec.job_nonce,
        }
    else:
        raw = spec if isinstance(spec, Mapping) else {}
        signing = raw.get("signing") if isinstance(raw.get("signing"), Mapping) else {}
        evidence = raw.get("evidence") if isinstance(raw.get("evidence"), Mapping) else {}
        binding = raw.get("binding") if isinstance(raw.get("binding"), Mapping) else {}
        resolved_episode = episode if episode is not None else raw.get("episode", 0)
        view = {
            "signing_mode": str(
                signing.get("mode") or evidence.get("signing_mode") or "single"
            ),
            "job_id": str(
                binding.get("job_id") or raw.get("job_id") or raw.get("run_id") or result.run_id or "local"
            ),
            "attempt_id": str(
                result.attempt_id or raw.get("attempt_id") or result.run_id or "local"
            ),
            "episode": int(resolved_episode or 0),
            "job_nonce": binding.get("nonce") or raw.get("job_nonce") or None,
        }

    # **只**认 spec 里显式写出的 digest。`HarnessSpec.job_digest` 可能是
    # parse_spec 的兜底值（缺显式字段时按执行视图重算），它只说明“这份输入
    # 算出来是什么”，不是后端发单时冻结配置的证明。
    view["explicit_job_digest"] = _explicit_job_digest(spec)
    return view


def _resolve_evidence_mode(
    spec: HarnessSpec | Mapping[str, Any] | None,
    signing_mode: str | None,
) -> str:
    """运营显式值优先，其次环境，最后 spec；未知模式直接拒绝。"""

    mode = signing_mode
    if mode is None:
        mode = os.environ.get(EVIDENCE_SIGNING_MODE_ENV, "").strip() or None
    if mode is None:
        if isinstance(spec, HarnessSpec):
            mode = spec.signing_mode
        else:
            raw = spec if isinstance(spec, Mapping) else {}
            signing = raw.get("signing") if isinstance(raw.get("signing"), Mapping) else {}
            evidence = raw.get("evidence") if isinstance(raw.get("evidence"), Mapping) else {}
            mode = str(signing.get("mode") or evidence.get("signing_mode") or "single")
    if mode not in {"single", "three_party"}:
        raise DeliveryEvidenceError(
            REASON_BINDING, f"未知签名模式 {mode!r}；不会猜一个方向交付"
        )
    return str(mode)


def _simulator_trust_from_env(raw: str) -> Any:
    """``party:key_id:hex`` → TrustStore。只接受 simulator 公钥。"""

    from agent_evidence.signing import TrustStore

    store = TrustStore()
    for chunk in raw.split(","):
        item = chunk.strip()
        if not item:
            continue
        parts = item.split(":")
        if len(parts) != 3:
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_UNVERIFIED,
                f"{SIMULATOR_PUBLIC_KEYS_ENV} 的条目要 party:key_id:hex，收到 {item!r}",
            )
        party, key_id, public_key = (part.strip() for part in parts)
        if party != "simulator":
            raise DeliveryEvidenceError(
                REASON_BINDING,
                f"{SIMULATOR_PUBLIC_KEYS_ENV} 只接受 simulator 公钥，收到 {party!r}",
            )
        try:
            store.add(party, key_id, public_key)
        except (ValueError, TypeError) as exc:
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_UNVERIFIED,
                f"{SIMULATOR_PUBLIC_KEYS_ENV} 里的公钥不可用：{exc}",
            ) from exc
    if not store.to_dict()["keys"].get("simulator"):
        raise DeliveryEvidenceError(
            REASON_SIMULATOR_UNVERIFIED, f"{SIMULATOR_PUBLIC_KEYS_ENV} 没有可用公钥"
        )
    return store


def _resolve_simulator_inputs(
    simulator_evidence: Any,
    simulator_trust: Any,
) -> tuple[Any, Any]:
    """显式参数优先，其次读环境里的**路径 / 公钥**（都不是私钥）。"""

    evidence = simulator_evidence
    if evidence is None:
        path = os.environ.get(SIMULATOR_EVIDENCE_ENV, "").strip()
        if path:
            evidence = path
    trust = simulator_trust
    if trust is None and evidence is not None:
        raw = os.environ.get(SIMULATOR_PUBLIC_KEYS_ENV, "").strip()
        if raw:
            trust = _simulator_trust_from_env(raw)
    return evidence, trust


def build_delivery_request(
    result: RunResult,
    *,
    hotkey: str,
    frame_uploads: Sequence[FrameManifest] = (),
    episode: int | None = None,
    runner_id: str | None = None,
    spec: HarnessSpec | Mapping[str, Any] | None = None,
    simulator_evidence: Any = None,
    simulator_trust: Any = None,
    frozen_job_digest: str | None = None,
    signing_mode: str | None = None,
) -> dict[str, Any]:
    """组装 ``POST .../result`` 的请求体。**只带实际上传成功的帧。**

    ``sim_time_s`` / ``api_cost_usd`` 来自 OPE-198 的计量：有测量值就带测量值，
    测不出来就带 JSON ``null``（显式未知），**不会用 0 冒充**。

    ``runner_id`` 是执行者租约（进程级 UUID4），后端按它校验 attempt 归属；
    空值只为兼容不走 worker 的本地调用，生产路径必须带。

    ``frozen_job_digest`` 是**后端已认证响应**里的冻结 config 摘要
    （`spec_digest` / `spec.job_digest`）。`three_party` 必须有它；executor 根
    与 simulator 根都要绑定同一个值。缺失时 fail-closed，**不**拿
    `parse_spec()` 的兜底摘要或 spec 自报的 `evidence.job_digest` 冒充。

    ``signing_mode`` 是运营选择的执行层证据模式；后端 `/spec` 不下发
    `evidence` 块，不能假设 `parse_spec()` 推断出的模式就是冻结模式。未传时
    才退回 spec 里的值（测试/本地）。后端仍按自己冻结的 spec 判定奖励。

    - ``three_party``：executor + simulator 各一条原文链、各一份签名根，放
      ``chains``；缺 simulator / 绑定错 / 工具动作对不上 / 链或根被改一律抛
      :class:`DeliveryEvidenceError`，不发交付。gateway 证据永不从请求上传。
    - ``single``：保持旧形状 ``events`` + ``roots``，只交 executor；即使调用方
      给了 simulator 证据也不会升级成可计奖的三方交付。
    """

    view = _spec_evidence_view(result, spec, episode)
    mode = _resolve_evidence_mode(spec, signing_mode)
    expected_digest = _resolve_expected_digest(spec, frozen_job_digest)

    status = episode_status(result)
    delivered = is_delivered_status(status)
    metering = _metering_record(result, spec)
    cost = metering.get("api_cost_usd") if isinstance(metering.get("api_cost_usd"), Mapping) else {}
    sim = metering.get("sim_time_s") if isinstance(metering.get("sim_time_s"), Mapping) else {}
    report: dict[str, Any] = {
        "episode": int(view["episode"]),
        "status": status,
        "reason": result.reason or None,
        "steps": int(result.steps),
        "turns": int(result.turns),
        "sim_time_s": sim.get("value") if sim.get("status") == "measured" else None,
        "api_cost_usd": cost.get("value") if cost.get("status") == "measured" else None,
        "run_id": result.run_id or None,
        "events": [],
        "roots": [],
        "chains": [],
        "frame_uploads": [
            {"seq": int(frame.seq), "sha256": frame.sha256} for frame in frame_uploads
        ],
    }

    if mode == "three_party":
        signing = result.extra.get("signing") if isinstance(result.extra, Mapping) else None
        has_root = isinstance(signing, Mapping) and isinstance(
            signing.get("root_record"), Mapping
        )
        if not has_root:
            if delivered:
                raise DeliveryEvidenceError(
                    REASON_EXECUTOR_ROOT,
                    "three_party 交付需要 executor 签名根；没有根就不会生成完整证据",
                )
            # 基建失败 / 超时：没有可签的 complete run，按旧形状交付失败分类；
            # 这时不读取 simulator 证据，也不把失败伪装成三方证据。
            report["events"] = list(result.events)
            report["roots"] = []
        else:
            if expected_digest is None:
                raise DeliveryEvidenceError(
                    REASON_FROZEN_DIGEST_MISSING,
                    "three_party 需要后端签发的 frozen job digest；parse_spec 的"
                    "兜底值或 spec 自报的 evidence.job_digest 不能当真实性证明",
                )
            simulator = (
                load_simulator_evidence(simulator_evidence)
                if simulator_evidence is not None
                else None
            )
            expected = {
                "job_id": view["job_id"],
                "attempt_id": view["attempt_id"],
                "episode": view["episode"],
                "job_nonce": view["job_nonce"],
            }
            events, root, expected = validate_executor_evidence(
                result, expected=expected
            )
            root_digest = _normalise_frozen_digest(root.get("job_digest"))
            if root_digest is None or root_digest != expected_digest:
                raise DeliveryEvidenceError(
                    REASON_BINDING,
                    "executor 根绑定的 job_digest 与后端签发的 frozen digest 不一致",
                )
            chains = pack_evidence_chains(
                signing_mode=mode,
                executor_events=events,
                executor_root=root,
                simulator_evidence=simulator,
                expected=expected,
                job_digest=expected_digest,
                simulator_trust=simulator_trust,
                delivered=delivered,
            )
            report["chains"] = list(chains)
    else:
        # single 联调档：保持旧形状；签名根可有可无，但永远不计奖。
        report["events"] = list(result.events)
        report["roots"] = _signing_roots(result)

    # 后端 outcome 与结果分类必须自洽：timeout / provider_5xx / executor_failure
    # / sim_infra_failure 属于未交付，不能因为 harness 进程本身没抛异常就写
    # ``delivered``（后端会 422，且会掩盖一次没跑完的运行）。
    outcome = "delivered" if delivered else "failed"
    payload: dict[str, Any] = {
        "hotkey": hotkey,
        "attempt_id": view["attempt_id"],
        "outcome": outcome,
        "results": [report],
    }
    if runner_id:
        payload["runner_id"] = runner_id
    return payload


def execute_attempt(
    spec: HarnessSpec | Mapping[str, Any],
    *,
    attempt_no: int,
    client: EvalBackendClient,
    runtime: Any = None,
    chat_fn: Any = None,
    runner: Any = None,
    runtime_override: str | None = None,
    strict: bool = True,
    signer: Any = None,
    runner_id: str | None = None,
    local_mode: bool = False,
    unknown_metering: str | None = None,
    simulator_evidence: Any = None,
    simulator_trust: Any = None,
    frozen_job_digest: str | None = None,
    signing_mode: str | None = None,
) -> RunResult:
    """跑一次 harness run，把帧直传，然后交付。

    ``attempt_no`` 由接单响应给出，spec 里没有它。``client`` 同时负责
    presign、PUT 和交付（同一个 hotkey / API key）。``runner_id`` 是开跑时
    认领 attempt 的进程级租约，交付时原样带回；它**不写进 spec**。

    ``unknown_metering`` 决定成本/仿真时长测不出来时怎么办：

    * ``null``（默认）：交付里带显式 ``null``，由后端按未知处理；
    * ``fail``：在交付前抛 :class:`MeteringUnavailable`，fail-closed。

    没有 ``zero`` 选项：测不出来不能写 0。

    ``simulator_evidence`` 是独立 simulator 主体（OPE-203）交出的原文链与
    签名根，本函数只消费、不生成、不代签；``simulator_trust`` 是运营侧提供
    的 simulator 公钥（:class:`agent_evidence.signing.TrustStore`），用于交付
    前 fail-closed 验签。``three_party`` 的已交付运行缺任一项都会抛
    :class:`agent_harness.delivery.DeliveryEvidenceError`，不会发一份假的三方
    证据给后端。

    ``frozen_job_digest`` 必须来自后端已认证的 job/spec 响应（`spec_digest`
    或 `spec.job_digest`），不是 `parse_spec()` 的兜底值；缺失时 `three_party`
    fail-closed。``signing_mode`` 是运营执行策略，避免把后端不下发的
    `evidence` 块默认成 `single` 后误判证据形状。两者也可由
    ``EVAL_FROZEN_JOB_DIGEST`` / ``EVAL_EVIDENCE_SIGNING_MODE`` 注入。

    ``chat_fn`` 不传时由 :func:`agent_harness.model_transport.build_model_transport`
    按运营契约选择：生产只允许后端可信网关，缺配置在模型/仿真之前 fail-closed；
    只有调用方显式 ``local_mode=True`` 时才允许本地直连。

    传入的 ``runtime`` 由调用方拥有：本函数只负责 episode 的 finish/abort，
    不 close；``eval_worker.runner.execute_in_process`` 在 finally 里关闭它。
    """

    # 延迟 import：本模块要被包顶层导出，而 ``run`` 定义在 ``__init__`` 里。
    from . import run as run_harness

    parsed = (
        spec
        if isinstance(spec, HarnessSpec)
        else parse_spec(spec, strict=strict, local_mode=local_mode)
    )
    policy = (unknown_metering or os.environ.get("AGENT_UNKNOWN_METERING_POLICY") or "null").strip().lower()
    if policy not in {"null", "fail"}:
        raise ValueError("unknown_metering must be 'null' or 'fail'")

    # 生产 B 的唯一模型出口是后端可信网关。配置缺失 / 不完整在任何模型或
    # 仿真动作之前 fail-closed；直连只允许显式 local_mode（smoke / 单测）。
    if chat_fn is None:
        transport = build_model_transport(parsed, local_mode=local_mode)
        chat_fn = transport.chat
        if signing_mode is None:
            signing_mode = transport.signing_mode
    else:
        # 运营配了网关契约时，注入一个 chat 函数就是绕过 data plane。
        contract = resolve_gateway_contract(parsed.job_id)
        if contract is not None and not is_backend_gateway_chat(chat_fn):
            raise ModelTransportConfigError(
                "a backend model gateway contract is configured; an injected "
                "chat function would bypass it"
            )

    resolved_digest = frozen_job_digest
    if resolved_digest is None:
        resolved_digest = os.environ.get(FROZEN_JOB_DIGEST_ENV, "").strip() or None
    resolved_mode = _resolve_evidence_mode(parsed, signing_mode)

    # 缺配置必须在**模型/仿真开始之前**失败：three_party 需要独立 simulator
    # runtime（或已产出的证据文件）、后端冻结摘要和运营公钥。不要把一次完整
    # 本地评测跑完才在交付前报缺 simulator。
    pre_trust = simulator_trust
    trust_env = os.environ.get(SIMULATOR_PUBLIC_KEYS_ENV, "").strip()
    if pre_trust is None and trust_env:
        pre_trust = _simulator_trust_from_env(trust_env)
    evidence_env = os.environ.get(SIMULATOR_EVIDENCE_ENV, "").strip()
    socket_env = os.environ.get(SIMULATOR_SOCKET_ENV, "").strip()
    required = os.environ.get(SIMULATOR_REQUIRED_ENV, "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    if required and not socket_env and simulator_evidence is None and not evidence_env:
        raise DeliveryEvidenceError(
            REASON_SIMULATOR_MISSING,
            f"{SIMULATOR_REQUIRED_ENV}=1 但 {SIMULATOR_SOCKET_ENV} 未配置；"
            "在模型/仿真前拒绝",
        )
    if resolved_mode == "three_party":
        # 先报「没有 simulator 执行方」，再报摘要/公钥缺失：缺 runtime 时
        # 本来就不可能产出本次工具动作的证据，其他配置错误也不该掩盖它。
        if simulator_evidence is None and not evidence_env:
            if parsed.assurance.isolated:
                if runtime is not None:
                    raise DeliveryEvidenceError(
                        REASON_SIMULATOR_MISSING,
                        "isolated profile 不允许注入 runtime；simulator client 必须"
                        "在 sandbox worker 内创建",
                    )
                if not socket_env:
                    raise DeliveryEvidenceError(
                        REASON_SIMULATOR_MISSING,
                        f"isolated three_party 需要运营 {SIMULATOR_SOCKET_ENV}；"
                        "在模型/仿真前拒绝",
                    )
            elif runtime is None or not callable(getattr(runtime, "call", None)):
                raise DeliveryEvidenceError(
                    REASON_SIMULATOR_MISSING,
                    "three_party 需要独立 simulator runtime；在模型/仿真前拒绝",
                )
            elif not callable(getattr(runtime, "finish_episode", None)):
                raise DeliveryEvidenceError(
                    REASON_SIMULATOR_MISSING,
                    "simulator runtime 没有 finish_episode()，无法产出签名根；"
                    "在模型/仿真前拒绝",
                )
        if _resolve_expected_digest(parsed, resolved_digest) is None:
            raise DeliveryEvidenceError(
                REASON_FROZEN_DIGEST_MISSING,
                "three_party 需要后端签发的 frozen job digest；在模型/仿真前拒绝",
            )
        if pre_trust is None and not trust_env:
            raise DeliveryEvidenceError(
                REASON_SIMULATOR_UNVERIFIED,
                f"three_party 需要 simulator 公钥（{SIMULATOR_PUBLIC_KEYS_ENV}）；"
                "在模型/仿真前拒绝",
            )

    collector = FrameCollector()
    result = run_harness(
        parsed,
        runtime=runtime,
        chat_fn=chat_fn,
        runner=runner,
        runtime_override=runtime_override,
        strict=strict,
        signer=signer,
        frame_collector=collector,
        local_mode=local_mode,
    )

    # OPE-203: 独立 simulator 主体在 episode 结束时签根。``run()`` 内部
    # 自建的 sandbox remote runtime 在返回前已经 finish/abort，并通过
    # ``result.extra["simulator_evidence"]`` 交出原文；显式传入的
    # ``simulator_evidence`` 优先。
    if simulator_evidence is None and isinstance(result.extra, Mapping):
        simulator_evidence = result.extra.get("simulator_evidence")
    fatal_tool = result.extra.get("fatal_tool_runtime") if isinstance(result.extra, Mapping) else None
    simulator_fatal = bool(fatal_tool) or str(result.reason or "").startswith("simulator_fatal")
    if simulator_evidence is None:
        if simulator_fatal:
            abort = getattr(runtime, "abort_episode", None)
            if callable(abort):
                try:
                    abort(reason=f"fatal:{result.reason}")
                except Exception as exc:  # noqa: BLE001 - 失败路径只记录清理错误
                    logger.warning(
                        "[eval-execute] job=%s attempt=%s simulator abort 失败（%s）",
                        parsed.job_id,
                        attempt_no,
                        type(exc).__name__,
                    )
        else:
            finish = getattr(runtime, "finish_episode", None)
            if callable(finish):
                try:
                    simulator_evidence = finish()
                except Exception as exc:  # noqa: BLE001 - 成功路径必须 fail-closed
                    if result.status == "ok":
                        raise
                    logger.warning(
                        "[eval-execute] job=%s attempt=%s simulator finish 失败（%s），"
                        "按基建失败交付",
                        parsed.job_id,
                        attempt_no,
                        type(exc).__name__,
                    )

    metering = result.extra.get("metering") if isinstance(result.extra, Mapping) else None
    if not isinstance(metering, Mapping):
        # 旧 harness / 外部构造的 RunResult：按同一条事件链重算，不补数字。
        metering = measure(parsed.raw, result.events, runtime).payload()
        result.extra = {**dict(result.extra), "metering": metering}
    if policy == "fail":
        missing = unknown_fields(metering if isinstance(metering, Mapping) else {})
        if missing:
            raise MeteringUnavailable(
                "这次 run 的成本/时长无法计量，按 unknown_metering=fail 拒绝交付："
                + ", ".join(missing)
            )

    uploaded = collector.upload(
        client,
        job_id=parsed.job_id,
        attempt_no=int(attempt_no),
    )
    if len(uploaded) != len(collector.frames):
        logger.warning(
            "[eval-execute] job=%s attempt=%s 帧 %d/%d 上传成功，其余按 missing 交付",
            parsed.job_id,
            attempt_no,
            len(uploaded),
            len(collector.frames),
        )

    result.frame_uploads = [
        {"seq": int(frame.seq), "sha256": frame.sha256} for frame in uploaded
    ]
    resolved_evidence, resolved_trust = _resolve_simulator_inputs(
        simulator_evidence, pre_trust
    )
    payload = build_delivery_request(
        result,
        hotkey=client.hotkey,
        frame_uploads=uploaded,
        episode=parsed.episode,
        runner_id=runner_id,
        spec=parsed,
        simulator_evidence=resolved_evidence,
        simulator_trust=resolved_trust,
        frozen_job_digest=resolved_digest,
        signing_mode=resolved_mode,
    )
    client.deliver_attempt(
        job_id=parsed.job_id,
        attempt_no=int(attempt_no),
        payload=payload,
    )
    # 只留交付摘要；完整 payload 带整条事件链，别塞进结果记录里。
    result.extra = {
        **dict(result.extra),
        "frame_uploads": list(result.frame_uploads),
        "delivery": {
            "attempt_id": payload["attempt_id"],
            "outcome": payload["outcome"],
            "status": payload["results"][0]["status"],
            "frame_uploads": list(result.frame_uploads),
        },
    }
    return result


__all__ = [
    "DeliveryEvidenceError",
    "build_delivery_request",
    "episode_status",
    "execute_attempt",
]
