"""Read and validate the part of EvaluationSpec a harness needs.

The backend (OPE-121) owns the authoritative whole-spec validator. The harness
only reads what it executes and re-checks the three frozen agent fields so the
execution layer cannot run a different harness than the job was quoted for.

Accepted shape (the backend's blocks plus two execution-layer extensions)::

    {
      "run_id": "...", "attempt_id": "...",
      "task": {"source": "axis", "task_id": "9001", "instance": 0},
      "agent": {"harness_commit": "...", "system_prompt_digest": "...",
                "tools_digest": "..."},
      "model": {"provider": "deepseek", "model": "deepseek-chat", ...},
      "permissions": {"mode": "privileged", "allowed_sensors": ["image", ...]},
      "budget": {"max_api_calls": 20, "wall_seconds": 600, ...},
      "timing": {"control_step_seconds": 0.2, ...},
      "delivery": {...}, "binding": {...},
      "assurance_profile": "demo-no-isolation",            # OPE-124
      "harness": {"name": "headless", "options": {...}},   # extension
      "evidence": {"path": "..."}                            # extension
    }

The miner-facing fields are frozen: ``agent`` must match this process, and
supplying ``system_prompt`` / ``tools`` *anywhere* is a hard error rather than
a silent override.
"""

from __future__ import annotations

import re
import secrets
from dataclasses import dataclass
from typing import Any, Mapping

from task_source.base import TASK_SOURCES

from .assurance import AssuranceError, AssuranceProfile, resolve_assurance_profile
from .canonical import canonical_sha256
from .manifest import HARNESS_NAME, HARNESS_VERSION, verify_agent_binding
from .modes import EffectivePermissions, ModeError, resolve_permissions, resolve_timing

_SHA256_RE = re.compile(r"\A[0-9a-f]{64}\Z")
_GIT_COMMIT_RE = re.compile(r"\A[0-9a-f]{40}\Z")
_SIGNING_MODES = ("single", "three_party")
_PARTIES = ("executor", "gateway", "simulator")
#: ``job_digest`` 的兜底计算排除这些每次运行/执行层字段。
_VOLATILE_FOR_JOB_DIGEST = {"binding", "evidence", "evidence_path", "runtime", "signing"}

DEFAULT_HARNESS = "headless"
DEFAULT_MAX_TURNS = 20
DEFAULT_MAX_STEPS = 200
DEFAULT_WALL_SECONDS = 900.0
DEFAULT_CONTROL_STEP_SECONDS = 0.2

_TOP_LEVEL_KEYS = {
    "run_id",
    "attempt_id",
    "episode",
    "task",
    "agent",
    "model",
    "permissions",
    "budget",
    "timing",
    "delivery",
    "binding",
    "harness",
    "evidence",
    "evidence_path",
    "instruction",
    "runtime",
    "scenario",
    "assurance_profile",
    "job_id",
    "job_nonce",
    "job_digest",
    "signing",
    #: A 参照组收分绑定（panel / member / trial / package / config / settlement）。
    #: 只有 A 入口会填；B 默认不带，行为不变。
    "panel_binding",
}

#: Keys that would let a caller replace the frozen agent definition.
_FORBIDDEN_KEYS = {"system_prompt", "prompt", "tools", "tool_manifest", "harness_code"}


class SpecError(ValueError):
    """The spec is unusable (missing field, unknown mode, digest mismatch...)."""


@dataclass(frozen=True)
class HarnessSpec:
    raw: Mapping[str, Any]
    run_id: str
    attempt_id: str | None
    episode: int | None
    source: str
    task_id: str
    instance: int
    task_package_root: str | None
    #: OPE-197：冻结题包的内容摘要。执行前必须与实际加载的目录逐文件
    #: 复算一致；缺失 / 不匹配一律拒跑（本地 smoke 也要显式给）。
    task_version_digest: str | None
    #: 可选的不可变取包引用（``task.package_repo`` / ``task.package_commit``）。
    #: 后端尚未下发；有值时按 revision 锁定下载，没有时只认本地已验证内容。
    task_package_repo: str | None
    task_package_commit: str | None
    model: Mapping[str, Any]
    harness_name: str
    harness_options: Mapping[str, Any]
    mode: str
    sensors: tuple[str, ...]
    permissions: EffectivePermissions
    timing: Mapping[str, Any]
    max_turns: int
    max_steps: int
    wall_seconds: float
    control_step_seconds: float
    evidence_path: str | None
    instruction: str | None
    runtime_override: str | None
    #: OPE-126 evidence binding. ``job_id`` / ``job_nonce`` come from the
    #: backend ``binding`` block when present; ``job_digest`` is the frozen
    #: config digest every signing party must bind to.
    job_id: str
    job_nonce: str
    job_digest: str
    signing_mode: str
    party: str
    #: OPE-124 isolation declaration. Frozen with the spec and written into
    #: ``run_start`` / the result record; a run never guesses this at runtime.
    assurance: AssuranceProfile
    #: A 参照组收分绑定；None = 这次运行不声明 A 绑定（B 默认行为）。
    panel_binding: Mapping[str, Any] | None

    @property
    def assurance_profile(self) -> str:
        return self.assurance.name

    @property
    def agent(self) -> Mapping[str, Any]:
        block = self.raw.get("agent")
        return block if isinstance(block, Mapping) else {}

    def permissions_payload(self) -> dict[str, Any]:
        """The per-field permission declaration that goes into evidence."""

        payload = self.permissions.payload()
        payload["timing"] = {
            "clock_mode": self.timing["clock_mode"],
            "s": self.timing["s"],
        }
        return payload


def _mapping(value: Any, field: str) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise SpecError(f"{field} must be an object")
    return dict(value)


def _positive_int(value: Any, field: str, default: int) -> int:
    if value is None:
        return default
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise SpecError(f"{field} must be an integer") from exc
    if parsed < 1:
        raise SpecError(f"{field} must be >= 1")
    return parsed


def _non_negative_int(value: Any, field: str, default: int) -> int:
    if value is None:
        return default
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise SpecError(f"{field} must be an integer") from exc
    if parsed < 0:
        raise SpecError(f"{field} must be >= 0")
    return parsed


def _positive_float(value: Any, field: str, default: float) -> float:
    if value is None:
        return default
    try:
        parsed = float(value)
    except (TypeError, ValueError) as exc:
        raise SpecError(f"{field} must be a number") from exc
    if parsed <= 0:
        raise SpecError(f"{field} must be > 0")
    return parsed


def _flatten_model(model: Mapping[str, Any]) -> dict[str, Any]:
    """Merge the backend's optional nested ``model.model`` block into one view."""

    nested = model.get("model")
    if not isinstance(nested, Mapping):
        return dict(model)
    flat = {key: value for key, value in model.items() if key != "model"}
    flat.update({key: value for key, value in nested.items() if value is not None})
    return flat


def _check_for_overrides(raw: Mapping[str, Any]) -> None:
    for key in _FORBIDDEN_KEYS:
        if key in raw:
            raise SpecError(f"{key!r} may not be supplied by the spec; harness definitions are frozen")
    harness = raw.get("harness")
    if isinstance(harness, Mapping):
        for key in _FORBIDDEN_KEYS:
            if key in harness:
                raise SpecError(f"harness.{key!r} may not be supplied by the spec; harness definitions are frozen")


def _panel_binding(raw: Mapping[str, Any]) -> dict[str, Any] | None:
    value = raw.get("panel_binding")
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise SpecError("panel_binding must be an object")
    return dict(value)


def parse_spec(raw: Mapping[str, Any], *, strict: bool = True, local_mode: bool = False) -> HarnessSpec:
    """Validate a raw EvaluationSpec dict and return the harness view.

    ``strict=True`` (default) requires a matching ``agent`` block. ``strict=False``
    is for local smoke runs and still rejects an ``agent`` block that does not
    match — it only allows the block to be absent.

    ``local_mode=True`` is the **only** way to accept the execution-layer
    ``task.package_root`` field. Production specs must locate the package with
    ``task.package_repo`` + ``task.package_commit``; a miner cannot turn a
    local-directory field into a production authorization. Default is off.
    """

    if not isinstance(raw, Mapping):
        raise SpecError("evaluation spec must be an object")
    raw = dict(raw)
    unknown = sorted(set(raw) - _TOP_LEVEL_KEYS)
    if unknown:
        raise SpecError(f"unknown top-level fields {unknown}; refusing to guess")
    _check_for_overrides(raw)

    task = _mapping(raw.get("task"), "task")
    if not task:
        raise SpecError("task block is missing")
    source = str(task.get("source") or "").strip()
    if source not in TASK_SOURCES:
        raise SpecError(f"task.source must be one of {TASK_SOURCES}, got {source!r}")
    task_id = str(task.get("task_id") or "").strip()
    if not task_id:
        raise SpecError("task.task_id is missing")
    instance = _non_negative_int(task.get("instance"), "task.instance", 0)
    package_root = task.get("package_root")
    if package_root is not None:
        if not local_mode:
            raise SpecError(
                "task.package_root is a local smoke/test field and is disabled in "
                "production; the frozen spec must carry task.package_repo + "
                "task.package_commit"
            )
        package_root = str(package_root)
    version_digest = task.get("version_digest")
    if version_digest is not None:
        version_digest = str(version_digest).strip().lower()
        if not _SHA256_RE.match(version_digest):
            raise SpecError(f"task.version_digest must be a 64-char lowercase sha256 hex, got {version_digest!r}")
    package_repo = task.get("package_repo")
    package_commit = task.get("package_commit")
    execution_profile = task.get("execution_profile")
    if execution_profile is not None:
        try:
            from openroboto_protocol.task_profiles import checker_types_for_profile

            if isinstance(execution_profile, Mapping) and execution_profile.get("id") == "panda-open-scene-v1":
                from openroboto_protocol import scene_contract

                scene_contract.profile_document(execution_profile)
                supported = True
            else:
                supported = bool(checker_types_for_profile(execution_profile))
        except ImportError as exc:
            raise SpecError("task.execution_profile requires the task-contract protocol release") from exc
        except ValueError as exc:
            raise SpecError("task.execution_profile does not match the installed scene contract") from exc
        if source != "axis" or not supported:
            raise SpecError("task.execution_profile is not the exact published execution profile")
    if (package_repo is None) != (package_commit is None):
        raise SpecError("task.package_repo and task.package_commit must be supplied together")
    if package_repo is not None:
        package_repo = str(package_repo).strip()
        if not package_repo:
            raise SpecError("task.package_repo may not be empty")
        package_commit = str(package_commit).strip().lower()
        if not _GIT_COMMIT_RE.match(package_commit):
            raise SpecError(f"task.package_commit must be a 40-char lowercase git sha, got {package_commit!r}")

    model = _mapping(raw.get("model"), "model")
    if not model:
        raise SpecError("model block is missing")
    model = _flatten_model(model)
    if not model.get("provider"):
        raise SpecError("model.provider is missing")
    if not (model.get("model") or model.get("name")):
        raise SpecError("model.model is missing")

    permissions_block = _mapping(raw.get("permissions"), "permissions")
    try:
        permissions = resolve_permissions(permissions_block, require_testnet=True)
    except ModeError as exc:
        raise SpecError(str(exc)) from None
    try:
        assurance = resolve_assurance_profile(raw.get("assurance_profile"))
    except AssuranceError as exc:
        raise SpecError(str(exc)) from None
    mode = permissions.mode
    sensors = permissions.sensors

    budget = _mapping(raw.get("budget"), "budget")
    timing_block = _mapping(raw.get("timing"), "timing")
    try:
        timing = resolve_timing(timing_block, permissions)
    except ModeError as exc:
        raise SpecError(str(exc)) from None
    control_step = _positive_float(
        timing_block.get("control_step_seconds"), "timing.control_step_seconds", DEFAULT_CONTROL_STEP_SECONDS
    )
    max_turns = _positive_int(
        budget.get("max_api_calls", budget.get("max_turns")), "budget.max_api_calls", DEFAULT_MAX_TURNS
    )
    if budget.get("max_steps") is not None:
        max_steps = _positive_int(budget.get("max_steps"), "budget.max_steps", DEFAULT_MAX_STEPS)
    elif budget.get("sim_seconds") is not None:
        sim_seconds = _positive_float(budget.get("sim_seconds"), "budget.sim_seconds", 0.0)
        max_steps = max(1, int(sim_seconds / control_step))
    else:
        max_steps = DEFAULT_MAX_STEPS
    wall_seconds = _positive_float(budget.get("wall_seconds"), "budget.wall_seconds", DEFAULT_WALL_SECONDS)

    harness = _mapping(raw.get("harness"), "harness")
    harness_name = str(harness.get("name") or DEFAULT_HARNESS).strip()
    if not harness_name:
        raise SpecError("harness.name may not be empty")
    if execution_profile is not None and harness_name != "headless":
        raise SpecError("this execution profile requires the input-replayable headless harness")
    harness_options = _mapping(harness.get("options"), "harness.options")

    evidence = _mapping(raw.get("evidence"), "evidence")
    evidence_path = evidence.get("path") or raw.get("evidence_path")
    if evidence_path is not None:
        evidence_path = str(evidence_path)

    runtime = raw.get("runtime")
    runtime_override = None
    if isinstance(runtime, str):
        runtime_override = runtime
    elif isinstance(runtime, Mapping) and runtime.get("override"):
        runtime_override = str(runtime["override"])

    agent = raw.get("agent")
    if agent is None:
        if strict:
            raise SpecError("agent block is missing; the job must freeze the harness first")
    else:
        problems = verify_agent_binding(agent)
        if problems:
            raise SpecError("frozen agent does not match this harness: " + "; ".join(problems))
        if not isinstance(agent, Mapping):
            raise SpecError("agent must be an object")

    instruction = raw.get("instruction")
    if instruction is not None:
        instruction = str(instruction)

    episode = raw.get("episode")
    if episode is not None:
        episode = _non_negative_int(episode, "episode", 0)

    # --- OPE-126 evidence binding -----------------------------------------
    binding = _mapping(raw.get("binding"), "binding")
    job_id = str(binding.get("job_id") or raw.get("job_id") or raw.get("run_id") or "local")
    job_nonce = str(binding.get("nonce") or raw.get("job_nonce") or "")
    if not job_nonce:
        # 本地 smoke 没有发单绑定;生成一个仅本次运行使用的 nonce。
        job_nonce = secrets.token_hex(16)

    signing = _mapping(raw.get("signing"), "signing")
    signing_mode = str(signing.get("mode") or evidence.get("signing_mode") or "single")
    if signing_mode not in _SIGNING_MODES:
        raise SpecError(f"signing.mode must be one of {_SIGNING_MODES}, got {signing_mode!r}")
    party = str(signing.get("party") or "executor")
    if party not in _PARTIES:
        raise SpecError(f"signing.party must be one of {_PARTIES}, got {party!r}")

    explicit_digest = evidence.get("job_digest") or raw.get("job_digest")
    if explicit_digest is not None:
        job_digest = str(explicit_digest).lower()
        if not _SHA256_RE.match(job_digest):
            raise SpecError("job_digest must be a 64-char lowercase sha256 hex")
    else:
        # 执行层可以传 backend EvaluationSpec.digest() 覆盖;没有时用冻结配置的
        # canonical sha256 兜底,三方用同一份 raw spec 时会得到同一个值。
        comparable = {key: value for key, value in raw.items() if key not in _VOLATILE_FOR_JOB_DIGEST}
        job_digest = canonical_sha256(comparable)

    return HarnessSpec(
        raw=raw,
        run_id=str(raw.get("run_id") or ""),
        attempt_id=str(raw["attempt_id"]) if raw.get("attempt_id") is not None else None,
        episode=episode,
        source=source,
        task_id=task_id,
        instance=instance,
        task_package_root=package_root,
        task_version_digest=version_digest,
        task_package_repo=package_repo,
        task_package_commit=package_commit,
        model=model,
        harness_name=harness_name,
        harness_options=harness_options,
        mode=mode,
        sensors=sensors,
        permissions=permissions,
        timing=timing,
        max_turns=max_turns,
        max_steps=max_steps,
        wall_seconds=wall_seconds,
        control_step_seconds=control_step,
        evidence_path=evidence_path,
        instruction=instruction,
        runtime_override=runtime_override,
        job_id=job_id,
        job_nonce=job_nonce,
        job_digest=job_digest,
        signing_mode=signing_mode,
        party=party,
        assurance=assurance,
        panel_binding=_panel_binding(raw),
    )


def build_spec(
    *,
    source: str,
    task_id: str,
    instance: int = 0,
    version_digest: str | None = None,
    package_root: str | None = None,
    package_repo: str | None = None,
    package_commit: str | None = None,
    model: Mapping[str, Any],
    mode: str = "privileged",
    sensors: list[str] | None = None,
    harness_name: str = DEFAULT_HARNESS,
    run_id: str = "local",
    max_turns: int = DEFAULT_MAX_TURNS,
    max_steps: int | None = None,
    wall_seconds: float = DEFAULT_WALL_SECONDS,
    evidence_path: str | None = None,
    include_binding: bool = True,
    binding: Mapping[str, Any] | None = None,
    signing_mode: str = "single",
    assurance_profile: str | None = None,
    **extra: Any,
) -> dict[str, Any]:
    """Build a spec for tests, the CLI and the smoke tool.

    ``binding`` is the backend job binding (``job_id`` / ``nonce``); it is
    optional for local smoke runs. ``signing_mode`` is the OPE-126 executor
    policy (``single`` on the testnet, ``three_party`` after launch).

    ``assurance_profile`` is the OPE-124 isolation declaration. It is always
    written into the spec (the operator default when omitted) so the digest and
    the evidence both name the level the run was quoted for.
    """

    from .manifest import agent_binding

    resolved_assurance = resolve_assurance_profile(assurance_profile)
    spec: dict[str, Any] = {
        "run_id": run_id,
        "assurance_profile": resolved_assurance.name,
        "task": {
            "source": source,
            "task_id": task_id,
            "instance": instance,
            **({"version_digest": version_digest} if version_digest is not None else {}),
            **({"package_root": package_root} if package_root is not None else {}),
            **({"package_repo": package_repo} if package_repo is not None else {}),
            **({"package_commit": package_commit} if package_commit is not None else {}),
        },
        "model": dict(model),
        "permissions": {
            "mode": mode,
            "allowed_sensors": list(sensors) if sensors is not None else None,
        },
        "budget": {
            "max_api_calls": max_turns,
            "wall_seconds": wall_seconds,
        },
        # 时钟跟着模式走：real-time 是墙钟 + S=1，其余是仿真钟 + S=0。
        "timing": {
            "control_step_seconds": 0.2,
            "clock_mode": "wall" if mode == "realtime" else "sim",
            "s": 1.0 if mode == "realtime" else 0.0,
        },
        "harness": {"name": harness_name},
        "signing": {"mode": signing_mode},
    }
    if max_steps is not None:
        spec["budget"]["max_steps"] = max_steps
    if evidence_path is not None:
        spec["evidence"] = {"path": evidence_path}
    if binding is not None:
        spec["binding"] = dict(binding)
    if include_binding:
        spec["agent"] = agent_binding()
    spec.update(extra)
    if spec["permissions"]["allowed_sensors"] is None:
        spec["permissions"].pop("allowed_sensors")
    return spec


def harness_identity() -> dict[str, str]:
    return {"name": HARNESS_NAME, "version": HARNESS_VERSION}


__all__ = [
    "DEFAULT_HARNESS",
    "HarnessSpec",
    "SpecError",
    "build_spec",
    "harness_identity",
    "parse_spec",
]
