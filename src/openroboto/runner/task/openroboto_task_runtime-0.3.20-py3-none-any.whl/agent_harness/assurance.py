"""Assurance profiles: how much the execution layer is trusted for one run.

An ``assurance_profile`` is a *frozen* part of the EvaluationSpec, not a runtime
guess. It states what the execution layer promises about the tool process:

``demo-no-isolation``
    Testnet only. Tools run in the harness process, the operator vouches for
    every script, and one model is evaluated at a time. No uid drop, no
    namespaces. This is the default so existing testnet jobs keep working.

``isolated``
    Production. Tools run in a separate process under a dedicated uid, in their
    own mount / network / pid namespaces, with credential environment stripped,
    ``ptrace`` blocked and no route to any provider. The only model exit is the
    in-harness gateway (:mod:`agent_eval.gateway`).

The profile is written into ``run_start`` and into the result record, so a
result can never be silently compared across assurance levels. Switching the
default is an operator setting (``AGENT_EVAL_ASSURANCE_PROFILE``); *requiring*
isolation (production gate) is ``AGENT_EVAL_REQUIRE_ISOLATION=1``.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Mapping

DEFAULT_ASSURANCE_PROFILE = "demo-no-isolation"
ISOLATED_PROFILE = "isolated"
ASSURANCE_PROFILES: tuple[str, ...] = (DEFAULT_ASSURANCE_PROFILE, ISOLATED_PROFILE)

#: Operator switches. They change the default/required level, not the code.
DEFAULT_PROFILE_ENV = "AGENT_EVAL_ASSURANCE_PROFILE"
REQUIRE_ISOLATION_ENV = "AGENT_EVAL_REQUIRE_ISOLATION"

_TRUE = {"1", "true", "yes", "on"}


class AssuranceError(ValueError):
    """Unknown profile, or a profile that the operator/switch does not allow."""


def _env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in _TRUE


@dataclass(frozen=True)
class AssuranceProfile:
    """One frozen assurance declaration. Every field is explicit."""

    name: str
    isolated: bool
    tool_process: str
    #: Namespaces the tool process gets. Empty for the demo profile.
    namespaces: tuple[str, ...]
    #: Whether the tool process runs under its own uid/gid.
    dedicated_uid: bool
    #: ``stripped`` / ``inherited``.
    credentials: str
    #: ``blocked`` / ``allowed``.
    ptrace: str
    #: ``hidden`` / ``visible``.
    parent_proc: str
    #: ``gateway-only`` / ``unrestricted``.
    model_egress: str
    #: ``trusted-only`` / ``untrusted``.
    scripts: str
    #: ``single-model`` / ``specified-model``.
    model_choice: str

    @property
    def requires_isolation(self) -> bool:
        return self.isolated

    def payload(self) -> dict[str, Any]:
        """The declaration that goes into evidence and the result record."""

        return {
            "profile": self.name,
            "isolated": self.isolated,
            "tool_process": self.tool_process,
            "privileges": {
                "uid": "dedicated" if self.dedicated_uid else "same-as-harness",
                "namespaces": list(self.namespaces),
            },
            "proc": {"parent": self.parent_proc},
            "ptrace": self.ptrace,
            "credentials": self.credentials,
            "model_egress": self.model_egress,
            "trusted_scripts_only": self.scripts == "trusted-only",
            "model_choice": self.model_choice,
        }

    def digest_material(self) -> Mapping[str, Any]:
        return self.payload()


_PROFILES: Mapping[str, AssuranceProfile] = {
    DEFAULT_ASSURANCE_PROFILE: AssuranceProfile(
        name=DEFAULT_ASSURANCE_PROFILE,
        isolated=False,
        tool_process="in-harness",
        namespaces=(),
        dedicated_uid=False,
        credentials="inherited",
        ptrace="allowed",
        parent_proc="visible",
        model_egress="unrestricted",
        scripts="trusted-only",
        model_choice="single-model",
    ),
    ISOLATED_PROFILE: AssuranceProfile(
        name=ISOLATED_PROFILE,
        isolated=True,
        tool_process="separate-process",
        namespaces=("mount", "net", "pid"),
        dedicated_uid=True,
        credentials="stripped",
        ptrace="blocked",
        parent_proc="hidden",
        model_egress="gateway-only",
        scripts="untrusted",
        model_choice="specified-model",
    ),
}


def profile(name: str) -> AssuranceProfile:
    """Look up a profile by its exact name; never guess a near match."""

    key = str(name or "").strip()
    try:
        return _PROFILES[key]
    except KeyError:
        raise AssuranceError(f"unknown assurance_profile {key!r}; supported: {', '.join(ASSURANCE_PROFILES)}") from None


def default_profile_name() -> str:
    """Operator default. Requiring isolation also makes it the default."""

    if _env_flag(REQUIRE_ISOLATION_ENV):
        return ISOLATED_PROFILE
    override = os.environ.get(DEFAULT_PROFILE_ENV, "").strip()
    if override:
        profile(override)  # unknown names are a configuration error, not a fallback
        return override
    return DEFAULT_ASSURANCE_PROFILE


def resolve_assurance_profile(value: Any) -> AssuranceProfile:
    """Resolve a spec value (``None`` = operator default) to a profile.

    When ``AGENT_EVAL_REQUIRE_ISOLATION=1`` the demo profile is rejected: a
    production host may not accept a job that promised no isolation. There is
    no silent upgrade — the spec must say ``isolated`` so the digest matches
    what actually ran.
    """

    if value is None or (isinstance(value, str) and not value.strip()):
        resolved = profile(default_profile_name())
    elif not isinstance(value, str):
        raise AssuranceError("assurance_profile must be a string")
    else:
        resolved = profile(value.strip())

    if _env_flag(REQUIRE_ISOLATION_ENV) and not resolved.isolated:
        raise AssuranceError(
            f"{REQUIRE_ISOLATION_ENV}=1 requires assurance_profile={ISOLATED_PROFILE!r}; "
            f"got {resolved.name!r}. Refusing to run without the promised isolation."
        )
    return resolved


def assurance_evidence(spec: Any, runtime: Any = None) -> dict[str, Any]:
    """Profile declaration plus what the concrete runtime actually enforced.

    A sandboxed runtime adds uid, namespaces, environment digest and worker
    guards. A plain in-process runtime adds nothing, so the record keeps saying
    ``demo-no-isolation`` rather than implying protection it does not have.
    """

    declaration = spec.assurance.payload()
    extra = getattr(runtime, "assurance_payload", None)
    if callable(extra):
        declaration.update(dict(extra()))
    return declaration


def describe_profiles() -> dict[str, dict[str, Any]]:
    """Ops view: every profile field plus which one is the current default."""

    default = default_profile_name()
    result: dict[str, dict[str, Any]] = {}
    for name in ASSURANCE_PROFILES:
        payload = _PROFILES[name].payload()
        payload["default"] = name == default
        result[name] = payload
    return result


__all__ = [
    "ASSURANCE_PROFILES",
    "AssuranceError",
    "AssuranceProfile",
    "DEFAULT_ASSURANCE_PROFILE",
    "DEFAULT_PROFILE_ENV",
    "ISOLATED_PROFILE",
    "REQUIRE_ISOLATION_ENV",
    "assurance_evidence",
    "default_profile_name",
    "describe_profiles",
    "profile",
    "resolve_assurance_profile",
]
