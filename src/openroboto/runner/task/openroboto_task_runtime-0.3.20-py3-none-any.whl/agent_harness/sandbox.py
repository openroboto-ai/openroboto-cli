"""Sandboxing for the tool process (OPE-124).

Two layers, applied together by ``assurance_profile=isolated``:

**OS layer** (Linux, execution host runs as root)
    ``unshare`` gives the worker its own mount, network and pid namespaces and
    mounts a fresh ``/proc`` (so the harness and its ``/proc/<pid>`` are not
    visible), then ``setpriv`` drops to a dedicated uid/gid. ``libseccomp``
    blocks ``ptrace`` / ``process_vm_readv`` / ``process_vm_writev`` /
    ``kcmp`` / ``pidfd_getfd``. The worker is started with a stripped
    environment, so provider credentials never cross the process boundary.

**Process layer** (portable, always on for the worker)
    ``sys.addaudithook`` refuses outbound sockets, DNS, subprocess/exec and
    reads of another process's ``/proc`` entries. This is what makes a leaked
    key useless even on a host where namespaces are unavailable: there is no
    route to a provider. The model exit stays in the harness process and goes
    through the OPE-125 gateway.

``assurance_profile=demo-no-isolation`` does not launch a worker at all; tools
stay in the harness process (testnet behaviour). The launcher still exists so
tests can exercise the process layer on any platform.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import json
import os
import pathlib
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

from task_source.base import RuntimeUnavailable

from .assurance import DEFAULT_ASSURANCE_PROFILE, AssuranceProfile, profile
from .canonical import canonical_sha256

#: Tokens that make an environment variable a credential. Environment names are
#: split on non-alphanumerics, so ``MONKEY`` does not match ``KEY``.
_SECRET_TOKENS = frozenset({
    "KEY",
    "KEYS",
    "TOKEN",
    "TOKENS",
    "SECRET",
    "SECRETS",
    "PASSWORD",
    "PASSWD",
    "CRED",
    "CREDS",
    "CREDENTIAL",
    "CREDENTIALS",
    "AUTH",
    "PRIVATE",
    "CERT",
    "COOKIE",
    "SIGNING",
})

#: Environment a tool process may inherit. This is an allowlist, not a denylist:
#: a new variable is invisible until someone deliberately adds it here.
_SAFE_ENV = (
    "PATH",
    "HOME",
    "TMPDIR",
    "TEMP",
    "TMP",
    "LANG",
    "LC_ALL",
    "LC_CTYPE",
    "SHELL",
    "USER",
    "LOGNAME",
    "TERM",
    "PYTHONHASHSEED",
    "PYTHONPATH",
    "PYTHONUNBUFFERED",
    # simulator / GL environment; never credentials
    "MUJOCO_GL",
    "PYOPENGL_PLATFORM",
    "DISPLAY",
    "WAYLAND_DISPLAY",
    "XDG_RUNTIME_DIR",
    "CUDA_VISIBLE_DEVICES",
    "NVIDIA_VISIBLE_DEVICES",
    "LIBGL_ALWAYS_SOFTWARE",
    "EGL_PLATFORM",
)

#: Local IPC that a renderer may legitimately need. Everything else is denied.
_LOCAL_SOCKET_PREFIXES = ("/tmp/.X11-unix/", "/tmp/.ICE-unix/", "/run/user/", "/dev/shm/")
#: 运营在父进程里从 `EVAL_SIMULATOR_SOCKET` 派生的**精确** socket 路径。
#: 只允许这一个 AF_UNIX 目标，不是宽泛前缀；请求/spec 不能设置它。
_ALLOWED_SOCKET_EXACT_ENV = "AGENT_SANDBOX_ALLOWED_SOCKET"

_SANDBOX_UID_ENV = "AGENT_SANDBOX_UID"
_SANDBOX_GID_ENV = "AGENT_SANDBOX_GID"
_DEFAULT_SANDBOX_UID = 65534

_SYSCALL_DENY = (
    b"ptrace",
    b"process_vm_readv",
    b"process_vm_writev",
    b"kcmp",
    b"pidfd_getfd",
)


class SandboxError(RuntimeError):
    """Configuration or protocol failure in the sandbox."""


class SandboxUnavailable(SandboxError):
    """The host cannot enforce the requested assurance profile."""


class SandboxFatalError(RuntimeUnavailable):
    """Worker/IPC failure that must terminate the attempt.

    Preserves the structured ``code`` / ``fatal`` / ``recorded`` fields from
    the worker instead of stringifying them. ``record_tool`` checks ``fatal``
    and turns this into a terminal attempt; EOF/worker exit/timeout are also
    fatal because the execution state can no longer be trusted.
    """

    def __init__(
        self,
        code: str,
        detail: str,
        *,
        recorded: bool = False,
        fatal: bool = True,
    ) -> None:
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail
        self.recorded = recorded
        self.fatal = fatal


# ---------------------------------------------------------------------------
# Host capabilities
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HostCapabilities:
    platform: str
    linux: bool
    root: bool
    unshare: str | None
    setpriv: str | None
    seccomp: bool
    missing: tuple[str, ...]

    @property
    def isolated(self) -> bool:
        return not self.missing

    def payload(self) -> dict[str, Any]:
        return {
            "platform": self.platform,
            "isolated_available": self.isolated,
            "linux": self.linux,
            "root": self.root,
            "unshare": self.unshare,
            "setpriv": self.setpriv,
            "seccomp": self.seccomp,
            "missing": list(self.missing),
        }


def _libseccomp() -> str | None:
    found = ctypes.util.find_library("seccomp")
    return found or None


def probe_host() -> HostCapabilities:
    """What this host can actually enforce. Missing items fail closed."""

    linux = sys.platform.startswith("linux")
    geteuid = getattr(os, "geteuid", None)
    root = bool(geteuid and geteuid() == 0)
    unshare = shutil.which("unshare") if linux else None
    setpriv = shutil.which("setpriv") if linux else None
    seccomp = bool(_libseccomp())

    missing: list[str] = []
    if not linux:
        missing.append(f"linux namespaces (host is {sys.platform})")
    if linux and not root:
        missing.append("root (uid drop and unshare need CAP_SETUID/CAP_SYS_ADMIN)")
    if linux and not unshare:
        missing.append("unshare(1) from util-linux")
    if linux and not setpriv:
        missing.append("setpriv(1) from util-linux")
    if linux and not seccomp:
        missing.append("libseccomp (ptrace cannot be blocked without it)")
    return HostCapabilities(
        platform=sys.platform,
        linux=linux,
        root=root,
        unshare=unshare,
        setpriv=setpriv,
        seccomp=seccomp,
        missing=tuple(missing),
    )


def require_isolated_host() -> HostCapabilities:
    caps = probe_host()
    if not caps.isolated:
        raise SandboxUnavailable(
            "assurance_profile='isolated' is not enforceable on this host: " + "; ".join(caps.missing)
        )
    return caps


# ---------------------------------------------------------------------------
# Environment
# ---------------------------------------------------------------------------


def _is_secret_name(name: str) -> bool:
    tokens = {token.upper() for token in re.split(r"[^A-Za-z0-9]+", name) if token}
    return bool(tokens & _SECRET_TOKENS)


def sanitized_env(
    base: Mapping[str, str] | None = None,
    *,
    extra: Mapping[str, str] | None = None,
    allow: Iterable[str] = (),
) -> dict[str, str]:
    """Return an allowlisted environment with every credential removed.

    ``extra`` is for values the launcher itself needs (``HOME``, ``PYTHONPATH``).
    A secret-looking name in ``extra`` is a programming error and is rejected
    rather than silently passed through.
    """

    source = os.environ if base is None else base
    allowed = set(_SAFE_ENV) | {str(name) for name in allow}
    env: dict[str, str] = {}
    for name in allowed:
        if _is_secret_name(name):
            raise SandboxError(f"refusing to expose credential-like variable {name!r} to the sandbox")
        value = source.get(name)
        if value is not None:
            env[name] = str(value)
    for name, value in (extra or {}).items():
        if _is_secret_name(name):
            raise SandboxError(f"refusing to expose credential-like variable {name!r} to the sandbox")
        env[str(name)] = str(value)
    return env


# ---------------------------------------------------------------------------
# Launch plan
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SandboxPlan:
    profile: AssuranceProfile
    command: tuple[str, ...]
    env: Mapping[str, str]
    cwd: str | None
    uid: int | None
    gid: int | None
    namespaces: tuple[str, ...]
    seccomp: bool
    home: str | None = None

    def payload(self) -> dict[str, Any]:
        return {
            "profile": self.profile.name,
            "tool_process": self.profile.tool_process,
            "uid": self.uid,
            "gid": self.gid,
            "namespaces": list(self.namespaces),
            "seccomp": self.seccomp,
            "credentials": self.profile.credentials,
            "ptrace": self.profile.ptrace,
            "parent_proc": self.profile.parent_proc,
            "model_egress": self.profile.model_egress,
            "environment": sorted(self.env),
            "environment_sha256": canonical_sha256(dict(self.env)),
        }


def _sandbox_ids(uid: int | None, gid: int | None) -> tuple[int, int]:
    if uid is None:
        try:
            uid = int(os.environ.get(_SANDBOX_UID_ENV, "") or _DEFAULT_SANDBOX_UID)
        except ValueError:
            raise SandboxError(f"{_SANDBOX_UID_ENV} must be an integer") from None
    if gid is None:
        raw = os.environ.get(_SANDBOX_GID_ENV, "")
        try:
            gid = int(raw) if raw else uid
        except ValueError:
            raise SandboxError(f"{_SANDBOX_GID_ENV} must be an integer") from None
    if uid <= 0 or gid <= 0:
        raise SandboxError("the sandbox uid/gid must be non-root (>= 1)")
    return uid, gid


def build_sandbox_plan(
    assurance: AssuranceProfile | str,
    command: Sequence[str],
    *,
    cwd: str | None = None,
    env: Mapping[str, str] | None = None,
    env_extra: Mapping[str, str] | None = None,
    home: str | None = None,
    uid: int | None = None,
    gid: int | None = None,
    capabilities: HostCapabilities | None = None,
) -> SandboxPlan:
    """Turn a command into an execution plan for ``assurance``.

    For ``isolated`` this fails closed when the host cannot enforce every
    promised property. For ``demo-no-isolation`` no wrapper is added.
    """

    resolved = assurance if isinstance(assurance, AssuranceProfile) else profile(assurance)
    if not command:
        raise SandboxError("sandbox command is empty")

    extra = dict(env_extra or {})
    if home:
        extra.setdefault("HOME", home)
    clean_env = sanitized_env(env, extra=extra)

    if not resolved.isolated:
        return SandboxPlan(
            profile=resolved,
            command=tuple(str(part) for part in command),
            env=clean_env,
            cwd=cwd,
            uid=None,
            gid=None,
            namespaces=(),
            seccomp=False,
            home=home,
        )

    caps = capabilities or require_isolated_host()
    if not caps.isolated:
        raise SandboxUnavailable(
            "assurance_profile='isolated' is not enforceable on this host: " + "; ".join(caps.missing)
        )
    sandbox_uid, sandbox_gid = _sandbox_ids(uid, gid)
    wrapped = (
        str(caps.unshare),
        "--mount",
        "--net",
        "--pid",
        "--fork",
        "--mount-proc",
        "--propagation",
        "private",
        "--kill-child",
        "--",
        str(caps.setpriv),
        "--reuid",
        str(sandbox_uid),
        "--regid",
        str(sandbox_gid),
        "--clear-groups",
        "--",
        *(str(part) for part in command),
    )
    return SandboxPlan(
        profile=resolved,
        command=wrapped,
        env=clean_env,
        cwd=cwd,
        uid=sandbox_uid,
        gid=sandbox_gid,
        namespaces=("mount", "net", "pid"),
        seccomp=bool(caps.seccomp),
        home=home,
    )


def launch_sandboxed(
    plan: SandboxPlan,
    *,
    pass_fds: Sequence[int] = (),
    stdin: Any = subprocess.PIPE,
    stdout: Any = subprocess.PIPE,
    stderr: Any = subprocess.PIPE,
    cwd: str | None = None,
) -> subprocess.Popen:
    """Spawn the planned process. The plan is the only source of argv/env."""

    workdir = cwd if cwd is not None else plan.cwd
    if plan.home:
        pathlib.Path(plan.home).mkdir(parents=True, exist_ok=True)
        if plan.uid is not None:
            try:
                os.chown(plan.home, plan.uid, plan.gid or plan.uid)
            except PermissionError:
                pass  # non-root best effort; isolated runs already require root
    return subprocess.Popen(
        list(plan.command),
        stdin=stdin,
        stdout=stdout,
        stderr=stderr,
        env=dict(plan.env),
        cwd=workdir,
        pass_fds=tuple(pass_fds),
        start_new_session=True,
    )


# ---------------------------------------------------------------------------
# Process-level guard (portable)
# ---------------------------------------------------------------------------

_ALLOWED_LOCAL_SOCKET = _LOCAL_SOCKET_PREFIXES
_NETWORK_AUDIT_EVENTS = frozenset({
    "socket.connect",
    "socket.getaddrinfo",
    "socket.gethostbyname",
    "socket.gethostbyname_ex",
    "socket.getnameinfo",
})
_SPAWN_AUDIT_EVENTS = frozenset({
    "subprocess.Popen",
    "os.system",
    "os.exec",
    "os.posix_spawn",
    "os.spawn",
    "os.fork",
    "os.forkpty",
    "pty.spawn",
})
_PROC_RE = re.compile(r"\A/proc/(\d+)(?:/|\Z)")


def _socket_address_allowed(address: Any) -> bool:
    if isinstance(address, (str, bytes, os.PathLike)):
        path = os.fsdecode(address)
        exact = os.environ.get(_ALLOWED_SOCKET_EXACT_ENV, "").strip()
        if exact and path == exact:
            return True
        return any(path.startswith(prefix) for prefix in _ALLOWED_LOCAL_SOCKET)
    return False


def _guard(event: str, args: tuple[Any, ...]) -> None:
    if event in _NETWORK_AUDIT_EVENTS:
        if event == "socket.connect" and args and _socket_address_allowed(args[-1]):
            return
        raise PermissionError(f"sandbox: outbound network is blocked ({event})")
    if event in _SPAWN_AUDIT_EVENTS:
        raise PermissionError(f"sandbox: spawning processes is blocked ({event})")
    if event == "open" and args:
        target = args[0]
        if isinstance(target, (str, bytes, os.PathLike)):
            # Resolve symlinks so ``/proc/self/root/proc/<pid>/environ`` cannot
            # walk around the check on hosts with a visible parent /proc.
            try:
                path = os.path.realpath(os.fsdecode(target))
            except OSError:
                path = os.fsdecode(target)
            match = _PROC_RE.match(path)
            if match and int(match.group(1)) not in {0, os.getpid()}:
                raise PermissionError(f"sandbox: reading another process's /proc entry is blocked ({target!r})")
    if event == "os.kill" and len(args) >= 1:
        try:
            pid = int(args[0])
        except (TypeError, ValueError):
            return
        if pid not in {0, os.getpid()}:
            raise PermissionError("sandbox: signalling other processes is blocked")


def install_process_guard() -> None:
    """Install the portable audit-hook guard. Idempotent under the worker.

    Audit hooks cannot be removed, and they are inherited across ``fork``; the
    worker installs this before touching the task source or simulator code.
    """

    if getattr(install_process_guard, "_installed", False):
        return
    sys.addaudithook(_guard)
    install_process_guard._installed = True  # type: ignore[attr-defined]


def _prctl(option: int, value: int) -> bool:
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        result = libc.prctl(option, ctypes.c_ulong(value), 0, 0, 0)
    except Exception:  # noqa: BLE001 - guard is best effort off Linux
        return False
    return result == 0


PR_SET_DUMPABLE = 4
PR_SET_NO_NEW_PRIVS = 38
_SCMP_ACT_ALLOW = 0x7FFF0000


def _scmp_act_errno(errno: int) -> int:
    return 0x00050000 | (errno & 0x0000FFFF)


def install_syscall_guard() -> bool:
    """Block ptrace-family syscalls with libseccomp. Returns whether it loaded.

    On non-Linux hosts this returns ``False``; the caller records that fact in
    the evidence instead of pretending the guarantee exists.
    """

    if not sys.platform.startswith("linux"):
        return False
    name = _libseccomp()
    if not name:
        return False
    try:
        lib = ctypes.CDLL(name, use_errno=True)
        lib.seccomp_init.argtypes = [ctypes.c_uint32]
        lib.seccomp_init.restype = ctypes.c_void_p
        lib.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
        lib.seccomp_syscall_resolve_name.restype = ctypes.c_int
        lib.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
        lib.seccomp_rule_add.restype = ctypes.c_int
        lib.seccomp_load.argtypes = [ctypes.c_void_p]
        lib.seccomp_load.restype = ctypes.c_int
        lib.seccomp_release.argtypes = [ctypes.c_void_p]
        lib.seccomp_release.restype = None

        _prctl(PR_SET_NO_NEW_PRIVS, 1)
        _prctl(PR_SET_DUMPABLE, 0)
        context = lib.seccomp_init(_SCMP_ACT_ALLOW)
        if not context:
            return False
        try:
            for syscall_name in _SYSCALL_DENY:
                number = lib.seccomp_syscall_resolve_name(syscall_name)
                if number < 0:
                    continue
                lib.seccomp_rule_add(context, _scmp_act_errno(1), number, 0)
            return lib.seccomp_load(context) == 0
        finally:
            lib.seccomp_release(context)
    except Exception:  # noqa: BLE001 - missing ABI / libc detail
        return False


def install_guards() -> dict[str, Any]:
    """Install both guard layers and report exactly what took effect."""

    install_process_guard()
    _prctl(PR_SET_DUMPABLE, 0)
    seccomp = install_syscall_guard()
    return {
        "process_guard": True,
        "proc_parent_hidden": True,
        "network": "blocked",
        "spawn": "blocked",
        "seccomp": seccomp,
        "dumpable": False,
    }


# ---------------------------------------------------------------------------
# Parent-side worker runtime
# ---------------------------------------------------------------------------


def _jsonable(value: Any) -> Any:
    """Convert observations to plain JSON without losing numeric fidelity."""

    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value]
    for attr in ("tolist", "item"):
        method = getattr(value, attr, None)
        if callable(method):
            try:
                return _jsonable(method())
            except Exception:  # noqa: BLE001
                break
    if isinstance(value, (bytes, bytearray)):
        return value.decode("utf-8", "replace")
    return str(value)


def worker_config(
    spec: Any,
    *,
    runtime_override: str | None = None,
    package_root: str | pathlib.Path | None = None,
    remote_simulator: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """The init message for the worker: only what building a runtime needs.

    Deliberately excludes the ``model`` block (it may carry an inline API key)
    and the binding/signing blocks. The worker gets no credential material.

    ``package_root`` is the directory the parent already resolved **by the
    frozen digest** (OPE-197). The child re-verifies it: the digest and local
    root are both passed down, while ``package_repo`` / ``package_commit`` are
    not — re-fetching in the sandbox is the parent's job, and a cached copy
    must still pass the content check every time.
    """

    if package_root is None:
        package_root = spec.task_package_root
    if package_root:
        # The worker runs with the repository root as cwd; resolve here so a
        # relative package root means the same thing in both processes.
        package_root = str(pathlib.Path(package_root).expanduser().resolve())

    config = {
        "source": spec.source,
        "task_id": spec.task_id,
        "instance": spec.instance,
        "package_root": package_root,
        "version_digest": spec.task_version_digest,
        "instruction": spec.instruction,
        "mode": spec.mode,
        "max_steps": spec.max_steps,
        "scenario": spec.raw.get("scenario"),
        "runtime": runtime_override or spec.runtime_override,
    }
    if remote_simulator is not None:
        config["remote_simulator"] = dict(remote_simulator)
    return config


def _remote_simulator_config(spec: Any) -> dict[str, Any] | None:
    """Operator-provided simulator endpoint for the sandbox worker.

    The socket path comes from the operator environment, never from the spec or
    the request. The binding is derived from the verified HarnessSpec; the
    operator store on the simulator supplies the frozen config. The worker
    creates the client **inside** the sandbox, so no runtime is injected into
    the harness process.
    """

    socket_path = os.environ.get("EVAL_SIMULATOR_SOCKET", "").strip()
    required = os.environ.get("EVAL_SIMULATOR_REQUIRED", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    if not socket_path:
        if required:
            raise RuntimeUnavailable(
                "EVAL_SIMULATOR_REQUIRED=1 but EVAL_SIMULATOR_SOCKET is not set"
            )
        return None
    if not os.path.isabs(socket_path):
        raise RuntimeUnavailable("EVAL_SIMULATOR_SOCKET must be an absolute path")
    raw = spec.raw if isinstance(getattr(spec, "raw", None), Mapping) else {}
    evidence = raw.get("evidence") if isinstance(raw.get("evidence"), Mapping) else {}
    explicit = evidence.get("job_digest") or raw.get("job_digest")
    digest = os.environ.get("EVAL_FROZEN_JOB_DIGEST", "").strip().lower() or (
        str(explicit).strip().lower() if explicit else ""
    )
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise RuntimeUnavailable(
            "isolated simulator needs the backend-issued frozen digest "
            "(EVAL_FROZEN_JOB_DIGEST or explicit spec.job_digest)"
        )
    return {
        "socket_path": socket_path,
        "binding": {
            "job_id": spec.job_id,
            "attempt_id": spec.attempt_id or spec.run_id or "local",
            "episode": spec.episode or 0,
            "job_nonce": spec.job_nonce,
            "job_digest": digest,
        },
        "run_id": spec.run_id or None,
    }


class SandboxedToolRuntime:
    """``ToolRuntime`` backed by a worker process, spoken over a socketpair."""

    source = ""
    instruction = ""

    def __init__(
        self,
        spec: Any,
        *,
        enforce_os: bool = True,
        runtime_override: str | None = None,
        timeout_s: float = 600.0,
        local_mode: bool = False,
    ) -> None:
        self._spec = spec
        self._lock = threading.Lock()
        self._closed = False
        self._timeout = float(timeout_s)
        self._home = tempfile.mkdtemp(prefix="agent-sandbox-")
        self._profile = spec.assurance
        # ``enforce_os=False`` is the test/smoke path: the portable process
        # layer runs, but no uid/namespace wrapper is added. It is never used
        # for a spec whose assurance profile promises OS isolation.
        self._enforce_os = bool(enforce_os and self._profile.isolated)
        assurance = self._profile if self._enforce_os else profile(DEFAULT_ASSURANCE_PROFILE)
        remote = _remote_simulator_config(spec)
        self._remote_simulator = remote is not None
        self._remote_socket = str(remote["socket_path"]) if remote is not None else ""
        # OPE-197: resolve and verify *before* spawning the tool process. A
        # missing / mismatched digest must fail before any simulator or model
        # work, and the child never gets a chance to load a same-named sample.
        # In remote-simulator mode the operator simulator loads and verifies
        # the package from its own frozen-config store; the executor must not
        # resolve or replace it.
        from .runtimes import frozen_package

        self._package = None if remote is not None else frozen_package(spec, local_mode=local_mode)

        parent_sock, child_sock = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
        parent_sock.settimeout(self._timeout)
        try:
            fd = child_sock.fileno()
            root = str(pathlib.Path(__file__).resolve().parents[1])
            pythonpath = os.environ.get("PYTHONPATH", "")
            env_extra = {
                "PYTHONPATH": root + (os.pathsep + pythonpath if pythonpath else ""),
                "PYTHONUNBUFFERED": "1",
            }
            if remote is not None:
                # 精确允许运营 socket；不是请求可指定的宽泛前缀。
                env_extra[_ALLOWED_SOCKET_EXACT_ENV] = self._remote_socket
            command = (
                sys.executable,
                "-m",
                "agent_harness.sandbox_worker",
                "--fd",
                str(fd),
                "--guard",
            )
            plan = build_sandbox_plan(
                assurance,
                command,
                env=None,
                env_extra=env_extra,
                home=self._home,
                capabilities=probe_host() if self._enforce_os else None,
            )
            self._plan = plan
            process = launch_sandboxed(
                plan,
                pass_fds=(fd,),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=root,
            )
        except BaseException:
            parent_sock.close()
            shutil.rmtree(self._home, ignore_errors=True)
            raise
        finally:
            child_sock.close()

        self._process = process
        self._sock = parent_sock
        self._reader = parent_sock.makefile("rb")
        self._writer = parent_sock.makefile("wb")

        reply = self._request(
            "init",
            config=worker_config(
                spec,
                runtime_override=runtime_override,
                package_root=(self._package.directory if self._package is not None else None),
                remote_simulator=remote,
            ),
        )
        self.source = str(reply.get("source") or spec.source)
        self.instruction = str(reply.get("instruction") or spec.instruction or "")
        self._worker_guard = dict(reply.get("guards") or {})
        if self._remote_simulator:
            # 只有 remote 模式的实例才“长得像”一个支持 correlation 的
            # runtime；普通 sandbox 仍走 observe/move_to/...，不会误用。
            self.call = self._remote_call
            self.finish_episode = self._remote_finish_episode
            self.abort_episode = self._remote_abort_episode

    # -- lifecycle ---------------------------------------------------------

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            if self._process.poll() is None:
                self._send({"op": "close"})
        except Exception:  # noqa: BLE001 - teardown is best effort
            pass
        for handle in (self._writer, self._reader, self._sock):
            try:
                handle.close()
            except Exception:  # noqa: BLE001
                pass
        try:
            self._process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:  # pragma: no cover
                self._process.kill()
                self._process.wait(timeout=5)
        for stream in (self._process.stdout, self._process.stderr):
            if stream is not None:
                try:
                    stream.close()
                except Exception:  # noqa: BLE001
                    pass
        shutil.rmtree(self._home, ignore_errors=True)

    def __enter__(self) -> SandboxedToolRuntime:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # -- ToolRuntime protocol ---------------------------------------------

    def reset(self) -> Mapping[str, Any]:
        return dict(self._request("reset")["observation"])

    def observe(self) -> Mapping[str, Any]:
        return dict(self._request("observe")["observation"])

    def move_to(self, x: float, y: float, z: float, gripper: float, steps: int = 10, yaw: float = 0.0) -> Any:
        return self._outcome(
            self._request(
                "move_to",
                x=float(x),
                y=float(y),
                z=float(z),
                gripper=float(gripper),
                steps=int(steps),
                yaw=float(yaw),
            )
        )

    def grasp(self, steps: int = 5) -> Any:
        return self._outcome(self._request("grasp", steps=int(steps)))

    def release(self, steps: int = 5) -> Any:
        return self._outcome(self._request("release", steps=int(steps)))

    def step(self, action: Any, steps: int = 1) -> Any:
        return self._outcome(self._request("step", action=_jsonable(action), steps=int(steps)))

    def success(self) -> tuple[bool, Mapping[str, Any]]:
        reply = self._request("success")
        return bool(reply.get("success")), dict(reply.get("detail") or {})

    def sim_time_s(self) -> float | None:
        """问隔离进程里的仿真器时钟；没有就保持 ``None``（未知）。"""

        value = self._request("sim_time_s").get("sim_time_s")
        if isinstance(value, bool) or value is None:
            return None
        try:
            value = float(value)
        except (TypeError, ValueError):
            return None
        return value if value >= 0 else None

    # -- remote simulator --------------------------------------------------

    def _remote_call(self, correlation_id: str, name: str, args: Mapping[str, Any]) -> Any:
        if not isinstance(correlation_id, str) or not correlation_id:
            raise ValueError("remote simulator call requires a non-empty correlation_id")
        return self._outcome(
            self._request(
                "call",
                correlation_id=correlation_id,
                name=name,
                args=_jsonable(dict(args)),
            )
        )

    def _remote_finish_episode(self) -> dict[str, Any]:
        reply = self._request("finish_episode")
        evidence = reply.get("evidence")
        if not isinstance(evidence, Mapping):
            raise SandboxFatalError(
                "SANDBOX_EVIDENCE_MISSING",
                "sandbox worker returned no simulator evidence",
            )
        return dict(evidence)

    def _remote_abort_episode(self, *, reason: str = "") -> None:
        self._request("abort_episode", reason=str(reason))

    # -- reporting ---------------------------------------------------------

    def assurance_payload(self) -> dict[str, Any]:
        payload = self._plan.payload()
        payload.update({
            "profile": self._profile.name,
            "tool_process": "separate-process",
            "credentials": "stripped",
            "os_isolation_enforced": self._enforce_os,
            "worker_pid": self._process.pid,
            "worker_exitcode": self._process.poll(),
            "worker_guards": dict(self._worker_guard),
        })
        if self._remote_simulator:
            # 明确记录工具实际在运营 simulator 进程执行；本地平台若未启用
            # OS 隔离，上面的 os_isolation_enforced=False 已经如实记录。
            payload.update({
                "remote_simulator": True,
                "tool_execution": "operator-simulator",
            })
        return payload

    # -- protocol ----------------------------------------------------------

    @staticmethod
    def _outcome(reply: Mapping[str, Any]) -> Any:
        from .tools import ToolOutcome

        return ToolOutcome(
            observation=dict(reply.get("observation") or {}),
            success=bool(reply.get("success")),
            detail=dict(reply.get("detail") or {}),
            steps=int(reply.get("steps") or 0),
        )

    def _send(self, message: Mapping[str, Any]) -> None:
        payload = json.dumps(dict(message), ensure_ascii=False, sort_keys=True) + "\n"
        self._writer.write(payload.encode("utf-8"))
        self._writer.flush()

    def _request(self, op: str, **fields: Any) -> dict[str, Any]:
        if self._closed:
            raise SandboxFatalError(
                "SANDBOX_CLOSED", "sandboxed tool process is already closed"
            )
        with self._lock:
            try:
                self._send({"op": op, **fields})
                line = self._reader.readline()
            except (OSError, ValueError) as exc:
                # Timeout / broken pipe / worker death: execution state is
                # unknown, so the attempt must terminate.
                raise SandboxFatalError(
                    "SANDBOX_WORKER_IO", f"sandboxed tool process failed: {exc}"
                ) from exc
            if not line:
                stderr = b""
                try:
                    assert self._process.stderr is not None
                    stderr = self._process.stderr.read() or b""
                except Exception:  # noqa: BLE001
                    pass
                tail = stderr.decode("utf-8", "replace").strip().splitlines()[-5:]
                raise SandboxFatalError(
                    "SANDBOX_WORKER_EXIT",
                    "sandboxed tool process exited unexpectedly"
                    + (": " + " | ".join(tail) if tail else ""),
                )
            try:
                reply = json.loads(line)
            except ValueError as exc:
                raise SandboxFatalError(
                    "SANDBOX_WORKER_PROTOCOL",
                    f"sandboxed tool process sent invalid JSON: {exc}",
                ) from exc
        if not reply.get("ok"):
            code = str(reply.get("error_code") or "SANDBOX_ERROR")
            detail = str(reply.get("error") or "sandboxed tool call failed")
            recorded = bool(reply.get("recorded", False))
            if reply.get("fatal", True):
                raise SandboxFatalError(code, detail, recorded=recorded)
            raise SandboxError(detail)
        return reply


def _readlink(path: str) -> str | None:
    try:
        return os.readlink(path)
    except OSError:
        return None


def ptrace_errno() -> int | None:
    """Try PTRACE_ATTACH on a non-existent pid and return ``errno``.

    Without seccomp the kernel answers ``ESRCH`` (3); with our filter it must
    answer ``EPERM`` (1). ``None`` means the host/libc has no ptrace probe.
    """

    if not sys.platform.startswith("linux"):
        return None
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        ctypes.set_errno(0)
        result = libc.ptrace(16, 999999, None, None)  # PTRACE_ATTACH
    except Exception:  # noqa: BLE001
        return None
    return 0 if result == 0 else ctypes.get_errno()


def worker_environment_report() -> dict[str, Any]:
    """What the process guard exposes for the probe command (tests/ops)."""

    watch = ("ANTHROPIC_API_KEY", "DEEPSEEK_API_KEY", "PI_API_KEY")
    namespaces = {
        name: _readlink(f"/proc/self/ns/{name}")
        for name in ("mnt", "net", "pid", "user", "uts", "ipc")
    }
    pid_entries = (
        sorted(name for name in os.listdir("/proc") if name.isdigit())
        if os.path.isdir("/proc")
        else []
    )
    return {
        "pid": os.getpid(),
        "ppid": os.getppid(),
        "uid": os.getuid() if hasattr(os, "getuid") else None,
        "gid": os.getgid() if hasattr(os, "getgid") else None,
        "namespaces": namespaces,
        "pid_entries": pid_entries,
        "ptrace_errno": ptrace_errno(),
        "credentials": {name: os.environ.get(name) for name in watch},
        "secret_like_env": sorted(name for name in os.environ if _is_secret_name(name)),
    }


__all__ = [
    "HostCapabilities",
    "SandboxError",
    "SandboxPlan",
    "SandboxUnavailable",
    "SandboxedToolRuntime",
    "build_sandbox_plan",
    "install_guards",
    "install_process_guard",
    "install_syscall_guard",
    "launch_sandboxed",
    "probe_host",
    "ptrace_errno",
    "require_isolated_host",
    "sanitized_env",
    "worker_config",
    "worker_environment_report",
]
