"""三种评测模式：Standard / Real-time / Privileged。

同一道题在不同模式下不可比，所以模式不是运行时的「一个开关」，而是一份
**逐字段冻结的权限声明**：允许看哪些观察字段、世界什么时候推进、时钟怎么走、
能不能 reset、是否是探索沙箱、最终解要不要冻结。这个模块是这份声明的唯一
来源：

* ``MODE_CONFIGS`` 一次写清每个模式的每个字段，不做「没写就是默认」的推断。
* :func:`resolve_permissions` 把 spec 的 ``permissions`` 块与名册对照，
  允许**收窄**（例如只要 image），不允许**加宽**（standard 要看物体位置直接拒）。
* :func:`resolve_timing` 把 ``timing`` 块与模式对照。standard / privileged 的
  世界只能由动作推进；real-time 必须 ``clock_mode=wall`` 且 ``s=1``。

测试网先开放 standard 与 privileged。real-time 的配置已经写好，但默认拒跑，
由 ``AGENT_EVAL_ENABLE_REALTIME=1`` 显式打开 —— 开关不是代码分支，回滚不需要
改代码。等实时时钟（C4）落地后再打开。

模式与结果分榜的关系见 :mod:`agent_harness.results`：结果记录的键包含 mode，
跨模式的聚合会被明确拒绝，不会悄悄混进同一张榜。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Callable, Mapping, TypeVar

from .canonical import canonical_json, canonical_sha256

#: 观察字段的全集。每个模式的 ``fields`` 都必须把这五项**逐字段**写成
#: true / false —— 「image-based」这种笼统说法不算声明。
SENSOR_FIELDS: tuple[str, ...] = (
    "image",
    "proprioception",
    "object_positions",
    "state",
    "success",
)

MODE_NAMES: tuple[str, ...] = ("standard", "realtime", "privileged")

#: 测试网开关。Real-time 等 C4 完成后再打开；打开方式见模块文档。
REALTIME_SWITCH = "AGENT_EVAL_ENABLE_REALTIME"

#: Privileged 探索阶段允许的 reset 次数上限。测试网初值，运营可下调（spec 里
#: 写 ``permissions.reset_budget``），但不能超过这个硬上限。
PRIVILEGED_RESET_BUDGET = 10

#: spec 的 ``permissions`` 块允许出现的键。多一个未知键就拒 —— 静默忽略一个
#: 「看起来像权限」的字段，比直接报错危险得多。
PERMISSION_KEYS: frozenset[str] = frozenset(
    {"mode", "allowed_sensors", "fields", "reset_budget", "exploration", "final_execution"}
)

#: spec 的 ``timing`` 块允许出现的键。``s`` 是速度倍率（S）：standard /
#: privileged 为 0（只有动作推进仿真），real-time 为 1。``s_scale`` 是同义别名。
TIMING_KEYS: frozenset[str] = frozenset({"control_step_seconds", "clock_mode", "s", "s_scale"})

ENVIRONMENT_ADVANCES = ("on_action", "wall_clock")
CLOCK_MODES = ("sim", "wall")
FINAL_EXECUTIONS = ("live", "frozen")


class ModeError(ValueError):
    """模式、权限或时钟配置不合法。"""


@dataclass(frozen=True)
class ModeConfig:
    """一个模式的完整权限声明。字段都是显式的，没有隐藏默认值。"""

    name: str
    sensors: tuple[str, ...]
    environment_advance: str
    clock_mode: str
    speed_scale: float
    reset_budget: int
    reset_budget_max: int
    exploration: bool
    final_execution: str
    testnet_ready: bool

    @property
    def allows_reset(self) -> bool:
        return self.reset_budget_max > 0

    def field_whitelist(self) -> dict[str, bool]:
        """五项观察字段逐字段写 true / false。"""

        return {field: field in self.sensors for field in SENSOR_FIELDS}

    def enabled_on_testnet(self) -> bool:
        """测试网是否开放。未开放的模式只有在显式开关下才能跑。"""

        if self.testnet_ready:
            return True
        value = os.environ.get(REALTIME_SWITCH, "").strip().lower()
        return value in {"1", "true", "yes", "on"}

    def payload(self) -> dict[str, Any]:
        """写进证据链和结果的权限声明（逐字段）。"""

        return {
            "mode": self.name,
            "fields": self.field_whitelist(),
            "allowed_sensors": list(self.sensors),
            "environment": {
                "advance": self.environment_advance,
                "clock": self.clock_mode,
                "s": self.speed_scale,
            },
            "reset": {"budget": self.reset_budget, "max": self.reset_budget_max},
            "exploration": self.exploration,
            "final_execution": self.final_execution,
            "testnet_ready": self.testnet_ready,
        }


#: 三模式名册。表里的每一列都在这里落成字段，不做推断。
MODE_CONFIGS: Mapping[str, ModeConfig] = {
    "standard": ModeConfig(
        name="standard",
        sensors=("image", "proprioception"),
        environment_advance="on_action",
        clock_mode="sim",
        speed_scale=0.0,
        reset_budget=0,
        reset_budget_max=0,
        exploration=False,
        final_execution="live",
        testnet_ready=True,
    ),
    "realtime": ModeConfig(
        name="realtime",
        sensors=("image", "proprioception"),
        environment_advance="wall_clock",
        clock_mode="wall",
        speed_scale=1.0,
        reset_budget=0,
        reset_budget_max=0,
        exploration=False,
        final_execution="live",
        testnet_ready=False,
    ),
    "privileged": ModeConfig(
        name="privileged",
        sensors=SENSOR_FIELDS,
        environment_advance="on_action",
        clock_mode="sim",
        speed_scale=0.0,
        reset_budget=PRIVILEGED_RESET_BUDGET,
        reset_budget_max=PRIVILEGED_RESET_BUDGET,
        exploration=True,
        final_execution="frozen",
        testnet_ready=True,
    ),
}


def mode_config(mode: str) -> ModeConfig:
    """按名字取模式；未知模式直接拒，不猜最像的那个。"""

    name = str(mode or "").strip()
    try:
        return MODE_CONFIGS[name]
    except KeyError:
        raise ModeError(f"unknown mode {name!r}; supported: {', '.join(MODE_NAMES)}") from None


def describe_modes() -> dict[str, dict[str, Any]]:
    """运维视图：每个模式的逐字段声明 + 测试网是否开放。"""

    result: dict[str, dict[str, Any]] = {}
    for name in MODE_NAMES:
        config = MODE_CONFIGS[name]
        payload = config.payload()
        payload["enabled_on_testnet"] = config.enabled_on_testnet()
        result[name] = payload
    return result


@dataclass(frozen=True)
class EffectivePermissions:
    """spec 收窄之后真正生效的权限。"""

    mode: str
    sensors: tuple[str, ...]
    reset_budget: int
    reset_budget_max: int
    exploration: bool
    final_execution: str
    environment_advance: str
    clock_mode: str
    speed_scale: float

    @property
    def fields(self) -> dict[str, bool]:
        return {field: field in self.sensors for field in SENSOR_FIELDS}

    def payload(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "fields": self.fields,
            "allowed_sensors": list(self.sensors),
            "environment": {
                "advance": self.environment_advance,
                "clock": self.clock_mode,
                "s": self.speed_scale,
            },
            "reset": {"budget": self.reset_budget, "max": self.reset_budget_max},
            "exploration": self.exploration,
            "final_execution": self.final_execution,
        }

    def digest(self) -> str:
        """权限声明的稳定摘要，结果记录用它区分配置不同的运行。"""

        return canonical_sha256(canonical_json(self.payload()))


def _sensor_set(value: Any, field: str) -> tuple[str, ...]:
    if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple, set)):
        raise ModeError(f"{field} must be a list of sensor names")
    names = sorted({str(item).strip() for item in value if str(item).strip()})
    unknown = sorted(set(names) - set(SENSOR_FIELDS))
    if unknown:
        raise ModeError(f"unknown sensors {unknown}; supported: {', '.join(SENSOR_FIELDS)}")
    return tuple(names)


def _declared_fields(value: Any) -> dict[str, bool] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ModeError("permissions.fields must be an object of field -> bool")
    unknown = sorted(set(value) - set(SENSOR_FIELDS))
    missing = sorted(set(SENSOR_FIELDS) - set(value))
    if unknown:
        raise ModeError(f"permissions.fields has unknown sensors {unknown}")
    if missing:
        raise ModeError(
            f"permissions.fields must declare every sensor field explicitly; missing {missing}"
        )
    declared: dict[str, bool] = {}
    for field in SENSOR_FIELDS:
        raw = value[field]
        if not isinstance(raw, bool):
            raise ModeError(f"permissions.fields.{field} must be true or false")
        declared[field] = raw
    return declared


def _reset_budget(value: Any, config: ModeConfig) -> int:
    if value is None:
        return config.reset_budget
    if isinstance(value, bool) or not isinstance(value, int):
        raise ModeError("permissions.reset_budget must be a non-negative integer")
    if value < 0:
        raise ModeError("permissions.reset_budget must be a non-negative integer")
    if config.reset_budget_max == 0:
        if value != 0:
            raise ModeError(
                f"mode {config.name!r} must not reset (reset_budget=0); "
                f"the world only moves through tool actions"
            )
        return 0
    if value > config.reset_budget_max:
        raise ModeError(
            f"mode {config.name!r} allows at most {config.reset_budget_max} resets, got {value}"
        )
    return value


def resolve_permissions(
    permissions: Mapping[str, Any] | None,
    *,
    require_testnet: bool = False,
) -> EffectivePermissions:
    """校验 spec 的权限块，返回生效的逐字段声明。

    * 未知键、缺 mode、未知传感器一律拒。
    * ``fields`` 与 ``allowed_sensors`` 都是**收窄**手段，不能加宽模式。
    * 两者都写时必须一致，避免同一份 spec 里出现两套权限。
    """

    block = dict(permissions or {})
    unknown = sorted(set(block) - PERMISSION_KEYS)
    if unknown:
        raise ModeError(
            f"unknown permission fields {unknown}; declared fields are {sorted(PERMISSION_KEYS)}"
        )

    mode_name = str(block.get("mode") or "").strip()
    if not mode_name:
        raise ModeError("permissions.mode is missing")
    config = mode_config(mode_name)
    if require_testnet and not config.enabled_on_testnet():
        raise ModeError(
            f"mode {mode_name!r} is not enabled on the testnet yet; "
            f"set {REALTIME_SWITCH}=1 only after the real-time clock (C4) is available"
        )

    declared = _declared_fields(block.get("fields"))
    allowed = block.get("allowed_sensors")
    allowed_set = _sensor_set(allowed, "permissions.allowed_sensors") if allowed is not None else None

    if declared is not None:
        fields_set = tuple(field for field in SENSOR_FIELDS if declared[field])
    else:
        fields_set = None

    if fields_set is not None and allowed_set is not None and set(fields_set) != set(allowed_set):
        raise ModeError(
            "permissions.fields and permissions.allowed_sensors disagree "
            f"({list(fields_set)} vs {list(allowed_set)})"
        )

    requested = fields_set if fields_set is not None else allowed_set
    if requested is None:
        requested = config.sensors

    forbidden = sorted(set(requested) - set(config.sensors))
    if forbidden:
        raise ModeError(f"mode {config.name!r} may not expose sensors {forbidden}")

    raw_exploration = block.get("exploration")
    if raw_exploration is None:
        exploration = config.exploration
    else:
        if not isinstance(raw_exploration, bool):
            raise ModeError("permissions.exploration must be true or false")
        if raw_exploration != config.exploration:
            # 探索能力是模式的定义的一部分，不能在同一张榜下悄悄改。
            raise ModeError(
                f"mode {config.name!r} fixes exploration={config.exploration}; "
                "a different value needs another mode"
            )
        exploration = raw_exploration

    final_execution = block.get("final_execution")
    if final_execution is None:
        final_execution = config.final_execution
    else:
        final_execution = str(final_execution).strip()
        if final_execution not in FINAL_EXECUTIONS:
            raise ModeError(
                f"permissions.final_execution must be one of {FINAL_EXECUTIONS}, got {final_execution!r}"
            )
        if final_execution != config.final_execution:
            raise ModeError(
                f"mode {config.name!r} fixes final_execution={config.final_execution!r}; "
                f"got {final_execution!r}"
            )

    return EffectivePermissions(
        mode=config.name,
        sensors=tuple(requested),
        reset_budget=_reset_budget(block.get("reset_budget"), config),
        reset_budget_max=config.reset_budget_max,
        exploration=exploration,
        final_execution=final_execution,
        environment_advance=config.environment_advance,
        clock_mode=config.clock_mode,
        speed_scale=config.speed_scale,
    )


def resolve_timing(timing: Mapping[str, Any] | None, permissions: EffectivePermissions) -> dict[str, Any]:
    """校验模式时钟：standard / privileged 只能 ``sim`` + S=0；real-time 只能
    ``wall`` + S=1。返回要写进证据链的生效值。"""

    block = dict(timing or {})
    unknown = sorted(set(block) - TIMING_KEYS)
    if unknown:
        raise ModeError(f"unknown timing fields {unknown}; declared fields are {sorted(TIMING_KEYS)}")

    raw_clock = block.get("clock_mode")
    clock_mode = str(raw_clock).strip() if raw_clock is not None else permissions.clock_mode
    if clock_mode not in CLOCK_MODES:
        raise ModeError(f"timing.clock_mode must be one of {CLOCK_MODES}, got {clock_mode!r}")
    if clock_mode != permissions.clock_mode:
        raise ModeError(
            f"mode {permissions.mode!r} requires timing.clock_mode={permissions.clock_mode!r}, "
            f"got {clock_mode!r}"
        )

    if "s" in block and "s_scale" in block:
        try:
            same = float(block["s"]) == float(block["s_scale"])
        except (TypeError, ValueError):
            same = False
        if not same:
            raise ModeError("timing.s and timing.s_scale disagree")

    raw_s = block.get("s", block.get("s_scale"))
    if raw_s is None:
        speed = permissions.speed_scale
    else:
        if isinstance(raw_s, bool) or not isinstance(raw_s, (int, float)):
            raise ModeError("timing.s must be a number")
        speed = float(raw_s)
        if speed != permissions.speed_scale:
            raise ModeError(
                f"mode {permissions.mode!r} requires timing.s={permissions.speed_scale}, got {speed}"
            )

    return {
        "clock_mode": clock_mode,
        "s": speed,
        "environment_advance": permissions.environment_advance,
    }


# ---------------------------------------------------------------------------
# reset 预算与最终解冻结
# ---------------------------------------------------------------------------


class ResetBudgetExceeded(RuntimeError):
    """reset 次数超过模式允许的上限。"""


class ResetGuard:
    """执行层的 reset 计数器。

    harness 开场的 ``runtime.reset()`` 是初始化，不算预算；之后每次探针/探索
    的 reset 都要过这里。standard / real-time 的预算为 0，所以第一次额外
    reset 就会被拒。frozen 五工具本身不暴露 reset，这个类给 Privileged 探索
    沙箱（以及将来显式的 reset 入口）用。
    """

    def __init__(self, permissions: EffectivePermissions) -> None:
        self.permissions = permissions
        self.used = 0

    @property
    def remaining(self) -> int:
        return max(0, self.permissions.reset_budget - self.used)

    _T = TypeVar("_T")

    def reset(self, reset_fn: Callable[[], _T], *, initial: bool = False) -> _T:
        if initial:
            return reset_fn()
        if self.used >= self.permissions.reset_budget:
            raise ResetBudgetExceeded(
                f"mode {self.permissions.mode!r} allows {self.permissions.reset_budget} "
                f"resets after the initial one; already used {self.used}"
            )
        self.used += 1
        return reset_fn()


def freeze_final(payload: Any) -> dict[str, Any]:
    """冻结最终解：只记录内容摘要，之后的干净执行必须按这个摘要加载。"""

    return {"frozen": True, "sha256": canonical_sha256(payload)}


__all__ = [
    "CLOCK_MODES",
    "ENVIRONMENT_ADVANCES",
    "FINAL_EXECUTIONS",
    "EffectivePermissions",
    "MODE_CONFIGS",
    "MODE_NAMES",
    "ModeConfig",
    "ModeError",
    "PERMISSION_KEYS",
    "PRIVILEGED_RESET_BUDGET",
    "REALTIME_SWITCH",
    "ResetBudgetExceeded",
    "ResetGuard",
    "SENSOR_FIELDS",
    "TIMING_KEYS",
    "describe_modes",
    "freeze_final",
    "mode_config",
    "resolve_permissions",
    "resolve_timing",
]
