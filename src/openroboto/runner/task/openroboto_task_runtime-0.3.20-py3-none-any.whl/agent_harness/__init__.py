"""Agent harness: the shell that calls a model, runs tools and records evidence.

Both implementations expose the same contract::

    result = run(spec)          # RunResult, iterable over events
    for event in run(spec): ... # same thing, event stream only

``spec`` is the harness view of EvaluationSpec (see :mod:`agent_harness.spec`).
The harness is chosen by ``harness.name`` — ``headless`` (default) or ``pi``.
An unknown name or a frozen ``agent`` block that does not match this code is
rejected, so a miner cannot swap the harness.

Tool implementations come from the task-source layer: AXIS uses MuJoCo,
RoboDojo uses Isaac Sim. ``run`` only resolves them when the caller does not
inject a runtime, which is what the smoke tool and tests do on machines without
a simulator.
"""

from __future__ import annotations

import logging
from typing import Any, Mapping

from task_source.base import RuntimeUnavailable, TaskSourceError

from .assurance import (
    ASSURANCE_PROFILES,
    AssuranceError,
    AssuranceProfile,
    DEFAULT_ASSURANCE_PROFILE,
    ISOLATED_PROFILE,
    describe_profiles,
    resolve_assurance_profile,
)
from .delivery import DeliveryEvidenceError, SimulatorEvidence, load_simulator_evidence
from .execution import build_delivery_request, episode_status, execute_attempt
from .frames import (
    BackendError,
    EvalBackendClient,
    FrameCollector,
    FrameManifest,
    FrameUploader,
    UploadTarget,
)
from .headless import HeadlessHarness
from .manifest import (
    HARNESS_NAME,
    HARNESS_VERSION,
    agent_binding,
    binding,
    describe,
    harness_commit,
    system_prompt_digest,
)
from .modes import (
    MODE_CONFIGS,
    MODE_NAMES,
    EffectivePermissions,
    ModeConfig,
    ModeError,
    ResetBudgetExceeded,
    ResetGuard,
    describe_modes,
    resolve_permissions,
)
from .pi import PiHarness
from .result import RunResult
from .results import (
    ModeMixError,
    assurance_profile_of,
    board_key,
    ensure_single_mode,
    group_by_board,
    leaderboard_key,
    result_record,
    write_result,
)
from .runtimes import ScenarioToolRuntime, build_tool_runtime
from .sandbox import (
    SandboxError,
    SandboxPlan,
    SandboxUnavailable,
    SandboxedToolRuntime,
    build_sandbox_plan,
    probe_host,
    sanitized_env,
)
from .spec import HarnessSpec, SpecError, build_spec, parse_spec
from .tools import TOOL_NAMES, TOOL_SPECS, ToolRuntime, tools_digest

HARNESSES = {
    "headless": HeadlessHarness,
    "pi": PiHarness,
}


def _check_model_egress(parsed: HarnessSpec, chat_fn: Any) -> None:
    """Under ``isolated`` the only model exit may be the OPE-125 gateway.

    Pi calls the provider itself with a provider key, so it is not allowed at
    this level until it can be pointed at the gateway. An injected chat callable
    is accepted only when it is a bound :class:`ModelGateway.chat` or the
    production :class:`BackendModelGateway.chat` (backend data plane); anything
    else would bypass allow-or-reject and the budget ledger.
    """

    if not parsed.assurance.isolated:
        return
    if parsed.harness_name != "headless":
        raise SpecError(
            f"assurance_profile='isolated' requires the headless harness (gateway model exit); "
            f"harness={parsed.harness_name!r} calls the provider directly"
        )
    if chat_fn is None:
        return
    from agent_eval.backend_gateway import BackendModelGateway
    from agent_eval.gateway import ModelGateway

    if not isinstance(getattr(chat_fn, "__self__", None), (ModelGateway, BackendModelGateway)):
        raise SpecError(
            "assurance_profile='isolated' requires the OPE-125 gateway or the "
            "backend model gateway; an injected chat function would bypass "
            "allow-or-reject and the run budget"
        )


logger = logging.getLogger(__name__)


def run(
    spec: HarnessSpec | Mapping[str, Any],
    *,
    runtime: ToolRuntime | None = None,
    chat_fn: Any = None,
    runner: Any = None,
    runtime_override: str | None = None,
    strict: bool = True,
    signer: Any = None,
    frame_collector: Any = None,
    local_mode: bool = False,
    run_budget: Any = None,
) -> RunResult:
    """Execute one evaluation and return its evidence-bearing result.

    ``runtime`` / ``chat_fn`` / ``runner`` are injection points for tests and
    for the execution layer. In production all three come from the frozen spec
    and the host: the runtime from the task source, ``chat_fn`` from OPE-120,
    the RoboDojo runner from the GPU worker.

    ``signer`` is an optional :class:`agent_evidence.signing.Signer` for the
    executor party. When present, the finished chain is signed and the root /
    single-party bundle are written next to ``evidence.path``.
    """

    parsed = spec if isinstance(spec, HarnessSpec) else parse_spec(spec, strict=strict, local_mode=local_mode)
    harness_class = HARNESSES.get(parsed.harness_name)
    if harness_class is None:
        raise SpecError(f"unknown harness {parsed.harness_name!r}; allowed: {', '.join(sorted(HARNESSES))}")
    _check_model_egress(parsed, chat_fn)
    if run_budget is not None and parsed.harness_name != "headless":
        raise SpecError(f"run_budget is only enforced on the headless gateway; harness={parsed.harness_name!r}")

    owns_runtime = runtime is None
    if runtime is None:
        if parsed.assurance.isolated:
            # OPE-124: tools live in a separate, unprivileged process. A runner
            # callable cannot cross that boundary; rebuilding it inside the
            # worker is the execution layer's job (see docs/agent-harness.md).
            if runner is not None:
                raise SpecError(
                    "assurance_profile='isolated' cannot marshal a runner callable into the sandbox; "
                    "pass a sandbox-loadable runtime instead"
                )
            runtime = SandboxedToolRuntime(
                parsed,
                enforce_os=True,
                runtime_override=runtime_override,
                local_mode=local_mode,
            )
        else:
            runtime = build_tool_runtime(parsed, override=runtime_override, runner=runner, local_mode=local_mode)
    elif parsed.assurance.isolated:
        # An injected runtime would run in the harness process, silently
        # breaking the promise recorded in the spec. There is no flag/marker
        # exception: the operator simulator client must be created **inside**
        # the sandbox worker, not injected here.
        raise SpecError(
            "assurance_profile='isolated' cannot run with an injected runtime; "
            "the sandboxed tool process (and any operator simulator client) "
            "must be created by the harness/worker"
        )
    assert runtime is not None
    try:
        result = harness_class().run(
            parsed,
            runtime,
            chat_fn=chat_fn,
            signer=signer,
            frame_collector=frame_collector,
            **({"run_budget": run_budget} if run_budget is not None else {}),
        )
        if owns_runtime and getattr(runtime, "remote_simulator", False):
            # sandbox worker 内的 operator simulator client 由这里结束：
            # fatal 只 abort，不产出签名根；其他终态 finish 并把原文交给
            # execute_attempt 的交付打包。
            fatal = result.extra.get("fatal_tool_runtime") if isinstance(result.extra, Mapping) else None
            try:
                if fatal:
                    abort = getattr(runtime, "abort_episode", None)
                    if callable(abort):
                        abort(reason=f"fatal:{result.reason}")
                else:
                    finish = getattr(runtime, "finish_episode", None)
                    if callable(finish):
                        evidence = finish()
                        if evidence is not None:
                            result.extra = {
                                **dict(result.extra),
                                "simulator_evidence": evidence,
                            }
            except Exception as exc:  # noqa: BLE001 - successful runs fail closed
                if result.status == "ok":
                    raise
                logger.warning(
                    "[agent-harness] simulator cleanup failed for job=%s attempt=%s: %s",
                    parsed.job_id,
                    parsed.attempt_id,
                    type(exc).__name__,
                )
        return result
    finally:
        if owns_runtime:
            runtime.close()


__all__ = [
    "ASSURANCE_PROFILES",
    "AssuranceError",
    "AssuranceProfile",
    "BackendError",
    "DEFAULT_ASSURANCE_PROFILE",
    "EvalBackendClient",
    "FrameCollector",
    "FrameManifest",
    "FrameUploader",
    "UploadTarget",
    "HARNESSES",
    "HARNESS_NAME",
    "HARNESS_VERSION",
    "ISOLATED_PROFILE",
    "MODE_CONFIGS",
    "MODE_NAMES",
    "EffectivePermissions",
    "ModeConfig",
    "ModeError",
    "ModeMixError",
    "HarnessSpec",
    "assurance_profile_of",
    "PiHarness",
    "HeadlessHarness",
    "ResetBudgetExceeded",
    "ResetGuard",
    "RunResult",
    "RuntimeUnavailable",
    "SandboxError",
    "SandboxPlan",
    "SandboxUnavailable",
    "SandboxedToolRuntime",
    "ScenarioToolRuntime",
    "SpecError",
    "TOOL_NAMES",
    "TOOL_SPECS",
    "TaskSourceError",
    "ToolRuntime",
    "agent_binding",
    "binding",
    "board_key",
    "DeliveryEvidenceError",
    "SimulatorEvidence",
    "build_delivery_request",
    "load_simulator_evidence",
    "build_sandbox_plan",
    "build_spec",
    "build_tool_runtime",
    "describe",
    "describe_modes",
    "describe_profiles",
    "ensure_single_mode",
    "episode_status",
    "execute_attempt",
    "group_by_board",
    "harness_commit",
    "leaderboard_key",
    "parse_spec",
    "probe_host",
    "resolve_assurance_profile",
    "resolve_permissions",
    "result_record",
    "run",
    "sanitized_env",
    "system_prompt_digest",
    "tools_digest",
    "write_result",
]
