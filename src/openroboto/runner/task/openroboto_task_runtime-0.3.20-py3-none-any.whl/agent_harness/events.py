"""Append-only, hash-chained run events (OPE-126 evidence format).

Every model call and **every** tool call goes through this stream. Each event
carries the B-07 fields:

    {"v": 1, "job_id", "attempt_id", "episode", "run_id", "party", "recorder",
     "seq", "nonce", "job_nonce", "ts", "ts_monotonic", "recorded_at",
     "type", "correlation_id"?, "payload", "payload_sha256", "prev", "hash"}

``hash = sha256(prev || canonical(event without hash))``. ``ts`` / ``ts_monotonic``
are monotonic seconds since the stream started, so a wall-clock adjustment
cannot reorder a run. ``recorded_at`` is only an audit anchor.

The same JSONL is verifiable by ``agent_evidence.verify_chain``; signing roots
are produced by :func:`agent_harness.loop.sign_run_evidence`.
"""

from __future__ import annotations

import datetime as _dt
import pathlib
import secrets
import threading
import time
from typing import Any, Callable, Iterable, Mapping

from .canonical import canonical_json, canonical_sha256, sha256_hex

GENESIS = "0" * 64
EVENT_VERSION = 1


def _utcnow() -> _dt.datetime:
    return _dt.datetime.now(_dt.timezone.utc)


def _isoformat(value: Any) -> str:
    if isinstance(value, str):
        return value
    if not isinstance(value, _dt.datetime):
        raise TypeError("wall_clock must return a datetime or ISO-8601 string")
    if value.tzinfo is None:
        value = value.replace(tzinfo=_dt.timezone.utc)
    return value.astimezone(_dt.timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


class EventStream:
    """Collect run events and (optionally) persist them as JSONL."""

    def __init__(
        self,
        *,
        run_id: str | None = None,
        attempt_id: str | None = None,
        episode: int | None = None,
        job_id: str | None = None,
        party: str = "executor",
        recorder: str | None = None,
        job_nonce: str | None = None,
        clock: Any = None,
        wall_clock: Callable[[], Any] | None = None,
        nonce_factory: Callable[[], str] | None = None,
        persist_path: str | pathlib.Path | None = None,
    ) -> None:
        self.run_id = run_id
        self.attempt_id = attempt_id
        self.episode = episode
        self.job_id = job_id or run_id or "local"
        self.party = party or "executor"
        self.recorder = recorder or self.party
        self.job_nonce = job_nonce or secrets.token_hex(16)
        if not isinstance(self.job_id, str) or not self.job_id.strip():
            raise ValueError("job_id must be a non-empty string")
        if not isinstance(self.party, str) or not self.party.strip():
            raise ValueError("party must be a non-empty string")
        if not isinstance(self.job_nonce, str) or not self.job_nonce.strip():
            raise ValueError("job_nonce must be a non-empty string")
        self._clock = clock or time.monotonic
        self._wall_clock = wall_clock or _utcnow
        self._nonce_factory = nonce_factory or (lambda: secrets.token_hex(16))
        self._started = self._clock()
        self._prev = GENESIS
        self._events: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self.persist_path = pathlib.Path(persist_path).expanduser() if persist_path else None
        if self.persist_path is not None:
            self.persist_path.parent.mkdir(parents=True, exist_ok=True)
            self.persist_path.write_text("", encoding="utf-8")

    @property
    def events(self) -> tuple[dict[str, Any], ...]:
        return tuple(self._events)

    @property
    def root(self) -> str:
        return self._prev

    def append(
        self,
        kind: str,
        payload: Mapping[str, Any] | None = None,
        *,
        correlation_id: str | None = None,
    ) -> dict[str, Any]:
        """Add one event; returns the stored record.

        ``correlation_id`` is the cross-party key for the same action
        (``call_id`` for tools, provider ``request_id`` for model calls).
        """

        body_payload = dict(payload or {})
        with self._lock:
            ts = round(self._clock() - self._started, 6)
            event: dict[str, Any] = {
                "v": EVENT_VERSION,
                "seq": len(self._events),
                "type": kind,
                "ts": ts,
                "ts_monotonic": ts,
                "recorded_at": _isoformat(self._wall_clock()),
                "run_id": self.run_id,
                "job_id": self.job_id,
                "attempt_id": self.attempt_id,
                "episode": self.episode,
                "party": self.party,
                "recorder": self.recorder,
                "nonce": self._nonce_factory(),
                "job_nonce": self.job_nonce,
                "prev": self._prev,
                "payload": body_payload,
                "payload_sha256": canonical_sha256(body_payload),
            }
            if correlation_id is not None:
                event["correlation_id"] = str(correlation_id)
            event["hash"] = sha256_hex(self._prev + canonical_json(event))
            self._prev = event["hash"]
            self._events.append(event)
            if self.persist_path is not None:
                with self.persist_path.open("a", encoding="utf-8") as handle:
                    handle.write(canonical_json(event) + "\n")
            return event


def verify_events(events: Iterable[Mapping[str, Any]], *, root: str | None = None) -> tuple[bool, str]:
    """Recompute the chain from genesis. Returns ``(ok, message)``."""

    prev = GENESIS
    count = 0
    for expected_seq, event in enumerate(events):
        count += 1
        if event.get("seq") != expected_seq:
            return False, f"seq mismatch at position {expected_seq}: {event.get('seq')!r}"
        if event.get("prev") != prev:
            return False, f"prev mismatch at seq {expected_seq}"
        payload = event.get("payload") or {}
        if event.get("payload_sha256") != canonical_sha256(payload):
            return False, f"payload hash mismatch at seq {expected_seq}"
        body = {key: value for key, value in event.items() if key != "hash"}
        if event.get("hash") != sha256_hex(prev + canonical_json(body)):
            return False, f"hash mismatch at seq {expected_seq}"
        prev = str(event["hash"])
    if root is not None and prev != root:
        return False, "root mismatch"
    return True, f"ok ({count} events)"


def verify_path(path: str | pathlib.Path, *, root: str | None = None) -> tuple[bool, str]:
    """Verify a JSONL file written by :class:`EventStream`."""

    import json

    events = []
    for line_number, line in enumerate(pathlib.Path(path).read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            events.append(json.loads(line))
        except ValueError as exc:
            return False, f"line {line_number} is not JSON: {exc}"
    return verify_events(events, root=root)


__all__ = ["EVENT_VERSION", "GENESIS", "EventStream", "verify_events", "verify_path"]
