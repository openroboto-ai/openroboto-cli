"""Tool-process worker: the thing that actually runs inside the sandbox.

Started by :class:`agent_harness.sandbox.SandboxedToolRuntime` with a socketpair
on an inherited fd. The protocol is one JSON object per line:

    {"op": "init", "config": {...}}      -> task source + runtime built here
    {"op": "reset"}                      -> {"ok": true, "observation": {...}}
    {"op": "observe"} ...
    {"op": "move_to", "x": ..., ...}
    {"op": "grasp" / "release" / "step"}
    {"op": "success"}                    -> {"ok": true, "success": bool, ...}
    {"op": "close"}                      -> reply, then exit

The worker installs the portable process guard *before* importing any task
source or simulator code, so tool code cannot open outbound sockets, resolve
DNS, spawn processes, signal the harness or read its ``/proc`` entries. On
Linux the launcher also puts it in fresh mount/net/pid namespaces under a
dedicated uid and blocks the ptrace syscall family with seccomp.
"""

from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess  # noqa: F401 - the probe reports whether spawning is blocked
import sys
from typing import Any, Mapping

from .sandbox import install_guards, worker_environment_report
from .spec import build_spec, parse_spec


def _reply(handle: Any, payload: Mapping[str, Any]) -> None:
    handle.write((json.dumps(dict(payload), ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8"))
    handle.flush()


def _error(exc: BaseException) -> dict[str, Any]:
    """Structured error reply: preserve code/fatal/recorded across the IPC.

    ``SimulatorFatalError`` (and any exception carrying ``fatal=True``) must
    reach the parent as fatal; unknown worker errors are fatal by default
    because the execution state can no longer be trusted.
    """

    code = str(getattr(exc, "code", "") or type(exc).__name__)
    detail = str(getattr(exc, "detail", "") or exc)
    return {
        "ok": False,
        "error": f"{type(exc).__name__}: {exc}",
        "error_code": code,
        "detail": detail,
        "fatal": bool(getattr(exc, "fatal", True)),
        "recorded": bool(getattr(exc, "recorded", False)),
    }


def _worker_spec(config: Mapping[str, Any]) -> Any:
    """Build the minimal HarnessSpec the runtime needs, without model config."""

    raw = build_spec(
        source=str(config["source"]),
        task_id=str(config["task_id"]),
        instance=int(config.get("instance") or 0),
        model={"provider": "sandbox", "model": "no-model"},
        mode=str(config.get("mode") or "privileged"),
        max_steps=int(config.get("max_steps") or 200),
        include_binding=False,
    )
    task = raw["task"]
    if config.get("version_digest") is not None:
        task["version_digest"] = str(config["version_digest"])
    if config.get("package_root") is not None:
        task["package_root"] = str(config["package_root"])
    if config.get("instruction") is not None:
        raw["instruction"] = str(config["instruction"])
    if config.get("scenario") is not None:
        raw["scenario"] = config["scenario"]
    if config.get("runtime"):
        raw["runtime"] = {"override": str(config["runtime"])}
    # Internal parent -> child channel: the parent already resolved and
    # verified this directory, and this message is not a miner-supplied spec.
    return parse_spec(raw, strict=False, local_mode=True)


def _observation(runtime: Any) -> dict[str, Any]:
    from .sandbox import _jsonable

    return dict(_jsonable(runtime.observe()))


def _outcome(value: Any) -> dict[str, Any]:
    from .sandbox import _jsonable

    return {
        "ok": True,
        "observation": _jsonable(value.observation),
        "success": bool(value.success),
        "detail": _jsonable(value.detail),
        "steps": int(value.steps),
    }


def _run_worker(fd: int) -> int:
    from .runtimes import build_tool_runtime

    sock = socket.socket(fileno=fd)
    handle = sock.makefile("rwb")
    runtime = None
    try:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
                if not isinstance(request, Mapping):
                    raise ValueError("request must be a JSON object")
                op = str(request.get("op") or "")
                if runtime is None and op != "init":
                    raise RuntimeError("worker is not initialised")
                if op == "init":
                    config = dict(request.get("config") or {})
                    remote = config.get("remote_simulator")
                    if remote is not None:
                        from agent_simulator.client import SimulatorToolRuntime

                        if not isinstance(remote, Mapping):
                            raise ValueError("remote_simulator config must be an object")
                        socket_path = str(remote.get("socket_path") or "")
                        binding = remote.get("binding")
                        if not socket_path or not isinstance(binding, Mapping):
                            raise ValueError("remote_simulator needs socket_path and binding")
                        runtime = SimulatorToolRuntime.connect_from_binding(
                            dict(binding),
                            socket_path=socket_path,
                            timeout=float(remote.get("timeout") or 600.0),
                            run_id=remote.get("run_id"),
                        )
                        source = str(getattr(runtime, "source", "") or "")
                        instruction = str(getattr(runtime, "instruction", "") or "")
                    else:
                        spec = _worker_spec(config)
                        runtime = build_tool_runtime(spec, local_mode=True)
                        source = spec.source
                        instruction = runtime.instruction
                    _reply(
                        handle,
                        {
                            "ok": True,
                            "source": source,
                            "instruction": instruction,
                            "guards": dict(_GUARDS),
                        },
                    )
                elif op == "reset":
                    from .sandbox import _jsonable

                    _reply(handle, {"ok": True, "observation": _jsonable(runtime.reset())})
                elif op == "observe":
                    _reply(handle, {"ok": True, "observation": _observation(runtime)})
                elif op == "move_to":
                    _reply(
                        handle,
                        _outcome(
                            runtime.move_to(
                                float(request["x"]),
                                float(request["y"]),
                                float(request["z"]),
                                float(request["gripper"]),
                                int(request.get("steps", 10)),
                                float(request.get("yaw", 0.0)),
                            )
                        ),
                    )
                elif op == "grasp":
                    _reply(handle, _outcome(runtime.grasp(int(request.get("steps", 5)))))
                elif op == "release":
                    _reply(handle, _outcome(runtime.release(int(request.get("steps", 5)))))
                elif op == "step":
                    _reply(
                        handle,
                        _outcome(runtime.step(request["action"], int(request.get("steps", 1)))),
                    )
                elif op == "call":
                    correlation_id = request.get("correlation_id")
                    if not isinstance(correlation_id, str) or not correlation_id:
                        raise ValueError("call requires a non-empty correlation_id")
                    name = request.get("name")
                    if not isinstance(name, str) or not name:
                        raise ValueError("call requires a tool name")
                    args = request.get("args")
                    if args is None:
                        args = {}
                    if not isinstance(args, Mapping):
                        raise ValueError("call args must be an object")
                    _reply(
                        handle,
                        _outcome(runtime.call(correlation_id, name, dict(args))),
                    )
                elif op == "finish_episode":
                    _reply(handle, {"ok": True, "evidence": runtime.finish_episode()})
                elif op == "abort_episode":
                    runtime.abort_episode(reason=str(request.get("reason") or ""))
                    _reply(handle, {"ok": True})
                elif op == "success":
                    ok, detail = runtime.success()
                    from .sandbox import _jsonable

                    _reply(handle, {"ok": True, "success": bool(ok), "detail": _jsonable(detail)})
                elif op == "sim_time_s":
                    # OPE-198：仿真时钟在隔离进程里，读数必须回传；没有就返回 null。
                    reader = getattr(runtime, "sim_time_s", None)
                    _reply(handle, {"ok": True, "sim_time_s": reader() if callable(reader) else None})
                elif op == "close":
                    _reply(handle, {"ok": True})
                    break
                else:
                    raise ValueError(f"unknown op {op!r}")
            except Exception as exc:  # noqa: BLE001 - report the failure to the harness
                _reply(handle, _error(exc))
    except (BrokenPipeError, ConnectionResetError):
        return 0
    finally:
        if runtime is not None:
            try:
                runtime.close()
            except Exception:  # noqa: BLE001 - teardown is best effort
                pass
        try:
            handle.close()
        except Exception:  # noqa: BLE001
            pass
    return 0


def _probe() -> int:
    report: dict[str, Any] = {"guards": dict(_GUARDS), **worker_environment_report()}

    try:
        socket.create_connection(("127.0.0.1", 9), timeout=1)
    except PermissionError as exc:
        report["network"] = {"blocked": True, "error": str(exc)}
    except OSError as exc:
        report["network"] = {"blocked": False, "error": f"{type(exc).__name__}: {exc}"}
    else:
        report["network"] = {"blocked": False, "error": None}

    try:
        socket.getaddrinfo("example.com", 443)
    except PermissionError as exc:
        report["dns"] = {"blocked": True, "error": str(exc)}
    except OSError as exc:
        report["dns"] = {"blocked": False, "error": f"{type(exc).__name__}: {exc}"}
    else:
        report["dns"] = {"blocked": False, "error": None}

    try:
        subprocess.run([sys.executable, "-c", "pass"], check=False, timeout=10)
    except PermissionError as exc:
        report["spawn"] = {"blocked": True, "error": str(exc)}
    except OSError as exc:
        report["spawn"] = {"blocked": False, "error": f"{type(exc).__name__}: {exc}"}
    else:
        report["spawn"] = {"blocked": False, "error": None}

    parent_environ = f"/proc/{os.getppid()}/environ"
    try:
        with open(parent_environ, "rb"):
            pass
    except PermissionError as exc:
        report["parent_proc"] = {"blocked": True, "error": str(exc)}
    except OSError as exc:
        report["parent_proc"] = {"blocked": False, "error": f"{type(exc).__name__}: {exc}"}
    else:
        report["parent_proc"] = {"blocked": False, "error": None}

    try:
        from agent_eval.spec import from_evaluation_spec

        model = from_evaluation_spec({"model": {"provider": "anthropic", "model": "claude-opus-5-5"}})
        model.require_api_key()
    except Exception as exc:  # noqa: BLE001 - any failure means no usable provider call
        report["provider"] = {"usable": False, "error": f"{type(exc).__name__}: {exc}"}
    else:
        report["provider"] = {"usable": True, "error": None}

    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    return 0


_GUARDS: dict[str, Any] = {}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="agent_harness.sandbox_worker")
    parser.add_argument("--fd", type=int, default=None, help="inherited socketpair fd")
    parser.add_argument("--guard", action="store_true", help="install the portable process guard")
    parser.add_argument("--probe", action="store_true", help="run sandbox self-checks and print JSON")
    args = parser.parse_args(argv)

    if args.guard:
        _GUARDS.update(install_guards())
    if args.probe:
        return _probe()
    if args.fd is None:
        parser.error("--fd is required unless --probe is used")
    return _run_worker(args.fd)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
