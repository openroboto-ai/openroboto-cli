"""Frozen harness identity: version, code digest, prompt digest, tool digest.

These three values are what ``EvaluationSpec.agent`` carries:

    agent.harness_commit     40 hex, identity of the harness code
    agent.system_prompt_digest  sha256 of the exact system prompt
    agent.tools_digest          sha256 of the canonical tool manifest

A miner cannot supply its own values: :func:`agent_harness.run` compares the
spec against what this process actually loaded and rejects a mismatch.

``harness_commit`` is a *content* digest, not necessarily a git sha. Deployment
sets ``AGENT_HARNESS_COMMIT`` to the 40-char git sha of the image build so the
spec is traceable to a commit; locally we derive a deterministic 40-hex value
from the source files. Both are 40 lowercase hex, which is what the backend
validator enforces.
"""

from __future__ import annotations

import os
import pathlib
import re

from .canonical import canonical_sha256, sha256_hex
from .prompts import system_prompt
from .tools import tools_digest

HARNESS_NAME = "agent-harness"
HARNESS_VERSION = "1"

GIT_SHA_RE = re.compile(r"\A[0-9a-f]{40}\Z")
_COMMIT_ENV = "AGENT_HARNESS_COMMIT"

_PACKAGE_DIR = pathlib.Path(__file__).resolve().parent


#: Everything that can change agent behaviour. The Pi extension is included so
#: a changed tool bridge is a different harness commit, not just code drift.
_HARNESS_SUFFIXES = {".py", ".ts", ".json"}


def harness_files() -> dict[str, str]:
    """Map harness sources/assets -> sha256, sorted by relative path."""

    files: dict[str, str] = {}
    for path in sorted(_PACKAGE_DIR.rglob("*")):
        if not path.is_file() or path.suffix not in _HARNESS_SUFFIXES:
            continue
        if "__pycache__" in path.parts:
            continue
        files[path.relative_to(_PACKAGE_DIR).as_posix()] = sha256_hex(path.read_text(encoding="utf-8"))
    return files


def harness_code_digest() -> str:
    """Deterministic 40-hex identity of the harness source."""

    return canonical_sha256({"name": HARNESS_NAME, "files": harness_files()})[:40]


def harness_commit() -> str:
    """Deployment git sha when set, otherwise the content digest."""

    override = os.environ.get(_COMMIT_ENV, "").strip().lower()
    if override:
        if not GIT_SHA_RE.match(override):
            raise ValueError(f"{_COMMIT_ENV} must be a 40-char lowercase git sha, got {override!r}")
        return override
    return harness_code_digest()


def system_prompt_digest() -> str:
    return sha256_hex(system_prompt())


def agent_binding() -> dict[str, str]:
    """The block that goes into ``EvaluationSpec.agent``."""

    return {
        "harness_commit": harness_commit(),
        "system_prompt_digest": system_prompt_digest(),
        "tools_digest": tools_digest(),
    }


def binding() -> dict[str, object]:
    """Everything the execution layer needs to freeze for a run."""

    return {
        "agent": agent_binding(),
        "harness": {"name": HARNESS_NAME, "version": HARNESS_VERSION},
    }


def verify_agent_binding(agent: object) -> list[str]:
    """Return human-readable mismatches; empty means the spec matches this code."""

    if not isinstance(agent, dict):
        return ["agent block is missing; freeze EvaluationSpec.agent first"]
    expected = agent_binding()
    problems = []
    for field, value in expected.items():
        actual = str(agent.get(field) or "").lower()
        if actual != value:
            problems.append(f"agent.{field}={agent.get(field)!r} does not match this harness ({value})")
    return problems


def describe() -> dict[str, object]:
    return {
        "name": HARNESS_NAME,
        "version": HARNESS_VERSION,
        "commit": harness_commit(),
        "code_digest": harness_code_digest(),
        "system_prompt_digest": system_prompt_digest(),
        "tools_digest": tools_digest(),
        "files": harness_files(),
    }


__all__ = [
    "HARNESS_NAME",
    "HARNESS_VERSION",
    "agent_binding",
    "binding",
    "describe",
    "harness_code_digest",
    "harness_commit",
    "harness_files",
    "system_prompt_digest",
    "verify_agent_binding",
]
