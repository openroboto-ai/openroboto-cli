"""Canonical JSON and hashing helpers shared by harness, tools and evidence."""

from __future__ import annotations

import hashlib
import json
from typing import Any


def canonical_json(value: Any) -> str:
    """Stable JSON: sorted keys, compact separators, UTF-8, no NaN.

    ``allow_nan=False`` matters for evidence: NaN has no portable JSON spelling
    and two implementations would hash it differently.
    """

    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True, allow_nan=False)


def sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical_sha256(value: Any) -> str:
    return sha256_hex(canonical_json(value))


__all__ = ["canonical_json", "canonical_sha256", "sha256_hex"]
