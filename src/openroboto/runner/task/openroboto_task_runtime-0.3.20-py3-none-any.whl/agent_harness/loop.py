"""Shared loop pieces used by the headless and Pi harnesses.

Keeping tool execution and message construction here means both harness
implementations produce the same evidence and the same model-visible data.
"""

from __future__ import annotations

import json
import pathlib
from typing import Any, Mapping

from .canonical import canonical_sha256
from .events import EventStream
from .frames import evidence_only_observation
from .prompts import system_prompt
from .spec import HarnessSpec
from .tools import ToolOutcome, ToolRuntime, execute_tool, filter_observation, tool_manifest, tools_digest

ChatFn = Any


class FatalToolRuntimeError(RuntimeError):
    """工具执行方要求立即终止整次 attempt（绑定/预算/协议/传输失败）。

    与工具级拒绝不同：后者写成 ``tool_result.ok=false`` 后可以继续给模型
    看；fatal 不能再发起同批工具或后续 model 调用，否则会在协议/绑定失败后
    继续消耗模型预算，违背 OPE-203/204 的终止契约。
    """

    def __init__(self, code: str, detail: str, *, recorded: bool = False) -> None:
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail
        self.recorded = recorded


def default_chat(messages: list[dict], tools: list[dict], model_spec: Any, **kwargs: Any) -> dict:
    """Call the OPE-120 provider layer with the frozen tool manifest."""

    from agent_eval import chat as provider_chat

    return provider_chat(messages, tools, model_spec, **kwargs)


def model_messages(observation: Mapping[str, Any], instruction: str) -> list[dict]:
    """Initial user message: goal + visible observation + optional image."""

    text, image = observation_text(observation, instruction)
    content: list[dict] = [{"type": "text", "text": text}]
    if image is not None:
        content.append(image_block(image))
    return [{"role": "system", "content": system_prompt()}, {"role": "user", "content": content}]


def observation_text(observation: Mapping[str, Any], instruction: str) -> tuple[str, Mapping[str, Any] | None]:
    """Split an observation into text (no base64) and an optional image."""

    visible = dict(observation)
    image = visible.pop("image", None)
    header = f"Goal: {instruction}\n" if instruction else ""
    return header + "Observation:\n" + json.dumps(visible, ensure_ascii=False, sort_keys=True), image


def image_block(image: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "type": "image",
        "source": {
            "type": "base64",
            "media_type": str(image.get("mime_type") or "image/png"),
            "data": str(image.get("data_base64") or ""),
        },
    }


def assistant_message(
    content: str,
    tool_calls: list[Mapping[str, Any]],
    *,
    reasoning_content: str | None = None,
) -> dict[str, Any]:
    blocks: list[dict[str, Any]] = []
    if content:
        blocks.append({"type": "text", "text": content})
    for call in tool_calls:
        raw_args = call.get("args", call.get("arguments", {}))
        blocks.append({
            "type": "tool_use",
            "id": str(call.get("id") or ""),
            "name": str(call.get("name") or ""),
            "input": dict(raw_args) if isinstance(raw_args, Mapping) else raw_args,
        })
    message: dict[str, Any] = {"role": "assistant", "content": blocks}
    if reasoning_content is not None:
        message["reasoning_content"] = reasoning_content
    return message


def tool_result_messages(results: list[tuple[str, Mapping[str, Any]]]) -> list[dict]:
    """One user message with all tool results, then one with their images."""

    blocks: list[dict[str, Any]] = []
    images: list[dict[str, Any]] = []
    for call_id, observation in results:
        text, image = observation_text(observation, "")
        blocks.append({"type": "tool_result", "tool_use_id": call_id, "content": text.strip()})
        if image is not None:
            images.append(image_block(image))
    messages: list[dict] = [{"role": "user", "content": blocks}]
    if images:
        messages.append({"role": "user", "content": images})
    return messages


def record_tool(
    stream: EventStream,
    runtime: ToolRuntime,
    spec: HarnessSpec,
    *,
    call_id: str,
    name: str,
    args: Any,
    prior_observation_sha256: str | None,
    frame_collector: Any = None,
) -> tuple[ToolOutcome | None, Mapping[str, Any] | None, str | None]:
    """Execute one tool call and put both call and result in the evidence chain.

    Failures are evidence too: an unknown tool or a bad argument is recorded
    with ``ok=false`` and then returned to the model instead of crashing the run.
    Non-object arguments are recorded as rejected and stop the attempt before dispatch.
    """

    if not isinstance(args, Mapping):
        stream.append(
            "tool_rejected",
            {
                "call_id": call_id,
                "name": name,
                "args": args,
                "args_sha256": canonical_sha256(args),
                "code": "invalid_tool_arguments",
            },
            correlation_id=call_id,
        )
        raise FatalToolRuntimeError("invalid_tool_arguments", "tool arguments must be an object", recorded=True)

    stream.append(
        "tool_call",
        {
            "call_id": call_id,
            "name": name,
            "args": dict(args),
            "args_sha256": canonical_sha256(dict(args)),
            "manifest_digest": tools_digest(),
            "prior_observation_sha256": prior_observation_sha256,
        },
        correlation_id=call_id,
    )
    error: str | None = None
    outcome: ToolOutcome | None = None
    fatal: FatalToolRuntimeError | None = None
    remote = getattr(runtime, "call", None)
    try:
        if callable(remote):
            # OPE-203: 独立 simulator 客户端要把同一个 correlation_id 和
            # **原始 args** 写进它自己的链。不能经 execute_tool 展开补默认值，
            # 否则 simulator 的 args_sha256 与这里记录的摘要对不上。
            if not isinstance(call_id, str) or not call_id:
                raise ValueError("remote tool runtime requires a non-empty call_id")
            outcome = remote(call_id, name, dict(args))
        else:
            outcome = execute_tool(runtime, name, args)
    except Exception as exc:  # noqa: BLE001 - every tool failure is evidence
        error = f"{type(exc).__name__}: {exc}"
        if bool(getattr(exc, "fatal", False)):
            fatal = FatalToolRuntimeError(
                str(getattr(exc, "code", "") or type(exc).__name__),
                str(getattr(exc, "detail", "") or exc),
                recorded=bool(getattr(exc, "recorded", False)),
            )

    if outcome is not None:
        visible = filter_observation(outcome.observation, spec.sensors)
        success = bool(outcome.success)
        steps = int(outcome.steps)
        # Observe returns a bare ToolOutcome. Retain its raw checker detail in
        # the audit chain while filter_observation keeps it out of model input.
        detail = dict(outcome.detail or outcome.observation.get("detail") or {})
    else:
        visible = None
        success = False
        steps = 0
        detail = {}

    evidence = evidence_observation(visible)
    event = stream.append(
        "tool_result",
        {
            "call_id": call_id,
            "name": name,
            "ok": error is None,
            "error": error,
            "success": success,
            "steps": steps,
            "detail": detail,
            "observation": evidence,
            "observation_sha256": canonical_sha256(evidence) if evidence is not None else None,
            **({"fatal": True, "error_code": fatal.code, "recorded": fatal.recorded} if fatal is not None else {}),
        },
        correlation_id=call_id,
    )
    if frame_collector is not None and visible is not None:
        # 事件链只留 sha256/bytes；原始字节在这里还活着，交给上传器。
        # seq 必须取**这一个**事件的序号，交付回报才能和链上逐字对上。
        frame_collector.capture(
            visible,
            seq=int(event["seq"]),
            episode=int(spec.episode or 0),
        )
        record_evidence_frame(
            stream,
            spec,
            outcome.observation if outcome is not None else None,
            frame_collector=frame_collector,
            correlation_id=call_id,
        )
    if fatal is not None:
        # 先把 fatal 的 tool_call/tool_result 留在 executor 链上，再终止整次
        # attempt；调用方（headless/Pi）不得继续同批工具或后续 model 调用。
        raise fatal
    return outcome, visible, error


def record_evidence_frame(
    stream: EventStream,
    spec: HarnessSpec,
    raw_observation: Mapping[str, Any] | None,
    *,
    frame_collector: Any,
    correlation_id: str,
) -> None:
    """Sign a separate evidence-only frame without changing the visible view/hash."""
    if frame_collector is None or "image" in spec.sensors:
        return
    raw_frame = evidence_only_observation(raw_observation, spec.raw, spec.job_digest)
    if raw_frame is None:
        return
    evidence = evidence_observation(raw_frame)
    event = stream.append(
        "observation",
        {"evidence_only": True, "observation": evidence, "observation_sha256": canonical_sha256(evidence)},
        correlation_id=correlation_id,
    )
    frame_collector.capture(raw_frame, seq=int(event["seq"]), episode=int(spec.episode or 0))


def tool_manifest_for_model() -> list[dict]:
    return tool_manifest()


def evidence_observation(observation: Mapping[str, Any] | None) -> dict[str, Any] | None:
    """Replace inline image bytes with their hash so the chain stays compact."""

    if observation is None:
        return None
    payload = dict(observation)
    image = payload.get("image")
    if isinstance(image, Mapping):
        payload["image"] = {
            "mime_type": image.get("mime_type"),
            "sha256": image.get("sha256"),
            "bytes": image.get("bytes"),
        }
    return payload


def current_success(runtime: ToolRuntime) -> tuple[bool, Mapping[str, Any]]:
    try:
        return runtime.success()
    except Exception as exc:  # noqa: BLE001
        return False, {"error": f"{type(exc).__name__}: {exc}"}


def sign_run_evidence(result: Any, stream: EventStream, spec: HarnessSpec, signer: Any) -> None:
    """Sign the finished chain and attach the signing summary to ``result``.

    This is the OPE-126 emit point: every harness (headless / Pi) goes through
    the same ``EventStream`` and the same ``record_tool``, so signing here
    covers all model and tool events without duplicating per-harness code.

    - no signer: the chain stays valid but is marked ``signed=false``;
    - ``single``: write ``<evidence>.root.json`` and ``<evidence>.bundle.json``
      (one executor root; ``verify_bundle`` passes with a testnet warning);
    - ``three_party``: write only the executor root; the execution layer
      collects gateway / simulator roots and assembles the bundle.
    """

    from agent_evidence.signing import Signer, build_bundle, sign_root

    signing: dict[str, Any] = {
        "signed": False,
        "mode": spec.signing_mode,
        "party": spec.party,
        "job_id": spec.job_id,
        "job_nonce": spec.job_nonce,
        "job_digest": spec.job_digest,
        "root_path": None,
        "bundle_path": None,
    }
    if signer is None:
        result.extra = {**dict(result.extra), "signing": signing}
        return
    if not isinstance(signer, Signer):
        raise TypeError("signer must be an agent_evidence.signing.Signer")
    if signer.party != spec.party:
        raise ValueError(f"signer party {signer.party!r} != harness party {spec.party!r}")

    root = sign_root(
        stream.events,
        signer,
        job_digest=spec.job_digest,
        attempt_id=spec.attempt_id or spec.run_id or "local",
        episode=spec.episode,
        run_id=spec.run_id or None,
    )
    signing.update({
        "signed": True,
        "key_id": signer.key_id,
        "root": root["root"],
        "root_record": root,
    })
    if spec.evidence_path:
        root_path = pathlib.Path(spec.evidence_path + ".root.json")
        root_path.write_text(json.dumps(root, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        signing["root_path"] = str(root_path)

    if spec.signing_mode == "single":
        bundle = build_bundle([root], mode="single")
        if spec.evidence_path:
            bundle_path = pathlib.Path(spec.evidence_path + ".bundle.json")
            bundle_path.write_text(json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            signing["bundle_path"] = str(bundle_path)
        else:
            signing["bundle"] = bundle

    result.extra = {**dict(result.extra), "signing": signing}


__all__ = [
    "ChatFn",
    "FatalToolRuntimeError",
    "assistant_message",
    "current_success",
    "default_chat",
    "evidence_observation",
    "image_block",
    "model_messages",
    "observation_text",
    "record_tool",
    "sign_run_evidence",
    "tool_manifest_for_model",
    "tool_result_messages",
]
