"""评测帧：在字节还在手里时采集、直传预签名地址，并回报成功的那些。

后端契约以 OPE-148 为准：

- ``POST /api/v1/eval/jobs/{job_id}/attempts/{attempt_no}/frames/presign``
  返回 ``url`` 和必须原样带上的 ``headers``（``Content-Type`` / ``Content-MD5``）；
- 字节不经过 API：执行层直接 PUT 到对象存储；
- 交付请求里每个 episode 带 ``frame_uploads: [{seq, sha256}]``，**只回报真的
  PUT 成功的帧**。上传失败不让交付失败 —— 帧是展示证据，钱路径只看事件链
  和签名（后端会把回报与事件链逐字比对，对不上的按 ``missing``）。

## 为什么在 ``evidence_observation()`` 之前采集

事件链里只留 ``{mime_type, sha256, bytes}``，base64 字节在写事件前就被丢掉。
帧上传需要原始字节，所以采集点必须和写事件的点重合：``record_tool`` /
headless 的开局观察在把观察交给 ``evidence_observation()`` 时，顺手把 image
的 ``data_base64`` 解出来交给 :class:`FrameCollector`。事件 ``seq`` 就是上传
回报里的 ``seq``，两者必须来自同一个事件。

## 失败语义

- presign 一批失败：这一批全部跳过，继续下一批；
- 单帧 PUT 失败：只跳过这一帧；
- 后端返回的 target 与请求的 ``(episode, seq, sha256)`` 对不上：跳过，不猜；
- 采集时声明 sha256 与实际字节不一致：跳过并告警（否则 URL 取回的字节和
  事件链对不上）。

:meth:`FrameCollector.upload` 只返回成功的帧；交付请求据此组装
``frame_uploads``。
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import threading
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence


EVIDENCE_FRAME_FIELD = "_evidence_frame"


def frozen_frames_required(raw_spec: Mapping[str, Any]) -> bool:
    """Only an explicit frozen evidence.frames policy authorizes hidden frames.

    allowed_sensors controls the agent's view, not this independent trusted
    delivery channel. Missing policy is never inferred from a collector object.
    """
    evidence = raw_spec.get("evidence")
    frames = evidence.get("frames") if isinstance(evidence, Mapping) else None
    minimum = frames.get("min_frames") if isinstance(frames, Mapping) else None
    return isinstance(minimum, int) and not isinstance(minimum, bool) and minimum >= 1


def evidence_only_observation(
    observation: Mapping[str, Any] | None, raw_spec: Mapping[str, Any], job_digest: str,
) -> dict[str, Any] | None:
    """A raw image for trusted evidence only; never a model/tool response view."""
    if not isinstance(observation, Mapping):
        return None
    channel = observation.get(EVIDENCE_FRAME_FIELD)
    if isinstance(channel, Mapping):
        # The simulator checked its operator-managed frozen policy. /spec omits
        # that policy, so the authenticated runtime forwards this private channel.
        if channel.get("job_digest") != job_digest:
            raise ValueError("evidence frame belongs to a different frozen job")
        image = channel.get("image")
    elif frozen_frames_required(raw_spec):
        image = observation.get("image")
    else:
        return None
    return {"image": dict(image)} if isinstance(image, Mapping) else None

logger = logging.getLogger(__name__)

#: 与后端 ``eval_evidence._MAX_FRAMES`` 同值。一批超过它会被整批拒绝，
#: 所以按 episode 分组之后再切块。
PRESIGN_BATCH_SIZE = 1000


@dataclass(frozen=True, slots=True)
class FrameManifest:
    """一帧的登记值 + 原始字节。``data`` 只在内存里，从不进事件链。"""

    episode: int
    seq: int
    sha256: str
    mime_type: str | None
    data: bytes

    @property
    def bytes_len(self) -> int:
        return len(self.data)

    @property
    def md5_b64(self) -> str:
        return base64.b64encode(hashlib.md5(self.data).digest()).decode("ascii")

    def presign_payload(self) -> dict[str, Any]:
        """后端 presign 端点要的登记值。**不含对象键**（键由后端算）。"""

        return {
            "episode": self.episode,
            "seq": self.seq,
            "sha256": self.sha256,
            "mime_type": self.mime_type,
            "bytes_len": self.bytes_len,
            "md5_b64": self.md5_b64,
        }


@dataclass(frozen=True, slots=True)
class UploadTarget:
    """后端签出来的一个上传目标。``headers`` 必须原样带回。"""

    episode: int
    seq: int
    sha256: str
    url: str
    headers: Mapping[str, str]


class FrameUploader(Protocol):
    """上传通道。生产实现是 :class:`EvalBackendClient`；测试可以注入替身。"""

    def presign_frames(
        self, *, job_id: str, attempt_no: int, frames: Sequence[FrameManifest]
    ) -> Sequence[UploadTarget]:
        ...

    def put_frame(self, target: UploadTarget, frame: FrameManifest) -> None:
        ...


class FrameCollector:
    """收集一次 harness run 的帧字节，按事件 ``seq`` 对齐。

    一个 collector 对应一次 run（一个 episode）。``episode`` 也可以显式传给
    :meth:`capture`，方便调用方一次跑多个 episode 时复用同一个对象。
    """

    def __init__(self) -> None:
        self._frames: dict[tuple[int, int], FrameManifest] = {}
        self._lock = threading.Lock()

    def capture(
        self,
        observation: Mapping[str, Any] | None,
        *,
        seq: int,
        episode: int = 0,
    ) -> FrameManifest | None:
        """从原始观察里截下图像字节；``seq`` 是该观察所在事件的序号。"""

        if not isinstance(observation, Mapping):
            return None
        image = observation.get("image")
        if not isinstance(image, Mapping):
            return None
        encoded = image.get("data_base64")
        if not isinstance(encoded, str) or not encoded:
            return None
        try:
            data = base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError):
            logger.warning("[eval-frames] episode=%s seq=%s 的 image.data_base64 解不开，跳过", episode, seq)
            return None
        declared = image.get("sha256")
        actual = hashlib.sha256(data).hexdigest()
        if declared != actual:
            logger.warning(
                "[eval-frames] episode=%s seq=%s 声明 sha256=%s 与实际字节 %s 不一致，"
                "跳过（不上传一份对不上事件链的帧）",
                episode,
                seq,
                declared,
                actual,
            )
            return None
        mime_type = image.get("mime_type")
        frame = FrameManifest(
            episode=int(episode),
            seq=int(seq),
            sha256=actual,
            mime_type=str(mime_type) if mime_type else None,
            data=data,
        )
        with self._lock:
            self._frames[(frame.episode, frame.seq)] = frame
        return frame

    @property
    def frames(self) -> tuple[FrameManifest, ...]:
        with self._lock:
            return tuple(sorted(self._frames.values(), key=lambda frame: (frame.episode, frame.seq)))

    def upload(
        self,
        uploader: FrameUploader,
        *,
        job_id: str,
        attempt_no: int,
    ) -> tuple[FrameManifest, ...]:
        """按 episode 分批调 presign、逐帧 PUT，返回实际成功的帧。

        **任何上传失败都在这里被吃掉**：调用方拿到的是「能交付的帧」，不是
        异常。交付路径不能让对象存储的短暂故障决定一次评测的成败。
        """

        grouped: dict[int, list[FrameManifest]] = {}
        for frame in self.frames:
            grouped.setdefault(frame.episode, []).append(frame)

        uploaded: list[FrameManifest] = []
        for episode in sorted(grouped):
            frames = grouped[episode]
            for start in range(0, len(frames), PRESIGN_BATCH_SIZE):
                batch = frames[start : start + PRESIGN_BATCH_SIZE]
                try:
                    targets = uploader.presign_frames(
                        job_id=job_id,
                        attempt_no=attempt_no,
                        frames=batch,
                    )
                except Exception:  # noqa: BLE001 - 上传失败不让交付失败
                    logger.warning(
                        "[eval-frames] job=%s attempt=%s episode=%s 的 %d 帧签不出上传地址，按 missing 处理",
                        job_id,
                        attempt_no,
                        episode,
                        len(batch),
                        exc_info=True,
                    )
                    continue

                by_slot = {
                    (target.episode, target.seq, target.sha256): target
                    for target in targets
                }
                for frame in batch:
                    target = by_slot.get((frame.episode, frame.seq, frame.sha256))
                    if target is None:
                        logger.warning(
                            "[eval-frames] job=%s attempt=%s episode=%s seq=%s 没有对应的上传目标，跳过",
                            job_id,
                            attempt_no,
                            frame.episode,
                            frame.seq,
                        )
                        continue
                    try:
                        uploader.put_frame(target, frame)
                    except Exception:  # noqa: BLE001 - 单帧失败只丢这一帧
                        logger.warning(
                            "[eval-frames] job=%s attempt=%s episode=%s seq=%s（%d 字节）PUT 失败，按 missing 处理",
                            job_id,
                            attempt_no,
                            frame.episode,
                            frame.seq,
                            frame.bytes_len,
                            exc_info=True,
                        )
                        continue
                    uploaded.append(frame)
        return tuple(sorted(uploaded, key=lambda frame: (frame.episode, frame.seq)))


class BackendError(RuntimeError):
    """后端返回了错误信封，或者 HTTP 状态不是 2xx。"""

    def __init__(self, message: str, *, status_code: int | None = None, code: str | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code

    @property
    def claimed_elsewhere(self) -> bool:
        """attempt 已被另一个 ``runner_id`` 持有（409 ``EVAL_ATTEMPT_CLAIMED``）。"""

        return self.status_code == 409 and self.code == "EVAL_ATTEMPT_CLAIMED"


class EvalBackendClient:
    """最小执行层客户端：presign + PUT + 交付。

    只用标准库（这个仓的核心依赖仍然是 stdlib-only）。``api_key`` 由部署
    环境注入，**不进事件链、不写日志**。
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        hotkey: str,
        *,
        timeout_s: float = 60.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.hotkey = hotkey
        self.timeout_s = timeout_s

    # -- HTTP -------------------------------------------------------------
    def _post(self, path: str, payload: Mapping[str, Any]) -> Any:
        body = json.dumps(dict(payload), ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            data=body,
            headers={"Content-Type": "application/json", "X-API-Key": self.api_key},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_s) as response:
                status = int(getattr(response, "status", 0) or 0)
                raw = response.read()
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            code = None
            message = raw.decode("utf-8", "replace")[:500]
            try:
                envelope = json.loads(raw)
            except ValueError:
                envelope = None
            if isinstance(envelope, Mapping):
                error = envelope.get("error")
                if isinstance(error, Mapping):
                    code = str(error.get("code") or "") or None
                    message = str(error.get("message") or message)
            raise BackendError(message, status_code=exc.code, code=code) from exc
        if not 200 <= status < 300:
            raise BackendError(f"HTTP {status}", status_code=status)
        data = json.loads(raw or b"{}")
        if isinstance(data, Mapping) and "error" in data:
            error = data.get("error")
            if isinstance(error, Mapping):
                raise BackendError(
                    str(error.get("message") or "backend error"),
                    code=str(error.get("code") or "") or None,
                )
        if isinstance(data, Mapping) and "data" in data:
            return data["data"]
        return data

    # -- frames -----------------------------------------------------------
    @staticmethod
    def _attempt_path(job_id: str, attempt_no: int, suffix: str) -> str:
        job = urllib.parse.quote(str(job_id), safe="")
        return f"/api/v1/eval/jobs/{job}/attempts/{int(attempt_no)}{suffix}"

    def presign_frames(
        self,
        *,
        job_id: str,
        attempt_no: int,
        frames: Sequence[FrameManifest],
    ) -> Sequence[UploadTarget]:
        data = self._post(
            self._attempt_path(job_id, attempt_no, "/frames/presign"),
            {
                "hotkey": self.hotkey,
                "frames": [frame.presign_payload() for frame in frames],
            },
        )
        targets: list[UploadTarget] = []
        for item in data.get("frames", []) if isinstance(data, Mapping) else []:
            targets.append(
                UploadTarget(
                    episode=int(item["episode"]),
                    seq=int(item["seq"]),
                    sha256=str(item["sha256"]),
                    url=str(item["url"]),
                    headers={str(key): str(value) for key, value in (item.get("headers") or {}).items()},
                )
            )
        return tuple(targets)

    def put_frame(self, target: UploadTarget, frame: FrameManifest) -> None:
        request = urllib.request.Request(
            target.url,
            data=frame.data,
            headers=dict(target.headers),
            method="PUT",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_s) as response:
                status = int(getattr(response, "status", 0) or 0)
                response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")[:300]
            raise BackendError(
                f"PUT 帧失败: HTTP {exc.code} {detail}", status_code=exc.code
            ) from exc
        if not 200 <= status < 300:
            raise BackendError(f"PUT 帧失败: HTTP {status}", status_code=status)

    # -- delivery ---------------------------------------------------------
    def deliver_attempt(
        self,
        *,
        job_id: str,
        attempt_no: int,
        payload: Mapping[str, Any],
    ) -> Any:
        return self._post(self._attempt_path(job_id, attempt_no, "/result"), payload)


__all__ = [
    "PRESIGN_BATCH_SIZE",
    "BackendError",
    "EvalBackendClient",
    "FrameCollector",
    "FrameManifest",
    "FrameUploader",
    "UploadTarget",
]
