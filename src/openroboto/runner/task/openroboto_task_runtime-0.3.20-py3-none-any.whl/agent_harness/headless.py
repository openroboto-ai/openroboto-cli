"""The headless tool-use loop.

This is the main test-net harness: one model call per turn, one tool call per
turn, every observation appended to the evidence chain. It is intentionally
small enough to audit in one sitting.
"""

from __future__ import annotations

import copy
import dataclasses
import time
from typing import Any, Mapping

from .assurance import assurance_evidence
from .canonical import canonical_sha256
from .events import EventStream
from .loop import (
    FatalToolRuntimeError,
    assistant_message,
    current_success,
    evidence_observation,
    model_messages,
    record_tool,
    record_evidence_frame,
    sign_run_evidence,
    tool_manifest_for_model,
    tool_result_messages,
)
from .manifest import HARNESS_VERSION, agent_binding
from .metering import measure
from .result import RunResult
from .spec import HarnessSpec
from .tools import ToolRuntime, filter_observation


class HeadlessHarness:
    name = "headless"
    version = HARNESS_VERSION

    def run(
        self,
        spec: HarnessSpec,
        runtime: ToolRuntime,
        *,
        chat_fn: Any = None,
        signer: Any = None,
        frame_collector: Any = None,
        run_budget: Any = None,
    ) -> RunResult:
        stream = EventStream(
            run_id=spec.run_id,
            attempt_id=spec.attempt_id,
            episode=spec.episode,
            job_id=spec.job_id,
            party=spec.party,
            recorder=f"agent_harness:{self.name}",
            job_nonce=spec.job_nonce,
            persist_path=spec.evidence_path,
        )
        result = RunResult(
            run_id=spec.run_id,
            attempt_id=spec.attempt_id,
            harness=self.name,
            source=spec.source,
            task_id=spec.task_id,
            instance=spec.instance,
            mode=spec.mode,
            permissions=spec.permissions_payload(),
            assurance_profile=spec.assurance.name,
            assurance=assurance_evidence(spec, runtime),
            evidence_path=spec.evidence_path,
        )
        contract_fields = _execution_contract_fields(spec, runtime)
        started = time.monotonic()
        turns = 0
        steps = 0
        last_observation_sha: str | None = None

        stream.append(
            "run_start",
            {
                "harness": self.name,
                "harness_version": self.version,
                "source": spec.source,
                "task_id": spec.task_id,
                "instance": spec.instance,
                "runtime": type(runtime).__name__,
                "assurance_profile": spec.assurance.name,
                "assurance": assurance_evidence(spec, runtime),
                "mode": spec.mode,
                "sensors": list(spec.sensors),
                "permissions": spec.permissions_payload(),
                "model": _model_evidence(spec),
                "agent": dict(agent_binding()),
                "max_turns": spec.max_turns,
                "max_steps": spec.max_steps,
                "wall_seconds": spec.wall_seconds,
                **_panel_binding_fields(spec),
                **contract_fields,
            },
        )

        try:
            observation = runtime.reset()
        except Exception as exc:  # noqa: BLE001 - infra failure is recorded, then returned
            fatal = bool(getattr(exc, "fatal", False))
            code = str(getattr(exc, "code", "") or type(exc).__name__)
            stream.append(
                "error",
                {
                    "stage": "reset",
                    "code": code if fatal else None,
                    "error": f"{type(exc).__name__}: {exc}",
                },
            )
            if fatal:
                result.extra = {
                    **dict(result.extra),
                    "fatal_tool_runtime": {
                        "code": code,
                        "detail": str(getattr(exc, "detail", "") or exc),
                        "recorded": bool(getattr(exc, "recorded", False)),
                    },
                }
            return self._finish(
                result,
                stream,
                status="error",
                reason=f"simulator_fatal:{code}" if fatal else "reset_error",
                turns=0,
                steps=0,
                spec=spec,
                signer=signer,
                runtime=runtime,
            )

        visible = filter_observation(observation, spec.sensors)
        last_observation_sha = canonical_sha256(evidence_observation(visible))
        first_event = stream.append(
            "observation",
            {"step": 0, "observation": evidence_observation(visible), "observation_sha256": last_observation_sha},
            correlation_id="step:0",
        )
        if frame_collector is not None:
            frame_collector.capture(visible, seq=int(first_event["seq"]), episode=int(spec.episode or 0))
            record_evidence_frame(
                stream,
                spec,
                observation,
                frame_collector=frame_collector,
                correlation_id="step:0",
            )

        messages = model_messages(visible, runtime.instruction)
        model_spec = self._model_spec(spec)
        if chat_fn is None:
            chat_fn = self._gateway_chat(spec, model_spec, run_budget=run_budget)
        reason = "turn_limit"
        status = "ok"
        success = False

        for turn in range(1, spec.max_turns + 1):
            if time.monotonic() - started > spec.wall_seconds:
                reason = "wall_time"
                status = "error"
                break
            turns = turn
            input_tools = tool_manifest_for_model()
            input_snapshot = None
            if (spec.raw.get("task") or {}).get("execution_profile"):
                # Snapshot before the provider call, including prior reasoning and images.
                # No endpoint, authentication headers or model credentials are included.
                input_snapshot = {
                    "input_messages": copy.deepcopy(messages),
                    "input_tools": copy.deepcopy(input_tools),
                    "messages_sha256": canonical_sha256(messages),
                    "tools_sha256": canonical_sha256(input_tools),
                }
            try:
                reply = chat_fn(
                    messages,
                    input_tools,
                    model_spec,
                    run_id=spec.run_id,
                    attempt_id=spec.attempt_id,
                )
            except Exception as exc:  # noqa: BLE001 - provider failure is a terminal event
                stream.append("error", {"stage": "model_call", "turn": turn, "error": f"{type(exc).__name__}: {exc}"})
                return self._finish(
                    result,
                    stream,
                    status="error",
                    reason="model_error",
                    turns=turn,
                    steps=steps,
                    spec=spec,
                    signer=signer,
                    runtime=runtime,
                )

            tool_calls = list(reply.get("tool_calls") or [])
            provider_meta = reply.get("provider_meta") or {}
            stream.append(
                "model_call",
                {
                    "turn": turn,
                    **(input_snapshot or {}),
                    "reasoning_content": reply.get("reasoning_content"),
                    "content": reply.get("content") or "",
                    "content_sha256": canonical_sha256(reply.get("content") or ""),
                    "tool_calls": [
                        {
                            "id": call.get("id"),
                            "name": call.get("name"),
                            "args": call.get("args", call.get("arguments", {})),
                            "args_sha256": canonical_sha256(call.get("args", call.get("arguments", {}))),
                        }
                        for call in tool_calls
                    ],
                    "usage": reply.get("usage") or {},
                    "provider_meta": provider_meta,
                },
                correlation_id=provider_meta.get("request_id") or f"turn:{turn}",
            )
            # Validate the entire batch before dispatching any call. A JSON
            # string/list/null is model output, never an empty or coerced action.
            invalid = [
                call for call in tool_calls if not isinstance(call.get("args", call.get("arguments", {})), Mapping)
            ]
            if invalid:
                stream.append(
                    "error",
                    {"stage": "tool_arguments", "code": "invalid_tool_arguments", "turn": turn, "calls": invalid},
                )
                return self._finish(
                    result,
                    stream,
                    status="error",
                    reason="invalid_tool_arguments",
                    turns=turn,
                    steps=steps,
                    spec=spec,
                    signer=signer,
                    runtime=runtime,
                )
            messages.append(
                assistant_message(
                    reply.get("content") or "",
                    tool_calls,
                    reasoning_content=reply.get("reasoning_content"),
                )
            )
            if not tool_calls:
                reason = "model_stop"
                break

            execution: list[tuple[str, Mapping[str, Any]]] = []
            fatal_error: FatalToolRuntimeError | None = None
            for index, call in enumerate(tool_calls):
                name = str(call.get("name") or "")
                args = dict(call.get("args", call.get("arguments", {})))
                call_id = str(call.get("id") or f"call-{turn}-{index}")
                try:
                    outcome, tool_visible, _error = record_tool(
                        stream,
                        runtime,
                        spec,
                        call_id=call_id,
                        name=name,
                        args=args,
                        prior_observation_sha256=last_observation_sha,
                        frame_collector=frame_collector,
                    )
                except FatalToolRuntimeError as exc:
                    # 绑定/预算/协议/传输 fatal：同批剩余工具、后续 turn 和
                    # 模型调用都必须停止；tool_call/tool_result 已由
                    # record_tool 留在 executor 链上。
                    fatal_error = exc
                    break
                if outcome is not None:
                    steps = max(steps, int(outcome.steps))
                if tool_visible is not None:
                    last_observation_sha = canonical_sha256(evidence_observation(tool_visible))
                    execution.append((call_id, tool_visible))
                else:
                    execution.append((call_id, {"step": steps, "instruction": runtime.instruction}))
                if outcome is not None and outcome.success:
                    success = True

            if fatal_error is not None:
                stream.append(
                    "error",
                    {
                        "stage": "tool_runtime",
                        "turn": turn,
                        "code": fatal_error.code,
                        "error": f"{type(fatal_error).__name__}: {fatal_error}",
                        "recorded": fatal_error.recorded,
                    },
                )
                result.extra = {
                    **dict(result.extra),
                    "fatal_tool_runtime": {
                        "code": fatal_error.code,
                        "detail": fatal_error.detail,
                        "recorded": fatal_error.recorded,
                    },
                }
                status = "error"
                reason = f"simulator_fatal:{fatal_error.code}"
                break

            messages.extend(tool_result_messages(execution))

            if success:
                reason = "success"
                break
            ok, detail = current_success(runtime)
            stream.append(
                "success_check",
                {"success": bool(ok), "detail": dict(detail), "step": steps},
                correlation_id=f"step:{steps}",
            )
            if ok:
                success = True
                reason = "success"
                break
            if steps >= spec.max_steps:
                reason = "step_limit"
                break
        else:
            reason = "turn_limit"

        if not success:
            ok, detail = current_success(runtime)
            success = bool(ok)
            if success:
                reason = "success"
                stream.append(
                    "success_check",
                    {"success": True, "detail": dict(detail), "step": steps},
                    correlation_id=f"step:{steps}",
                )

        return self._finish(
            result,
            stream,
            status=status,
            reason=reason,
            turns=turns,
            steps=steps,
            success=success,
            spec=spec,
            signer=signer,
            runtime=runtime,
        )

    @staticmethod
    def _model_spec(spec: HarnessSpec) -> Any:
        from agent_eval.spec import from_evaluation_spec

        model_spec = from_evaluation_spec(spec.raw)
        if spec.evidence_path:
            model_spec = dataclasses.replace(model_spec, record_path=f"{spec.evidence_path}.calls.jsonl")
        return model_spec

    @staticmethod
    def _gateway_chat(spec: HarnessSpec, model_spec: Any, *, run_budget: Any = None) -> Any:
        """One gateway per run: allow-or-reject + budget derived from the frozen spec.

        ``run_budget`` is the cross-episode/cross-process ledger owned by the
        caller. When it is present, every actual attempt reserves before the
        network send; when it is absent there is no run-level cost gate.
        """

        from agent_eval import CallRecorder, ModelGateway

        recorder = CallRecorder(model_spec.record_path) if model_spec.record_path else None
        return ModelGateway.from_evaluation_spec(spec.raw, recorder=recorder, run_budget=run_budget).chat

    @staticmethod
    def _finish(
        result: RunResult,
        stream: EventStream,
        *,
        status: str,
        reason: str,
        turns: int,
        steps: int,
        success: bool = False,
        spec: HarnessSpec | None = None,
        signer: Any = None,
        runtime: Any = None,
    ) -> RunResult:
        # OPE-198：计量必须进签名链，且在任何终态（成功/失败）都写。
        if type(runtime).__module__ == "task_source.scene_views.episode":
            from task_source.scene_views.episode import _SceneRuntime

            if type(runtime) is _SceneRuntime:
                cleanup = runtime.finish_episode()
                terminal = cleanup.get("terminal")
                if terminal is not None:
                    status, success = "error", False
                    if reason != terminal["code"] and not reason.endswith(":" + terminal["code"]):
                        reason = terminal["code"]
                    result.extra = {**dict(result.extra), "scene_terminal": terminal}
                stream.append("scene_episode_cleanup", cleanup)
        if spec is not None:
            measurement = measure(spec.raw, stream.events, runtime)
            record = measurement.payload()
            stream.append("usage_summary", record)
            result.extra = {**dict(result.extra), "metering": record}
        stream.append(
            "run_end",
            {
                "status": status,
                "reason": reason,
                "success": success,
                "turns": turns,
                "steps": steps,
                **({"error": "" if status == "ok" else reason} if spec is not None and spec.panel_binding else {}),
            },
        )
        result.events = list(stream.events)
        result.root = stream.root
        result.status = status
        result.reason = reason
        result.turns = turns
        result.steps = steps
        result.success = success
        if spec is not None:
            sign_run_evidence(result, stream, spec, signer)
        return result


__all__ = ["HeadlessHarness"]


def _model_evidence(spec: HarnessSpec) -> dict[str, Any]:
    model = {"provider": spec.model.get("provider"), "model": spec.model.get("model")}
    extra = spec.model.get("extra_body")
    if isinstance(extra, Mapping):
        thinking = extra.get("thinking")
        if isinstance(thinking, Mapping) and thinking.get("type") in ("enabled", "disabled"):
            model["thinking"] = thinking["type"]
    return model


def _panel_binding_fields(spec: Any) -> dict[str, Any]:
    """A 参照组绑定字段；没有绑定（B 默认）时返回空。"""
    binding = getattr(spec, "panel_binding", None)
    if not binding:
        return {}
    keys = (
        "run_id",
        "panel",
        "member",
        "kind",
        "trial",
        "package_digest",
        "version_digest",
        "config_version",
        "config_digest",
        "settlement",
    )
    return {key: binding[key] for key in keys if key in binding}


def _execution_contract_fields(spec: HarnessSpec, runtime: ToolRuntime) -> dict[str, Any]:
    """A 合同从实际解析的运行参数重建，声明不能代替生效条件。"""
    binding = spec.panel_binding or {}
    if "execution_contract" not in binding:
        return {}
    if type(runtime).__module__ == "task_source.scene_views.episode":
        from task_source.scene_views.episode import _SceneRuntime

        if type(runtime) is _SceneRuntime:
            return runtime.contract_evidence(spec)
    from task_source.execution_contract import (
        execution_contract_digest,
        parse_execution_contract,
        verify_execution_runtime,
    )

    actual_document = {
        "version": 1,
        "harness": {"name": spec.harness_name},
        "agent": dict(agent_binding()),
        "permissions": {"mode": spec.mode, "allowed_sensors": list(spec.sensors)},
        "budget": {"max_api_calls": spec.max_turns, "max_steps": spec.max_steps, "wall_seconds": spec.wall_seconds},
        "timing": {
            "control_step_seconds": spec.control_step_seconds,
            "clock_mode": spec.timing["clock_mode"],
            "s": spec.timing["s"],
        },
    }
    task = getattr(runtime, "task", None)
    if task is not None and "imported_scene" in task.metadata:
        actual_document.update(
            version=3,
            execution_profile=task.metadata["execution_profile"],
            observation_contract=task.metadata["observation_contract"],
            resource_profile=task.metadata["resource_profile"],
        )
    actual = parse_execution_contract(actual_document)
    declared = parse_execution_contract(binding["execution_contract"])
    digest = execution_contract_digest(actual)
    if actual != declared or binding.get("execution_contract_digest") != digest:
        from .spec import SpecError

        raise SpecError("A execution_contract does not match the effective harness parameters")
    try:
        execution_runtime = verify_execution_runtime(actual, runtime)
    except ValueError as exc:
        from .spec import SpecError

        raise SpecError(str(exc)) from exc
    return {
        "execution_contract": actual,
        "execution_contract_digest": digest,
        "execution_runtime": execution_runtime,
    }
