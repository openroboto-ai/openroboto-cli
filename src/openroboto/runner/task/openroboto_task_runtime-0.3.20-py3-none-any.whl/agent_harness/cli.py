"""``python -m agent_harness`` command line."""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
from typing import Any

from . import HARNESSES, binding, describe, run
from .assurance import describe_profiles
from .events import verify_path
from .modes import describe_modes
from .results import write_result
from .sandbox import probe_host
from .spec import SpecError


def _read(path: str) -> dict[str, Any]:
    data = json.loads(pathlib.Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SpecError(f"{path}: evaluation spec must be a JSON object")
    return data


def _write_json(value: Any) -> None:
    json.dump(value, sys.stdout, ensure_ascii=False, indent=1, sort_keys=True)
    sys.stdout.write("\n")


def _cmd_describe(_args: argparse.Namespace) -> int:
    _write_json(describe())
    return 0


def _cmd_binding(_args: argparse.Namespace) -> int:
    _write_json(binding())
    return 0


def _cmd_modes(_args: argparse.Namespace) -> int:
    _write_json(describe_modes())
    return 0


def _cmd_assurance(_args: argparse.Namespace) -> int:
    _write_json({"profiles": describe_profiles(), "host": probe_host().payload()})
    return 0


def _cmd_verify(args: argparse.Namespace) -> int:
    # 新记录是 OPE-126 evidence-v1;旧 harness 记录仍走原来的复算。
    from agent_evidence.events import load_events
    from agent_evidence.verify import verify_chain

    legacy_ok, legacy_message = verify_path(args.events)
    try:
        evidence = verify_chain(load_events(args.events))
    except ValueError as exc:
        evidence = None
        evidence_error = str(exc)
    else:
        evidence_error = None
    if evidence is not None and evidence.ok:
        _write_json(
            {
                "ok": True,
                "format": "evidence-v1",
                "message": f"ok ({evidence.details.get('event_count')} events)",
                "events": args.events,
                "legacy_ok": legacy_ok,
            }
        )
        return 0
    _write_json(
        {
            "ok": legacy_ok,
            "format": "legacy",
            "message": legacy_message,
            "events": args.events,
            "evidence_errors": (evidence.errors if evidence is not None else [evidence_error]),
        }
    )
    return 0 if legacy_ok else 2


def _cmd_run(args: argparse.Namespace) -> int:
    raw = _read(args.spec)
    if args.out:
        out = pathlib.Path(args.out).expanduser()
        out.mkdir(parents=True, exist_ok=True)
        raw.setdefault("evidence", {})["path"] = str(out / "events.jsonl")
    if args.signing_mode:
        raw.setdefault("signing", {})["mode"] = args.signing_mode
    if args.assurance_profile:
        raw["assurance_profile"] = args.assurance_profile

    signer = None
    if args.signing_key:
        from agent_evidence.signing import Signer

        signer = Signer.from_keyfile(args.signing_key)
    try:
        result = run(
            raw,
            runtime_override=None if args.runtime == "auto" else args.runtime,
            strict=not args.allow_unbound,
            signer=signer,
            local_mode=args.local_mode,
        )
    except Exception as exc:  # noqa: BLE001 - CLI boundary
        _write_json({"status": "error", "error": f"{type(exc).__name__}: {exc}"})
        return 2

    summary = result.to_dict()
    if result.evidence_path:
        ok, message = verify_path(result.evidence_path, root=result.root)
        summary["evidence_verified"] = ok
        summary["evidence_message"] = message
    if args.out:
        # Mode is part of the path: the same task in another mode never
        # overwrites this record.
        summary["result_path"] = str(write_result(args.out, result))
    signing = result.extra.get("signing") if isinstance(result.extra, dict) else None
    if isinstance(signing, dict) and signing.get("signed") and signer is not None:
        from agent_evidence.signing import TrustStore, verify_bundle, verify_root
        from agent_evidence.verify import verify_chain

        trust = TrustStore()
        trust.add(signer.party, signer.key_id, signer.public_key_hex)
        chain_check = verify_chain(result.events)
        summary["evidence_chain_verified"] = chain_check.ok
        summary["evidence_chain_errors"] = chain_check.errors
        root_check = verify_root(signing["root_record"], trust)
        summary["evidence_root_verified"] = root_check.ok
        summary["evidence_root_errors"] = root_check.errors
        if signing.get("bundle_path"):
            bundle = json.loads(pathlib.Path(signing["bundle_path"]).read_text(encoding="utf-8"))
            bundle_check = verify_bundle(bundle, trust_store=trust, chains={signer.party: result.events})
            summary["evidence_bundle_verified"] = bundle_check.ok
            summary["evidence_bundle_warnings"] = bundle_check.warnings
    _write_json(summary)
    return 0 if result.status == "ok" else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="agent_harness", description="Agent eval harness (B-04)")
    sub = parser.add_subparsers(dest="command", required=True)

    describe_parser = sub.add_parser("describe", help="print harness identity and digests")
    describe_parser.set_defaults(func=_cmd_describe)

    binding_parser = sub.add_parser("binding", help="print the frozen EvaluationSpec binding")
    binding_parser.set_defaults(func=_cmd_binding)

    modes_parser = sub.add_parser("modes", help="print the three-mode per-field declarations")
    modes_parser.set_defaults(func=_cmd_modes)

    assurance_parser = sub.add_parser(
        "assurance", help="print assurance profiles and what this host can enforce (OPE-124)"
    )
    assurance_parser.set_defaults(func=_cmd_assurance)

    verify_parser = sub.add_parser("verify", help="recompute an events.jsonl hash chain")
    verify_parser.add_argument("--events", required=True)
    verify_parser.set_defaults(func=_cmd_verify)

    run_parser = sub.add_parser("run", help="run one evaluation spec")
    run_parser.add_argument("--spec", required=True)
    run_parser.add_argument("--out", default=None, help="directory for events.jsonl")
    run_parser.add_argument(
        "--runtime", default="auto", choices=["auto", "task_source", "scenario"], help="runtime selection"
    )
    run_parser.add_argument(
        "--allow-unbound", action="store_true", help="allow a spec without agent digests (local smoke only)"
    )
    run_parser.add_argument(
        "--local-mode",
        action="store_true",
        help="allow task.package_root for local smoke/tests (production specs use package_repo + package_commit)",
    )
    run_parser.add_argument(
        "--signing-key",
        default=None,
        help="executor signing key file (agent_evidence Signer.keyfile JSON)",
    )
    run_parser.add_argument(
        "--signing-mode",
        default=None,
        choices=["single", "three_party"],
        help="override signing.mode in the spec",
    )
    run_parser.add_argument(
        "--assurance-profile",
        default=None,
        choices=["demo-no-isolation", "isolated"],
        help="override assurance_profile in the spec (OPE-124)",
    )
    run_parser.set_defaults(func=_cmd_run)

    harnesses = sub.add_parser("harnesses", help="list harness implementations")
    harnesses.set_defaults(func=lambda _args: (_write_json(sorted(HARNESSES)), 0)[1])
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
