# Pi extension: robot tools

`robot_tools.ts` registers the five frozen tools with [Pi](https://github.com/earendil-works/pi)
and forwards every call to the loopback bridge that `agent_harness.pi` starts.

- Pi version is pinned in the execution image, not here.
- `PI_HARNESS_BRIDGE` and `PI_HARNESS_TOKEN` are injected by the harness into
  the Pi child process only.
- The extension runs inside Pi with the same OS permissions; OPE-124 owns the
  isolation level and must revisit this boundary before production.
- It is included in `harness_commit` (the manifest digests `*.ts` as well as
  `*.py`), so editing the bridge changes the frozen agent identity.
