/**
 * Pi extension that exposes the frozen robot tools.
 *
 * Pi never executes a robot tool itself. Every call is forwarded to the
 * loopback bridge started by agent_harness.pi, which runs the tool through the
 * task-source runtime and appends the call to the evidence chain. The bridge
 * address and per-run token come from the environment and are only present in
 * the Pi child process.
 */

import { Type } from "typebox";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";

const BRIDGE = process.env.PI_HARNESS_BRIDGE;
const TOKEN = process.env.PI_HARNESS_TOKEN ?? "";

type Observation = {
  image?: { mime_type?: string; data_base64?: string } | null;
  [key: string]: unknown;
};

async function callTool(name: string, args: unknown): Promise<Observation> {
  if (!BRIDGE) {
    throw new Error("PI_HARNESS_BRIDGE is not set; this extension only runs under agent_harness.pi");
  }
  const response = await fetch(`${BRIDGE}/tool`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-harness-token": TOKEN },
    body: JSON.stringify({ name, args }),
  });
  const payload = (await response.json()) as {
    ok?: boolean;
    error?: string | null;
    observation?: Observation | null;
  };
  if (!response.ok || payload.ok === false) {
    throw new Error(payload.error ?? `tool ${name} failed`);
  }
  return payload.observation ?? {};
}

export default function install(pi: ExtensionAPI): void {
  const register = (
    name: string,
    label: string,
    description: string,
    parameters: unknown,
    promptSnippet: string,
  ): void => {
    pi.registerTool({
      name,
      label,
      description,
      promptSnippet,
      parameters,
      async execute(_toolCallId, params) {
        const observation = await callTool(name, params);
        const { image, ...rest } = observation;
        const content: Array<Record<string, unknown>> = [
          { type: "text", text: JSON.stringify(rest) },
        ];
        if (image?.data_base64) {
          content.push({
            type: "image",
            data: image.data_base64,
            mimeType: image.mime_type ?? "image/png",
          });
        }
        return { content, details: { observation: rest } };
      },
    } as never);
  };

  register(
    "observe",
    "Observe",
    "Return the current observation allowed for this evaluation.",
    Type.Object({}),
    "observe returns the current robot observation",
  );
  register(
    "move_to",
    "Move To",
    "Move the tool center point to (x, y, z) with the given gripper opening.",
    Type.Object({
      x: Type.Number(),
      y: Type.Number(),
      z: Type.Number(),
      gripper: Type.Number({ minimum: 0, maximum: 1 }),
      steps: Type.Optional(Type.Integer({ minimum: 1, maximum: 100 })),
      yaw: Type.Optional(Type.Number()),
    }),
    "move_to moves the tool center point in meters",
  );
  register(
    "grasp",
    "Grasp",
    "Close the gripper and hold for a few control steps.",
    Type.Object({ steps: Type.Optional(Type.Integer({ minimum: 1, maximum: 100 })) }),
    "grasp closes the gripper",
  );
  register(
    "release",
    "Release",
    "Open the gripper and hold for a few control steps.",
    Type.Object({ steps: Type.Optional(Type.Integer({ minimum: 1, maximum: 100 })) }),
    "release opens the gripper",
  );
  register(
    "step",
    "Step",
    "Apply one raw source-level action vector.",
    Type.Object({
      action: Type.Array(Type.Number()),
      steps: Type.Optional(Type.Integer({ minimum: 1, maximum: 100 })),
    }),
    "step applies one raw source action",
  );
}
