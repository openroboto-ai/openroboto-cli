"""执行层的模型传输选择：生产走后端可信网关，直连只在显式本地模式。

B worker 的模型请求只有两条明确路径：

``backend_gateway``（生产唯一路径）
    运营 / 接单契约给出网关 URL、bearer 凭据、共同 ``run_id`` 和
    ``signing_mode``。所有请求经 backend ``POST /v1/chat``，由后端用冻结
    spec 校验、预留预算、转发真实 provider，并把原文 / 根落
    ``model_gateway_calls`` / ``model_gateway_roots``。

``direct``（本地 smoke / 单测）
    只有调用方显式传了 ``local_mode=True`` 才允许，且本地测试 / smoke 工具
    自己注入 ``chat_fn`` 时也不受影响。生产入口 ``python -m eval_worker``
    从不设置 ``local_mode``，所以**直连不是生产默认，也不是任何 fallback**。

契约来源（按优先级）：

``EVAL_MODEL_GATEWAY_CONTRACT``
    一个 JSON 文件（建议 0600）::

        {
          "url": "https://gateway.example.com",
          "run_id": "common-run-123",
          "signing_mode": "three_party",
          "tokens": {"<backend job id>": "<bearer token>"},
          "timeout_s": 600
        }

    也可以只给 ``"token"``（单 job 部署）。未知字段直接拒绝，避免拼写错误
    被静默忽略。

环境变量（没有契约文件时）
    ``EVAL_MODEL_GATEWAY_URL`` / ``EVAL_MODEL_GATEWAY_TOKEN`` /
    ``EVAL_RUN_ID`` / ``EVAL_EVIDENCE_SIGNING_MODE``。

任何一个来源被配置了但缺少必填项 → 在模型 / 仿真开始前
:class:`ModelTransportConfigError`；不会回退到直连。
"""

from __future__ import annotations

import json
import os
import pathlib
import stat
import urllib.parse
from dataclasses import dataclass, field
from typing import Any, Mapping

from agent_eval.backend_gateway import (
    BackendGatewayConfigError,
    BackendGatewayTarget,
    BackendModelGateway,
    normalize_gateway_url,
)
from agent_eval.spec import ModelSpec, from_evaluation_spec

MODEL_GATEWAY_URL_ENV = "EVAL_MODEL_GATEWAY_URL"
MODEL_GATEWAY_TOKEN_ENV = "EVAL_MODEL_GATEWAY_TOKEN"  # noqa: S105 - 只是变量名
MODEL_RUN_ID_ENV = "EVAL_RUN_ID"
MODEL_GATEWAY_CONTRACT_ENV = "EVAL_MODEL_GATEWAY_CONTRACT"
EVIDENCE_SIGNING_MODE_ENV = "EVAL_EVIDENCE_SIGNING_MODE"

SIGNING_MODES = ("single", "three_party")
_CONTRACT_KEYS = {"url", "token", "tokens", "run_id", "signing_mode", "timeout_s"}


class ModelTransportConfigError(RuntimeError):
    """模型传输配置缺失 / 不合规；必须在任何 provider 调用之前 fail-closed。"""


def _env(env: Mapping[str, str] | None) -> Mapping[str, str]:
    return os.environ if env is None else env


def _text(value: Any) -> str:
    return str(value or "").strip()


def _signing_mode(value: Any, *, source: str) -> str:
    mode = _text(value)
    if mode not in SIGNING_MODES:
        raise ModelTransportConfigError(
            f"{source} must be one of {SIGNING_MODES}, got {mode!r}; "
            "the backend /spec does not ship the evidence block, so silence is not 'single'"
        )
    return mode


def _optional_timeout(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool):
        raise ModelTransportConfigError("gateway timeout_s must be a positive number")
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        raise ModelTransportConfigError("gateway timeout_s must be a positive number") from None
    if parsed <= 0:
        raise ModelTransportConfigError("gateway timeout_s must be a positive number")
    return parsed


@dataclass(frozen=True)
class GatewayContract:
    url: str
    token: str = field(repr=False)
    run_id: str
    signing_mode: str
    job_id: str
    timeout_s: float | None = None


def _check_contract_file_permissions(path: pathlib.Path) -> None:
    """契约里可能有 bearer token；Group/Other 可读视为配置错误。"""

    if os.name == "nt":  # pragma: no cover - CI 是 POSIX
        return
    mode = stat.S_IMODE(path.stat().st_mode)
    if mode & 0o077:
        raise ModelTransportConfigError(
            f"model gateway contract {path} has mode {mode:04o}; expected 0600"
        )


def _contract_from_document(
    document: Mapping[str, Any],
    *,
    job_id: str,
    path: pathlib.Path | None = None,
) -> GatewayContract:
    where = str(path) if path is not None else "the model gateway contract"
    if not isinstance(document, Mapping):
        raise ModelTransportConfigError(f"{where} must contain a JSON object")
    unknown = sorted(set(document) - _CONTRACT_KEYS)
    if unknown:
        raise ModelTransportConfigError(
            f"{where} has unknown fields {unknown}; refusing to guess"
        )
    url = normalize_gateway_url(document.get("url"))
    run_id = _text(document.get("run_id"))
    if not run_id:
        raise ModelTransportConfigError(f"{where} needs a non-empty run_id")
    mode = _signing_mode(document.get("signing_mode"), source=f"{where} signing_mode")
    timeout_s = _optional_timeout(document.get("timeout_s"))

    token = _text(document.get("token"))
    tokens = document.get("tokens")
    if tokens is not None:
        if not isinstance(tokens, Mapping):
            raise ModelTransportConfigError(f"{where} tokens must be an object keyed by job id")
        per_job = tokens.get(job_id)
        if per_job is not None:
            token = _text(per_job)
    if not token:
        raise ModelTransportConfigError(
            f"{where} has no bearer token for job {job_id!r}"
        )
    return GatewayContract(
        url=url,
        token=token,
        run_id=run_id,
        signing_mode=mode,
        job_id=job_id,
        timeout_s=timeout_s,
    )


def resolve_gateway_contract(
    job_id: str,
    *,
    env: Mapping[str, str] | None = None,
) -> GatewayContract | None:
    """返回受控网关契约；完全没配置时返回 None（由调用方决定是否 fail-closed）。"""

    source = _env(env)
    path_value = _text(source.get(MODEL_GATEWAY_CONTRACT_ENV))
    if path_value:
        path = pathlib.Path(path_value).expanduser()
        try:
            _check_contract_file_permissions(path)
            document = json.loads(path.read_text(encoding="utf-8"))
        except OSError as exc:
            raise ModelTransportConfigError(
                f"cannot read model gateway contract {path}: {type(exc).__name__}"
            ) from None
        except ValueError as exc:
            raise ModelTransportConfigError(
                f"model gateway contract {path} is not valid JSON: {exc}"
            ) from None
        return _contract_from_document(document, job_id=job_id, path=path)

    values = {
        "url": _text(source.get(MODEL_GATEWAY_URL_ENV)),
        "token": _text(source.get(MODEL_GATEWAY_TOKEN_ENV)),
        "run_id": _text(source.get(MODEL_RUN_ID_ENV)),
        # 模式单独出现是本地 / smoke 的既有用法，不构成"配了网关"。
        "signing_mode": _text(source.get(EVIDENCE_SIGNING_MODE_ENV)),
    }
    identity_configured = any(values[name] for name in ("url", "token", "run_id"))
    if not identity_configured:
        return None
    missing = [name for name, value in values.items() if not value]
    if missing:
        names = {
            "url": MODEL_GATEWAY_URL_ENV,
            "token": MODEL_GATEWAY_TOKEN_ENV,
            "run_id": MODEL_RUN_ID_ENV,
            "signing_mode": EVIDENCE_SIGNING_MODE_ENV,
        }
        raise ModelTransportConfigError(
            "the backend model gateway is partially configured; missing "
            + ", ".join(names[name] for name in missing)
        )
    document = {
        "url": values["url"],
        "token": values["token"],
        "run_id": values["run_id"],
        "signing_mode": values["signing_mode"],
    }
    return _contract_from_document(document, job_id=job_id)


def _model_spec(raw: Mapping[str, Any]) -> ModelSpec:
    return from_evaluation_spec(raw)


def _assert_gateway_is_not_the_provider(url: str, model: ModelSpec) -> None:
    """运营契约也不能把网关 URL 指回冻结的 provider 本体。"""

    try:
        provider_endpoint = model.resolved_endpoint()
    except Exception:  # noqa: BLE001 - 缺 endpoint 由后续冻结校验处理
        return
    gateway = urllib.parse.urlparse(url)
    provider = urllib.parse.urlparse(provider_endpoint)
    if (
        gateway.scheme == provider.scheme
        and gateway.netloc == provider.netloc
        and provider.netloc
    ):
        raise ModelTransportConfigError(
            "the model gateway URL points at the frozen provider origin; "
            "requests must go through the backend data plane"
        )


def _require_controlled_binding(parsed: Any) -> tuple[str, str, int]:
    """job / attempt / episode 必须来自后端认证响应与 start，不接受 spec 自报。"""

    raw = parsed.raw
    binding = raw.get("binding") if isinstance(raw, Mapping) else None
    job_id = _text(binding.get("job_id")) if isinstance(binding, Mapping) else ""
    if not job_id:
        raise ModelTransportConfigError(
            "the backend gateway needs the authenticated binding.job_id from /spec; "
            "refusing to send before the job is bound"
        )
    if job_id != _text(parsed.job_id):
        raise ModelTransportConfigError(
            "binding.job_id and the parsed job id disagree; refusing a split identity"
        )
    attempt_id = _text(parsed.attempt_id)
    if not attempt_id:
        raise ModelTransportConfigError(
            "the backend gateway needs the backend attempt_id; refusing before start"
        )
    episode = parsed.episode if parsed.episode is not None else 0
    if isinstance(episode, bool) or not isinstance(episode, int) or episode < 0:
        raise ModelTransportConfigError("episode must be a non-negative integer")
    return job_id, attempt_id, episode


def _assert_budget_block(raw: Mapping[str, Any]) -> None:
    """B 的预算权威在后端；冻结 spec 必须带上后端需要的预算字段。"""

    budget = raw.get("budget") if isinstance(raw, Mapping) else None
    if not isinstance(budget, Mapping):
        raise ModelTransportConfigError(
            "the frozen spec has no budget block; the backend cannot reserve a run budget"
        )
    max_cost = budget.get("max_cost_usd")
    if max_cost is None:
        raise ModelTransportConfigError(
            "the frozen spec has no budget.max_cost_usd; refusing before the gateway"
        )
    max_calls = budget.get("max_api_calls")
    if isinstance(max_calls, bool) or not isinstance(max_calls, int) or max_calls <= 0:
        raise ModelTransportConfigError(
            "the frozen spec needs a positive budget.max_api_calls"
        )


@dataclass(frozen=True)
class ModelTransportPlan:
    #: ``backend_gateway`` 或 ``direct``。
    kind: str
    #: backend gateway 的 ``chat``；direct 时为 None（由 harness 建本地网关）。
    chat: Any = None
    signing_mode: str = "single"
    run_id: str | None = None


def is_backend_gateway_chat(chat_fn: Any) -> bool:
    return isinstance(getattr(chat_fn, "__self__", None), BackendModelGateway)


def build_model_transport(
    parsed: Any,
    *,
    local_mode: bool,
    env: Mapping[str, str] | None = None,
) -> ModelTransportPlan:
    """按受控契约选传输；缺配置时在生产模式 fail-closed。"""

    contract = resolve_gateway_contract(_text(parsed.job_id), env=env)
    if contract is not None:
        job_id, attempt_id, episode = _require_controlled_binding(parsed)
        _assert_budget_block(parsed.raw)
        model = _model_spec(parsed.raw)
        _assert_gateway_is_not_the_provider(contract.url, model)
        target = BackendGatewayTarget(
            base_url=contract.url,
            token=contract.token,
            job_id=job_id,
            attempt_id=attempt_id,
            episode=episode,
            run_id=contract.run_id,
            model_spec=model,
            timeout_s=contract.timeout_s or model.timeout_s,
        )
        try:
            gateway = BackendModelGateway(target)
        except BackendGatewayConfigError as exc:
            raise ModelTransportConfigError(str(exc)) from None
        return ModelTransportPlan(
            kind="backend_gateway",
            chat=gateway.chat,
            signing_mode=contract.signing_mode,
            run_id=contract.run_id,
        )

    if local_mode:
        raw = parsed.raw
        signing = raw.get("signing") if isinstance(raw, Mapping) else None
        evidence = raw.get("evidence") if isinstance(raw, Mapping) else None
        mode = (
            _text(_env(env).get(EVIDENCE_SIGNING_MODE_ENV))
            or (_text(signing.get("mode")) if isinstance(signing, Mapping) else "")
            or (_text(evidence.get("signing_mode")) if isinstance(evidence, Mapping) else "")
            or "single"
        )
        return ModelTransportPlan(
            kind="direct",
            chat=None,
            signing_mode=_signing_mode(mode, source="local signing mode"),
            run_id=None,
        )

    raise ModelTransportConfigError(
        "production eval_worker requires the backend model gateway contract "
        f"({MODEL_GATEWAY_CONTRACT_ENV}, or {MODEL_GATEWAY_URL_ENV} + "
        f"{MODEL_GATEWAY_TOKEN_ENV} + {MODEL_RUN_ID_ENV} + {EVIDENCE_SIGNING_MODE_ENV}); "
        "direct provider calls are not a fallback"
    )


def assert_worker_transport_configured(env: Mapping[str, str] | None = None) -> None:
    """worker 启动时预检：没有契约就别等到第一个 job 才发现。"""

    source = _env(env)
    if _text(source.get(MODEL_GATEWAY_CONTRACT_ENV)):
        # 契约按 job 取 token，启动时只能校验文件本身；显式 job id 占位。
        path = pathlib.Path(_text(source.get(MODEL_GATEWAY_CONTRACT_ENV))).expanduser()
        try:
            _check_contract_file_permissions(path)
            document = json.loads(path.read_text(encoding="utf-8"))
        except OSError as exc:
            raise ModelTransportConfigError(
                f"cannot read model gateway contract {path}: {type(exc).__name__}"
            ) from None
        except ValueError as exc:
            raise ModelTransportConfigError(
                f"model gateway contract {path} is not valid JSON: {exc}"
            ) from None
        if not isinstance(document, Mapping):
            raise ModelTransportConfigError("model gateway contract must be a JSON object")
        unknown = sorted(set(document) - _CONTRACT_KEYS)
        if unknown:
            raise ModelTransportConfigError(
                f"model gateway contract has unknown fields {unknown}"
            )
        normalize_gateway_url(document.get("url"))
        if not _text(document.get("run_id")):
            raise ModelTransportConfigError("model gateway contract needs a non-empty run_id")
        _signing_mode(document.get("signing_mode"), source="model gateway contract signing_mode")
        _optional_timeout(document.get("timeout_s"))
        tokens = document.get("tokens")
        if not _text(document.get("token")) and not isinstance(tokens, Mapping):
            raise ModelTransportConfigError(
                "model gateway contract needs a token or a tokens map keyed by job id"
            )
        return
    if (
        _text(source.get(MODEL_GATEWAY_URL_ENV))
        or _text(source.get(MODEL_GATEWAY_TOKEN_ENV))
        or _text(source.get(MODEL_RUN_ID_ENV))
    ):
        # 复用完整校验；job id 只影响 per-job token，不影响必填项检查。
        resolve_gateway_contract("startup", env=source)
        return
    raise ModelTransportConfigError(
        "eval_worker requires the backend model gateway contract; "
        f"set {MODEL_GATEWAY_CONTRACT_ENV} or "
        f"{MODEL_GATEWAY_URL_ENV}/{MODEL_GATEWAY_TOKEN_ENV}/{MODEL_RUN_ID_ENV}/"
        f"{EVIDENCE_SIGNING_MODE_ENV}. Direct provider calls are not a fallback."
    )


__all__ = [
    "EVIDENCE_SIGNING_MODE_ENV",
    "GatewayContract",
    "MODEL_GATEWAY_CONTRACT_ENV",
    "MODEL_GATEWAY_TOKEN_ENV",
    "MODEL_GATEWAY_URL_ENV",
    "MODEL_RUN_ID_ENV",
    "ModelTransportConfigError",
    "ModelTransportPlan",
    "assert_worker_transport_configured",
    "build_model_transport",
    "is_backend_gateway_chat",
    "resolve_gateway_contract",
]
