"""Pi harness adapter.

Pi (https://github.com/earendil-works/pi, MIT) is driven in its documented RPC
mode: JSONL commands on stdin, JSONL responses/events on stdout. We do **not**
let Pi execute robot tools itself. A bundled Pi extension registers the five
tools and forwards every call to a loopback bridge served by this process, so
tool execution still goes through :class:`agent_harness.loop.record_tool` and
therefore into the same evidence chain.

The adapter requires a ``pi`` binary on the execution host. When it is missing
the run fails with ``RuntimeUnavailable`` (infrastructure, not model failure).
"""

from __future__ import annotations

import json
import os
import pathlib
import queue
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Mapping

from agent_eval.spec import DEFAULT_API_KEY_ENV, from_evaluation_spec

from .assurance import assurance_evidence
from .canonical import canonical_sha256
from .events import EventStream
from .loop import (
    FatalToolRuntimeError,
    evidence_observation,
    observation_text,
    record_tool,
    record_evidence_frame,
    sign_run_evidence,
)
from .manifest import HARNESS_VERSION, agent_binding
from .metering import measure
from .prompts import system_prompt
from .result import RunResult
from .spec import HarnessSpec
from .tools import ToolRuntime, filter_observation

_EXTENSION_PATH = pathlib.Path(__file__).resolve().parent / "pi_extension" / "robot_tools.ts"
_ENV_KEEP = ("PATH", "HOME", "TMPDIR", "LANG", "LC_ALL", "SHELL", "USER", "LOGNAME", "TERM")


@dataclass
class _RunState:
    success: bool = False
    steps: int = 0
    tool_calls: int = 0
    error: str | None = None
    detail: Mapping[str, Any] = field(default_factory=dict)
    #: 工具执行方的 fatal 错误；设置后 bridge 拒绝后续调用，主循环立即终止。
    fatal: FatalToolRuntimeError | None = None


class ToolBridge:
    """Loopback HTTP endpoint the Pi extension calls for every tool."""

    def __init__(
        self,
        runtime: ToolRuntime,
        spec: HarnessSpec,
        stream: EventStream,
        state: _RunState,
        *,
        frame_collector: Any = None,
    ) -> None:
        self.runtime = runtime
        self.spec = spec
        self.stream = stream
        self.state = state
        self.frame_collector = frame_collector
        self.token = secrets.token_hex(16)
        self.last_observation_sha: str | None = None
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        # Pi executes sibling tool calls concurrently by default. A robot must
        # see them one at a time, and the runtime is not thread-safe.
        self._lock = threading.Lock()

    @property
    def url(self) -> str:
        if self._server is None:
            raise RuntimeError("bridge is not started")
        host, port = self._server.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> str:
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):  # noqa: N802
                if self.path != "/tool":
                    self._reply(404, {"ok": False, "error": "not found"})
                    return
                if self.headers.get("X-Harness-Token") != bridge.token:
                    self._reply(403, {"ok": False, "error": "bad token"})
                    return
                length = int(self.headers.get("Content-Length") or 0)
                try:
                    request = json.loads(self.rfile.read(length) or b"{}")
                except ValueError as exc:
                    self._reply(400, {"ok": False, "error": f"bad json: {exc}"})
                    return
                self._reply(200, bridge.execute(request))

            def _reply(self, status: int, payload: Mapping[str, Any]) -> None:
                body = json.dumps(dict(payload), ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):  # noqa: ARG002
                return None

        self._server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=lambda: self._server.serve_forever(poll_interval=0.05), daemon=True)
        self._thread.start()
        return self.url

    def execute(self, request: Mapping[str, Any]) -> dict[str, Any]:
        with self._lock:
            if self.state.fatal is not None:
                fatal = self.state.fatal
                return {
                    "ok": False,
                    "fatal": True,
                    "error_code": fatal.code,
                    "error": "tool execution terminated",
                    "observation": None,
                    "success": self.state.success,
                    "steps": self.state.steps,
                }
            index = self.state.tool_calls
            self.state.tool_calls += 1
            name = str(request.get("name") or "")
            args = request.get("args", request.get("arguments", {}))
            try:
                outcome, visible, error = record_tool(
                    self.stream,
                    self.runtime,
                    self.spec,
                    call_id=str(request.get("call_id") or f"pi-{index}"),
                    name=name,
                    args=args,
                    prior_observation_sha256=self.last_observation_sha,
                    frame_collector=self.frame_collector,
                )
            except FatalToolRuntimeError as exc:
                self.state.fatal = exc
                return {
                    "ok": False,
                    "fatal": True,
                    "error_code": exc.code,
                    "error": "tool execution terminated",
                    "observation": None,
                    "success": self.state.success,
                    "steps": self.state.steps,
                }
            if visible is not None:
                self.last_observation_sha = canonical_sha256(evidence_observation(visible))
            if outcome is not None:
                self.state.steps = max(self.state.steps, int(outcome.steps))
                if outcome.success:
                    self.state.success = True
                    self.state.detail = dict(outcome.detail)
            if error is not None:
                self.state.error = error
            return {
                "ok": error is None,
                # Raw exception messages may contain checker internals. The
                # complete error is already recorded by record_tool for audit.
                "error": "tool execution failed" if error is not None else None,
                "observation": dict(visible) if visible is not None else None,
                "success": self.state.success,
                "steps": self.state.steps,
            }

    def stop(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        if self._thread is not None:
            self._thread.join(timeout=2)
            self._thread = None


class PiHarness:
    name = "pi"
    version = HARNESS_VERSION

    def run(
        self,
        spec: HarnessSpec,
        runtime: ToolRuntime,
        *,
        chat_fn: Any = None,  # noqa: ARG002
        signer: Any = None,
        frame_collector: Any = None,
    ) -> RunResult:
        options = dict(spec.harness_options)
        command = options.get("command") or ["pi"]
        if isinstance(command, str):
            command = [command]
        command = [str(part) for part in command]
        if shutil.which(command[0]) is None:
            from task_source.base import RuntimeUnavailable

            raise RuntimeUnavailable(
                f"Pi harness needs the {command[0]!r} executable on the execution host; install Pi or set "
                "harness.options.command"
            )

        stream = EventStream(
            run_id=spec.run_id,
            attempt_id=spec.attempt_id,
            episode=spec.episode,
            job_id=spec.job_id,
            party=spec.party,
            recorder=f"agent_harness:{self.name}",
            job_nonce=spec.job_nonce,
            persist_path=spec.evidence_path,
        )
        result = RunResult(
            run_id=spec.run_id,
            attempt_id=spec.attempt_id,
            harness=self.name,
            source=spec.source,
            task_id=spec.task_id,
            instance=spec.instance,
            mode=spec.mode,
            permissions=spec.permissions_payload(),
            assurance_profile=spec.assurance.name,
            assurance=assurance_evidence(spec, runtime),
            evidence_path=spec.evidence_path,
        )
        stream.append(
            "run_start",
            {
                "harness": self.name,
                "harness_version": self.version,
                "source": spec.source,
                "task_id": spec.task_id,
                "instance": spec.instance,
                "runtime": type(runtime).__name__,
                "assurance_profile": spec.assurance.name,
                "assurance": assurance_evidence(spec, runtime),
                "mode": spec.mode,
                "sensors": list(spec.sensors),
                "permissions": spec.permissions_payload(),
                "model": {"provider": spec.model.get("provider"), "model": spec.model.get("model")},
                "agent": dict(agent_binding()),
                "max_turns": spec.max_turns,
                "max_steps": spec.max_steps,
                "wall_seconds": spec.wall_seconds,
                "pi_command": command,
                **_panel_binding_fields(spec),
            },
        )

        try:
            observation = runtime.reset()
        except Exception as exc:  # noqa: BLE001
            fatal = bool(getattr(exc, "fatal", False))
            code = str(getattr(exc, "code", "") or type(exc).__name__)
            stream.append(
                "error",
                {
                    "stage": "reset",
                    "code": code if fatal else None,
                    "error": f"{type(exc).__name__}: {exc}",
                },
            )
            if fatal:
                result.extra = {
                    **dict(result.extra),
                    "fatal_tool_runtime": {
                        "code": code,
                        "detail": str(getattr(exc, "detail", "") or exc),
                        "recorded": bool(getattr(exc, "recorded", False)),
                    },
                }
            return self._finish(
                result,
                stream,
                status="error",
                reason=f"simulator_fatal:{code}" if fatal else "reset_error",
                state=_RunState(),
                spec=spec,
                signer=signer,
                runtime=runtime,
            )

        visible = filter_observation(observation, spec.sensors)
        record_evidence_frame(
            stream,
            spec,
            observation,
            frame_collector=frame_collector,
            correlation_id="step:0",
        )
        if self._is_blank_observation(visible):
            stream.append("error", {"stage": "reset", "error": "runtime returned no observation"})
            return self._finish(
                result,
                stream,
                status="error",
                reason="reset_error",
                state=_RunState(),
                spec=spec,
                signer=signer,
                runtime=runtime,
            )

        model_spec = from_evaluation_spec(spec.raw)
        state = _RunState()
        bridge = ToolBridge(runtime, spec, stream, state, frame_collector=frame_collector)
        bridge_url = bridge.start()
        prompt_file: pathlib.Path | None = None
        process: subprocess.Popen | None = None
        stderr_tail: list[str] = []
        settled = False
        reason = "agent_settled"
        status = "ok"

        try:
            system_path = options.get("system_prompt_file")
            if system_path:
                prompt_file = pathlib.Path(str(system_path)).expanduser()
            else:
                handle = tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8")
                handle.write(system_prompt())
                handle.close()
                prompt_file = pathlib.Path(handle.name)

            extra = [str(item) for item in options.get("args") or []]
            cmd = command + ["--mode", "rpc", "--no-session", "--no-builtin-tools"]
            extension = options.get("extension", str(_EXTENSION_PATH))
            if extension:
                cmd += ["--extension", str(extension)]
            if prompt_file is not None:
                cmd += ["--system-prompt", str(prompt_file)]
            provider = str(options.get("provider") or model_spec.provider)
            model_name = str(options.get("pi_model") or model_spec.model)
            cmd += ["--model", f"{provider}/{model_name}"]
            if model_spec.effort:
                cmd += ["--thinking", str(model_spec.effort)]
            cmd += extra

            process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                env=self._pi_env(model_spec, bridge_url, bridge.token),
                cwd=options.get("cwd"),
            )
            records: queue.Queue[dict[str, Any] | None] = queue.Queue()
            self._pump(process, records, stderr_tail)

            text, image = observation_text(visible, runtime.instruction)
            prompt: dict[str, Any] = {"id": "prompt-1", "type": "prompt", "message": text}
            if image is not None:
                prompt["images"] = [
                    {
                        "type": "image",
                        "data": str(image.get("data_base64") or ""),
                        "mimeType": str(image.get("mime_type") or "image/png"),
                    }
                ]
            self._send(process, prompt)

            deadline = time.monotonic() + spec.wall_seconds
            while True:
                if state.fatal is not None:
                    stream.append(
                        "error",
                        {
                            "stage": "tool_runtime",
                            "code": state.fatal.code,
                            "error": f"{type(state.fatal).__name__}: {state.fatal}",
                            "recorded": state.fatal.recorded,
                        },
                    )
                    result.extra = {
                        **dict(result.extra),
                        "fatal_tool_runtime": {
                            "code": state.fatal.code,
                            "detail": state.fatal.detail,
                            "recorded": state.fatal.recorded,
                        },
                    }
                    status = "error"
                    reason = f"simulator_fatal:{state.fatal.code}"
                    break
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    reason = "wall_time"
                    status = "error"
                    break
                try:
                    record = records.get(timeout=min(remaining, 1.0))
                except queue.Empty:
                    if process.poll() is not None:
                        reason = "pi_exit"
                        status = "error"
                        break
                    continue
                if record is None:
                    reason = "pi_exit"
                    status = "error"
                    break
                self._handle_record(record, spec, stream, state, process, bridge)
                if state.fatal is not None:
                    continue
                if record.get("type") == "agent_settled":
                    settled = True
                    break
                if record.get("type") == "response" and record.get("command") == "prompt":
                    if record.get("success") is False:
                        state.error = str(record.get("error") or "prompt rejected")
                        status = "error"
                        reason = "prompt_rejected"
                        break
            if not settled and status == "ok":
                reason = "agent_end"
        except Exception as exc:  # noqa: BLE001 - any adapter failure is a recorded run error
            stream.append("error", {"stage": "pi", "error": f"{type(exc).__name__}: {exc}"})
            status = "error"
            reason = "pi_error"
        finally:
            bridge.stop()
            if process is not None:
                if not settled and process.poll() is None:
                    try:
                        self._send(process, {"type": "abort", "id": "abort-1"})
                    except Exception:  # noqa: BLE001
                        pass
                self._shutdown(process)
            if prompt_file is not None and not options.get("system_prompt_file"):
                prompt_file.unlink(missing_ok=True)

        if stderr_tail:
            stream.append("pi_stderr", {"lines": stderr_tail[-20:]})
        if state.success:
            reason = "success"
        return self._finish(
            result,
            stream,
            status=status,
            reason=reason,
            state=state,
            spec=spec,
            signer=signer,
            runtime=runtime,
        )

    @staticmethod
    def _is_blank_observation(observation: Mapping[str, Any]) -> bool:
        return not any(value for key, value in observation.items() if key not in {"step", "instruction"})

    @staticmethod
    def _pi_env(model_spec: Any, bridge_url: str, token: str) -> dict[str, str]:
        env = {key: os.environ[key] for key in _ENV_KEEP if key in os.environ}
        env["PI_HARNESS_BRIDGE"] = bridge_url
        env["PI_HARNESS_TOKEN"] = token
        key_env = model_spec.api_key_env or DEFAULT_API_KEY_ENV.get(model_spec.provider)
        if key_env and os.environ.get(key_env):
            env[key_env] = os.environ[key_env]
        return env

    @staticmethod
    def _pump(process: subprocess.Popen, records: queue.Queue, stderr_tail: list[str]) -> None:
        def read() -> None:
            assert process.stdout is not None
            for line in process.stdout:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.put(json.loads(line))
                except ValueError:
                    records.put({"type": "parse_error", "line": line})
            records.put(None)

        def read_stderr() -> None:
            assert process.stderr is not None
            for line in process.stderr:
                stderr_tail.append(line.rstrip())
                if len(stderr_tail) > 50:
                    stderr_tail.pop(0)

        threading.Thread(target=read, name="pi-stdout", daemon=True).start()
        threading.Thread(target=read_stderr, name="pi-stderr", daemon=True).start()

    @staticmethod
    def _send(process: subprocess.Popen, record: Mapping[str, Any]) -> None:
        assert process.stdin is not None
        process.stdin.write(json.dumps(dict(record), ensure_ascii=False) + "\n")
        process.stdin.flush()

    def _handle_record(
        self,
        record: Mapping[str, Any],
        spec: HarnessSpec,
        stream: EventStream,
        state: _RunState,
        process: subprocess.Popen,
        bridge: ToolBridge,
    ) -> None:
        kind = record.get("type")
        if kind == "message_end":
            message = record.get("message") or {}
            if message.get("role") == "assistant":
                text = _message_text(message)
                stream.append(
                    "pi_message",
                    {
                        "content": text,
                        "content_sha256": canonical_sha256(text),
                        "tool_calls": _message_tool_calls(message),
                        "usage": message.get("usage") or {},
                        "stop_reason": message.get("stopReason"),
                    },
                )
        elif kind == "tool_execution_start":
            stream.append(
                "pi_tool_execution",
                {
                    "phase": "start",
                    "tool_call_id": record.get("toolCallId"),
                    "tool": record.get("toolName"),
                    "args_sha256": canonical_sha256(record.get("args") or {}),
                },
            )
        elif kind == "tool_execution_end":
            stream.append(
                "pi_tool_execution",
                {
                    "phase": "end",
                    "tool_call_id": record.get("toolCallId"),
                    "tool": record.get("toolName"),
                    "is_error": bool(record.get("isError")),
                    "duration_ms": record.get("durationMs"),
                    "result_sha256": canonical_sha256(record.get("result") or {}),
                },
            )
        elif kind in {"extension_error", "parse_error"}:
            state.error = str(record.get("error") or record.get("line") or kind)
            stream.append("pi_error", {"type": kind, "detail": dict(record)})
        elif kind in {"agent_start", "turn_start", "turn_end", "agent_end"}:
            stream.append("pi_event", {"type": kind})
        elif kind == "message_update" and (record.get("assistantMessageEvent") or {}).get("type") == "error":
            state.error = str((record.get("assistantMessageEvent") or {}).get("error") or "assistant error")
            stream.append("pi_error", {"type": "assistant", "detail": dict(record)})
        elif kind == "abort_requested":
            stream.append("pi_event", {"type": kind})
        if record.get("type") == "agent_settled" and not state.success:
            ok, detail = self._runtime_success(bridge)
            state.success = bool(ok)
            state.detail = dict(detail)

    @staticmethod
    def _runtime_success(bridge: ToolBridge) -> tuple[bool, Mapping[str, Any]]:
        try:
            return bridge.runtime.success()
        except Exception as exc:  # noqa: BLE001
            return False, {"error": f"{type(exc).__name__}: {exc}"}

    @staticmethod
    def _shutdown(process: subprocess.Popen) -> None:
        try:
            if process.stdin is not None:
                process.stdin.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:  # pragma: no cover
                process.kill()
                process.wait(timeout=5)
        for stream in (process.stdout, process.stderr):
            if stream is not None:
                try:
                    stream.close()
                except Exception:  # noqa: BLE001
                    pass

    @staticmethod
    def _finish(
        result: RunResult,
        stream: EventStream,
        *,
        status: str,
        reason: str,
        state: _RunState,
        spec: HarnessSpec | None = None,
        signer: Any = None,
        runtime: Any = None,
    ) -> RunResult:
        metering: dict[str, Any] | None = None
        if spec is not None:
            # OPE-198：Pi 的 usage 在各条 pi_message 上，计量同样进签名链。
            measurement = measure(spec.raw, stream.events, runtime)
            metering = measurement.payload()
            stream.append("usage_summary", metering)
        stream.append(
            "run_end",
            {
                "status": status,
                "reason": reason,
                "success": state.success,
                "steps": state.steps,
                "tool_calls": state.tool_calls,
                "detail": dict(state.detail),
                "error": state.error,
            },
        )
        result.events = list(stream.events)
        result.root = stream.root
        result.status = status
        result.reason = reason
        result.success = state.success
        result.steps = state.steps
        result.turns = 0
        extra: dict[str, Any] = {"tool_calls": state.tool_calls, "error": state.error}
        if metering is not None:
            extra["metering"] = metering
        result.extra = extra
        if spec is not None:
            sign_run_evidence(result, stream, spec, signer)
        return result


def _message_tool_calls(message: Mapping[str, Any]) -> list[dict[str, Any]]:
    content = message.get("content")
    if not isinstance(content, list):
        return []
    calls = []
    for block in content:
        if isinstance(block, Mapping) and block.get("type") == "toolCall":
            calls.append({
                "id": block.get("id") or block.get("toolCallId"),
                "name": block.get("name") or block.get("toolName"),
                "args_sha256": canonical_sha256(block.get("arguments") or block.get("args") or {}),
            })
    return calls


def _message_text(message: Mapping[str, Any]) -> str:
    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(str(block.get("text") or "") for block in content if isinstance(block, Mapping))
    return ""


__all__ = ["PiHarness", "ToolBridge"]


def _panel_binding_fields(spec: Any) -> dict[str, Any]:
    """A 参照组绑定字段；没有绑定（B 默认）时返回空。"""
    binding = getattr(spec, "panel_binding", None)
    if not binding:
        return {}
    keys = (
        "run_id",
        "panel",
        "member",
        "kind",
        "trial",
        "package_digest",
        "version_digest",
        "config_version",
        "config_digest",
        "settlement",
    )
    return {key: binding[key] for key in keys if key in binding}
