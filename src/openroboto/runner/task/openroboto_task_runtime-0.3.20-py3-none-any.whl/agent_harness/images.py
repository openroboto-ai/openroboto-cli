"""Small stdlib-only image helpers (PNG encode + observation payload)."""

from __future__ import annotations

import base64
import hashlib
import struct
import zlib
from typing import Any


def _chunk(kind: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)


def png_bytes(width: int, height: int, rgb: tuple[int, int, int] = (0, 0, 0)) -> bytes:
    """Encode an 8-bit RGB PNG without third-party dependencies."""

    if width < 1 or height < 1:
        raise ValueError("width and height must be positive")
    row = bytes(rgb) * width
    raw = b"".join(b"\x00" + row for _ in range(height))
    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return _png(header, raw)


def png_from_rgb(pixels: Any) -> bytes:
    """Encode an ``(height, width, 3)`` uint8 array (NumPy or nested lists)."""

    rows = []
    for row in pixels:
        values = bytearray()
        for pixel in row:
            red, green, blue = (int(channel) for channel in pixel[:3])
            values.extend((max(0, min(255, red)), max(0, min(255, green)), max(0, min(255, blue))))
        rows.append(bytes(values))
    if not rows:
        raise ValueError("image has no rows")
    height = len(rows)
    width = len(rows[0]) // 3
    raw = b"".join(b"\x00" + row for row in rows)
    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return _png(header, raw)


def _png(header: bytes, raw: bytes) -> bytes:
    return (
        b"\x89PNG\r\n\x1a\n" + _chunk(b"IHDR", header) + _chunk(b"IDAT", zlib.compress(raw, 9)) + _chunk(b"IEND", b"")
    )


def image_payload(data: bytes, mime_type: str = "image/png") -> dict[str, str]:
    """A JSON-safe image observation: base64 bytes plus content hash."""

    return {
        "mime_type": mime_type,
        "data_base64": base64.b64encode(data).decode("ascii"),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": str(len(data)),
    }


def placeholder(width: int = 320, height: int = 180) -> dict[str, str]:
    return image_payload(png_bytes(width, height))


__all__ = ["image_payload", "placeholder", "png_bytes", "png_from_rgb"]
