"""一次 run 的成本与仿真时长：只报能复算的数，未知就是未知（OPE-198）。

这里不做任何估算：

* ``api_cost_usd`` 只从**签名事件链里 provider 自己返回的 token usage** 出发，
  乘以运营方提供的价目表。价目表按冻结 spec 的
  ``delivery.price_list_version`` 取；版本对不上、没有价目表、某次调用没有
  usage，都返回 ``unknown``，**绝不拿 0 当测量值**。
* ``sim_time_s`` 只从仿真器自己的时钟读（MuJoCo ``data.time`` / 仿真器返回的
  ``sim_time_s``）。没有仿真时钟（例如 scenario 夹具）就是 ``unknown``；墙钟
  和 ``steps × control_step`` 都不是仿真时钟，不能混进来。

价目表不只是「同名文件」：版本必须绑定到**不可变内容摘要**。执行机从
``AGENT_PRICE_LIST_BINDINGS``（``{"version": "<sha256>"}``）或
``AGENT_PRICE_LIST_SHA256``（单版本）拿运营签发的期望摘要，价目表内容的
canonical SHA-256 必须逐字相等；否则按未知拒绝。本次实际使用的分项单价、
内容摘要与 token 汇总都会写进 ``usage_summary``，脱离本地文件也能复算。

0 是合法测量值的唯一情形是**有证据表明确实是 0**：整条链一次模型调用都没有
（``no_model_calls``），或者所有调用都带 usage 且 token 合计为 0。

价目表由运营配置，代码里没有任何单价常量。文件格式见
:func:`load_price_list`；路径来自环境变量 ``AGENT_PRICE_LIST_PATH``。
"""

from __future__ import annotations

import json
import math
import os
import pathlib
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Iterable, Mapping

from .canonical import canonical_sha256

#: 计量记录本身的格式版本，写进事件链，便于日后复算。
MEASUREMENT_VERSION = 1

#: 与后端 ``fee_ledger.api_cost_usd numeric(20, 6)`` 相同的精度。
USD_QUANTUM = Decimal("0.000001")

#: 运营价目表文件。内容不进冻结 spec，版本由 spec 冻结。
PRICE_LIST_ENV = "AGENT_PRICE_LIST_PATH"
#: 版本 → 不可变内容摘要（运营签发，执行机只读）。
PRICE_LIST_BINDINGS_ENV = "AGENT_PRICE_LIST_BINDINGS"
#: 单版本简写；与 bindings 同时存在时 bindings 优先。
PRICE_LIST_SHA256_ENV = "AGENT_PRICE_LIST_SHA256"

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_SUPPORTED_CURRENCY = "USD"
_SUPPORTED_UNIT = "per_million_tokens"
_PRICE_FIELDS = (
    "input_usd_per_million_tokens",
    "output_usd_per_million_tokens",
    "cache_read_usd_per_million_tokens",
    "cache_creation_usd_per_million_tokens",
)

_TOKENS_PER_UNIT = Decimal(1_000_000)

#: ``model_call`` 是 headless 的事件；``pi_message`` 是 Pi harness 的模型回复。
_USAGE_EVENT_TYPES = ("model_call", "pi_message")


class MeteringUnavailable(RuntimeError):
    """调用方要求必须有测量值，但这次 run 有无法计量的字段。"""


@dataclass(frozen=True)
class PriceList:
    """已核对币种、单位与版本摘要的运营价目表。"""

    version: str
    sha256: str
    document: Mapping[str, Any]
    models: Mapping[str, Any]
    #: 摘要从哪来：frozen_spec（冻结 spec 自带）或 operator_env（执行机绑定）。
    binding_source: str = "operator_env"

    def price_for(self, provider: str | None, model: str | None) -> tuple[Mapping[str, Any] | None, str, str]:
        keys: list[str] = []
        if provider and model:
            keys.append(f"{provider}/{model}")
        if model:
            keys.append(model)
        for key in keys:
            entry = self.models.get(key)
            if isinstance(entry, Mapping):
                if self.document.get("billing_mode") == "subscription":
                    floor = entry.get("min_remaining_percent")
                    if (
                        isinstance(floor, bool)
                        or not isinstance(floor, (int, float))
                        or not 0 <= floor < 100
                        or any(
                            not isinstance(entry.get(k), str) or not entry[k]
                            for k in ("quota_provider", "quota_plan", "quota_window")
                        )
                    ):
                        return None, "", "subscription_policy_invalid"
                    if any("usd" in k for k in entry):
                        return None, "", "subscription_policy_cannot_claim_usd_prices"
                return entry, key, ""
        return None, "", "price_list_model_missing"


@dataclass(frozen=True)
class Measurement:
    """一次 run 的计量结果。``None`` 表示未知，``0`` 表示有证明的 0。"""

    price_list_version: str | None
    usage: Mapping[str, Any]
    api_cost_usd: Decimal | None
    api_cost_source: str
    api_cost_reason: str
    sim_time_s: float | None
    sim_time_source: str
    sim_time_reason: str
    price_list: Mapping[str, Any] | None = None

    @property
    def api_cost_known(self) -> bool:
        return self.api_cost_usd is not None

    @property
    def api_cost_usd_text(self) -> str | None:
        return _decimal_text(self.api_cost_usd)

    @property
    def sim_time_known(self) -> bool:
        return self.sim_time_s is not None

    def payload(self) -> dict[str, Any]:
        """JSON-safe 记录；写进事件链和 ``RunResult.extra``。"""

        return {
            "measurement_version": MEASUREMENT_VERSION,
            "price_list_version": self.price_list_version,
            "price_list": dict(self.price_list) if self.price_list is not None else None,
            "usage": dict(self.usage),
            "api_cost_usd": {
                "status": "measured" if self.api_cost_known else "unknown",
                "value": _decimal_text(self.api_cost_usd) if self.api_cost_known else None,
                "unit": "USD",
                "source": self.api_cost_source,
                **({} if self.api_cost_known else {"reason": self.api_cost_reason}),
            },
            "sim_time_s": {
                "status": "measured" if self.sim_time_known else "unknown",
                "value": self.sim_time_s,
                "unit": "s",
                "source": self.sim_time_source,
                **({} if self.sim_time_known else {"reason": self.sim_time_reason}),
            },
        }


def _decimal_text(value: Decimal | None) -> str | None:
    if value is None:
        return None
    # 与后端 numeric(20, 6) 对齐；0 也写成 0.000000，避免和「未上报」混淆。
    return format(value.quantize(USD_QUANTUM), "f")


def _price_text(value: Decimal) -> str:
    """单价原文（不量化）：离线复算必须能逐位还原计算时用的值。"""

    return format(value, "f")


def _as_decimal(value: Any) -> Decimal | None:
    if isinstance(value, bool):
        return None
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None
    if not parsed.is_finite() or parsed < 0:
        return None
    return parsed


def _as_non_negative_int(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value if value >= 0 else None


def _usage_tokens(usage: Any) -> dict[str, int] | None:
    """把一次调用的 usage 归一成可计价的分项；拆不出来就返回 ``None``。

    只有 ``total_tokens`` 没有输入/输出拆分时不能乘单价（否则等于猜），
    按「这次调用未计量」处理。
    """

    if not isinstance(usage, Mapping):
        return None
    input_tokens = _as_non_negative_int(usage.get("input_tokens", usage.get("prompt_tokens")))
    output_tokens = _as_non_negative_int(usage.get("output_tokens", usage.get("completion_tokens")))
    if input_tokens is None or output_tokens is None:
        return None
    tokens = {"input_tokens": input_tokens, "output_tokens": output_tokens}
    for key in ("cache_read_input_tokens", "cache_creation_input_tokens"):
        value = usage.get(key)
        if value is not None:
            parsed = _as_non_negative_int(value)
            if parsed is None:
                return None
            tokens[key] = parsed
    return tokens


def summarize_usage(events: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """汇总事件链里的模型调用与 token 用量。

    ``unmetered_calls`` 包括：模型调用成功但没回 usage（或只回了 total），
    以及 ``error.stage=model_call`` 这种发了请求却拿不到 usage 的失败调用。
    只要有一项未计量，整体成本就是未知 —— 只算已知部分会静默漏算。
    """

    calls = 0
    metered = 0
    unmetered = 0
    input_tokens = 0
    output_tokens = 0
    cache_read = 0
    cache_creation = 0
    provider: str | None = None
    api_format: str | None = None
    model: str | None = None

    for event in events:
        kind = event.get("type")
        payload = event.get("payload")
        payload = payload if isinstance(payload, Mapping) else {}
        if kind == "run_start":
            declared = payload.get("model") if isinstance(payload.get("model"), Mapping) else {}
            provider = provider or declared.get("provider")
            model = model or declared.get("model")
            continue
        if kind in _USAGE_EVENT_TYPES:
            calls += 1
            if kind == "model_call":
                meta = payload.get("provider_meta")
                meta = meta if isinstance(meta, Mapping) else {}
                provider = provider or meta.get("provider")
                api_format = api_format or meta.get("api_format")
                model = model or meta.get("model")
            tokens = _usage_tokens(payload.get("usage"))
            if tokens is None:
                unmetered += 1
                continue
            metered += 1
            input_tokens += tokens["input_tokens"]
            output_tokens += tokens["output_tokens"]
            cache_read += tokens.get("cache_read_input_tokens", 0)
            cache_creation += tokens.get("cache_creation_input_tokens", 0)
            continue
        if kind == "error" and payload.get("stage") == "model_call":
            # 请求已经发出（provider 可能已经计费），但链上没有 usage。
            calls += 1
            unmetered += 1

    return {
        "calls": calls,
        "metered_calls": metered,
        "unmetered_calls": unmetered,
        "input_tokens": input_tokens if metered else None,
        "output_tokens": output_tokens if metered else None,
        "cache_read_input_tokens": cache_read if metered else None,
        "cache_creation_input_tokens": cache_creation if metered else None,
        "provider": provider,
        "api_format": api_format,
        "model": model,
    }


def price_list_sha256(document: Mapping[str, Any]) -> str:
    """价目表内容的 canonical SHA-256（键排序、无空白差异）。"""

    return canonical_sha256(dict(document))


def _expected_price_list_sha256(version: str) -> tuple[str | None, str]:
    """运营签发的「版本 → 内容摘要」绑定；没有绑定就不计价。"""

    raw_bindings = os.environ.get(PRICE_LIST_BINDINGS_ENV)
    if raw_bindings:
        try:
            bindings = json.loads(raw_bindings)
        except ValueError:
            return None, "price_list_bindings_unreadable"
        if not isinstance(bindings, Mapping):
            return None, "price_list_bindings_invalid"
        value = bindings.get(version)
        if not value:
            return None, "price_list_binding_missing"
        expected = str(value).strip().lower()
        if not _SHA256_RE.match(expected):
            return None, "price_list_binding_invalid"
        return expected, ""
    single = os.environ.get(PRICE_LIST_SHA256_ENV)
    if single:
        expected = str(single).strip().lower()
        if not _SHA256_RE.match(expected):
            return None, "price_list_binding_invalid"
        return expected, ""
    return None, "price_list_binding_missing"


def load_price_list(
    version: str | None,
    *,
    path: str | os.PathLike[str] | None = None,
    expected_sha256: str | None = None,
) -> tuple[PriceList | None, str]:
    """读取运营价目表并核对版本、币种、单位与不可变内容摘要。

    文件由运营提供（``AGENT_PRICE_LIST_PATH``），形如::

        {
          "version": "2026-10-01",
          "currency": "USD",
          "unit": "per_million_tokens",
          "models": {
            "deepseek/deepseek-flash": {
              "input_usd_per_million_tokens": "0.27",
              "output_usd_per_million_tokens": "1.10"
            }
          }
        }

    美元策略使用每百万 token 单位；显式订阅策略只记录请求与 token，不分摊美元。
    只有 ``currency == "USD"`` 且内容摘要等于运营绑定（
    ``AGENT_PRICE_LIST_BINDINGS`` / ``AGENT_PRICE_LIST_SHA256``）时才返回可用
    价目表。缺价、版本不一致、摘要不一致、文件不可读都返回原因，由调用方
    记为 ``unknown``；这里不猜价格。
    """

    if not version:
        return None, "price_list_version_missing"
    location = path if path is not None else os.environ.get(PRICE_LIST_ENV)
    if not location:
        return None, "price_list_not_configured"
    candidate = pathlib.Path(location).expanduser()
    try:
        data = json.loads(candidate.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None, "price_list_not_found"
    except (OSError, ValueError):
        return None, "price_list_unreadable"
    if not isinstance(data, Mapping):
        return None, "price_list_invalid"
    declared_version = data.get("version")
    if str(declared_version or "") != str(version):
        return None, "price_list_version_mismatch"
    subscription = data.get("billing_mode") == "subscription"
    if data.get("billing_mode", "token_usd") not in {"token_usd", "subscription"}:
        return None, "billing_mode_unsupported"
    if subscription:
        if data.get("currency") != "N/A" or data.get("unit") != "requests_and_tokens":
            return None, "subscription_policy_units_invalid"
        if type(data.get("max_requests")) is not int or data["max_requests"] < 1:
            return None, "subscription_policy_limit_invalid"
    elif str(data.get("currency") or "").upper() != _SUPPORTED_CURRENCY:
        return None, "price_list_currency_unsupported"
    if not subscription and data.get("unit") != _SUPPORTED_UNIT:
        return None, "price_list_unit_unsupported"
    models = data.get("models")
    if not isinstance(models, Mapping):
        return None, "price_list_models_missing"
    digest = price_list_sha256(data)
    if expected_sha256 is not None:
        expected = str(expected_sha256).strip().lower()
        if not _SHA256_RE.match(expected):
            return None, "price_list_binding_invalid"
        binding_source = "frozen_spec"
    else:
        expected, reason = _expected_price_list_sha256(str(version))
        if expected is None:
            return None, reason
        binding_source = "operator_env"
    if digest != expected:
        return None, "price_list_binding_mismatch"
    return (
        PriceList(
            version=str(version),
            sha256=digest,
            document=data,
            models=models,
            binding_source=binding_source,
        ),
        "",
    )


def _cost_from_usage(
    usage: Mapping[str, Any],
    price: Mapping[str, Any],
) -> tuple[Decimal | None, str, Mapping[str, str] | None]:
    """usage × 价目表。任一必需分项缺价就返回未知，不部分计价。

    返回 ``(成本, 失败原因, 本次实际使用的分项单价)``；单价同时写进事件链，
    使成本脱离本地价目表也能复算。
    """

    input_tokens = int(usage.get("input_tokens") or 0)
    output_tokens = int(usage.get("output_tokens") or 0)
    cache_read = int(usage.get("cache_read_input_tokens") or 0)
    cache_creation = int(usage.get("cache_creation_input_tokens") or 0)

    api_format = usage.get("api_format")
    if cache_read or cache_creation:
        if api_format == "openai":
            # OpenAI 兼容接口的 prompt_tokens 已包含 cached_tokens。
            billable_input = input_tokens - cache_read
        elif api_format == "anthropic":
            # Anthropic 的 input_tokens 不含缓存读写，缓存另列。
            billable_input = input_tokens
        else:
            return None, "api_format_unknown_for_cache_pricing", None
        if billable_input < 0:
            return None, "usage_cache_exceeds_input", None
    else:
        billable_input = input_tokens

    # 单价按原精度入档；只有最终美元金额才按账本 6 位量化。截短单价会让
    # 离线复算与上报金额对不上（OPE-198 打回 R2）。
    # 只在对应 token 非零时要求该分项有价；缓存-only 允许价目表省略
    # input/output（0 贡献），但缓存单价必须给出。
    used: dict[str, str] = {}
    input_price = _as_decimal(price.get("input_usd_per_million_tokens"))
    if billable_input > 0:
        if input_price is None:
            return None, "price_list_input_price_missing", None
    if input_price is not None:
        used["input_usd_per_million_tokens"] = _price_text(input_price)
    output_price = _as_decimal(price.get("output_usd_per_million_tokens"))
    if output_tokens > 0:
        if output_price is None:
            return None, "price_list_output_price_missing", None
    if output_price is not None:
        used["output_usd_per_million_tokens"] = _price_text(output_price)

    total = Decimal(billable_input) * (input_price or Decimal(0)) + Decimal(output_tokens) * (
        output_price or Decimal(0)
    )
    if cache_read:
        cache_read_price = _as_decimal(price.get("cache_read_usd_per_million_tokens"))
        if cache_read_price is None:
            return None, "price_list_cache_read_price_missing", None
        used["cache_read_usd_per_million_tokens"] = _price_text(cache_read_price)
        total += Decimal(cache_read) * cache_read_price
    if cache_creation:
        cache_creation_price = _as_decimal(price.get("cache_creation_usd_per_million_tokens"))
        if cache_creation_price is None:
            return None, "price_list_cache_creation_price_missing", None
        used["cache_creation_usd_per_million_tokens"] = _price_text(cache_creation_price)
        total += Decimal(cache_creation) * cache_creation_price

    return (total / _TOKENS_PER_UNIT).quantize(USD_QUANTUM, rounding=ROUND_HALF_UP), "", used


def read_sim_time(runtime: Any) -> tuple[float | None, str, str]:
    """从 runtime 的仿真时钟读数。返回 ``(秒, 来源, 失败原因)``。

    只有 runtime 自己实现的 ``sim_time_s()`` 才算数；scenario 夹具没有物理
    时钟，返回 ``None``，由 :func:`measure` 记为未知。
    """

    reader = getattr(runtime, "sim_time_s", None)
    if not callable(reader):
        return None, "runtime_has_no_sim_clock", "runtime_has_no_sim_clock"
    try:
        raw = reader()
    except Exception as exc:  # noqa: BLE001 - a broken clock is unknown, not zero
        return None, "simulator_clock", f"sim_clock_error:{type(exc).__name__}"
    if raw is None:
        return None, "simulator_clock", "sim_clock_unavailable"
    if isinstance(raw, bool):
        return None, "simulator_clock", "sim_clock_invalid"
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return None, "simulator_clock", "sim_clock_invalid"
    if not math.isfinite(value) or value < 0:
        return None, "simulator_clock", "sim_clock_invalid"
    return value, "simulator_clock", ""


def measure(
    spec_raw: Mapping[str, Any] | None,
    events: Iterable[Mapping[str, Any]],
    runtime: Any = None,
) -> Measurement:
    """从已发生的事件链和 runtime 时钟算出这次 run 的计量结果。"""

    event_list = list(events)
    usage = summarize_usage(event_list)
    delivery = spec_raw.get("delivery") if isinstance(spec_raw, Mapping) else None
    delivery = delivery if isinstance(delivery, Mapping) else {}
    version = delivery.get("price_list_version")
    version = str(version) if version else None
    # 冻结 spec 自带的价目表摘要是权威绑定，优先于执行机上的运营绑定。
    spec_price_digest = delivery.get("price_list_sha256")

    api_cost: Decimal | None = None
    api_source = "provider_usage"
    api_reason = ""
    price_meta: dict[str, Any] | None = None
    if usage["unmetered_calls"]:
        api_reason = "usage_missing_for_some_model_calls"
    elif usage["calls"] == 0:
        api_cost = Decimal("0")
        api_source = "no_model_calls"
    elif not any(
        usage.get(key)
        for key in (
            "input_tokens",
            "output_tokens",
            "cache_read_input_tokens",
            "cache_creation_input_tokens",
        )
    ):
        # provider 明确回了 0 token：不管单价多少，成本都是 0。这是有证明的 0。
        api_cost = Decimal("0")
        api_source = "zero_token_usage"
    else:
        price_list, reason = load_price_list(
            version,
            expected_sha256=spec_price_digest if spec_price_digest else None,
        )
        if price_list is None:
            api_reason = reason
        else:
            price, model_key, reason = price_list.price_for(usage.get("provider"), usage.get("model"))
            if price is None:
                api_reason = reason
            elif price_list.document.get("billing_mode") == "subscription":
                api_source = "subscription_usage"
                api_reason = "subscription_usd_not_allocated"
                price_meta = {
                    "version": price_list.version,
                    "sha256": price_list.sha256,
                    "model_key": model_key,
                    "currency": "N/A",
                    "unit": "requests_and_tokens",
                    "binding_source": price_list.binding_source,
                    "prices": {},
                }
            else:
                api_cost, api_reason, used = _cost_from_usage(usage, price)
                if api_cost is not None:
                    api_source = "provider_usage_x_price_list"
                    price_meta = {
                        "version": price_list.version,
                        "sha256": price_list.sha256,
                        "model_key": model_key,
                        "currency": _SUPPORTED_CURRENCY,
                        "unit": _SUPPORTED_UNIT,
                        "binding_source": price_list.binding_source,
                        "prices": dict(used or {}),
                    }

    sim_time, sim_source, sim_reason = read_sim_time(runtime)
    return Measurement(
        price_list_version=version,
        usage=usage,
        api_cost_usd=api_cost,
        api_cost_source=api_source,
        api_cost_reason=api_reason,
        sim_time_s=sim_time,
        sim_time_source=sim_source,
        sim_time_reason=sim_reason,
        price_list=price_meta,
    )


def unknown_fields(record: Mapping[str, Any]) -> list[str]:
    """从已序列化的计量记录里列出未知项（给交付策略用）。"""

    missing: list[str] = []
    for key in ("api_cost_usd", "sim_time_s"):
        item = record.get(key)
        item = item if isinstance(item, Mapping) else {}
        if item.get("status") != "measured":
            missing.append(f"{key}({item.get('reason') or 'unknown'})")
    return missing


def require_measured(measurement: Measurement) -> None:
    """交付前显式拒绝未知（``AGENT_UNKNOWN_METERING_POLICY=fail``）。"""

    missing = unknown_fields(measurement.payload())
    if missing:
        raise MeteringUnavailable("这次 run 的成本/时长无法计量：" + ", ".join(missing))


__all__ = [
    "MEASUREMENT_VERSION",
    "MeteringUnavailable",
    "Measurement",
    "PRICE_LIST_BINDINGS_ENV",
    "PRICE_LIST_ENV",
    "PRICE_LIST_SHA256_ENV",
    "PriceList",
    "USD_QUANTUM",
    "load_price_list",
    "measure",
    "price_list_sha256",
    "read_sim_time",
    "require_measured",
    "summarize_usage",
    "unknown_fields",
]
