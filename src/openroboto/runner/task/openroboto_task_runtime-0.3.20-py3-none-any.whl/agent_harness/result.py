"""The object returned by ``agent_harness.run``."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterator, Mapping


@dataclass
class RunResult:
    """A completed (or failed) harness run.

    ``run(spec)`` returns this object; iterating it yields the evidence events,
    so ``for event in run(spec)`` matches the ``run(spec) -> events`` contract.
    """

    run_id: str
    attempt_id: str | None
    harness: str
    source: str
    task_id: str
    instance: int
    #: 评测模式。结果按 mode 分开记录，跨模式不混榜。
    mode: str = ""
    #: 生效的逐字段权限声明（见 ``agent_harness.modes``）。
    permissions: Mapping[str, Any] = field(default_factory=dict)
    #: OPE-124 隔离档位与生效的隔离属性。结果按档位分开看，不混在一起比较。
    assurance_profile: str = ""
    assurance: Mapping[str, Any] = field(default_factory=dict)
    events: list[dict[str, Any]] = field(default_factory=list)
    root: str = ""
    status: str = "ok"
    success: bool = False
    reason: str = ""
    turns: int = 0
    steps: int = 0
    evidence_path: str | None = None
    #: 真的 PUT 进对象存储的帧（``[{"seq", "sha256"}]``）。交付请求原样带它；
    #: 上传失败的帧不在这里，后端按 ``missing`` 处理。
    frame_uploads: list[dict[str, Any]] = field(default_factory=list)
    extra: Mapping[str, Any] = field(default_factory=dict)

    def __iter__(self) -> Iterator[dict[str, Any]]:
        return iter(self.events)

    def __len__(self) -> int:
        return len(self.events)

    def of_type(self, kind: str) -> list[dict[str, Any]]:
        return [event for event in self.events if event.get("type") == kind]

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "attempt_id": self.attempt_id,
            "harness": self.harness,
            "source": self.source,
            "task_id": self.task_id,
            "instance": self.instance,
            "mode": self.mode,
            "permissions": dict(self.permissions),
            "assurance_profile": self.assurance_profile,
            "assurance": dict(self.assurance),
            "root": self.root,
            "status": self.status,
            "success": self.success,
            "reason": self.reason,
            "turns": self.turns,
            "steps": self.steps,
            "events": len(self.events),
            "evidence_path": self.evidence_path,
            "frame_uploads": [dict(item) for item in self.frame_uploads],
            "extra": dict(self.extra),
        }


__all__ = ["RunResult"]
