"""Original pre-start material for the explicit, Operator-authorized recovery.

This capture is not an authorization or an empty-ledger fallback. The root
parent must separately verify its independently installed Operator grant and
quiescence before using these bytes to prepare a recovery transaction.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import math
from pathlib import Path
import stat

from task_source.scene_recovery import digest, require, stable_work, HEX
from task_source.scene_views.identity import decode, encoded

EMPTY_DIRECTORIES = ("specs", "results", "started", "episodes", "launches", "private-scene", "subscription")
ORIGINAL_FILES = frozenset({
    "work.json",
    "model-host.json",
    "package.json",
    "recovery-progress.json",
    "commitments/generation-0.json",
})
AUTHORIZATION_VERSION = "scene-zero-start-attestation-v1"
JOURNAL_VERSION = "scene-unstarted-recovery-journal-v1"
ORIGIN_DOMAIN = "openroboto:scene-unstarted-origin:v1"
V016_PRESTART_SOURCES = {
    "task_source/panel_worker.py": "9ada2b2f00104e9dbffe64686299f7df1725f5e478fb04d85cc06554a7449b98",
    "task_source/scene_episode_launcher.py": "2d4739905cc2ff7e68a57fcec51abe3e60b53cab706dea7fa0d0cfd6fbbc0648",
    "task_source/scene_episode_parent.py": "a6e2ef815064a6a415e15ce3ee85a5791bfce628d7893fd735b08c5a6d9e3455",
    "task_source/scene_recovery_parent.py": "626569f794eb6b846408332e5bc4713ffd9989682d15c031cf08e51f629ed140",
    "task_source/scene_episode_caller.py": "ee26718c6e10e1d88e557003ad0d5c690c543659fc206bf83465d322182951a0",
    "task_source/scene_runtime.py": "ada199d8c5f9ed3a4f10ce9996121d3096216f58fccd32a844c635ddeadc8123",
    "task_source/scene_episode_delegate.py": "0f3489ed1f11f92bb14031bb9c735856ae530eabc105ad54db11a9bc067e0e4f",
    "task_source/scene_panel.py": "87124676ca38b4c11b1378bc329fbfb620a30f734e1512a58997d0a1a87646fe",
}


@dataclass(frozen=True)
class UnstartedOriginals:
    _bytes: bytes = field(repr=False)

    @property
    def document(self):
        return decode(self._bytes)


def capture_originals(work, directory, deployment, *, now):
    """Read a complete pre-start tree; missing or partial records are refused."""
    from task_source.panel_worker import validate_host
    from task_source.scene_commitment import validate_receipt
    from task_source.scene_local_recovery import original_tree
    from task_source.scene_recovery_parent import operation_work
    from task_source.scene_adapter import epoch

    config, root = operation_work(work, deployment)
    require(Path(directory) == root, "SCENE_RECOVERY_UNSTARTED_DIRECTORY_CHANGED")
    require(work["status"] in {"running", "held"}, "SCENE_RECOVERY_COMPLETED")
    require(work["trials_per_member"] == config.raw["trials_per_member"], "SCENE_RECOVERY_N_CHANGED")
    lease_path = root / "lease.json"
    require(lease_path.is_file() and not lease_path.is_symlink(), "SCENE_RECOVERY_UNSTARTED_ORIGINAL_REQUIRED")
    lease = decode(lease_path.read_bytes())
    require(
        set(lease) == {"allowed", "expires_at"}
        and type(lease["allowed"]) is bool
        and epoch(lease["expires_at"]) <= now
        and epoch(work["lease_expires_at"]) <= now,
        "SCENE_RECOVERY_NOT_EXPIRED",
    )
    for name in (*EMPTY_DIRECTORIES, "commitments"):
        path = root / name
        require(path.is_dir() and not path.is_symlink(), "SCENE_RECOVERY_UNSTARTED_ORIGINAL_REQUIRED")
        info = path.stat()
        require(
            info.st_uid == deployment["control_uid"] and not stat.S_IMODE(info.st_mode) & 0o022,
            "SCENE_RECOVERY_UNSTARTED_DIRECTORY_CHANGED",
        )
        if name in EMPTY_DIRECTORIES:
            require(not any(path.iterdir()), "SCENE_RECOVERY_UNSTARTED_PARTIAL_RECORDS")
    require(
        {p.name for p in root.iterdir() if p.is_dir()} == {*EMPTY_DIRECTORIES, "commitments"},
        "SCENE_RECOVERY_UNSTARTED_PARTIAL_RECORDS",
    )
    originals = original_tree(root)
    require(set(originals) == ORIGINAL_FILES, "SCENE_RECOVERY_UNSTARTED_ORIGINAL_REQUIRED")
    for name in (*originals, "lease.json"):
        info = (root / name).lstat()
        require(
            info.st_uid == deployment["control_uid"] and stat.S_IMODE(info.st_mode) in {0o400, 0o600},
            "SCENE_RECOVERY_UNSTARTED_ORIGINAL_REQUIRED",
        )
    saved = decode(originals["work.json"])
    require(
        set(saved) == {"work", "binding", "public_key"}
        and stable_work(saved["work"]) == stable_work(work)
        and saved["binding"]
        == {
            "backend": deployment["backend_url"],
            "worker_id": deployment["worker_id"],
            "node_id": deployment["node_id"],
            "competition_id": work["task"]["competition_id"],
        }
        and saved["public_key"]
        == {
            "key_id": deployment["registration"]["key_id"],
            "public_key_hex": deployment["registration"]["public_key_hex"],
        },
        "SCENE_RECOVERY_WORK_CHANGED",
    )
    host = decode(originals["model-host.json"])
    validate_host(host, config)
    require(host["mode"] == "subscription" and digest(host) == deployment["host_digest"], "SCENE_RECOVERY_HOST_CHANGED")
    identity = work["task"]["scene_registration"]["identity"]
    require(
        decode(originals["package.json"])
        == {
            "package_digest": work["task"]["package_digest"],
            "instance_ids": list(range(identity["instances"])),
        },
        "SCENE_RECOVERY_WORK_CHANGED",
    )
    progress = decode(originals["recovery-progress.json"])
    require(
        set(progress) == {"schema_version", "local_binding_digest", "stage", "progress"}
        and progress["schema_version"] == "scene-accepted-progress-v1"
        and progress["local_binding_digest"] == digest(stable_work(work))
        and progress["stage"] in {"downloading", "evaluating", "held"},
        "SCENE_RECOVERY_PROGRESS_INVALID",
    )
    detail = progress["progress"]
    require(
        set(detail)
        == {"completed_trials", "total_trials", "current_member", "current_trial", "last_status", "error_code"}
        and detail["completed_trials"] == 0
        and type(detail["completed_trials"]) is int
        and detail["total_trials"] == work["trials_per_member"] * len(config.settlement.members)
        and detail["current_member"] is None
        and detail["current_trial"] is None,
        "SCENE_RECOVERY_UNSTARTED_PARTIAL_RECORDS",
    )
    commitment = decode(originals["commitments/generation-0.json"])
    data = validate_receipt(
        commitment,
        work,
        backend=deployment["backend_url"],
        worker_id=deployment["worker_id"],
        node_id=deployment["node_id"],
        generation=0,
    )
    # These are original captured facts, not trusted expected values. The
    # independently registered Operator authorization must match them later.
    return UnstartedOriginals(
        encoded({
            "work_binding": digest(stable_work(work)),
            "files": {name: hashlib.sha256(raw).hexdigest() for name, raw in originals.items()},
            "first_commitment": commitment,
            "first_commitment_data_digest": digest(data),
            "checkpoint_state": {"progress": detail, "artifacts": [], "report_digest": None},
        })
    )


def verify_zero_checkpoint(value, *, work, binding_digest, generation):
    from task_source.scene_checkpoint import LEDGERS, expected_ledgers, parse_portable
    from task_source.scene_recovery import checkpoint

    checkpoint(value)
    portable = parse_portable(value["portable"])
    require(
        value["binding_digest"] == binding_digest
        and portable["binding_digest"] == binding_digest
        and portable["run_id"] == work["run_id"]
        and portable["recovery_generation"] == generation,
        "SCENE_RECOVERY_UNSTARTED_AUTHORIZATION_MISMATCH",
    )
    empty = expected_ledgers({name: [] for name in LEDGERS})
    require(
        all(portable[name] == empty[name] and value[name] == {"count": 0, "digest": digest([])} for name in LEDGERS)
        and value["artifacts"] == []
        and value["report_digest"] is None
        and value["progress"]["completed_trials"] == 0,
        "SCENE_RECOVERY_UNSTARTED_NONZERO_CHECKPOINT",
    )


def registered_authorization(work, deployment, originals, *, now):
    """Load only the root-installed pin, never a worker/ZIP/HTTP-selected key.

    The Operator receipt is an independent pre-HTTP source. Its backend wire
    adapter is frozen separately; this registration is not minted by capture.
    """
    from task_source.scene_recovery_parent import private_file

    entries = deployment.get("unstarted_recovery_authorizations", {})
    require(type(entries) is dict and work["run_id"] in entries, "SCENE_RECOVERY_UNSTARTED_OPERATOR_REQUIRED")
    entry = entries[work["run_id"]]
    require(
        type(entry) is dict
        and set(entry) == {"path", "sha256", "historical_source_prefix", "originals_digest", "valid_until"}
        and type(entry["sha256"]) is str
        and HEX.fullmatch(entry["sha256"]),
        "SCENE_RECOVERY_UNSTARTED_OPERATOR_REQUIRED",
    )
    raw = private_file(entry["path"])
    require(hashlib.sha256(raw).hexdigest() == entry["sha256"], "SCENE_RECOVERY_UNSTARTED_AUTHORIZATION_CHANGED")
    doc = decode(raw)
    require(
        type(doc) is dict
        and set(doc)
        == {
            "schema_version",
            "scope",
            "run_id",
            "task_id",
            "worker_id",
            "node_id",
            "recovery_generation",
            "binding_digest",
            "commitment_data_digest",
            "task_ref_digest",
            "config_json_digest",
            "config_version",
            "config_digest",
            "registry_digest",
            "trials_per_member",
            "total_trials",
            "checkpoint",
            "checkpoint_digest",
            "observed_at",
            "execution_authorized",
        }
        and doc["schema_version"] == AUTHORIZATION_VERSION
        and doc["scope"] == "server-zero-records"
        and doc["execution_authorized"] is False,
        "SCENE_RECOVERY_UNSTARTED_AUTHORIZATION_INVALID",
    )
    from task_source.scene_adapter import epoch

    require(
        type(entry["valid_until"]) in (int, float)
        and math.isfinite(entry["valid_until"])
        and epoch(doc["observed_at"]) <= now < entry["valid_until"],
        "SCENE_RECOVERY_UNSTARTED_AUTHORIZATION_EXPIRED",
    )
    saved = originals.document
    # The API's task_ref projection retains every frozen field except current
    # assignment and the two explicitly lease-dependent authority fields.
    import copy

    task_ref = copy.deepcopy(work["_scene_frozen_task"])
    task_ref.pop("assignment")
    task_ref["receipt_authority"].pop("valid_until")
    task_ref["receipt_authority"].pop("retired")
    require(
        doc["run_id"] == work["run_id"]
        and doc["task_id"] == work["task"]["task_id"]
        and doc["worker_id"] == deployment["worker_id"]
        and doc["node_id"] == deployment["node_id"]
        and doc["config_digest"] == work["config_digest"]
        and doc["registry_digest"] == work["registry_digest"]
        and doc["config_version"] == work["config_version"]
        and doc["config_json_digest"] == digest(work["config"])
        and doc["trials_per_member"] == work["trials_per_member"]
        and doc["total_trials"] == saved["checkpoint_state"]["progress"]["total_trials"]
        and type(doc["recovery_generation"]) is int
        and doc["recovery_generation"] == 0
        and entry["originals_digest"] == digest(saved["files"])
        and doc["commitment_data_digest"] == saved["first_commitment_data_digest"]
        and doc["binding_digest"] == saved["first_commitment"]["data"]["binding_digest"]
        and doc["task_ref_digest"] == digest(task_ref)
        and doc["checkpoint_digest"] == digest(doc["checkpoint"])
        and all(
            doc["checkpoint"]["progress"][k] == saved["checkpoint_state"]["progress"][k]
            for k in ("completed_trials", "total_trials", "current_member", "current_trial")
        ),
        "SCENE_RECOVERY_UNSTARTED_AUTHORIZATION_MISMATCH",
    )
    verify_zero_checkpoint(doc["checkpoint"], work=work, binding_digest=doc["binding_digest"], generation=1)
    return doc, entry


def verify_origin(document, work, deployment):
    """A present-day Operator witness, never a reconstructed commitment-0."""
    from benchmark_worker.reference_panel.manifest import verify_manifest

    require(
        type(document) is dict
        and set(document)
        == {
            "domain",
            "deployment_digest",
            "work_binding",
            "observed_at",
            "authorization_sha256",
            "originals",
            "key_id",
            "algorithm",
            "signature",
        }
        and document["domain"] == ORIGIN_DOMAIN
        and document["deployment_digest"] == digest(deployment)
        and document["work_binding"] == digest(stable_work(work))
        and document["key_id"] == deployment["key_id"]
        and document["algorithm"] == "ed25519"
        and verify_manifest(document, deployment["public_key_hex"]),
        "SCENE_RECOVERY_UNSTARTED_ORIGIN_INVALID",
    )
    return document


def prepare_unstarted(request, deployment, archive):
    """Root-only pre-HTTP proof for the one generation-0 zero-start gap."""
    import time
    from task_source.panel_state import write
    from task_source.scene_recovery_parent import operation_work, private_file, root_sign, verify_quiescence
    from task_source.scene_episode_scope import EpisodeScopePlan
    from task_source.scene_recovery import RecoveryJournal

    work = request["work"]
    require(
        type(request["base_generation"]) is int and request["base_generation"] == 0,
        "SCENE_RECOVERY_UNSTARTED_GENERATION_INVALID",
    )
    config, root = operation_work(work, deployment)
    originals = capture_originals(work, root, deployment, now=time.time())
    authorization, entry = registered_authorization(work, deployment, originals, now=time.time())
    verify_prestart_barrier(deployment, entry)
    require(
        {p.name for p in archive.iterdir()} <= {"run.lock", "unstarted-origin.json", "unstarted-reconciled.json"},
        "SCENE_RECOVERY_UNSTARTED_PARTIAL_RECORDS",
    )
    instances = work["task"]["scene_registration"]["identity"]["instances"]
    plans = [
        EpisodeScopePlan.registered(
            deployment,
            episode={
                "run_id": work["run_id"],
                "attempt_id": f"{work['run_id']}:{member.id}:{trial}",
                "member_id": member.id,
                "worker_id": deployment["worker_id"],
                "node_id": deployment["node_id"],
                "trial": trial,
                "instance": trial % instances,
            },
            submission_digest=work["task"]["submission_digest"],
            config_digest=config.digest,
        )
        for member in config.settlement.members
        for trial in range(work["trials_per_member"])
    ]
    verify_quiescence(plans, deployment, root)
    path = archive / "unstarted-origin.json"
    if path.exists():
        origin = verify_origin(decode(private_file(path)), work, deployment)
        require(
            origin["authorization_sha256"] == entry["sha256"] and origin["originals"] == originals.document,
            "SCENE_RECOVERY_UNSTARTED_ORIGIN_CHANGED",
        )
    else:
        origin = root_sign(
            deployment,
            {
                "domain": ORIGIN_DOMAIN,
                "deployment_digest": digest(deployment),
                "work_binding": digest(stable_work(work)),
                "observed_at": time.time(),
                "authorization_sha256": entry["sha256"],
                "originals": originals.document,
            },
        )
        write(path, origin, exclusive=True)
    saved = originals.document
    return RecoveryJournal(
        encoded({
            "schema_version": JOURNAL_VERSION,
            "local_binding_digest": saved["work_binding"],
            # Held/error labels can be acknowledged after the last LeaseKeeper
            # snapshot. The independent Operator read freezes these server labels;
            # counts/current-trial and the complete local originals must still match.
            "checkpoint_state": {k: authorization["checkpoint"][k] for k in ("progress", "artifacts", "report_digest")},
            "server_binding_digest": authorization["binding_digest"],
            "files": saved["files"],
            "unresolved_calls": False,
            "quiescent": True,
            "unstarted": {
                "origin_digest": digest(origin),
                "authorization_sha256": entry["sha256"],
                "expected_checkpoint": authorization["checkpoint"],
            },
        })
    )


def reconcile_unstarted(journal, checkpoint, work, deployment, archive):
    from task_source.scene_recovery_parent import seal_once

    require(checkpoint == journal["unstarted"]["expected_checkpoint"], "SCENE_RECOVERY_CHECKPOINT_MISMATCH")
    verify_zero_checkpoint(checkpoint, work=work, binding_digest=journal["server_binding_digest"], generation=1)
    seal_once(
        archive / "unstarted-reconciled.json",
        {
            "kind": "unstarted-reconciled",
            "work_binding": journal["local_binding_digest"],
            "origin_digest": journal["unstarted"]["origin_digest"],
            "checkpoint_digest": digest(checkpoint),
        },
        deployment,
    )
    return {
        "matched": True,
        "local_binding_digest": journal["local_binding_digest"],
        "execution_authorized": False,
        "rerun_authorized": False,
    }


def first_binding(work, deployment, archive):
    """Only a reconciled late witness can replace the absent root archive."""
    from task_source.scene_recovery_parent import private_file, root_verify

    origin = verify_origin(decode(private_file(archive / "unstarted-origin.json")), work, deployment)
    receipt = root_verify(
        deployment, decode(private_file(archive / "unstarted-reconciled.json")), kind="unstarted-reconciled"
    )
    require(
        receipt["origin_digest"] == digest(origin) and receipt["work_binding"] == digest(stable_work(work)),
        "SCENE_RECOVERY_UNSTARTED_ORIGIN_CHANGED",
    )
    return origin["originals"]["first_commitment"]["data"]["binding_digest"]


def verify_prestart_barrier(deployment, entry):
    """Only the independently reviewed .16 archive-before-model path qualifies.

    Its original root-controlled source must remain available for verification.
    Unknown/changed source or an anonymous model route cannot establish zero.
    """
    from task_source.scene_recovery_parent import trusted_file
    from task_source.scene_views.episode_gateway import gateway_factory_identity, _SOURCES

    require(
        deployment["registration"]["runtime"]
        == {
            "id": "openroboto-task-runtime",
            "version": "0.3.16",
            "digest": "b798b843002ee27e7072122b30606713588db3a4e9f0f4ff920e156f36bafd67",
        }
        and gateway_factory_identity()["digest"]
        == deployment["episode_policy"]["gateway_factory_digest"]
        == "6e959cb29c08b8cb218fc11a120eaaf519e93d008dcd5f02754f9f9d12b3bd31"
        and deployment["allow_anonymous_models"] is False
        and deployment["model_key_files"],
        "SCENE_RECOVERY_UNSTARTED_BARRIER_UNAVAILABLE",
    )
    prefix = Path(entry["historical_source_prefix"])
    require(prefix.is_absolute() and prefix.resolve() == prefix, "SCENE_RECOVERY_UNSTARTED_BARRIER_UNAVAILABLE")
    for name, expected in V016_PRESTART_SOURCES.items():
        require(
            hashlib.sha256(trusted_file(prefix / name)).hexdigest() == expected,
            "SCENE_RECOVERY_UNSTARTED_BARRIER_UNAVAILABLE",
        )
    require(
        digest({name: hashlib.sha256(trusted_file(prefix / name)).hexdigest() for name in _SOURCES})
        == "6e959cb29c08b8cb218fc11a120eaaf519e93d008dcd5f02754f9f9d12b3bd31",
        "SCENE_RECOVERY_UNSTARTED_BARRIER_UNAVAILABLE",
    )
    # Prove credential protection without reading or returning its contents.
    for name in deployment["model_key_files"].values():
        path = Path(name)
        require(path.is_absolute() and path.resolve() == path, "SCENE_RECOVERY_UNSTARTED_BARRIER_UNAVAILABLE")
        for parent in path.parents:
            info = parent.lstat()
            require(
                stat.S_ISDIR(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022,
                "SCENE_RECOVERY_UNSTARTED_BARRIER_UNAVAILABLE",
            )
        info = path.lstat()
        require(
            stat.S_ISREG(info.st_mode)
            and info.st_uid == 0
            and info.st_nlink == 1
            and stat.S_IMODE(info.st_mode) in {0o400, 0o600},
            "SCENE_RECOVERY_UNSTARTED_BARRIER_UNAVAILABLE",
        )
