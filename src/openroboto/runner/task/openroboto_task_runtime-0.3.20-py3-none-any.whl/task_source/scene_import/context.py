"""Explicit worker configuration, never parsed or inferred from a submission.

The caller owns registry authenticity/selection. This value only binds that
exact selection to an unchanged Panda importer; it grants no runtime support,
new robot/control capability or permission to skip validation.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass

from .errors import reject

_PLATFORM_FIELDS = (
    "id",
    "mujoco",
    "platform_manifest_sha256",
    "joint_order",
    "action_dimensions",
    "tools_digest",
    "robot_initial_qpos",
    "scene_actuators",
)


def _snapshot(document):
    if not isinstance(document, Mapping):
        reject(
            "worker_registry_invalid",
            "worker.context.registry",
            "Expected a worker registry document",
            status="resource_unavailable",
        )
    try:
        return json.dumps(dict(document), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    except (ValueError, TypeError) as exc:
        reject("worker_registry_invalid", "worker.context.registry", str(exc), status="resource_unavailable")


@dataclass(frozen=True, init=False)
class SceneImportContext:
    """Immutable snapshot of a trusted worker registry and the base importer.

    Instantiate from operator-owned configuration, never task.environment or
    any task-supplied registry. Only the environment identity/adapter metadata
    can change: all actual platform/control constraints remain pinned. Copies
    returned by accessors cannot mutate this context, including nested lists.
    """

    _registry_json: str
    _importer_json: str
    _refs_json: str
    _importer_refs_json: str

    def __init__(self, *, registry_document: Mapping | None = None):
        from .platform import _registry_refs, registry_document as default_registry

        importer_json = _snapshot(default_registry())
        importer = json.loads(importer_json)
        selected_json = importer_json if registry_document is None else _snapshot(registry_document)
        selected = json.loads(selected_json)
        for key in _PLATFORM_FIELDS:
            if key not in selected or type(selected[key]) is not type(importer[key]) or selected[key] != importer[key]:
                reject(
                    "worker_registry_platform_conflict",
                    "worker.context.registry." + key,
                    "The trusted registry must retain the importer's exact platform/control constraint",
                    status="resource_unavailable",
                )
        for key in ("version", "adapter"):
            if not isinstance(selected.get(key), str) or not selected[key].strip():
                reject(
                    "worker_registry_invalid",
                    "worker.context.registry." + key,
                    "An exact nonempty worker registry identity is required",
                    status="resource_unavailable",
                )
        object.__setattr__(self, "_registry_json", selected_json)
        object.__setattr__(self, "_importer_json", importer_json)
        object.__setattr__(self, "_refs_json", _snapshot(_registry_refs(selected)))
        object.__setattr__(self, "_importer_refs_json", _snapshot(_registry_refs(importer)))

    def registry_document(self):
        return json.loads(self._registry_json)

    def registry_refs(self):
        return json.loads(self._refs_json)

    def importer_identity(self):
        importer = json.loads(self._importer_json)
        return {
            "adapter": importer["adapter"],
            "environment": json.loads(self._importer_refs_json)["environment"],
            "registry": importer,
        }


def resolve_context(context):
    if context is None:
        return SceneImportContext()
    if type(context) is not SceneImportContext:
        reject(
            "worker_context_invalid",
            "worker.context",
            "Pass an explicit SceneImportContext from worker configuration",
            status="resource_unavailable",
        )
    return context
