"""Compare schema-3 declarations to the compiled MuJoCo model, without scoring."""

import mujoco
import numpy as np

from task_source.tabletop import INITIAL_ARM, JOINT_ORDER

from .errors import reject


def rotation(xyzw):
    x, y, z, w = xyzw
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def wxyz(q):
    return [q[3], *q[:3]]


def matrix(pose):
    t = np.eye(4)
    t[:3, :3] = rotation(pose.quaternion_xyzw)
    t[:3, 3] = pose.position_m
    return t


def transform(pos, quat):
    t = np.eye(4)
    t[:3, :3] = rotation([*quat[1:], quat[0]])
    t[:3, 3] = pos
    return t


def close(actual, expected, path, code="model_mismatch", atol=2e-7):
    if np.shape(actual) != np.shape(expected) or not np.allclose(actual, expected, rtol=1e-7, atol=atol):
        reject(
            code, path, f"Compiled {np.asarray(actual).tolist()} differs from declared {np.asarray(expected).tolist()}"
        )


def named(model, kind, name, path):
    identifier = mujoco.mj_name2id(model, kind, name)
    if identifier < 0:
        reject("binding_missing", path, f"No compiled {kind.name}: {name}")
    return identifier


def frames(task):
    """Resolve every frame once, independently of author order or chain depth."""
    definitions = {f.id: f for f in task.scene.frames}
    result = {"world": np.eye(4)}
    for key in definitions:
        pending, active, name = [], set(), key
        while name not in result:
            if name in active:
                reject("frame_cycle", f"scene.frames.{name}.parent", "Frame ancestors contain a cycle")
            frame = definitions.get(name)
            if frame is None:
                reject("frame_parent_missing", f"scene.frames.{pending[-1].id}.parent", f"Unknown parent frame: {name}")
            active.add(name)
            pending.append(frame)
            name = frame.parent
        # Keep exactly the old parent-world @ child-local multiplication order.
        # The first parsed ancestor is reused for every later sibling/descendant.
        for frame in reversed(pending):
            result[frame.id] = result[frame.parent] @ matrix(frame.pose_in_parent)
    return result


def initial_data(model):
    data = mujoco.MjData(model)
    for name, value in zip(JOINT_ORDER, [0.04, 0.04, *INITIAL_ARM]):
        joint = named(model, mujoco.mjtObj.mjOBJ_JOINT, name, "robot.joints")
        data.qpos[model.jnt_qposadr[joint]] = value
        actuator = named(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name, "robot.actuators")
        data.ctrl[actuator] = value
    mujoco.mj_forward(model, data)
    return data


def reset(model, task, bindings, state_id):
    state = next((s for s in task.scene.initial_states if s.id == state_id), None)
    if state is None:
        reject("initial_state_missing", "scene.initial_states", f"Unknown initial state: {state_id}")
    data = initial_data(model)
    objects = {o.id: o for o in task.task_definition.objects}
    for obj_state in state.objects:
        obj = objects[obj_state.object_id]
        if obj.motion == "free":
            joint = bindings["free_joints"][obj.id]
            start = model.jnt_qposadr[joint]
            # A freejoint is accepted only directly under world, so its qpos is
            # exactly the world body-origin pose, independently of COM.
            data.qpos[start : start + 7] = [*obj_state.pose.position_m, *wxyz(obj_state.pose.quaternion_xyzw)]
    for joint_state in state.joints:
        joint = bindings["joints"][joint_state.joint_id]
        data.qpos[model.jnt_qposadr[joint]] = joint_state.position
    data.qvel[:] = 0
    mujoco.mj_forward(model, data)
    for obj_state in state.objects:
        body = bindings["bodies"][obj_state.object_id]
        close(
            transform(data.xpos[body], data.xquat[body]),
            matrix(obj_state.pose),
            f"scene.initial_states.{state_id}.objects.{obj_state.object_id}.pose",
            "initial_pose_mismatch",
        )
    if not np.all(np.isfinite(data.qpos)) or not np.all(np.isfinite(data.qvel)):
        reject("initial_nonfinite", f"scene.initial_states.{state_id}", "Non-finite initial state")
    if np.any(data.warning.number):
        reject("initial_warning", f"scene.initial_states.{state_id}", "MuJoCo warning at reset")
    return data


def geometry(model, geom, part, asset_pose, meshes, path):
    """Compare exact primitives or native compiled mesh hull; no box proxy."""
    kinds = {"box": 6, "sphere": 2, "capsule": 3, "cylinder": 5, "mesh": 7}
    if int(model.geom_type[geom]) != kinds[part.kind]:
        reject("geometry_kind", path, "Compiled geom kind differs from declared part")
    expected_pose = asset_pose @ matrix(part.pose_in_asset)
    actual_pose = transform(model.geom_pos[geom], model.geom_quat[geom])
    vertices = None
    if part.kind == "mesh":
        mesh_id = int(model.geom_dataid[geom])
        mesh_name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_MESH, mesh_id)
        mesh = meshes.get(mesh_name)
        if mesh is None or mesh.get("file") != "user/" + part.mesh_path:
            reject("mesh_binding", path, "Compiled mesh does not reference the declared materialized file")
        close(model.mesh_scale[mesh_id], part.size, path + ".scale")
        # MuJoCo recenters meshes and rotates to principal axes at compile.
        expected_pose = expected_pose @ transform(model.mesh_pos[mesh_id], model.mesh_quat[mesh_id])
        start, count = model.mesh_vertadr[mesh_id], model.mesh_vertnum[mesh_id]
        raw = np.asarray(model.mesh_vert[start : start + count], dtype=float)
        in_asset = np.linalg.inv(asset_pose) @ actual_pose
        vertices = raw @ in_asset[:3, :3].T + in_asset[:3, 3]
        if count > 100_000:
            reject("resource_mesh", path, "Compiled mesh vertex guard exceeded")
    else:
        close(model.geom_size[geom][: len(part.size)], part.size, path + ".size")
    close(actual_pose, expected_pose, path + ".pose")
    return {"kind": part.kind, "size": list(part.size), "pose": matrix(part.pose_in_asset), "vertices": vertices}


def _tensor(values):
    xx, yy, zz, xy, xz, yz = values
    return np.array([[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]])


def _symmetry(asset, shapes, path):
    """Conservative exact symmetry checks on verified geometry and mass tensor.

    A mesh's compiled convex vertices must map bijectively. Continuous groups
    are supported for one centered primitive only; compound continuous groups
    are explicitly unsupported rather than guessed from sampled projections.
    """
    symmetry = asset.symmetry
    inertia = _tensor(asset.physics.inertia_kg_m2)
    com = np.array(asset.physics.center_of_mass_m)
    if symmetry.category in {"isotropic", "axial_unsigned"}:
        if len(shapes) != 1:
            reject("symmetry_unsupported", path, "Continuous compound symmetry not implemented", status="unsupported")
        shape = shapes[0]
        close(shape["pose"][:3, 3], np.zeros(3), path + ".origin")
        close(com, np.zeros(3), path + ".com")
        if symmetry.category == "isotropic":
            if shape["kind"] != "sphere":
                reject("symmetry_mismatch", path, "Isotropic symmetry requires a centered sphere")
            close(inertia, np.eye(3) * inertia[0, 0], path + ".inertia", atol=1e-10)
        else:
            axis = np.array(symmetry.axis_xyz)
            if shape["kind"] not in {"sphere", "cylinder", "capsule"}:
                reject("symmetry_mismatch", path, "Unsigned axial symmetry requires an exact axial primitive")
            if shape["kind"] != "sphere":
                close(abs(float(shape["pose"][:3, 2] @ axis)), 1.0, path + ".axis")
            axial = float(axis @ inertia @ axis)
            transverse = (np.trace(inertia) - axial) / 2
            close(
                inertia,
                transverse * np.eye(3) + (axial - transverse) * np.outer(axis, axis),
                path + ".inertia",
                atol=1e-10,
            )
        return

    def equivalent(a, b, rot):
        if a["kind"] != b["kind"]:
            return False
        if a.get("contact") != b.get("contact"):
            return False
        if a["vertices"] is not None:
            first, second = a["vertices"] @ rot.T, b["vertices"]

            def ordered(v):
                v = np.round(v, 7)
                return v[np.lexsort((v[:, 2], v[:, 1], v[:, 0]))]

            return first.shape == second.shape and np.allclose(ordered(first), ordered(second), rtol=0, atol=2e-7)
        pa, pb = a["pose"], b["pose"]
        if not np.allclose(rot @ pa[:3, 3], pb[:3, 3], atol=1e-7):
            return False
        r = pb[:3, :3].T @ rot @ pa[:3, :3]
        if a["kind"] == "sphere":
            return np.allclose(a["size"], b["size"])
        if a["kind"] == "box":
            return np.allclose(np.sort(abs(r).flatten())[-3:], 1, atol=1e-7) and np.allclose(
                abs(r) @ a["size"], b["size"]
            )
        return np.allclose(a["size"], b["size"]) and abs(abs(r[2, 2]) - 1) < 1e-7

    # A finite symmetry set must actually be a group, not arbitrary sampled
    # rotations. Bind the complete set rather than inventing cube symmetries.
    rotations = [rotation(q) for q in symmetry.rotations_xyzw]
    if len(rotations) > 64:
        reject(
            "symmetry_unsupported", path, "Finite symmetry groups above 64 elements unsupported", status="unsupported"
        )
    if not any(np.allclose(r, np.eye(3), atol=1e-7) for r in rotations):
        reject("symmetry_mismatch", path, "Finite symmetry set lacks identity")
    for a in rotations:
        for b in rotations:
            if not any(np.allclose(a @ b, r, rtol=0, atol=1e-7) for r in rotations):
                reject("symmetry_mismatch", path, "Finite rotation set is not closed")
    # Geometry union must match one-to-one under every declared group rotation.
    for quaternion in symmetry.rotations_xyzw:
        rot = rotation(quaternion)
        close(rot @ com, com, path + ".com")
        close(rot @ inertia @ rot.T, inertia, path + ".inertia", atol=1e-10)
        unused = set(range(len(shapes)))
        for shape in shapes:
            match = next((i for i in sorted(unused) if equivalent(shape, shapes[i], rot)), None)
            if match is None:
                reject("symmetry_mismatch", path, "Declared rotation changes actual geometry")
            unused.remove(match)


def validate(model, task, author):
    data, frame_map = initial_data(model), frames(task)
    bindings = {
        "bodies": {},
        "geoms": {},
        "joints": {},
        "free_joints": {},
        "contact_targets": {},
        "platform_groups": {},
    }
    declared_joints = set()
    owned_geoms = set()
    for group in task.scene.platform_groups:
        ids = [
            named(model, mujoco.mjtObj.mjOBJ_GEOM, g, f"scene.platform_groups.{group.id}")
            for g in group.collision_geoms
        ]
        bindings["platform_groups"][group.id] = ids
        owned_geoms.update(ids)
    robot_joints = [named(model, mujoco.mjtObj.mjOBJ_JOINT, name, "robot.joints") for name in JOINT_ORDER]
    declared_joints.update(robot_joints)
    if model.nu != 9:
        reject(
            "robot_control_conflict", "robot.control_mapping", "Compiled Panda control must have exactly nine actuators"
        )
    actuators = []
    for name, joint in zip(JOINT_ORDER, robot_joints):
        aid = named(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name, "robot.control_mapping")
        if model.actuator_trntype[aid] != 0 or model.actuator_trnid[aid, 0] != joint:
            reject("robot_control_conflict", "robot.control_mapping", "Panda actuator transmission changed")
        actuators.append(aid)
    bindings["robot"] = {
        "joint_ids": robot_joints,
        "actuator_ids": actuators,
        "qpos_addresses": [int(model.jnt_qposadr[j]) for j in robot_joints],
        "joint_order": list(JOINT_ORDER),
    }
    assets = {a.id: a for a in task.scene.assets}
    meshes = {n.get("name"): n for n in author.iter("mesh")}
    inspection = {}
    for obj in task.task_definition.objects:
        path = "task_definition.objects." + obj.id
        body = named(model, mujoco.mjtObj.mjOBJ_BODY, obj.body, path + ".body")
        if obj.body.startswith("franka") or body == 0:
            reject("robot_identity_conflict", path + ".body", "Entity cannot own platform/world body")
        bindings["bodies"][obj.id] = body
        close(
            transform(data.xpos[body], data.xquat[body]),
            frame_map[obj.body_frame],
            path + ".body_frame",
            "frame_mismatch",
        )
        body_joints = set(range(int(model.body_jntadr[body]), int(model.body_jntadr[body] + model.body_jntnum[body])))
        scalar_names = [j.name for j in task.scene.joints if j.body_id == obj.id]
        if obj.motion == "free":
            j = named(model, mujoco.mjtObj.mjOBJ_JOINT, obj.free_joint_name, path + ".free_joint_name")
            if (
                model.jnt_type[j] != 0
                or model.jnt_bodyid[j] != body
                or model.body_parentid[body] != 0
                or body_joints != {j}
            ):
                reject("free_joint_mismatch", path, "Free entity needs one world-child freejoint")
            bindings["free_joints"][obj.id] = j
            declared_joints.add(j)
        elif obj.motion == "fixed":
            if body_joints:
                reject("motion_mismatch", path + ".motion", "Fixed entity has joints")
        elif not scalar_names or len(scalar_names) != len(body_joints):
            reject("motion_mismatch", path + ".motion", "Articulated entity must declare all scalar joints")
        asset = assets[obj.asset.id]
        asset_pose = matrix(obj.asset_pose_in_body)
        physics = asset.physics
        close(model.body_mass[body], physics.mass_kg, path + ".physics.mass_kg")
        close(model.body_ipos[body], (asset_pose @ np.array([*physics.center_of_mass_m, 1]))[:3], path + ".physics.com")
        inertia_rot = transform([0, 0, 0], model.body_iquat[body])[:3, :3]
        actual_inertia = inertia_rot @ np.diag(model.body_inertia[body]) @ inertia_rot.T
        close(
            actual_inertia,
            asset_pose[:3, :3] @ _tensor(physics.inertia_kg_m2) @ asset_pose[:3, :3].T,
            path + ".physics.inertia",
            atol=1e-10,
        )
        shapes, entity_geoms = [], {}
        for part in asset.collision.parts:
            gid = named(
                model, mujoco.mjtObj.mjOBJ_GEOM, obj.collision_geoms[part.id], path + ".collision_geoms." + part.id
            )
            if model.geom_bodyid[gid] != body or not (model.geom_contype[gid] or model.geom_conaffinity[gid]):
                reject(
                    "geom_owner_mismatch",
                    path + ".collision_geoms." + part.id,
                    "Collision geom must be physical and on this exact body",
                )
            shapes.append(geometry(model, gid, part, asset_pose, meshes, path + ".collision." + part.id))
            contact = physics.contacts[part.id]
            shapes[-1]["contact"] = contact.model_dump()
            close(model.geom_friction[gid], contact.friction, path + ".physics.contacts." + part.id + ".friction")
            close(model.geom_condim[gid], contact.contact_dimension, path + ".physics.contacts." + part.id + ".condim")
            entity_geoms[part.id] = gid
            owned_geoms.add(gid)
        bindings["geoms"][obj.id] = entity_geoms
        # There is no wire visual-geom name map. Match the exact multiset on
        # this body; a collision geom may also provide its visual part.
        visual_candidates = set(
            range(int(model.body_geomadr[body]), int(model.body_geomadr[body] + model.body_geomnum[body]))
        )
        visual_shapes = []
        for part in asset.visual.parts:
            match = None
            for gid in sorted(visual_candidates):
                from .errors import SceneImportError

                try:
                    shape = geometry(model, gid, part, asset_pose, meshes, path + ".visual." + part.id)
                except SceneImportError:
                    continue
                match = gid
                visual_shapes.append(shape)
                break
            if match is None:
                reject(
                    "visual_mismatch",
                    path + ".visual." + part.id,
                    "No exact body-local visual geom matches declared part",
                )
            visual_candidates.remove(match)
        if visual_candidates - set(entity_geoms.values()):
            reject("visual_undeclared", path + ".visual", "Body has undeclared visual geometry")
        _symmetry(asset, shapes, path + ".collision.symmetry")
        _symmetry(asset, visual_shapes, path + ".visual.symmetry")
        inspection[obj.id] = {
            "body_id": body,
            "geom_ids": entity_geoms,
            "mass_kg": float(model.body_mass[body]),
            "com_in_body": model.body_ipos[body].tolist(),
            "inertia_in_body": actual_inertia.tolist(),
            "asset": asset.model_dump(mode="json"),
            "collision_shapes": [
                {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in shape.items()} for shape in shapes
            ],
        }
    # Reject every unbound collision shape and scene body/joint; descendants are
    # never silently collected into their parent's logical contact identity.
    for gid in range(model.ngeom):
        if (model.geom_contype[gid] or model.geom_conaffinity[gid]) and gid not in owned_geoms:
            reject("geom_unowned", "scene.geoms." + str(gid), "Physical geom has no explicit entity/platform owner")
    for body in range(1, model.nbody):
        name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, body) or ""
        if not name.startswith("franka/") and body not in bindings["bodies"].values():
            reject("body_unowned", "scene.bodies." + str(body), "Every author body requires an explicit entity")
    for joint in task.scene.joints:
        path = "scene.joints." + joint.id
        jid = named(model, mujoco.mjtObj.mjOBJ_JOINT, joint.name, path)
        body = bindings["bodies"][joint.body_id]
        parent = named(model, mujoco.mjtObj.mjOBJ_BODY, joint.parent_body, path + ".parent_body")
        if model.jnt_bodyid[jid] != body or model.body_parentid[body] != parent:
            reject("joint_topology", path, "Compiled parent/child differs from declared topology")
        if model.jnt_type[jid] != (3 if joint.kind == "hinge" else 2):
            reject("joint_kind", path, "Expected scalar hinge/slide joint")
        close(model.jnt_axis[jid], joint.axis_in_child_body, path + ".axis")
        close(model.jnt_range[jid], joint.range, path + ".range")
        if not model.jnt_limited[jid]:
            reject("joint_range", path, "Scene scalar joint must be limited")
        bindings["joints"][joint.id] = jid
        declared_joints.add(jid)
    if declared_joints != set(range(model.njnt)):
        reject("joint_unowned", "scene.joints", "Compiled model has undeclared joints")
    for target in task.scene.contact_targets:
        bindings["contact_targets"][target.id] = [
            named(model, mujoco.mjtObj.mjOBJ_GEOM, g, "scene.contact_targets." + target.id) for g in target.geom_names
        ]
    camera = task.scene.camera
    cid = named(model, mujoco.mjtObj.mjOBJ_CAMERA, camera.name, "scene.camera.name")
    camera_body = int(model.cam_bodyid[cid])
    while camera_body:
        if model.body_jntnum[camera_body]:
            reject(
                "camera_unsupported",
                "scene.camera",
                "Moving camera calibration requires another adapter",
                status="unsupported",
            )
        camera_body = int(model.body_parentid[camera_body])
    if (
        model.ncam != 1
        or model.cam_mode[cid] != 0
        or model.cam_projection[cid] != 0
        or np.any(model.cam_sensorsize[cid])
    ):
        reject(
            "camera_unsupported",
            "scene.camera",
            "Exactly one fixed perspective/FOV camera required",
            status="unsupported",
        )
    actual_cam = np.eye(4)
    actual_cam[:3, :3] = data.cam_xmat[cid].reshape(3, 3)
    actual_cam[:3, 3] = data.cam_xpos[cid]
    close(actual_cam, frame_map[camera.frame] @ matrix(camera.pose_in_frame), "scene.camera.pose")
    close(model.cam_fovy[cid], camera.vertical_fov_deg, "scene.camera.vertical_fov_deg")
    close([model.vis.global_.offwidth, model.vis.global_.offheight], camera.image_size, "scene.camera.image_size")
    bindings["camera"] = {
        "id": cid,
        "name": camera.name,
        "image_size": list(camera.image_size),
        "calibration_digest": camera.digest,
    }
    states = {}
    for state in task.scene.initial_states:
        current = reset(model, task, bindings, state.id)
        states[state.id] = {
            "qpos": current.qpos.tolist(),
            "qvel": current.qvel.tolist(),
            "ctrl": current.ctrl.tolist(),
            "bodies": {
                key: {
                    "position_m": current.xpos[b].tolist(),
                    "quaternion_xyzw": [*current.xquat[b, 1:].tolist(), float(current.xquat[b, 0])],
                    "com_world_m": current.xipos[b].tolist(),
                }
                for key, b in bindings["bodies"].items()
            },
        }
    return bindings, inspection, states, {k: v.tolist() for k, v in frame_map.items()}
