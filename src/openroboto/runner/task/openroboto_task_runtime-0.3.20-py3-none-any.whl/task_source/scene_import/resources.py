"""Read once with openat/O_NOFOLLOW, then compile only in-memory dependencies.

No network resolution, XML entities, symlinks, special files or author plugins.
All edges are package-root relative, including nested include files. This walk
is a security/size guard; package identity still uses protocol.package_digest.
"""

import hashlib
import os
import stat
import xml.etree.ElementTree as ET
from pathlib import PurePosixPath

from .errors import reject

MAX_PACKAGE_BYTES = 20_000_000
MAX_FILES = 512
MAX_XML_NODES = 10_000
MAX_XML_DEPTH = 64
MAX_INCLUDE_DEPTH = 64
XML_STRUCTURE_LIMITS = {"body": 256, "geom": 1024, "joint": 128}
MAX_MESH_VERTICES = 100_000
MAX_TEXTURE_PIXELS = 4_194_304


def relative_path(value, where):
    p = PurePosixPath(value)
    if (
        not value
        or not p.parts
        or p.is_absolute()
        or p.as_posix() != value
        or any(x in (".", "..") for x in p.parts)
        or any(ord(c) < 32 or c in "\\:" for c in value)
    ):
        reject("path_escape", where, f"Non-canonical package-relative path: {value!r}")
    return value


def snapshot(directory):
    files, total, entries = {}, 0, 0

    def walk(fd, prefix=""):
        nonlocal total, entries
        for name in sorted(os.listdir(fd)):
            entries += 1
            if entries > MAX_FILES:
                reject("resource_files", prefix, f"More than {MAX_FILES} directory entries")
            path = relative_path(prefix + name, prefix + name)
            info = os.stat(name, dir_fd=fd, follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                reject("path_symlink", path, "Symlinks are forbidden, including internal links")
            flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
            if stat.S_ISDIR(info.st_mode):
                if len(PurePosixPath(path).parts) > 16:
                    reject("resource_depth", path, "Directory depth exceeds 16")
                child = os.open(name, flags | os.O_DIRECTORY, dir_fd=fd)
                try:
                    walk(child, path + "/")
                finally:
                    os.close(child)
            elif stat.S_ISREG(info.st_mode):
                child = os.open(name, flags, dir_fd=fd)
                try:
                    opened = os.fstat(child)
                    if not stat.S_ISREG(opened.st_mode) or opened.st_size + total > MAX_PACKAGE_BYTES:
                        reject("resource_bytes", path, "Actual package exceeds hard byte guard")
                    with os.fdopen(os.dup(child), "rb") as stream:
                        content = stream.read(MAX_PACKAGE_BYTES - total + 1)
                    total += len(content)
                    if total > MAX_PACKAGE_BYTES:
                        reject("resource_bytes", path, "Actual package exceeds hard byte guard")
                    files[path] = content
                finally:
                    os.close(child)
            else:
                reject("path_special", path, "Only directories and regular files are permitted")

    try:
        fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            walk(fd)
        finally:
            os.close(fd)
    except OSError as exc:
        reject("materialization_io", str(directory), str(exc))
    return files


def _structure_node(node, path, depth, counts):
    """Charge a node before any copying, recursive utilities or native compile."""
    if depth > MAX_XML_DEPTH:
        reject("resource_xml_depth", f"{path}:{node.tag}", f"XML depth exceeds {MAX_XML_DEPTH} (root depth is 1)")
    limit = XML_STRUCTURE_LIMITS.get(node.tag)
    if limit is not None:
        counts[node.tag] = counts.get(node.tag, 0) + 1
        if counts[node.tag] > limit:
            reject("resource_model", f"{path}:{node.tag}", f"Authored {node.tag} count exceeds {limit}")


def xml(content, path):
    try:
        content = content.decode("utf-8")
    except UnicodeError:
        reject("xml_encoding", path, "MJCF must be UTF-8")
    if "<!" in content:
        reject("xml_declaration", path, "DTD, entities and XML declarations with ! are forbidden")
    # Consume start/end events in bounded chunks, not a recursive walk or an
    # unbounded complete tree before checking its size. Parsing a large source
    # therefore stops as soon as a depth/node/structure guard is exceeded.
    parser = ET.XMLPullParser(events=("start", "end"))
    root, depth, nodes, structure = None, 0, 0, {}
    try:
        for offset in range(0, len(content), 4096):
            parser.feed(content[offset : offset + 4096])
            for event, node in parser.read_events():
                if event == "start":
                    root = node if root is None else root
                    depth += 1
                    nodes += 1
                    if nodes > MAX_XML_NODES:
                        reject("resource_xml", path, f"XML exceeds {MAX_XML_NODES} nodes")
                    _structure_node(node, path, depth, structure)
                else:
                    depth -= 1
        parser.close()
    except ET.ParseError as exc:
        reject("xml_invalid", path, str(exc))
    return root


def prepare_xml(task, contents):
    deps = {d.path: d for d in task.scene.dependencies}
    roots = {}
    for path, dependency in deps.items():
        content = contents.get(path)
        if content is None:
            reject("dependency_missing", path, "Declared dependency is missing")
        if len(content) != dependency.size_bytes or hashlib.sha256(content).hexdigest() != dependency.sha256:
            reject("dependency_drift", path, "Actual size or SHA256 differs from declaration")
    pending, xml_paths = [task.scene.entrypoint], set()
    while pending:
        path = pending.pop()
        if path in xml_paths:
            continue
        xml_paths.add(path)
        root = roots[path] = xml(contents[path], path)
        if root.tag not in {"mujoco", "mujocoinclude"}:
            reject("xml_root", path, "Expected mujoco or mujocoinclude")
        refs = set()
        for node in root.iter():
            if node.tag in {
                "plugin",
                "extension",
                "flex",
                "flexcomp",
                "composite",
                "skin",
                "hfield",
                "replicate",
                "attach",
            }:
                reject(
                    "capability_unsupported", f"{path}:{node.tag}", "Unsupported MJCF capability", status="unsupported"
                )
            for attribute in node.attrib:
                if attribute in {"meshdir", "texturedir", "assetdir", "strippath"}:
                    reject("path_resolution", f"{path}:{node.tag}@{attribute}", "Use explicit package-root paths")
                if attribute.startswith("file"):
                    if attribute != "file" or node.tag not in {"include", "mesh", "texture"}:
                        reject(
                            "capability_unsupported",
                            f"{path}:{node.tag}@{attribute}",
                            "Unsupported external file",
                            status="unsupported",
                        )
                    ref = relative_path(node.get(attribute), f"{path}:{node.tag}@{attribute}")
                    if ref not in deps:
                        reject("dependency_undeclared", f"{path}:{ref}", "XML dependency absent from manifest")
                    refs.add(ref)
                    if node.tag == "include":
                        pending.append(ref)
                    else:
                        node.set(attribute, "user/" + ref)
        if refs != set(deps[path].requires):
            reject("dependency_edges", path, f"Actual XML references {sorted(refs)} differ from declared direct edges")
    for path, dep in deps.items():
        if path not in xml_paths and dep.requires:
            reject("dependency_edges", path, "Terminal binary/mesh dependencies cannot declare edges")

    # Iteratively clone and expand. Both each source tree (above) and the
    # combined output are bounded before creating nodes. Individually shallow
    # include files can otherwise assemble a deeply nested or oversized tree.
    def clone(node):
        copy = ET.Element(node.tag, dict(node.attrib))
        copy.text, copy.tail = node.text, node.tail
        return copy

    entry = task.scene.entrypoint
    root = clone(roots[entry])
    expanded_nodes, structure = 1, {}
    _structure_node(root, entry, 1, structure)
    stack = [(iter(roots[entry]), root, entry, 1, (entry,))]
    while stack:
        children, parent, path, depth, chain = stack[-1]
        child = next(children, None)
        if child is None:
            stack.pop()
            continue
        expanded_nodes += 1
        if expanded_nodes > MAX_XML_NODES:
            reject("resource_xml", path, "Expanded include graph exceeds node guard")
        if child.tag == "include":
            target = child.get("file")
            if target in chain:
                reject("dependency_cycle", f"{path}:include@file", f"Include cycle at {target}")
            if len(chain) >= MAX_INCLUDE_DEPTH:
                reject("resource_include_depth", f"{path}:include@file", f"Include nesting exceeds {MAX_INCLUDE_DEPTH}")
            stack.append((iter(roots[target]), parent, target, depth, (*chain, target)))
        else:
            _structure_node(child, path, depth + 1, structure)
            copied = clone(child)
            parent.append(copied)
            stack.append((iter(child), copied, path, depth + 1, chain))
    # Bound decompression/compilation before handing bytes to native code.
    total_vertices = 0
    for node in root.iter("mesh"):
        name = node.get("file", "").removeprefix("user/")
        if not name:
            reject(
                "capability_unsupported",
                "mesh",
                "Inline meshes need a separately versioned adapter",
                status="unsupported",
            )
        content = contents[name]
        if name.lower().endswith(".obj"):
            vertices = sum(line.startswith(b"v ") for line in content.splitlines())
        elif name.lower().endswith(".stl") and len(content) >= 84:
            vertices = int.from_bytes(content[80:84], "little") * 3
        else:
            reject(
                "capability_unsupported", name, "Only fixed OBJ and binary STL meshes supported", status="unsupported"
            )
        if vertices > MAX_MESH_VERTICES:
            reject("resource_mesh", name, "Mesh vertex budget exceeded")
        total_vertices += vertices
        if total_vertices > 200_000:
            reject("resource_mesh", name, "Total authored mesh vertex budget exceeded")
    for node in root.iter("texture"):
        if node.get("file"):
            import io
            from PIL import Image

            name = node.get("file").removeprefix("user/")
            try:
                with Image.open(io.BytesIO(contents[name])) as image:
                    if image.width * image.height > MAX_TEXTURE_PIXELS:
                        reject("resource_texture", name, "Texture pixel budget exceeded")
            except (OSError, ValueError) as exc:
                reject("texture_invalid", name, str(exc))
        else:
            reject(
                "capability_unsupported", "texture", "Procedural textures are not in this adapter", status="unsupported"
            )
    return root
