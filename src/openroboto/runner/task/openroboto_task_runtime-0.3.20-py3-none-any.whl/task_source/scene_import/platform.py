"""Local development adapter identity and trusted Panda composition.

This registry is owned by the worker, never populated from a task manifest.
It registers an importer, not a server admission profile or reward capability.
"""

import xml.etree.ElementTree as ET

from openroboto_protocol.tabletop_assets import canonical_digest

from task_source.tabletop import DATA, INITIAL_ARM, JOINT_ORDER, verify_platform_assets

from .context import resolve_context
from .errors import reject

ADAPTER_VERSION = "openroboto-scene-import/1.0.0"


def registry_document():
    from agent_harness.tools import tools_digest

    return {
        "id": "panda-mujoco-scene",
        "version": "ope230-import-1",
        "adapter": ADAPTER_VERSION,
        "mujoco": "3.17.0",
        "platform_manifest_sha256": _platform_digest(),
        "joint_order": list(JOINT_ORDER),
        "action_dimensions": 9,
        "tools_digest": tools_digest(),
        "robot_initial_qpos": [0.04, 0.04, *INITIAL_ARM],
        "scene_actuators": "forbidden",
        "status": "development",
    }


def _platform_digest():
    from openroboto_protocol.task_contract import task_profile_catalog

    return task_profile_catalog()[0]["scene_manifest_sha256"]


def registry_refs():
    return _registry_refs(registry_document())


def _registry_refs(doc):
    return {
        "environment": {"id": doc["id"], "version": doc["version"], "digest": canonical_digest(doc)},
        "artifact": {
            "id": "franka-panda",
            "version": "panda-tabletop-v1/1.0.0",
            "digest": doc["platform_manifest_sha256"],
        },
        "control_mapping": {"id": "panda-tools", "version": "axis-tool-runtime/1", "digest": doc["tools_digest"]},
    }


def verify_identity(task, *, context=None):
    refs = resolve_context(context).registry_refs()
    # The environment digest covers every task_source source file, so a package
    # built before an unrelated worker fix would be rejected although the worker
    # itself still is the registered environment. Identity is (id, version); the
    # code that actually runs is the sealed worker, never anything in the package.
    environment = task.environment.model_dump()
    registered = refs["environment"]
    if environment.get("id") != registered["id"] or environment.get("version") != registered["version"]:
        reject("environment_unsupported", "environment", "Worker registry identity required", status="unsupported")
    for path, actual, expected in (
        ("robot.artifact", task.robot.artifact.model_dump(), refs["artifact"]),
        ("robot.control_mapping", task.robot.control_mapping.model_dump(), refs["control_mapping"]),
    ):
        if actual != expected:
            reject(
                "robot_identity_conflict",
                path,
                "Exact worker registry reference required",
                status="invalid_package",
            )


def compose(task, author, *, context=None):
    context = resolve_context(context)
    verify_identity(task, context=context)
    verify_platform_assets()
    root = ET.fromstring((DATA / "scene.xml").read_bytes())
    root.set("model", "openroboto-imported-scene")
    world = root.find("worldbody")
    robot = world.find("body")
    mount = task.robot.mount
    robot.set("pos", " ".join(map(str, mount.position_m)))
    q = mount.quaternion_xyzw
    robot.set("quat", " ".join(map(str, [q[3], *q[:3]])))
    # The authored, calibrated camera replaces the platform's default camera.
    for camera in list(world.findall("camera")):
        world.remove(camera)
    robot_geoms = [g.get("name") for g in robot.iter("geom")]
    expected_groups = {
        "robot": {"id": "robot", "body": robot.get("name"), "collision_geoms": robot_geoms},
        "table": {"id": "table", "body": "world", "collision_geoms": ["floor", "table"]},
    }
    for group in task.scene.platform_groups:
        actual, expected = group.model_dump(), expected_groups[group.id]
        if actual["body"] != expected["body"] or set(actual["collision_geoms"]) != set(expected["collision_geoms"]):
            reject(
                "platform_group_conflict", f"scene.platform_groups.{group.id}", "Exact trusted body/geom set required"
            )
    reserved = {n.get("name") for n in root.iter() if n.get("name")}
    for node in author.iter():
        name = node.get("name")
        if name in reserved or (name and name.startswith("franka")):
            reject("robot_identity_conflict", f"scene:{node.tag}:{name}", "Author name conflicts with trusted platform")
        if node.get("class", "").startswith("franka") or node.get("childclass", "").startswith("franka"):
            reject("robot_identity_conflict", f"scene:{node.tag}", "Author cannot use platform defaults")
    for child in author:
        if child.tag == "compiler":
            if (
                any(k not in {"angle", "autolimits"} for k in child.attrib)
                or child.get("angle", "radian") != "radian"
                or child.get("autolimits", "true") != "true"
            ):
                reject(
                    "capability_unsupported",
                    "scene.compiler",
                    "Use radians; compiler overrides are unsupported",
                    status="unsupported",
                )
        elif child.tag == "worldbody":
            world.extend(list(child))
        elif child.tag == "asset":
            for mesh in child.findall("mesh"):
                if set(mesh.attrib) - {"name", "file", "scale"}:
                    reject(
                        "capability_unsupported",
                        f"scene.mesh.{mesh.get('name')}",
                        "Mesh transform/processing overrides unsupported",
                        status="unsupported",
                    )
            root.find("asset").extend(list(child))
        elif child.tag == "default":
            # Global default overrides would mutate the trusted robot/table.
            if not child.get("class"):
                reject("robot_identity_conflict", "scene.default", "Author defaults must have their own class")
            root.find("default").append(child)
        elif child.tag == "actuator":
            reject(
                "scene_actuator_forbidden",
                "scene.actuator",
                "Scene joints are passive; Panda action remains nine-dimensional",
            )
        else:
            reject(
                "capability_unsupported",
                "scene." + child.tag,
                "Unsupported top-level MJCF section",
                status="unsupported",
            )
    if sum(1 for _ in root.iter("body")) > 256 or sum(1 for _ in root.iter("geom")) > 1024:
        reject("resource_model", "scene", "Body/geom count exceeds local import guard")
    if sum(1 for _ in root.iter("joint")) > 128:
        reject("resource_model", "scene.joints", "Joint count exceeds local import guard")
    width, height = task.scene.camera.image_size
    visual = ET.SubElement(root, "visual")
    ET.SubElement(visual, "global", offwidth=str(width), offheight=str(height))
    # Rewrite platform assets separately so author files cannot shadow them.
    assets = {}
    for relative in verify_platform_assets():
        if relative.startswith("assets/"):
            assets["platform/" + relative] = (DATA / relative).read_bytes()
    for mesh in root.find("asset").findall("mesh"):
        if mesh.get("name", "").startswith("franka/"):
            mesh.set("file", "platform/" + mesh.get("file"))
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="unicode") + "\n", assets, expected_groups


def platform_groups():
    root = ET.fromstring((DATA / "scene.xml").read_bytes())
    robot = root.find("worldbody/body")
    return [
        {"id": "robot", "body": robot.get("name"), "collision_geoms": [g.get("name") for g in robot.iter("geom")]},
        {"id": "table", "body": "world", "collision_geoms": ["floor", "table"]},
    ]
