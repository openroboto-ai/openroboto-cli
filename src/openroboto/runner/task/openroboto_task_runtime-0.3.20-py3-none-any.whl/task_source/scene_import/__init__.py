"""Schema-3 imported scenes, reached through task_source.package.load_package.

Worker-only output: native model, exact entity/part/joint/camera maps, immutable
input bytes and a canonical build identity. No monitor, tool, policy or admission
is installed here. P02 consumes this output; P03 owns process isolation.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import pathlib
import platform as python_platform
import tempfile
from dataclasses import dataclass
from types import MappingProxyType

from task_source.package import TaskPackage

from .context import SceneImportContext, resolve_context
from .errors import SceneImportError, reject
from .resources import prepare_xml, snapshot

__all__ = ["ImportedScene", "SceneImportContext", "SceneImportError", "ScenePackage", "load_scene_package"]


@dataclass(frozen=True)
class ImportedScene:
    source_directory: pathlib.Path
    model: object
    task: object
    contents: object
    xml: str
    assets: object
    model_bytes: bytes
    bindings: dict
    inspection: dict
    initial_states: dict
    manifest: dict
    digest: str

    def reset(self, state_id):
        """Fresh MjData every time; no renderer/monitor or previous episode state."""
        from .validation import reset

        return reset(self.model, self.task, self.bindings, state_id)

    def write_artifact(self, directory):
        """Write an exclusive, self-contained build OUTSIDE the hashed input root.

        The destination must be new. Authored bytes and provenance are retained;
        canonical identity is build.json, native MJB is separately digested.
        """
        from .resources import relative_path

        target = pathlib.Path(directory)
        if target.resolve().is_relative_to(self.source_directory.resolve()):
            reject("artifact_in_package", str(target), "Build artifacts must stay outside the execution package")
        target.mkdir(parents=True, exist_ok=False)
        for name, content in self.contents.items():
            path = target / "execution" / relative_path(name, name)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        for name, content in self.assets.items():
            path = target / "compiled" / relative_path(name, name)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        (target / "compiled" / "scene.xml").write_text(self.xml, encoding="utf-8")
        (target / "compiled" / "model.mjb").write_bytes(self.model_bytes)
        (target / "build.json").write_text(
            json.dumps(self.manifest, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
        )
        return target


@dataclass(frozen=True)
class ScenePackage(TaskPackage):
    imported_scene: ImportedScene


def _package_digest(contents):
    # Use the sole public directory rule on the frozen snapshot, not a second
    # locally reimplemented file-list ordering algorithm.
    from openroboto_protocol.package_digest import package_digest

    with tempfile.TemporaryDirectory(prefix="openroboto-scene-snapshot-") as tmp:
        root = pathlib.Path(tmp)
        for relative, content in contents.items():
            path = root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        return package_digest(root)


def load_scene_package(directory, *, context: SceneImportContext | None = None):
    """Compile with an exact worker-owned context; never infer one from task bytes."""
    try:
        import mujoco
        import numpy as np
        from openroboto_protocol import scene_contract
        from openroboto_protocol.scene_schema import SceneTask
        from openroboto_protocol.tabletop_assets import canonical_digest
        from openroboto_protocol.tabletop_v2 import resource_catalog
        from pydantic import ValidationError
    except ImportError as exc:
        reject("dependency_unavailable", "runtime", str(exc), status="resource_unavailable")
    from .platform import ADAPTER_VERSION, compose
    from .validation import validate

    context = resolve_context(context)
    root = pathlib.Path(directory).expanduser().absolute()
    contents = snapshot(root)
    if "task.json" not in contents:
        reject("dependency_missing", "task.json", "Missing task manifest")
    try:
        raw = json.loads(contents["task.json"])
    except (ValueError, UnicodeError) as exc:
        reject("manifest_json", "task.json", str(exc))
    if isinstance(raw, dict) and isinstance(raw.get("scene"), dict):
        # Frames are metadata, not model bodies/joints. The schema accepts long
        # frame trees; iterative resolution must retain every declared frame.
        for field in ("assets", "joints"):
            if isinstance(raw["scene"].get(field), list) and len(raw["scene"][field]) > 256:
                reject("resource_manifest", "scene." + field, "Descriptor count exceeds local import guard")
    try:
        task = SceneTask.model_validate(raw)
    except ValidationError as exc:
        error = exc.errors(include_input=False, include_context=False)[0]
        reject("scene_invalid", "task.json." + ".".join(map(str, error["loc"])), error["msg"])
    if mujoco.__version__ != "3.17.0":
        reject("runtime_version", "mujoco", "Exact MuJoCo 3.17.0 required", status="resource_unavailable")
    budget = resource_catalog()[task.task_definition.resource_profile]
    if sum(map(len, contents.values())) > budget["max_package_bytes"]:
        reject("resource_bytes", "package", "Actual decompressed bytes exceed selected resource tier")
    author = prepare_xml(task, contents)
    normalized_xml, platform_assets, _groups = compose(task, author, context=context)
    dependency_assets = {"user/" + d.path: contents[d.path] for d in task.scene.dependencies}
    assets = {**platform_assets, **dependency_assets}
    try:
        model = mujoco.MjModel.from_xml_string(normalized_xml, assets)
    except ValueError as exc:
        reject("mujoco_compile", task.scene.entrypoint, str(exc))
    if model.nbody > 256 or model.ngeom > 1024 or model.njnt > 128 or model.nmeshvert > 200_000:
        reject("resource_model", "scene", "Native compiled model exceeds guard")
    bindings, inspection, states, frame_map = validate(model, task, author)
    buffer = np.zeros(mujoco.mj_sizeModel(model), dtype=np.uint8)
    mujoco.mj_saveModel(model, None, buffer)
    model_bytes = buffer.tobytes()
    manifest = {
        "artifact_version": 1,
        "adapter": ADAPTER_VERSION,
        "status": "development",
        "admission": "not_run",
        "reward_status": "not_evaluated",
        "execution_package_digest": _package_digest(contents),
        "execution_profile": scene_contract.profile_ref(),
        "registry": context.registry_document(),
        "importer_identity": context.importer_identity(),
        "environment": task.environment.model_dump(),
        "robot": task.robot.model_dump(),
        "dependencies": [d.model_dump() for d in task.scene.dependencies],
        "engine": {
            "mujoco": mujoco.__version__,
            "numpy": np.__version__,
            "protocol": importlib.metadata.version("openroboto-protocol"),
            "pydantic": importlib.metadata.version("pydantic"),
            "python": python_platform.python_version(),
        },
        "importer_sources": {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(pathlib.Path(__file__).parent.glob("*.py"))
        },
        "normalized_xml_sha256": hashlib.sha256(normalized_xml.encode()).hexdigest(),
        "compiled_model_sha256": hashlib.sha256(model_bytes).hexdigest(),
        "compiled_model_size": len(model_bytes),
        "bindings": bindings,
        "entities": inspection,
        "initial_states": states,
        "frames": frame_map,
        "camera": task.scene.camera.model_dump(),
        "observation": {
            "contract": task.task_definition.observation,
            "allowed_sensors": list(task.execution_contract["permissions"]["allowed_sensors"]),
        },
    }
    digest = canonical_digest(manifest)
    manifest["digest"] = digest
    imported = ImportedScene(
        root,
        model,
        task,
        MappingProxyType(contents),
        normalized_xml,
        MappingProxyType(assets),
        model_bytes,
        bindings,
        inspection,
        states,
        manifest,
        digest,
    )
    return ScenePackage(root, raw, "axis", task.task_id, task.instruction.strip(), imported)
