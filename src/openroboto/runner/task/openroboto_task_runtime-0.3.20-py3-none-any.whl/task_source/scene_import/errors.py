"""Internal import diagnostics; callers must sanitize before public delivery."""

from dataclasses import asdict, dataclass

from task_source.base import TaskSourceError


@dataclass(frozen=True)
class Finding:
    code: str
    path: str
    message: str


class SceneImportError(TaskSourceError):
    def __init__(self, code, path, message, *, status="invalid_package"):
        self.status = status
        self.issues = (Finding(code, path, message),)
        super().__init__(f"{path}: {code}: {message}")

    def to_dict(self):
        return {"status": self.status, "issues": [asdict(i) for i in self.issues]}


def reject(code, path, message, *, status="invalid_package"):
    raise SceneImportError(code, path, message, status=status)
