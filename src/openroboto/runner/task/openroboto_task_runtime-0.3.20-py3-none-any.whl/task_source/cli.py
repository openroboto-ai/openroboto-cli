"""``python -m task_source``：列题、看题、结构校验、准入。

这个命令行是运维 / 出题方看适配层状态的入口，也是验收「10–20 道样题全部
通过准入」的可复现命令::

    python -m task_source sources
    python -m task_source list --source axis
    python -m task_source show 9001
    python -m task_source validate samples/axis samples/robodojo
    python -m task_source admit samples/axis/* samples/robodojo/*
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
from typing import Any

from .admission import admit_all, admit_package, admit_submission
from .base import AdmitResult, TaskSourceError
from .frozen import FrozenPackageError, resolve_frozen_package
from .package import TASK_FILE, discover_packages, load_package
from .registry import (
    get_source,
    load_config,
    load_source_modules,
    registered_checkers,
    registered_sources,
)


def _print_json(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, default=str))


def _source(args: argparse.Namespace):
    name = args.source or (load_config().get("default_source") or "axis")
    return get_source(name, load_config(), root=getattr(args, "root", None))


def command_sources(_: argparse.Namespace) -> int:
    config = load_config()
    load_source_modules(config)
    _print_json(
        {
            "default_source": config.get("default_source"),
            "sources": {
                name: {"factory": entry.get("factory"), "options": entry.get("options") or {}}
                for name, entry in sorted((config.get("sources") or {}).items())
            },
            "registered": registered_sources(),
        }
    )
    return 0


def command_list(args: argparse.Namespace) -> int:
    source = _source(args)
    _print_json({"source": source.source, "tasks": source.list_tasks()})
    return 0


def command_show(args: argparse.Namespace) -> int:
    source = _source(args)
    task = source.load_task(args.task_id)
    checker = source.checker(task)
    _print_json(
        {
            "task_id": task.task_id,
            "source": task.source,
            "instruction": task.instruction,
            "package_dir": task.package_dir,
            "instances": [item.instance for item in task.instances],
            "action_space": task.action_space.to_dict(),
            "observation_space": task.observation_space.to_dict(),
            "checker": checker.describe(),
            "has_reference": task.reference is not None,
            "metadata": {
                key: value
                for key, value in task.metadata.items()
                if key not in {"package", "benchmark_config", "randomization"}
            },
        }
    )
    return 0


def command_validate(args: argparse.Namespace) -> int:
    config = load_config()
    failed = 0
    for value in args.paths:
        root = pathlib.Path(value).expanduser()
        packages = discover_packages(root) if root.is_dir() else []
        if not packages:
            print(f"FAIL {value}: no task packages found")
            failed += 1
            continue
        for directory in packages:
            try:
                package = load_package(directory)
                # 题包所在目录就是搜索根：真实题包不一定在配置的 samples 根下。
                source = get_source(package.source, config, root=directory)
                task = source.load_task(package.task_id)
                checker = source.checker(task)
                for item in task.instances:
                    if not isinstance(item.initial_state, dict):
                        raise TaskSourceError(f"instance {item.instance}: initial_state is not an object")
                print(
                    f"OK   {directory}: source={task.source} task={task.task_id} "
                    f"instances={len(task.instances)} checker={checker.checker_type}"
                )
            except TaskSourceError as exc:
                print(f"FAIL {directory}: {exc}")
                failed += 1
    return 1 if failed else 0


def _admit_one(value: str, config: dict[str, Any]) -> list[AdmitResult]:
    path = pathlib.Path(value).expanduser()
    if path.is_file() and path.suffix == ".json":
        return [admit_submission(path, config=config)]
    if path.is_dir() and (path / TASK_FILE).is_file():
        return [admit_package(path, config=config)]
    if path.is_dir():
        return admit_all(path, config=config)
    raise TaskSourceError(f"not a task package, submission file, or directory: {value}")


def command_admit(args: argparse.Namespace) -> int:
    config = load_config()
    results: list[AdmitResult] = []
    errors: list[str] = []
    for value in args.paths:
        try:
            results.extend(_admit_one(value, config))
        except TaskSourceError as exc:
            errors.append(f"{value}: {exc}")

    if args.json:
        _print_json({"results": [result.to_dict() for result in results], "errors": errors})
    else:
        for result in results:
            mark = "ACCEPT" if result.accepted else "REJECT"
            print(f"{mark} {result.source}/{result.task_id} (runtime: {result.runtime_status})")
            for check in result.checks:
                if check.passed or check.kind != "structural":
                    continue
                print(f"       x {check.name}: {json.dumps(check.detail, ensure_ascii=False, sort_keys=True)}")
        for error in errors:
            print(f"ERROR {error}")
        accepted = sum(result.accepted for result in results)
        print(f"\n{accepted}/{len(results)} accepted; {len(errors)} error(s)")
    return 0 if results and all(result.accepted for result in results) and not errors else 1


def command_admit_runtime(args: argparse.Namespace) -> int:
    """完整准入（结构 + 运行期 + 去重 + 指令）。离线验收用。"""
    from agent_evidence.canonical import isoformat, utcnow
    from agent_evidence.signing import Signer

    from .manifest import build_manifest, sign_manifest
    from .runtime import get_profile, run_admission
    from .worker import package_digest

    profile = get_profile(args.profile, args.profile_config)
    if args.instruction_mode != "profile":
        instruction = dict(profile.get("instruction") or {})
        instruction["mode"] = args.instruction_mode
        profile["instruction"] = instruction
    if args.dedup_index:
        profile["dedup"] = {"index": args.dedup_index}

    started_at = isoformat(utcnow())
    verdict = run_admission(
        args.path,
        profile=profile,
        submitted_at=args.submitted_at,
        commit_block=args.commit_block,
        submission_id=args.submission_id,
    )
    finished_at = isoformat(utcnow())
    submission = {
        "submitted_at": args.submitted_at,
        "commit_block": args.commit_block,
        "submission_id": args.submission_id,
    }

    manifest = None
    if args.signing_key:
        signer = Signer.from_keyfile(args.signing_key)
        digest = args.package_digest or package_digest(args.path)
        manifest = sign_manifest(
            build_manifest(
                verdict=verdict,
                package_digest=digest,
                attempt=args.attempt,
                node_id=args.node_id,
                policy_version=str(profile.get("version") or 1),
                started_at=started_at,
                finished_at=finished_at,
                submission=submission,
                key_id=signer.key_id,
            ),
            signer,
        )

    if args.output and manifest is not None:
        pathlib.Path(args.output).expanduser().write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

    if args.json:
        document = verdict.to_dict()
        if manifest is not None:
            document["manifest"] = manifest
        _print_json(document)
    else:
        mark = "ACCEPT" if verdict.accepted else "REJECT"
        print(f"{mark} {verdict.source}/{verdict.task_id} code={verdict.code} reason={verdict.reason}")
        for check in verdict.checks:
            if check.passed:
                continue
            print(f"       x {check.name}: {json.dumps(check.detail, ensure_ascii=False, sort_keys=True)}")
        if manifest is None:
            print("manifest: not produced (pass --signing-key)")
        elif args.output:
            print(f"manifest: {args.output}")
        else:
            print(json.dumps(manifest, ensure_ascii=False, sort_keys=True))
    return 0 if verdict.accepted else 1


def command_verify_manifest(args: argparse.Namespace) -> int:
    """用 manifest 重跑一次准入，逐项比对输入 / 输出摘要。"""
    from .manifest_cli import verify_against_package

    try:
        report = verify_against_package(
            args.manifest,
            args.path,
            profile_name=args.profile,
            profile_config=args.profile_config,
            dedup_index=args.dedup_index,
            instruction_mode=args.instruction_mode,
            public_key_hex=args.public_key,
            expected_attempt=args.attempt,
            submitted_at=args.submitted_at,
            commit_block=args.commit_block,
            submission_id=args.submission_id,
        )
    except Exception as exc:  # noqa: BLE001 —— 复现失败要给出原因，不能只剩栈
        print(f"ERROR {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    if args.json:
        _print_json(report)
    else:
        if report["errors"]:
            print("MISMATCH")
            for error in report["errors"]:
                print(f"  - {error}")
        else:
            print("MATCH: every check reproduces the same input/output hashes")
        print(
            f"task={report['task_id']} attempt={report['attempt']} "
            f"outcome={report['outcome']} digest={report['package_digest']}"
        )
        for item in report["checks"]:
            status = "same" if item["match"] else "DIFF"
            print(f"  {item['name']:<14} {status} ok={item['expected_ok']}")
    return 0 if not report["errors"] else 1


def command_worker(args: argparse.Namespace) -> int:
    from .worker import main as worker_main

    return worker_main(args.worker_args)


def command_checkers(args: argparse.Namespace) -> int:
    load_source_modules(load_config())
    _print_json({"source": args.source, "checkers": registered_checkers(args.source)})
    return 0


def command_frozen_package(args: argparse.Namespace) -> int:
    """按 EvaluationSpec 的冻结摘要取包；报告 ok / 拒绝原因。

    ``--spec`` 接受后端 ``/eval/jobs/{id}/spec`` 的完整 ``spec`` 或单独一个
    ``task`` 块。执行路径（eval_worker）走同一个 ``resolve_frozen_package()``。
    """

    raw = json.loads(pathlib.Path(args.spec).read_text(encoding="utf-8"))
    task = raw.get("task") if isinstance(raw.get("task"), dict) else raw
    options = {
        "source": str(task.get("source") or ""),
        "task_id": str(task.get("task_id") or ""),
        "version_digest": task.get("version_digest"),
        "package_root": args.root or task.get("package_root"),
        "package_repo": task.get("package_repo"),
        "package_commit": task.get("package_commit"),
        "allow_local": args.local,
    }
    try:
        resolved = resolve_frozen_package(**options)
    except FrozenPackageError as exc:
        _print_json(
            {
                "ok": False,
                "code": exc.code,
                "reason": exc.reason(),
                "task": task,
            }
        )
        return 2
    _print_json(
        {
            "ok": True,
            "task": task,
            "package": {
                "directory": str(resolved.directory),
                "digest": resolved.digest,
                "source": resolved.source,
                "task_id": resolved.task_id,
                "file_count": resolved.file_count,
                "origin": resolved.origin,
            },
        }
    )
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m task_source", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    def add_source_options(command: argparse.ArgumentParser) -> None:
        command.add_argument("--source", help="题源名（默认取配置的 default_source）")
        command.add_argument("--root", help="覆盖题包搜索根目录")

    sources = sub.add_parser("sources", help="列出配置与已注册的题源")
    sources.set_defaults(func=command_sources)

    listing = sub.add_parser("list", help="列出某个题源的任务")
    add_source_options(listing)
    listing.set_defaults(func=command_list)

    show = sub.add_parser("show", help="打印一道题的规格")
    show.add_argument("task_id")
    add_source_options(show)
    show.set_defaults(func=command_show)

    validate = sub.add_parser("validate", help="结构校验（不跑准入判定）")
    validate.add_argument("paths", nargs="+")
    validate.set_defaults(func=command_validate)

    admit = sub.add_parser("admit", help="对题包 / 提交跑准入")
    admit.add_argument("paths", nargs="+")
    admit.add_argument("--json", action="store_true", help="输出 JSON")
    admit.set_defaults(func=command_admit)

    checkers = sub.add_parser("checkers", help="列出某题源注册的 checker 词表")
    checkers.add_argument("--source", required=True)
    checkers.set_defaults(func=command_checkers)

    runtime = sub.add_parser("admit-runtime", help="完整准入（结构 + 运行期 + 去重 + 指令）")
    runtime.add_argument("path", help="题包目录")
    runtime.add_argument("--profile", default="axis-cpu")
    runtime.add_argument("--profile-config", default=None)
    runtime.add_argument("--dedup-index", default=None, help="覆盖 profile 的指纹账本路径")
    runtime.add_argument(
        "--instruction-mode",
        choices=["profile", "llm", "disabled"],
        default="profile",
        help="disabled 只给离线调试用（生产 profile 必须走 llm）",
    )
    runtime.add_argument("--json", action="store_true")
    runtime.add_argument(
        "--signing-key",
        default=None,
        help="validator Ed25519 私钥文件；给了才产出签名 manifest（生产 worker 必填）",
    )
    runtime.add_argument("--node-id", default="cli", help="manifest 里的 node_id")
    runtime.add_argument("--attempt", type=int, default=1)
    runtime.add_argument("--package-digest", default=None, help="覆盖自动计算的题包摘要")
    runtime.add_argument("--output", default=None, help="把签名 manifest 写到这个文件")
    runtime.add_argument("--submitted-at", default=None, help="队列条目的 submitted_at（去重输入）")
    runtime.add_argument("--commit-block", type=int, default=None, help="队列条目的 commit_block（去重输入）")
    runtime.add_argument(
        "--submission-id",
        default=None,
        help="队列条目的 task_id（去重输入；生产 worker 用队列 id）",
    )
    runtime.set_defaults(func=command_admit_runtime)

    verify = sub.add_parser(
        "verify-manifest", help="用 manifest 重跑准入并逐项比对输入 / 输出摘要"
    )
    verify.add_argument("manifest", help="签名 manifest 的 JSON 文件")
    verify.add_argument("path", help="题包目录（与准入时逐字节相同）")
    verify.add_argument("--profile", default="axis-cpu")
    verify.add_argument("--profile-config", default=None)
    verify.add_argument("--dedup-index", default=None, help="与准入时相同的指纹账本")
    verify.add_argument(
        "--instruction-mode",
        choices=["profile", "llm", "disabled"],
        default=None,
        help="与准入时相同的指令检查模式；不传则跟随 profile",
    )
    verify.add_argument(
        "--public-key",
        default=None,
        help="validator 公钥（64 位 hex）；给了就同时验签",
    )
    verify.add_argument(
        "--attempt",
        type=int,
        default=None,
        help="要求 manifest 的 attempt 等于这个值（防止拿错一次的证据）",
    )
    verify.add_argument(
        "--submitted-at",
        default=None,
        help="覆盖 manifest.dedup_input.submitted_at（默认取 manifest 记录值）",
    )
    verify.add_argument(
        "--commit-block",
        type=int,
        default=None,
        help="覆盖 manifest.dedup_input.commit_block（默认取 manifest 记录值）",
    )
    verify.add_argument(
        "--submission-id",
        default=None,
        help="覆盖 manifest.dedup_input.submission_id（默认取 manifest 记录值）",
    )
    verify.add_argument("--json", action="store_true")
    verify.set_defaults(func=command_verify_manifest)

    frozen = sub.add_parser(
        "frozen-package",
        help="按 EvaluationSpec 的 task.version_digest 取包并逐文件验哈希（OPE-197）",
    )
    frozen.add_argument("--spec", required=True, help="冻结 spec（或单独的 task 块）JSON 文件")
    frozen.add_argument("--root", default=None, help="覆盖题包搜索根目录")
    frozen.add_argument(
        "--local",
        action="store_true",
        help="显式本地 smoke/测试模式：没有 repo@commit 时允许按 --root 选包（生产不要传）",
    )
    frozen.set_defaults(func=command_frozen_package)

    worker = sub.add_parser("worker", help="常驻准入 worker（参数透传给 task_source.worker）")
    worker.add_argument("worker_args", nargs=argparse.REMAINDER)
    worker.set_defaults(func=command_worker)
    return parser


def main(argv: list[str] | None = None) -> int:
    values = list(sys.argv[1:] if argv is None else argv)
    # `argparse.REMAINDER` 不会把 `--profile` 这类选项交给子命令：顶层解析器
    # 先看到它，报 `unrecognized arguments`。worker 的参数表在 worker 模块里，
    # 直接把 `worker` 之后的全部参数透传过去（runbook 与 e2e 都用这条命令）。
    if values[:1] == ["worker"]:
        from .worker import main as worker_main

        return worker_main(values[1:])
    parser = build_parser()
    args = parser.parse_args(values)
    try:
        return int(args.func(args))
    except TaskSourceError as exc:
        print(f"ERROR {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
