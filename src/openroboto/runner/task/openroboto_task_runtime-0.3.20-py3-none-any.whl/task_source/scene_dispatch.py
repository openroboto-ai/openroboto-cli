"""Dependency-free role selection; damaged scene pins cannot fall back to v1."""

from collections.abc import Mapping


def is_scene_task(task: Mapping) -> bool:
    ref = task.get("execution_profile") or task.get("expected_execution_profile")
    return (
        task.get("package_layout") == "scene"
        or (isinstance(ref, Mapping) and str(ref.get("id", "")).startswith("panda-open-scene"))
        or any(
            k in task
            for k in (
                "scene_task",
                "scene_registration",
                "receipt_authority",
                "assignment",
                "execution_package_digest",
                "submission_digest",
            )
        )
    )
