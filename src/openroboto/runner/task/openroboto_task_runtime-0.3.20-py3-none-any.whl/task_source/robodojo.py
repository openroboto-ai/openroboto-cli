"""RoboDojo 题源：官方 task + 官方判据 + Isaac Sim 运行时。

与 AXIS 的差别不在接口，而在「题」从哪来：

- AXIS 的题是矿工交的题包（MJCF + 初始状态 + checker 配置）。
- RoboDojo 的题是官方仓库里冻结的 task（``pinned 9226f48e``），**判据也归
  官方**：client 跑完一集写进 ``_result.json`` 的 ``success``。我们不改判据，
  只把它包成统一的 ``Checker``。

所以 ``RoboDojoSource`` 的题包 ``task.json`` 只是一张引用：官方 task 名、
维度、指令、pinned commit、实例数。没有 payload、没有矿工 checker。

运行时路径全部可配置（``ROBODOJO_DIR`` 或配置里的 ``robodojo_dir``），代码里
不出现某台机器的绝对路径。Isaac Sim 不可用时 ``make_env`` 抛
``RuntimeUnavailable``，准入把这类失败归 ``infra``，不判题不合格。
"""

from __future__ import annotations

import json
import os
import pathlib
from typing import Any, Callable, Mapping

from dataclasses import replace

from .base import (
    CheckResult,
    Checker,
    Env,
    ReplayResult,
    RuntimeUnavailable,
    Space,
    TaskSource,
    TaskSourceError,
    TaskSpec,
    UnknownTask,
    state_digest,
)
from .package import TaskPackage, discover_packages, load_package, read_json
from .registry import VALIDATOR_ROOT, _load_factory, register_checker, register_source

PINNED_REF = "9226f48ea694b3f53db12d4922e8b1199f8d0891"
DATA_PATH = pathlib.Path(__file__).resolve().parent / "data" / "robodojo_official_tasks.json"

# RoboDojo 是双臂 ARX X5，pi0.5 / pi0 的 state 与 action 都是 14 维。
ACTION_SPACE = Space(kind="box", shape=(14,), dtype="float32", meta={"semantics": "joint targets"})
OBSERVATION_SPACE = Space(
    kind="dict",
    meta={
        "image": {"shape": [180, 320, 3], "dtype": "uint8", "camera": "head"},
        "state": {"shape": [14], "dtype": "float32"},
    },
)

CHECKER_TYPE = "RoboDojoOfficialChecker"


def official_inventory() -> dict[str, Any]:
    return json.loads(DATA_PATH.read_text(encoding="utf-8"))


def official_task_index() -> dict[str, str]:
    """``{task_name: dimension}``，来自内置快照。"""
    inventory = official_inventory()
    return {
        task: dimension
        for dimension, tasks in inventory["dimensions"].items()
        for task in tasks
    }


class RoboDojoOfficialChecker:
    """官方判据的适配器。

    官方 client 对每一集给出 ``success`` 布尔；这里只读那个值，不做二次判分。
    缺 ``success`` 时 fail closed —— 不把「没跑到判据」当成成功。
    """

    checker_type = CHECKER_TYPE

    def __init__(self, config: Mapping[str, Any]) -> None:
        self.task = str(config.get("task") or config.get("official_task") or "")
        self.dimension = str(config.get("dimension") or "")
        if not self.task:
            raise TaskSourceError("RoboDojoOfficialChecker requires a 'task'")

    def evaluate(self, state: Mapping[str, Any]) -> CheckResult:
        current = state.get("current", state)
        if not isinstance(current, Mapping):
            return CheckResult(False, {"checker_type": self.checker_type, "passed": False, "reason": "bad state"})
        success = current.get("success")
        if not isinstance(success, bool):
            return CheckResult(
                False,
                {
                    "checker_type": self.checker_type,
                    "task": self.task,
                    "passed": False,
                    "reason": "official result has no boolean 'success'",
                },
            )
        return CheckResult(
            success,
            {"checker_type": self.checker_type, "task": self.task, "dimension": self.dimension, "passed": success},
        )

    def describe(self) -> Mapping[str, Any]:
        return {
            "source": "robodojo",
            "checker_type": self.checker_type,
            "task": self.task,
            "dimension": self.dimension,
            "criterion": "official _result.json success",
        }


def _make_checker(config: Mapping[str, Any]) -> RoboDojoOfficialChecker:
    return RoboDojoOfficialChecker(config)


register_checker("robodojo", CHECKER_TYPE, _make_checker)


class IsaacSimEnv:
    """Isaac Sim 环境的接口壳。

    实际执行由 ``libero_eval/robodojo_backend.py`` 驱动（官方 server/client
    + ``_result.json``）。worker 可以通过 ``runner`` 注入自己的执行器；没有
    runner 或 checkpoint 时明确报运行时不可用，不伪造状态。
    """

    def __init__(
        self,
        package_dir: str,
        runner: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
    ) -> None:
        self.package_dir = package_dir
        self.runner = runner

    def _require(self) -> Callable[[Mapping[str, Any]], Mapping[str, Any]]:
        if self.runner is None:
            raise RuntimeUnavailable(
                "RoboDojo requires Isaac Sim 5.1; run through libero_eval/run_eval.py --benchmark robodojo "
                "on the GPU worker (see docs/task-package-format.md)"
            )
        return self.runner

    def reset(self) -> Mapping[str, Any]:
        return self._require()({"op": "reset"})

    def step(self, action: Any) -> Mapping[str, Any]:
        return self._require()({"op": "step", "action": action})

    def state(self) -> Mapping[str, Any]:
        return self._require()({"op": "state"})

    def null_action(self) -> list[float]:
        # 官方协议里「什么都不做」= 全零关节目标（双臂保持初始位）。
        return [0.0] * ACTION_SPACE.shape[0]

    def close(self) -> None:
        if self.runner is not None:
            self.runner({"op": "close"})


class RoboDojoSource(TaskSource):
    source = "robodojo"

    def __init__(self, options: Mapping[str, Any] | None = None) -> None:
        options = dict(options or {})
        self.package_root = pathlib.Path(options.get("package_root") or "samples/robodojo").expanduser()
        if not self.package_root.is_absolute():
            self.package_root = VALIDATOR_ROOT / self.package_root
        self.robodojo_dir = pathlib.Path(
            options.get("robodojo_dir") or os.environ.get("ROBODOJO_DIR") or VALIDATOR_ROOT / "third_party" / "RoboDojo"
        ).expanduser()
        self.pinned_ref = str(options.get("pinned_ref") or PINNED_REF)
        self.runner = self._load_runner(options)
        self.inventory = self._load_inventory(options.get("task_index"))
        self.tasks = {
            task: dimension
            for dimension, names in self.inventory["dimensions"].items()
            for task in names
        }
        self._cache: dict[str, TaskPackage] | None = None

    @staticmethod
    def _load_runner(options: Mapping[str, Any]) -> Any | None:
        """执行器由部署配置注入：``runner``（测试）或 ``runner_factory``
        （``module:function``，返回实现了 ``EpisodeRunner.run`` 的对象）。

        GPU 机上指向官方的 Isaac Sim client；没有执行器时 ``replay`` 抛
        ``RuntimeUnavailable``，准入按基础设施问题重试，不判题不合格。
        """
        runner = options.get("runner")
        if runner is not None:
            return runner
        factory_spec = options.get("runner_factory")
        if factory_spec:
            factory = _load_factory(str(factory_spec))
            return factory(options)
        return None

    def _load_inventory(self, task_index: str | None) -> dict[str, Any]:
        """优先读官方 checkout 的本地索引；没有就用仓库内的冻结快照。

        索引格式与内置快照相同（``dimensions`` / ``instructions`` / ``pinned_ref``）。
        校验通过才采用，避免半截文件让题池悄悄变空。
        """
        candidates = []
        if task_index:
            candidates.append(pathlib.Path(task_index).expanduser())
        candidates.append(self.robodojo_dir / "task_index.json")
        for path in candidates:
            if path.is_file():
                data = read_json(path)
                if not isinstance(data, Mapping) or not isinstance(data.get("dimensions"), Mapping):
                    raise TaskSourceError(f"invalid RoboDojo task index: {path}")
                return dict(data)
        return official_inventory()

    def list_tasks(self) -> list[str]:
        return sorted(self.tasks)

    def load_task(self, task_id: str, instance: int | None = None) -> TaskSpec:
        task_id = str(task_id)
        if task_id not in self.tasks:
            raise UnknownTask(f"RoboDojo task {task_id!r} is not in the pinned official inventory")
        package = self._package_for_task(task_id)
        official_task = str(package.task.get("official_task") or task_id)
        if official_task != task_id:
            raise TaskSourceError(
                f"{package.directory}: official_task {official_task!r} does not match package task_id {task_id!r}"
            )
        dimension = str(package.task.get("dimension") or self.tasks[task_id])
        instruction = package.instruction
        count = int(package.task.get("instance_count") or self._default_instance_count(dimension))
        instances = tuple(
            self._instance(task_id, dimension, number, count)
            for number in range(count)
        )
        total_instances = len(instances)
        if instance is not None:
            instances = tuple(item for item in instances if item.instance == int(instance))
            if not instances:
                raise UnknownTask(f"RoboDojo task {task_id!r} has no instance {instance}")
        return TaskSpec(
            task_id=task_id,
            source=self.source,
            instruction=instruction,
            package_dir=str(package.directory),
            action_space=ACTION_SPACE,
            observation_space=OBSERVATION_SPACE,
            checker_config={
                "type": CHECKER_TYPE,
                "task": task_id,
                "dimension": dimension,
            },
            instances=instances,
            reference=None,
            metadata={
                "dimension": dimension,
                "skill": package.task.get("skill"),
                "instance_count": total_instances,
                "official_task": official_task,
                "robodojo_ref": package.task.get("robodojo_ref"),
                "protocol": package.task.get("protocol"),
                "package": package,
                "inventory_source": "checkout" if (self.robodojo_dir / "task_index.json").is_file() else "snapshot",
            },
        )

    def _default_instance_count(self, dimension: str) -> int:
        inventory = self.inventory.get("episodes") or {}
        if dimension == "generalization":
            half = int(inventory.get("generalization_half", 25))
            return half * 2
        return int(inventory.get("standalone", 50))

    @staticmethod
    def _instance(task_id: str, dimension: str, number: int, count: int) -> Any:
        from .base import InstanceSpec

        layout = "standard"
        if dimension == "generalization" and number >= count // 2:
            layout = "random"
        return InstanceSpec(
            instance=number,
            initial_state={"task": task_id, "dimension": dimension, "layout": layout, "episode": number},
            seed=number,
            metadata={"layout": layout, "official_task": task_id},
        )

    def _packages(self) -> dict[str, TaskPackage]:
        if self._cache is None:
            packages: dict[str, TaskPackage] = {}
            for directory in discover_packages(self.package_root):
                try:
                    package = load_package(directory)
                except TaskSourceError:
                    continue
                if package.source == self.source:
                    packages[package.task_id] = package
            self._cache = packages
        return self._cache

    def _package_for_task(self, task_id: str) -> TaskPackage:
        package = self._packages().get(task_id)
        if package is None:
            # 没交题包时，按官方清单生成一个内存中的引用，方便只读任务清单。
            directory = self.package_root / task_id
            task = {
                "schema_version": 1,
                "source": self.source,
                "task_id": task_id,
                "dimension": self.tasks[task_id],
                "official_task": task_id,
                "instruction": self._instruction(task_id),
                "robodojo_ref": self.pinned_ref,
            }
            return TaskPackage(directory, task, self.source, task_id, task["instruction"])
        return package

    def _instruction(self, task_id: str) -> str:
        instructions = self.inventory.get("instructions") or {}
        return str(instructions.get(task_id) or task_id.replace("_", " ") + ".")

    def make_env(self, task: TaskSpec, instance: int | None = None) -> Env:
        # 整集由 runner 执行；这个壳只给「运行时是否可用」和 null_action 用。
        return IsaacSimEnv(task.package_dir)

    def checker(self, task: TaskSpec) -> Checker:
        from .registry import create_checker

        return create_checker(self.source, task.checker_config)

    def replay(
        self,
        task: TaskSpec,
        instance: int,
        *,
        mode: str = "oracle",
        seed: int = 0,
        noise: Mapping[str, Any] | None = None,
        visibility_options: Mapping[str, Any] | None = None,
    ) -> ReplayResult:
        """官方 client 跑一集，返回它写的 ``_result.json``。

        判据不在这里做：``final_state`` 是 ``{"success": bool, ...}``，由
        ``RoboDojoOfficialChecker`` 统一求值。runner 缺失 = 运行时不可用。

        ``visibility_options`` 是 AXIS 相机检查的 profile 参数；RoboDojo 的
        可见性由官方 runner 写进 ``ReplayResult.visibility``，这里不解释。
        """
        if self.runner is None or not hasattr(self.runner, "run"):
            raise RuntimeUnavailable(
                "RoboDojo requires Isaac Sim 5.1; configure a runner "
                "(see docs/admission-worker.md) and run on the GPU worker"
            )
        result = self.runner.run(task, instance, mode=mode, seed=seed, noise=noise)
        if not isinstance(result, ReplayResult):
            raise TaskSourceError("RoboDojo runner must return task_source.base.ReplayResult")
        if not result.state_digest:
            result = replace(result, state_digest=state_digest(result.final_state))
        return result

    @property
    def action_space(self) -> Space:
        return ACTION_SPACE

    @property
    def observation_space(self) -> Space:
        return OBSERVATION_SPACE

    def static_checks(self, task: TaskSpec) -> list[tuple[str, bool, Mapping[str, Any]]]:
        canonical_dimension = self.tasks.get(task.task_id)
        declared_dimension = task.metadata.get("dimension")
        ref = task.metadata.get("robodojo_ref")
        count = int(task.metadata.get("instance_count") or len(task.instances))
        expected = self._default_instance_count(str(canonical_dimension))
        assets_ok = (self.robodojo_dir / "Assets").is_dir() or (self.robodojo_dir / "task_index.json").is_file()
        return [
            (
                "robodojo.official_task",
                canonical_dimension is not None,
                {"task": task.task_id, "dimension": canonical_dimension},
            ),
            (
                "robodojo.dimension",
                declared_dimension == canonical_dimension,
                {"declared": declared_dimension, "official": canonical_dimension},
            ),
            (
                "robodojo.pinned_ref",
                ref == self.pinned_ref,
                {"declared": ref, "pinned": self.pinned_ref},
            ),
            (
                "robodojo.instance_count",
                count == expected,
                {"count": count, "expected": expected},
            ),
            (
                "robodojo.runtime_configured",
                True,
                {
                    "robodojo_dir": str(self.robodojo_dir),
                    "configured_via": "ROBODOJO_DIR" if os.environ.get("ROBODOJO_DIR") else "default",
                    "checkout_present": assets_ok,
                },
            ),
        ]

    def runtime_status(self) -> tuple[str, Mapping[str, Any]]:
        present = (self.robodojo_dir / "Assets").is_dir() or (self.robodojo_dir / "task_index.json").is_file()
        return (
            "ready" if present else "unavailable",
            {
                "requires": "Isaac Sim 5.1 + A100",
                "robodojo_dir": str(self.robodojo_dir),
                "hint": "bash setup_robodojo.sh; then run libero_eval/run_eval.py --benchmark robodojo",
            },
        )

    def begin_admission(self) -> None:
        """清掉 runner 的 batch 缓存，保证每次 attempt 都真跑一遍。"""
        begin = getattr(self.runner, "begin_admission", None)
        if callable(begin):
            begin()

    def close(self) -> None:
        """停掉 runner 持有的官方 server 子进程。"""
        close = getattr(self.runner, "close", None)
        if callable(close):
            close()


register_source("robodojo", RoboDojoSource)


__all__ = [
    "ACTION_SPACE",
    "CHECKER_TYPE",
    "OBSERVATION_SPACE",
    "PINNED_REF",
    "IsaacSimEnv",
    "RoboDojoOfficialChecker",
    "RoboDojoSource",
    "official_inventory",
    "official_task_index",
]
