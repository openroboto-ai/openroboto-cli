"""Static source-material mutations with actual XML/dependency bytes; no MuJoCo execution."""

import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import PurePosixPath

from openroboto_protocol.package_digest import digest_of_files
from openroboto_protocol.scene_schema import SceneTask, dependency_issues
from openroboto_protocol.tabletop_assets import canonical_digest

from .scene_review import comparison, extract
from .scene_review_samples import mutate


def materialized_variants(root):
    raw = json.loads((root / "task.json").read_text())
    original = {d["path"]: (root / d["path"]).read_bytes() for d in raw["scene"]["dependencies"]}
    original["task.json"] = (root / "task.json").read_bytes()

    def digest(files):
        return digest_of_files((p, hashlib.sha256(files[p]).hexdigest()) for p in sorted(files, key=PurePosixPath))

    base = extract(
        raw,
        execution_package_digest=digest(original),
        submission_digest=canonical_digest({"diagnostic": digest(original)}),
    )
    result = {}
    for mode in ("copy", "rename", "recolor", "translate"):
        task = mutate(raw, mode)
        files = dict(original)
        entrypoint = task["scene"]["entrypoint"]
        xml = files[entrypoint]
        if mode == "rename":
            identifier = raw["task_definition"]["objects"][0]["id"]
            xml = xml.replace(('"' + identifier + '"').encode(), b'"renamed_object"')
        if mode == "recolor":
            tree = ET.fromstring(xml)
            geom = next(tree.iter("geom"))
            geom.set("rgba", "0.9 0.2 0.1 1")
            xml = ET.tostring(tree)
        if mode == "translate":
            tree = ET.fromstring(xml)
            world = tree.find("worldbody")
            for body in world.findall("body"):
                pos = [float(v) for v in body.get("pos", "0 0 0").split()]
                pos[0] += 0.2
                body.set("pos", " ".join(map(str, pos)))
            for frame in task["scene"]["frames"]:
                if frame["parent"] == "world":
                    frame["pose_in_parent"]["position_m"][0] += 0.2
            xml = ET.tostring(tree)
        files[entrypoint] = xml
        for dependency in task["scene"]["dependencies"]:
            content = files[dependency["path"]]
            dependency.update(sha256=hashlib.sha256(content).hexdigest(), size_bytes=len(content))
        files["task.json"] = original["task.json"] if mode == "copy" else json.dumps(task, sort_keys=True).encode()
        parsed = SceneTask.model_validate_json(files["task.json"])
        issues = dependency_issues(parsed, files)
        if issues:
            raise ValueError(issues[0].code)
        feature = extract(
            parsed.model_dump(mode="json"),
            execution_package_digest=digest(files),
            submission_digest=canonical_digest({"diagnostic": digest(files)}),
        )
        result[mode] = {
            "execution_digest": digest(files),
            "file_sha256": {p: hashlib.sha256(c).hexdigest() for p, c in files.items()},
            "comparison": comparison(base, feature),
            "dependency_issues": [],
            "physics_executions": 0,
        }
    return result
