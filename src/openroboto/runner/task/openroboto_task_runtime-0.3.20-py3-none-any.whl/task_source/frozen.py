"""冻结题包的内容寻址与校验（OPE-197）。

B 赛道的 EvaluationSpec 冻结了 ``task.version_digest``，主控确认的取包契约
（OPE-197 评论 905）还要求 ``task.package_repo`` + ``task.package_commit``：

1. 有不可变引用时，按 revision 锁定下载；下载失败就是失败，不回退本地同名包。
2. 下载到**包树之外**（HF 缓存 / 临时目录），只把包目录本身复制进内容寻址
   缓存；HF 元数据、`.cache`、下载临时文件都不进被哈希的树。
3. 拿到目录后**每次都重新读全部文件**算摘要，缓存命中也不例外；缓存被改动
   就拒跑，不会自动重新下载掩盖篡改。
4. 摘要不匹配、缺失、定位缺失、目录不可读、找不到——一律
   :class:`FrozenPackageError`，由调用方拒绝执行。

旧冻结 spec 没有 ``package_repo`` / ``package_commit`` 时**明确拒跑**，不给
它补默认仓库。唯一例外是调用方显式给了执行层本地目录（``package_root`` /
``roots``，本地 smoke / 单测）；这不是生产取包路径。

摘要算法只有一条，住在 :mod:`task_source.package`：``package_files()`` 递归
包目录里的**全部普通文件**（不设白名单、不排除非内容文件），按相对 POSIX
路径排序，逐文件 sha256，再对 ``path\\0file_sha256`` 用换行拼接后的字节串
做 sha256。准入 worker 上报的 ``package_digest``、后端
``tasks.package_digest``、冻结的 ``task.version_digest`` 都是这一条规则。

A 准入与 B 冻结执行共用 :mod:`task_source.hf_snapshot`：HF 标准缓存里的
合法 blob 文件链接在下载边界复制成真实普通文件。SDK 元数据不进入包树，
仓库自身的所有文件（含 dotfiles）照常参与摘要，不按名称排除或修正内容。
"""

from __future__ import annotations

import os
import pathlib
import re
import shutil
import tempfile
import uuid
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from .base import TaskSourceError
from .hf_snapshot import SnapshotError, download_materialized_snapshot
from .package import TASK_FILE, digest_of_files, discover_packages, package_files, read_json

_SHA256_RE = re.compile(r"\A[0-9a-f]{64}\Z")
_COMMIT_RE = re.compile(r"\A[0-9a-f]{40}\Z")
_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")

#: 冻结包不可用的稳定原因码。执行层把它们放进失败原因，便于 191 对账；
#: 这不是后端词表，不改变 ``outcome=failed`` 的分类。
CODE_MISSING_DIGEST = "missing_digest"
CODE_INVALID_DIGEST = "invalid_digest"
CODE_MISSING_LOCATOR = "missing_locator"
CODE_INVALID_PACKAGE_REF = "invalid_package_ref"
CODE_UNAVAILABLE = "unavailable"
CODE_NOT_FOUND = "not_found"
CODE_UNREADABLE = "unreadable"
CODE_UNSAFE_SYMLINK = "unsafe_symlink"
CODE_DIGEST_MISMATCH = "digest_mismatch"
CODE_IDENTITY_MISMATCH = "identity_mismatch"


class FrozenPackageError(TaskSourceError):
    """冻结题包取不到或内容不符。**这是拒跑，不是模型失败。**"""

    def __init__(self, message: str, *, code: str) -> None:
        super().__init__(message)
        self.code = code

    def reason(self) -> str:
        """worker 失败交付里使用的稳定前缀。"""

        return f"frozen-package:{self.code}: {self}"


@dataclass(frozen=True, slots=True)
class ResolvedPackage:
    """已经按冻结摘要验证过的题包目录。"""

    directory: pathlib.Path
    digest: str
    #: 包内 ``task.json`` 的 task_id（源侧 id），可能不等于后端业务 task_id。
    task_id: str
    source: str
    file_count: int
    #: ``fetched`` = 按 repo@commit 下载并复制到内容寻址缓存；
    #: ``local`` = 调用方显式给的本地目录（smoke / 单测）。
    origin: str


def normalize_version_digest(value: Any, *, field: str = "task.version_digest") -> str:
    """校验并归一冻结摘要；缺失 / 形状不对直接拒绝。"""

    if value is None or (isinstance(value, str) and not value.strip()):
        raise FrozenPackageError(
            f"{field} is missing; refusing to run an unverified task package",
            code=CODE_MISSING_DIGEST,
        )
    if not isinstance(value, str):
        raise FrozenPackageError(
            f"{field} must be a 64-char lowercase sha256 hex, got {type(value).__name__}",
            code=CODE_INVALID_DIGEST,
        )
    digest = value.strip().lower()
    if not _SHA256_RE.match(digest):
        raise FrozenPackageError(
            f"{field} must be a 64-char lowercase sha256 hex, got {value!r}",
            code=CODE_INVALID_DIGEST,
        )
    return digest


def normalize_package_ref(
    package_repo: Any, package_commit: Any, *, required: bool = False
) -> tuple[str, str] | None:
    """把 ``task.package_repo`` / ``task.package_commit`` 归一成 ``(repo, commit)``。

    两个字段要么都给、要么都不给。commit 只认 40 位小写 hex——和链上
    commitment / 后端 ``tasks.package_commit`` 同一条形状判据。``required``
    为真时，两个都没给也直接拒绝（生产执行路径）。
    """

    if package_repo is None and package_commit is None:
        if required:
            raise FrozenPackageError(
                "task.package_repo and task.package_commit are missing; "
                "refusing to guess a local package for an old frozen spec",
                code=CODE_MISSING_LOCATOR,
            )
        return None
    if package_repo is None or package_commit is None:
        raise FrozenPackageError(
            "task.package_repo and task.package_commit must be supplied together",
            code=CODE_INVALID_PACKAGE_REF,
        )
    repo = str(package_repo).strip()
    commit = str(package_commit).strip().lower()
    if not repo:
        raise FrozenPackageError(
            "task.package_repo may not be empty", code=CODE_INVALID_PACKAGE_REF
        )
    if not _COMMIT_RE.match(commit):
        raise FrozenPackageError(
            f"task.package_commit must be a 40-char lowercase git sha, got {package_commit!r}",
            code=CODE_INVALID_PACKAGE_REF,
        )
    return repo, commit


def default_package_cache() -> pathlib.Path:
    """内容寻址缓存根目录。``TASK_PACKAGE_CACHE`` 可覆盖，默认仓库内 ``var/``。"""

    configured = os.environ.get("TASK_PACKAGE_CACHE")
    if configured and configured.strip():
        return pathlib.Path(configured).expanduser()
    from .registry import VALIDATOR_ROOT

    return VALIDATOR_ROOT / "var" / "task-packages"


def _cache_directory(repo: str, commit: str, cache_root: pathlib.Path) -> pathlib.Path:
    name = _SAFE_NAME_RE.sub("-", repo).strip("-") or "package"
    return cache_root / f"{name}@{commit}"


def _download_snapshot(
    repo_id: str, commit: str, destination: pathlib.Path, *, token: str | None = None
) -> pathlib.Path:
    """A/B share the same trusted download and ordinary-file materialization."""
    try:
        return download_materialized_snapshot(
            repo_id, commit, destination, token=token or os.environ.get("HF_TOKEN")
        )
    except SnapshotError as exc:
        raise FrozenPackageError(str(exc), code=exc.code) from exc


def _check_symlinks(directory: pathlib.Path) -> None:
    """Materialized, cached and local package trees must contain no links."""

    root = directory.resolve()
    # os.walk(followlinks=False) enumerates the symlink entries without
    # descending into them, so a link loop cannot hang this check.
    links: list[pathlib.Path] = []
    for current, dirnames, filenames in os.walk(root, followlinks=False):
        base = pathlib.Path(current)
        for name in dirnames + filenames:
            candidate = base / name
            if candidate.is_symlink():
                links.append(candidate)
    for path in sorted(links):
        try:
            target = path.resolve()
        except (OSError, RuntimeError) as exc:
            raise FrozenPackageError(
                f"cannot resolve symlink {path}: {exc}", code=CODE_UNREADABLE
            ) from exc
        if not target.exists():
            raise FrozenPackageError(
                f"task package symlink {path} points to a missing target",
                code=CODE_UNREADABLE,
            )
        if target.is_relative_to(root):
            raise FrozenPackageError(
                f"task package symlink {path} points inside the package tree; "
                "aliases and directory loops are not allowed",
                code=CODE_UNSAFE_SYMLINK,
            )
        if target.is_dir():
            raise FrozenPackageError(
                f"task package symlink {path} points to a directory; refusing to walk it",
                code=CODE_UNSAFE_SYMLINK,
            )
        raise FrozenPackageError(
            f"task package symlink {path} escapes the package tree",
            code=CODE_UNSAFE_SYMLINK,
        )


def _copy_candidate(
    source: pathlib.Path,
    *,
    digest: str,
    cache_root: pathlib.Path,
) -> pathlib.Path:
    """把候选包复制到包树外的临时目录，验过摘要后再原子发布。"""

    _check_symlinks(source)
    cache_root.mkdir(parents=True, exist_ok=True)
    temporary = cache_root / f".tmp-{uuid.uuid4().hex}"
    try:
        # The shared download boundary has already removed HF cache links.
        # Local aliases cannot enter the content-addressed cache.
        try:
            shutil.copytree(source, temporary, symlinks=False)
        except (OSError, shutil.Error) as exc:
            raise FrozenPackageError(
                f"cannot copy task package under {source}: {type(exc).__name__}: {exc}",
                code=CODE_UNREADABLE,
            ) from exc
        # 对复制后的目录再走一次共同复验入口：此时不允许任何符号链接。
        verify_package(temporary, digest)
        destination = cache_root / digest
        if destination.exists():
            shutil.rmtree(temporary, ignore_errors=True)
            return destination
        temporary.replace(destination)
        return destination
    except BaseException:
        shutil.rmtree(temporary, ignore_errors=True)
        raise


def _fetch_and_verify(
    *,
    repo: str,
    commit: str,
    digest: str,
    source: str,
    cache_root: pathlib.Path,
    token: str | None = None,
) -> ResolvedPackage:
    """按 repo@commit 下载、复制、验摘要；缓存命中也要复验。"""

    repo_cache = _cache_directory(repo, commit, cache_root)
    content = repo_cache / digest

    if content.is_symlink():
        raise FrozenPackageError("cached package root must not be a symlink", code=CODE_UNSAFE_SYMLINK)
    if content.is_dir():
        # 缓存里有这份内容也必须复验；被改动就拒跑，不自动重下载掩盖篡改。
        return verify_package(content, digest, source=source, origin="fetched")

    cache_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".hf-materialize-", dir=cache_root) as temporary:
        snapshot = _download_snapshot(repo, commit, pathlib.Path(temporary) / "repository", token=token)
        return _verify_downloaded_snapshot(
            snapshot, repo=repo, commit=commit, digest=digest, source=source, repo_cache=repo_cache
        )


def _verify_downloaded_snapshot(
    snapshot: pathlib.Path,
    *,
    repo: str,
    commit: str,
    digest: str,
    source: str,
    repo_cache: pathlib.Path,
) -> ResolvedPackage:
    candidates = _candidates(snapshot, source=source)
    if not candidates:
        raise FrozenPackageError(
            f"downloaded {repo}@{commit[:12]} contains no {source} task package",
            code=CODE_NOT_FOUND,
        )

    mismatches: list[str] = []
    for directory, inner_task_id in candidates:
        try:
            copied = _copy_candidate(
                directory,
                digest=digest,
                cache_root=repo_cache,
            )
        except FrozenPackageError as exc:
            if exc.code == CODE_DIGEST_MISMATCH:
                mismatches.append(f"{directory} -> {_digest_of(directory)}")
                continue
            raise
        resolved = verify_package(
            copied, digest, source=source, task_id=None, origin="fetched"
        )
        if resolved.task_id != inner_task_id:
            # 复制之后 task.json 变了（理论上不会）：宁可拒绝。
            raise FrozenPackageError(
                f"task package under {copied} changed its task_id during verification",
                code=CODE_IDENTITY_MISMATCH,
            )
        return resolved

    detail = "; ".join(mismatches) if mismatches else "<no candidate>"
    raise FrozenPackageError(
        f"downloaded task package {repo}@{commit[:12]} does not match the frozen "
        f"version_digest {digest}: {detail}; refusing to run",
        code=CODE_DIGEST_MISMATCH,
    )


def _digest_of(directory: pathlib.Path) -> str:
    try:
        return digest_of_files(package_files(directory))
    except OSError:
        return "<unreadable>"


def _candidates(root: pathlib.Path, *, source: str) -> list[tuple[pathlib.Path, str]]:
    """``root`` 下所有属于 ``source`` 的题包目录与它们的 ``task.json`` id。"""

    if not root.is_dir():
        return []
    found: list[tuple[pathlib.Path, str]] = []
    for directory in discover_packages(root):
        try:
            task = read_json(directory / TASK_FILE)
        except TaskSourceError:
            continue
        if not isinstance(task, Mapping) or task.get("source") != source:
            continue
        found.append((directory, str(task.get("task_id"))))
    return found


def _dedupe(paths: Sequence[pathlib.Path]) -> list[pathlib.Path]:
    seen: set[pathlib.Path] = set()
    unique: list[pathlib.Path] = []
    for path in paths:
        resolved = path.expanduser().resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        unique.append(resolved)
    return unique


def resolve_frozen_package(
    *,
    source: str,
    task_id: str,
    version_digest: Any,
    package_root: str | pathlib.Path | None = None,
    roots: Sequence[str | pathlib.Path] = (),
    package_repo: Any = None,
    package_commit: Any = None,
    cache_root: str | pathlib.Path | None = None,
    token: str | None = None,
    allow_local: bool = False,
) -> ResolvedPackage:
    """按冻结摘要取得题包目录；任何不确定都拒绝，不回退同名样例。

    - ``package_repo`` / ``package_commit`` 都有：按 revision 下载并复制到
      内容寻址缓存；下载失败 / 摘要不匹配直接拒跑。
    - 没有引用但调用方显式开了 ``allow_local=True`` 并给了
      ``package_root`` / ``roots``：本地 smoke / 单测路径，仍然按摘要选中并
      逐文件校验。**生产入口（eval_worker）永远不传这个开关**。
    - 没有引用且没开本地模式：旧冻结 spec / 不合规 spec，**明确拒跑**
      （``missing_locator``），不猜仓库，也不接受 miner 可填的本地目录字段。

    返回的 ``task_id`` 是包内 ``task.json`` 的源侧 id；调用方必须用它去
    ``TaskSource.load_task()``，不要拿后端业务 task_id 替换。
    """

    digest = normalize_version_digest(version_digest)
    ref = normalize_package_ref(package_repo, package_commit)

    if ref is not None:
        root = (
            pathlib.Path(cache_root).expanduser().resolve()
            if cache_root is not None
            else default_package_cache().resolve()
        )
        root.mkdir(parents=True, exist_ok=True)
        return _fetch_and_verify(
            repo=ref[0],
            commit=ref[1],
            digest=digest,
            source=source,
            cache_root=root,
            token=token,
        )

    if not allow_local:
        raise FrozenPackageError(
            "frozen spec has no task.package_repo / task.package_commit; "
            "production execution refuses to guess a local package "
            "(local package_root is disabled)",
            code=CODE_MISSING_LOCATOR,
        )
    search_roots = []
    if package_root is not None:
        search_roots.append(pathlib.Path(str(package_root)))
    search_roots.extend(pathlib.Path(str(item)) for item in roots)
    if not search_roots:
        raise FrozenPackageError(
            "local mode needs an explicit package_root / roots; refusing to "
            "search a default directory",
            code=CODE_MISSING_LOCATOR,
        )
    search_roots = _dedupe(search_roots)

    hashed: list[tuple[pathlib.Path, str, str]] = []
    unreadable: list[tuple[pathlib.Path, str]] = []
    for root in search_roots:
        for directory, inner_task_id in _candidates(root, source=source):
            try:
                files = package_files(directory)
            except OSError as exc:
                unreadable.append((directory, f"{type(exc).__name__}: {exc}"))
                continue
            computed = digest_of_files(files)
            if computed == digest:
                # 本地路径也走同一个复验入口；返回包内源侧 task_id。
                return verify_package(directory, digest, source=source, origin="local")
            hashed.append((directory, inner_task_id, computed))

    if hashed:
        details = ", ".join(f"{directory} -> {computed}" for directory, _, computed in hashed)
        raise FrozenPackageError(
            f"task package content does not match the frozen version_digest {digest} "
            f"for task {str(task_id)!r}: {details}; refusing to fall back to a same-named package",
            code=CODE_DIGEST_MISMATCH,
        )

    if unreadable:
        directory, error = unreadable[0]
        raise FrozenPackageError(
            f"cannot read task package under {directory}: {error}",
            code=CODE_UNREADABLE,
        ) from None
    searched = ", ".join(str(root) for root in search_roots)
    raise FrozenPackageError(
        f"no task package matching version_digest {digest} for task {str(task_id)!r} "
        f"under {searched}; refusing to run",
        code=CODE_NOT_FOUND,
    )


def locate_local_package(
    source: str, task_id: str, *, root: str | pathlib.Path | None = None
) -> pathlib.Path:
    """本地工具用：按题源配置找到题包目录（**不验证摘要**）。

    只给 smoke / 参照组这类本来就要跑本地样例的工具算 ``version_digest``；
    执行路径不要用它，执行路径只走 :func:`resolve_frozen_package`。
    """

    from .registry import get_source

    task = get_source(source, root=root).load_task(str(task_id))
    return pathlib.Path(task.package_dir).expanduser().resolve()


def verify_package(
    directory: str | pathlib.Path,
    version_digest: Any,
    *,
    source: str | None = None,
    task_id: str | None = None,
    origin: str = "local",
) -> ResolvedPackage:
    """对一个**已经取到**的目录复算摘要。缓存命中也要走这里。"""

    digest = normalize_version_digest(version_digest)
    raw_path = pathlib.Path(directory).expanduser()
    if raw_path.is_symlink():
        raise FrozenPackageError("package root must not be a symlink", code=CODE_UNSAFE_SYMLINK)
    path = raw_path.resolve()
    # 共同复验入口：缓存命中、本地目录、复制后的目录都先做同一套链接检查。
    _check_symlinks(path)
    try:
        files = package_files(path)
    except OSError as exc:
        raise FrozenPackageError(
            f"cannot read task package under {path}: {type(exc).__name__}: {exc}",
            code=CODE_UNREADABLE,
        ) from exc
    computed = digest_of_files(files)
    if computed != digest:
        raise FrozenPackageError(
            f"task package under {path} has digest {computed}, expected {digest}; refusing to run",
            code=CODE_DIGEST_MISMATCH,
        )
    try:
        task = read_json(path / TASK_FILE)
    except TaskSourceError as exc:
        raise FrozenPackageError(
            f"task package under {path} is not loadable: {exc}",
            code=CODE_UNREADABLE,
        ) from exc
    if not isinstance(task, Mapping):
        raise FrozenPackageError(
            f"task package under {path} has a non-object {TASK_FILE}", code=CODE_UNREADABLE
        )
    inner_source = str(task.get("source"))
    inner_task_id = str(task.get("task_id"))
    if source is not None and inner_source != source:
        raise FrozenPackageError(
            f"task package under {path} declares source {inner_source!r}, expected {source!r}",
            code=CODE_IDENTITY_MISMATCH,
        )
    if task_id is not None and inner_task_id != str(task_id):
        raise FrozenPackageError(
            f"task package under {path} declares task_id {inner_task_id!r}, expected {str(task_id)!r}",
            code=CODE_IDENTITY_MISMATCH,
        )
    return ResolvedPackage(
        directory=path,
        digest=computed,
        task_id=inner_task_id,
        source=inner_source,
        file_count=len(files),
        origin=origin,
    )


__all__ = [
    "CODE_DIGEST_MISMATCH",
    "CODE_IDENTITY_MISMATCH",
    "CODE_INVALID_DIGEST",
    "CODE_INVALID_PACKAGE_REF",
    "CODE_MISSING_DIGEST",
    "CODE_MISSING_LOCATOR",
    "CODE_NOT_FOUND",
    "CODE_UNAVAILABLE",
    "CODE_UNREADABLE",
    "CODE_UNSAFE_SYMLINK",
    "FrozenPackageError",
    "ResolvedPackage",
    "default_package_cache",
    "locate_local_package",
    "normalize_package_ref",
    "normalize_version_digest",
    "resolve_frozen_package",
    "verify_package",
]
