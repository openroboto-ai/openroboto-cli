"""One worker-owned paid episode. All outputs remain original evidence, even on failure."""

from __future__ import annotations
import argparse
import hashlib
import os
import pathlib
import time
from datetime import datetime, UTC

from agent_eval import ModelGateway, CallRecorder
from agent_eval.errors import ProviderError
from task_source.panel_state import read, write


class LeaseCheckedGateway(ModelGateway):
    def __init__(self, base, lease_file):
        super().__init__(base.designated, base.policy, recorder=base.recorder, run_budget=base.run_budget)
        self.adapter = base.adapter
        self.ledger = base.ledger
        self.lease_file = lease_file

    def chat(self, *args, **kwargs):
        lease = read(self.lease_file)
        if not lease.get("allowed") or datetime.fromisoformat(
            lease["expires_at"].replace("Z", "+00:00")
        ) <= datetime.now(UTC):
            raise ProviderError("A worker lease is unavailable", provider=self.designated.provider, retryable=False)
        from agent_eval.subscription_gateway import SubscriptionRejected

        try:
            return super().chat(*args, **kwargs)
        except SubscriptionRejected as exc:
            self.subscription_rejection = exc
            raise


def execute(
    spec_path: pathlib.Path,
    signing_key: pathlib.Path,
    host_config: pathlib.Path,
    lease_file: pathlib.Path,
    result_path: pathlib.Path,
):
    from agent_harness import parse_spec, run
    from agent_evidence.signing import Signer

    spec = read(spec_path)
    parsed = parse_spec(spec)
    host = read(host_config)
    # The parent alone downloads with the official read token. Runtime is cache-only.
    for key in tuple(os.environ):
        if key in (
            "HF_TOKEN",
            "HF_READ_TOKEN",
            "HUGGING_FACE_HUB_TOKEN",
            "HUGGINGFACE_HUB_TOKEN",
            "VALIDATOR_API_KEY",
            "ADMIN_API_KEY",
            "ADMIN_KEY",
            "VALIDATOR_KEY",
        ):
            os.environ.pop(key, None)
    os.environ.update(HF_HUB_OFFLINE="1", HF_HUB_DISABLE_IMPLICIT_TOKEN="1")
    signer = Signer.from_keyfile(signing_key)
    signer = Signer("executor", signer.key_id, signer.seed)
    recorder = CallRecorder(spec["evidence"]["path"] + ".calls.jsonl")
    if host["mode"] == "subscription":
        from agent_eval.subscription_gateway import (
            MixedModelPolicy,
            make_model_gateway,
            confirm_session_route,
            session_for_episode,
        )

        subscription = host["subscription"]
        member = spec["panel_binding"]["member"]
        (result_path.parent.parent / "subscription").mkdir(exist_ok=True, mode=0o700)
        policy = MixedModelPolicy(
            run_id=parsed.run_id,
            ledger_path=result_path.parent.parent / "subscription" / f"{member}.jsonl",
            max_calls=subscription["max_calls_per_member"],
            per_episode_calls=subscription["max_calls_per_episode"],
            min_remaining=subscription["min_remaining"],
            session_prefix=host["session_prefix"],
            quota_timeout_s=subscription.get("quota_timeout_s", 8),
            codex_model=parsed.model["model"],
            codex_effort=parsed.model["effort"],
            codex_endpoint=parsed.model["endpoint"],
        )
        base = make_model_gateway(parsed, policy=policy, deepseek_budget=None, recorder=recorder)
    else:
        base = ModelGateway.from_evaluation_spec(parsed.raw, recorder=recorder)
    gateway = LeaseCheckedGateway(base, lease_file)
    started = time.monotonic()
    result = run(parsed, chat_fn=gateway.chat, signer=signer)
    row = result.to_dict()
    row["wall_s"] = time.monotonic() - started
    if host["mode"] == "subscription":
        rejection = getattr(gateway, "subscription_rejection", None)
        if rejection is not None and rejection.code == "quota_floor":
            write(
                result_path.parent.parent / "stops" / (result_path.stem + ".json"),
                {
                    "code": "SUBSCRIPTION_QUOTA_FLOOR",
                    "run_id": parsed.run_id,
                    "attempt_id": spec["attempt_id"],
                    "spec_sha256": hashlib.sha256(spec_path.read_bytes()).hexdigest(),
                    "result": row,
                },
                exclusive=True,
            )
            raise rejection
        row["subscription_route"] = confirm_session_route(policy, session_for_episode(parsed, policy))
    if not read(lease_file).get("allowed"):
        raise RuntimeError("lease failed during the episode; retain original attempt and hold")
    write(result_path, row, exclusive=True)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("spec", "signing-key", "host-config", "lease-file", "result"):
        p.add_argument("--" + name, required=True, type=pathlib.Path)
    a = p.parse_args(argv)
    execute(a.spec, a.signing_key, a.host_config, a.lease_file, a.result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
