"""A daemon -> installed trusted launcher, one child per scene trial.

The launcher is an explicit operator deployment, not an arbitrary command from
work/E. No inline runtime execution fallback exists. Only framed control data
crosses stdin/stdout; API/recovery credentials never enter argv/environment.
"""

from __future__ import annotations

import base64
import hashlib
import os
from pathlib import Path
import re
import select
import stat
import subprocess
import time

from task_source.panel_state import read
from task_source.scene_episode_scope import SceneLaunchError, require
from task_source.scene_views.identity import decode, encoded

MAX_FRAME = 16_000_000
RECEIPT_DOMAIN = "openroboto:scene-parent-lifecycle:v1"


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def trusted_file(path, *, limit=1_000_000, private=False):
    path = Path(path)
    require(path.is_absolute() and path.resolve() == path)
    for parent in path.parents:
        info = parent.lstat()
        require(stat.S_ISDIR(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        info = os.fstat(fd)
        require(stat.S_ISREG(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022 and info.st_size <= limit)
        if private:
            require(stat.S_IMODE(info.st_mode) in {0o400, 0o600}, "scene_episode_private_file_permissions")
        raw = os.read(fd, limit + 1)
        require(len(raw) <= limit)
        return raw
    finally:
        os.close(fd)


def request_document(view, context, metadata, receipt):
    from task_source.panel_client import contains_recovery_material
    from task_source.scene_adapter import original_frozen_task

    original = getattr(context, "receipt_bytes", None)
    require(type(original) is bytes and len(original) <= MAX_FRAME, "scene_episode_authenticated_receipt_missing")
    require(decode(original) == receipt, "scene_episode_authenticated_receipt_mismatch")

    caller = {
        key: str(getattr(context, key))
        for key in (
            "spec_path",
            "result_path",
            "evidence_path",
            "host_config",
            "lease_file",
        )
    }
    caller.update(
        member_id=context.member.id,
        trial=context.trial,
        instance=context.instance,
        registration=dict(context.registration),
    )
    document = {
        "schema_version": "scene-parent-request-v1",
        "work": context.work,
        "commitment": getattr(context, "recovery_commitment", None),
        "frozen_task": original_frozen_task(context.work),
        "metadata": metadata,
        "execution_contents": {name: base64.b64encode(raw).decode() for name, raw in view.contents.items()},
        "submission_manifest": view.manifest,
        "receipt": receipt,
        "receipt_bytes": base64.b64encode(original).decode(),
        "caller": caller,
    }
    require(len(encoded(document)) <= MAX_FRAME)
    require(not contains_recovery_material(document), "scene_episode_recovery_credential_forbidden")
    return decode(encoded(document))  # Freeze the caller's mutable work/metadata before IPC.


def stable_request_digest(request):
    """Resume may refresh L/deadlines, never the frozen episode/identity/E."""
    from task_source.scene_recovery import stable_work

    value = decode(encoded(request))
    value["work"] = stable_work(value["work"])
    value["metadata"].pop("lease_expires_at", None)
    value["metadata"]["receipt_authority"].pop("valid_until", None)
    if value.get("commitment") is not None:
        # Generation and HTTP capture bytes may rotate; the original server
        # enrollment binding and owner cannot change for an already paid trial.
        data = value["commitment"]["data"]
        value["commitment"] = {
            k: data[k] for k in ("schema_version", "run_id", "worker_id", "node_id", "binding_digest")
        }
    value["frozen_task"]["assignment"].pop("lease_expires_at", None)
    value["frozen_task"]["receipt_authority"].pop("valid_until", None)
    return digest(value)


def validate_receipt(document, *, request_digest, spec_sha256, public):
    from benchmark_worker.reference_panel.manifest import verify_manifest

    require(
        type(document) is dict
        and set(document)
        == {
            "domain",
            "request_digest",
            "spec_sha256",
            "deployment_digest",
            "scope",
            "watchdog_parent",
            "parent_pid",
            "initial_cpu",
            "final_cpu",
            "closed",
            "key_id",
            "algorithm",
            "signature",
        },
        "scene_episode_launch_receipt_invalid",
    )
    require(document["domain"] == RECEIPT_DOMAIN and document["closed"] is True)
    require(document["request_digest"] == request_digest and document["spec_sha256"] == spec_sha256)
    require(document["deployment_digest"] == public["deployment_digest"])
    require(document["key_id"] == public["key_id"] and document["algorithm"] == "ed25519")
    require(type(document["parent_pid"]) is int and document["parent_pid"] > 0)
    require(
        type(document["initial_cpu"]) is dict
        and type(document["initial_cpu"].get("usage_usec")) is int
        and document["initial_cpu"]["usage_usec"] == 0
    )
    require(
        type(document["final_cpu"]) is dict
        and type(document["final_cpu"].get("usage_usec")) is int
        and document["final_cpu"]["usage_usec"] >= 0
    )
    for name in ("scope", "watchdog_parent"):
        require(
            type(document[name]) is str
            and Path(document[name]).is_relative_to("/sys/fs/cgroup")
            and ".." not in Path(document[name]).parts
        )
    require(not Path(document["watchdog_parent"]).is_relative_to(Path(document["scope"])))
    # R4: watchdogs share the accounting ancestor, outside its killable child.
    require(
        Path(document["scope"]).name == "episode"
        and Path(document["watchdog_parent"]) == Path(document["scope"]).parent / "watchdogs"
    )
    # Same canonical signing primitive as existing parent evidence, a distinct
    # operational domain. This receipt has no score/reward/physical verdict.
    require(verify_manifest(document, public["public_key_hex"]), "scene_episode_launch_receipt_signature")
    return document


class RegisteredSceneLauncher:
    def __init__(self, configuration):
        self.configuration = Path(configuration)

    def public_document(self):
        require(os.geteuid() != 0, "scene_episode_daemon_must_be_unprivileged")
        doc = decode(trusted_file(self.configuration))
        require(
            type(doc) is dict
            and set(doc)
            == {
                "schema_version",
                "helper",
                "helper_sha256",
                "deployment_digest",
                "key_id",
                "public_key_hex",
                "prepare_timeout_s",
                "episode_timeout_s",
                "cleanup_timeout_s",
                "recovery_timeout_s",
            }
        )
        require(doc["schema_version"] == "scene-parent-launcher-v1")
        for name in ("helper_sha256", "deployment_digest", "public_key_hex"):
            require(type(doc[name]) is str and re.fullmatch(r"[0-9a-f]{64}", doc[name]))
        require(type(doc["key_id"]) is str and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,199}", doc["key_id"]))
        for name, ceiling in (
            ("prepare_timeout_s", 60),
            ("episode_timeout_s", 3600),
            ("cleanup_timeout_s", 10),
            ("recovery_timeout_s", 180),
        ):
            require(type(doc[name]) in (int, float) and 0 < doc[name] <= ceiling)
        require(hashlib.sha256(trusted_file(doc["helper"], limit=32_000_000)).hexdigest() == doc["helper_sha256"])
        return doc

    def open(self, view, *, context, metadata, receipt):
        try:
            public = self.public_document()  # Missing deployment fails BEFORE paid started.
        except (OSError, TypeError, KeyError) as exc:
            raise SceneLaunchError("scene_episode_launcher_unavailable") from exc
        return SceneParentSession(public, request_document(view, context, metadata, receipt))

    def verify_completed(self, path, *, request_digest, spec_sha256):
        return validate_receipt(
            read(path), request_digest=request_digest, spec_sha256=spec_sha256, public=self.public_document()
        )


class SceneParentSession:
    def __init__(self, public, request, *, stage="begin"):
        self.public, self.request = decode(encoded(public)), decode(encoded(request))
        self.request_digest = digest(self.request)
        self.process = None
        self.buffer = b""
        self.spec_sha256 = None
        self.ready = self.executed = False
        self.stage = stage

    def __enter__(self):
        # sudoers delegates this exact immutable helper, with no arguments.
        # Native code never has this daemon UID, sudo, host mounts or env.
        try:
            self.process = subprocess.Popen(
                ["/usr/bin/sudo", "-n", "--", self.public["helper"]],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                env={"LANG": "C.UTF-8", "PATH": "/nonexistent"},
                cwd="/",
                close_fds=True,
                start_new_session=True,
            )
        except OSError:
            raise SceneLaunchError("scene_episode_launcher_unavailable") from None
        self.send({"stage": self.stage, "deployment_digest": self.public["deployment_digest"], "request": self.request})
        return self

    def send(self, value):
        raw = encoded(value) + b"\n"
        require(len(raw) <= MAX_FRAME)
        self.process.stdin.write(raw)
        self.process.stdin.flush()

    def receive(self, stage, timeout):
        deadline = time.monotonic() + timeout
        while b"\n" not in self.buffer:
            remaining = deadline - time.monotonic()
            require(
                remaining > 0 and select.select([self.process.stdout], [], [], remaining)[0],
                "scene_episode_parent_timeout",
            )
            chunk = os.read(self.process.stdout.fileno(), min(65536, MAX_FRAME + 1 - len(self.buffer)))
            require(chunk and len(self.buffer) + len(chunk) <= MAX_FRAME, "scene_episode_parent_lost")
            self.buffer += chunk
        raw, self.buffer = self.buffer.split(b"\n", 1)
        value = decode(raw)
        require(type(value) is dict and value.get("stage") == stage, "scene_episode_parent_protocol")
        require(value.get("request_digest") == self.request_digest, "scene_episode_parent_binding")
        return value

    def candidate(self):
        reply = self.receive("candidate", self.public["prepare_timeout_s"])
        require(set(reply) == {"stage", "request_digest", "spec"} and type(reply["spec"]) is dict)
        return reply["spec"]

    def saved(self, spec_sha256):
        require(self.spec_sha256 is None)
        self.spec_sha256 = spec_sha256
        self.send({"stage": "saved", "request_digest": self.request_digest, "spec_sha256": spec_sha256})
        reply = self.receive("ready", self.public["prepare_timeout_s"])
        require(set(reply) == {"stage", "request_digest", "spec_sha256"} and reply["spec_sha256"] == spec_sha256)
        self.ready = True

    def execute(self, receipt_path):
        require(self.ready and not self.executed)
        self.executed = True
        self.send({"stage": "go", "request_digest": self.request_digest, "spec_sha256": self.spec_sha256})
        self.process.stdin.close()
        reply = self.receive("closed", self.public["episode_timeout_s"] + self.public["cleanup_timeout_s"])
        require(set(reply) == {"stage", "request_digest", "receipt"})
        receipt = validate_receipt(
            reply["receipt"], request_digest=self.request_digest, spec_sha256=self.spec_sha256, public=self.public
        )
        require(self.process.wait(timeout=self.public["cleanup_timeout_s"]) == 0, "scene_episode_parent_failed")
        require(read(receipt_path) == receipt, "scene_episode_launch_receipt_missing")
        return receipt

    def __exit__(self, *exc):
        if self.process is None:
            return
        if not self.process.stdin.closed:
            self.process.stdin.close()  # Child EOF aborts; root manager still enforces its deadline.
        try:
            status = self.process.wait(timeout=self.public["cleanup_timeout_s"])
        except subprocess.TimeoutExpired:
            # Never kill sudo alone and pretend the root descendants were
            # cleaned. The independent root manager must kill/reap its domain.
            raise SceneLaunchError("scene_episode_parent_cleanup_pending") from None
        finally:
            self.process.stdout.close()
        require(status == 0 or exc[0] is not None, "scene_episode_parent_failed")
