"""指令与判定的一致性检查（OPE-112）。

防「说 A 判 B」：指令写「把食物放进冰箱」，判据实际只检查「手靠近冰箱」。
做法是一次 LLM 比对，输入是 ``instruction`` + checker 配置 + checker 词表
语义；输出必须是 JSON。**LLM 不可用或输出不可解析时不出结论**
（``available=False``），准入按基础设施问题重试，绝不把「没问成」当成拒绝。

规则两档，默认严格：

- ``strict``（默认）：模型判「不一致」且置信度 ≥ 0.5 就拒；宁可让矿工补
  证据，也不放「说 A 判 B」的题进池。
- ``lenient``：只有置信度 ≥ 0.9 才拒，适合刚上线、模型结论还在校准的阶段。

每次比对都记录可复查的证据：配置的模型名、provider 实际返回的模型名、
prompt 版本 / SHA-256、被比对的 instruction / checker 摘要、原始输出、
provider 的 call id / 响应 hash。这些证据随 ``checks[].detail`` 进入
``POST /task/admit`` 的 verdict 和 worker 本地账本，不依赖人工复述。
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from .base import TaskSpec, canonical_sha256
from .spec_vocabulary import CHECKER_SEMANTICS

PROMPT_VERSION = "ope112-v1"
DEFAULT_RULE = "strict"
STRICT_CONFIDENCE = 0.5
LENIENT_CONFIDENCE = 0.9
RULE_CONFIDENCE = {
    "strict": STRICT_CONFIDENCE,
    "lenient": LENIENT_CONFIDENCE,
}
#: 单次 LLM 请求的默认超时。profile 里的 ``instruction.model.timeout_s``
#: 可以覆盖；准入引擎还会再加几秒硬上限，防止 provider 不守超时。
DEFAULT_PROVIDER_TIMEOUT_S = 30.0
#: 原始输出最多保留这么多字符；完整内容的 SHA-256 始终记录。
RAW_CONTENT_LIMIT = 8000


@dataclass(frozen=True)
class InstructionCheck:
    """一次比对结论。``available=False`` 表示「没问成」，不是「不一致」。"""

    consistent: bool
    available: bool
    reason: str | None = None
    detail: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "consistent": self.consistent,
            "available": self.available,
            "reason": self.reason,
        }
        payload.update(dict(self.detail))
        return payload


def build_prompt(task: TaskSpec) -> list[dict[str, Any]]:
    checker = json.dumps(task.checker_config, ensure_ascii=False, sort_keys=True, indent=1)
    semantics = json.dumps(CHECKER_SEMANTICS, ensure_ascii=False, indent=1)
    system = (
        "You are an admission reviewer for a robot task competition. You compare a "
        "natural-language task instruction with the executable success checker. "
        "Decide whether a robot that satisfies the checker necessarily satisfies the "
        "instruction. A checker that only checks part of the instruction, checks a different "
        "object, or can be satisfied without doing what the instruction asks is INCONSISTENT. "
        "Answer with a single JSON object and nothing else: "
        '{"consistent": true|false, "confidence": 0.0-1.0, "reason": "<short English reason>"}'
    )
    user = (
        f"Task instruction:\n{task.instruction}\n\n"
        f"Executable checker (JSON):\n{checker}\n\n"
        f"Checker vocabulary:\n{semantics}\n\n"
        "Is the checker consistent with the instruction?"
    )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]


def prompt_sha256(messages: list[dict[str, Any]]) -> str:
    """prompt 的稳定摘要（与 provider 的请求记录同一条 canonical JSON 规则）。"""
    return hashlib.sha256(json.dumps(messages, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def _parse_response(content: Any) -> Mapping[str, Any] | None:
    if not isinstance(content, str):
        return None
    text = content.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        return None
    try:
        value = json.loads(text[start : end + 1])
    except ValueError:
        return None
    return value if isinstance(value, Mapping) else None


def _raw_evidence(content: Any) -> dict[str, Any]:
    if not isinstance(content, str):
        return {"raw_content": None, "raw_content_sha256": None, "raw_content_truncated": False}
    return {
        "raw_content": content[:RAW_CONTENT_LIMIT],
        "raw_content_sha256": hashlib.sha256(content.encode("utf-8")).hexdigest(),
        "raw_content_truncated": len(content) > RAW_CONTENT_LIMIT,
    }


def _base_evidence(
    task: TaskSpec,
    *,
    model: Any,
    rule: str,
    prompt_version: str,
    prompt_sha: str,
) -> dict[str, Any]:
    model_name = model.get("model") if isinstance(model, Mapping) else None
    provider = model.get("provider") if isinstance(model, Mapping) else None
    return {
        "task_id": task.task_id,
        "source": task.source,
        "instruction": task.instruction,
        "instruction_sha256": hashlib.sha256(task.instruction.encode("utf-8")).hexdigest(),
        "checker_sha256": canonical_sha256(task.checker_config),
        "model": model_name,
        "provider": provider,
        "prompt_version": prompt_version,
        "prompt_sha256": prompt_sha,
        "rule": rule,
        "threshold": RULE_CONFIDENCE.get(rule),
    }


def check_instruction(
    task: TaskSpec,
    config: Mapping[str, Any],
    *,
    chat_fn: Callable[..., Mapping[str, Any]] | None = None,
) -> InstructionCheck:
    """比对一道题的 instruction 与 checker 语义。

    ``chat_fn(messages, spec) -> {"content", "provider_meta"}`` 可注入；缺省走
    :func:`agent_eval.chat`。任何「问不成」的情况都返回 ``available=False``，
    由准入引擎映射成 ``infra_download`` 重试。
    """
    model = config.get("model")
    rule = str(config.get("rule") or DEFAULT_RULE).strip().lower()
    prompt_version = str(config.get("prompt_version") or PROMPT_VERSION)
    messages = build_prompt(task)
    prompt_sha = prompt_sha256(messages)
    evidence = _base_evidence(
        task,
        model=model,
        rule=rule,
        prompt_version=prompt_version,
        prompt_sha=prompt_sha,
    )

    if rule not in RULE_CONFIDENCE:
        return InstructionCheck(
            False,
            False,
            f"unknown instruction rule {rule!r}; choose strict or lenient",
            {**evidence, "error": f"unknown rule {rule!r}"},
        )
    if not isinstance(model, Mapping) or not model:
        return InstructionCheck(
            False,
            False,
            "instruction check has no model configured",
            {**evidence, "error": "instruction.model is missing"},
        )

    spec = dict(model)
    spec.setdefault("timeout_s", DEFAULT_PROVIDER_TIMEOUT_S)
    spec.setdefault("stream", False)
    try:
        if chat_fn is None:
            from agent_eval import chat as default_chat

            response = default_chat(messages, [], spec)
        else:
            response = chat_fn(messages, spec)
    except Exception as exc:  # noqa: BLE001 —— provider/网络不可用不是题的错
        return InstructionCheck(
            False,
            False,
            f"instruction provider unavailable: {type(exc).__name__}: {exc}",
            {**evidence, "error": f"{type(exc).__name__}: {exc}"},
        )

    content = response.get("content") if isinstance(response, Mapping) else None
    meta = response.get("provider_meta") if isinstance(response, Mapping) else None
    meta = meta if isinstance(meta, Mapping) else {}
    parsed = _parse_response(content)
    detail = {
        **evidence,
        "response_model": meta.get("response_model"),
        "call_id": meta.get("call_id"),
        "raw_response_sha256": meta.get("raw_response_sha256"),
        **_raw_evidence(content),
        "verdict": dict(parsed) if parsed else None,
    }
    if parsed is None or not isinstance(parsed.get("consistent"), bool):
        return InstructionCheck(False, False, "instruction provider returned no parsable verdict", detail)

    consistent = bool(parsed["consistent"])
    try:
        confidence = float(parsed.get("confidence", 1.0))
    except (TypeError, ValueError):
        confidence = 1.0
    threshold = RULE_CONFIDENCE[rule]
    rejected = (not consistent) and confidence >= threshold
    reason = parsed.get("reason")
    detail["confidence"] = confidence
    detail["rejected"] = rejected
    if rejected:
        return InstructionCheck(False, True, str(reason or "instruction and checker disagree"), detail)
    return InstructionCheck(True, True, None, detail)


def prompt_digest(task: TaskSpec) -> str:
    """Prompt 内容的稳定摘要（写进准入证据用）。"""
    return canonical_sha256(build_prompt(task))


__all__ = [
    "DEFAULT_PROVIDER_TIMEOUT_S",
    "DEFAULT_RULE",
    "InstructionCheck",
    "LENIENT_CONFIDENCE",
    "PROMPT_VERSION",
    "RAW_CONTENT_LIMIT",
    "RULE_CONFIDENCE",
    "STRICT_CONFIDENCE",
    "build_prompt",
    "check_instruction",
    "prompt_digest",
    "prompt_sha256",
]
