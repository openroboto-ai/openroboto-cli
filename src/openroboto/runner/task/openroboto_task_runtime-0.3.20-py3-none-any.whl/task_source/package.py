"""题包目录的发现与最小校验。

题包格式见 ``docs/task-package-format.md``。这里只处理所有题源共有的一层：

    <package>/
      task.json              # 必有：source / task_id / instruction / checker
      ...                    # 其余文件由各题源自己解释

``task.json`` 是矿工提交的入口文件；AXIS 的 20 个实例和 RoboDojo 的官方 task
引用分别落在各自的目录约定里，由 ``AxisSource`` / ``RoboDojoSource`` 校验。

哈希规则与 AXIS 评测程序一致：``json.dumps(value, ensure_ascii=False,
separators=(",", ":"), sort_keys=True)`` 的 UTF-8 SHA-256。矿工和 validator
用同一条规则，哈希不符就是 ``reject_drift``。
"""

from __future__ import annotations

import hashlib
import json
import pathlib
from dataclasses import dataclass
from typing import Any, Mapping

from .base import TASK_SOURCES, TaskSourceError

TASK_FILE = "task.json"
SCHEMA_VERSION = 1


def canonical_json_sha256(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def package_files(directory: str | pathlib.Path) -> tuple[tuple[str, str], ...]:
    """题包里每个文件的 ``(相对 POSIX 路径, sha256(content))``，按路径排序。

    这是 OPE-197 冻结题包摘要的**唯一**文件清单规则：包目录下递归的全部
    普通文件，不设白名单、不排除「非内容文件」（例如 ``reference.json``、
    ``scene.xml``、``.DS_Store`` 都计入）。准入 worker 上报的
    ``package_digest``、后端 ``tasks.package_digest``、EvaluationSpec 的
    ``task.version_digest`` 都由这一条规则算出，任何一层都不另算一套。
    """

    root = pathlib.Path(directory).expanduser().resolve()
    entries: list[tuple[str, str]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        entries.append((relative, hashlib.sha256(path.read_bytes()).hexdigest()))
    return tuple(entries)


def digest_of_files(files: tuple[tuple[str, str], ...]) -> str:
    """把 ``package_files()`` 的结果汇总成题包摘要。"""

    encoded = "\n".join(f"{relative}\0{digest}" for relative, digest in files)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def package_digest(directory: str | pathlib.Path) -> str:
    """题包摘要：``sha256("\\n".join(f"{path}\\0{file_sha256}"))``。

    与 ``task_source.worker`` 历史上报的摘要逐字节相同（实现已收敛到这里）。
    后端只把它当幂等键和「两次回报是不是读了同一份内容」的证据，不解释目录
    结构；同一份题包在任何机器上算出来都一样。
    """

    return digest_of_files(package_files(directory))


def read_json(path: pathlib.Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise TaskSourceError(f"missing file: {path}") from exc
    except ValueError as exc:
        raise TaskSourceError(f"invalid JSON: {path}: {exc}") from exc


def write_json(path: pathlib.Path, value: Any, *, indent: int | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, ensure_ascii=False, indent=indent, sort_keys=bool(indent))
    path.write_text(text + "\n", encoding="utf-8")


@dataclass(frozen=True)
class TaskPackage:
    directory: pathlib.Path
    task: Mapping[str, Any]
    source: str
    task_id: str
    instruction: str

    def path(self, relative: str) -> pathlib.Path:
        candidate = (self.directory / relative).resolve()
        try:
            candidate.relative_to(self.directory.resolve())
        except ValueError as exc:
            raise TaskSourceError(f"package path escapes task directory: {relative!r}") from exc
        return candidate


def load_package(directory: str | pathlib.Path, *, scene_context=None) -> TaskPackage:
    directory = pathlib.Path(directory).expanduser().resolve()
    path = directory / TASK_FILE
    if not path.is_file():
        raise TaskSourceError(f"{directory} is not a task package: missing {TASK_FILE}")
    if path.is_symlink() or path.stat().st_size > 20_000_000:
        from .scene_import.errors import reject

        reject("manifest_unsafe", TASK_FILE, "Task manifest must be a regular bounded file, not a symlink")
    task = read_json(path)
    if not isinstance(task, Mapping):
        raise TaskSourceError(f"{path} must contain a JSON object")
    if task.get("schema_version") == 3 or (
        isinstance(task.get("execution_profile"), Mapping)
        and task["execution_profile"].get("id") == "panda-open-scene-v1"
    ):
        # The imported path owns its complete byte snapshot and compiler. Keep
        # historical v1 parsing/digests and the controlled generator unchanged.
        from .scene_import import load_scene_package

        return load_scene_package(directory, context=scene_context)
    if task.get("schema_version") != SCHEMA_VERSION:
        raise TaskSourceError(f"{path}: unsupported schema_version {task.get('schema_version')!r}")
    source = task.get("source")
    if source not in TASK_SOURCES:
        raise TaskSourceError(f"{path}: source must be one of {list(TASK_SOURCES)}, got {source!r}")
    task_id = task.get("task_id")
    if not isinstance(task_id, (str, int)) or str(task_id).strip() == "":
        raise TaskSourceError(f"{path}: task_id must be a non-empty string or integer")
    instruction = task.get("instruction")
    if not isinstance(instruction, str) or not instruction.strip():
        raise TaskSourceError(f"{path}: instruction must be a non-empty string")
    return TaskPackage(directory, task, str(source), str(task_id), instruction.strip())


def discover_packages(root: str | pathlib.Path) -> list[pathlib.Path]:
    """找出 ``root`` 下（最多两层）所有含 ``task.json`` 的目录。

    目录布局允许两种：``root/<pkg>/task.json``（样题目录）和
    ``root/<group>/<pkg>/task.json``（按题源分组）。排序保证输出稳定。
    """
    root = pathlib.Path(root).expanduser()
    if (root / TASK_FILE).is_file():
        return [root]
    found: list[pathlib.Path] = []
    for depth in (1, 2):
        pattern = "/".join(["*"] * depth) + f"/{TASK_FILE}"
        found.extend(path.parent for path in root.glob(pattern) if path.is_file())
    return sorted(set(found))


def package_id(package: TaskPackage) -> str:
    return f"{package.source}/{package.task_id}"


__all__ = [
    "SCHEMA_VERSION",
    "TASK_FILE",
    "TaskPackage",
    "canonical_json_sha256",
    "digest_of_files",
    "discover_packages",
    "load_package",
    "package_digest",
    "package_files",
    "package_id",
    "read_json",
    "write_json",
]
