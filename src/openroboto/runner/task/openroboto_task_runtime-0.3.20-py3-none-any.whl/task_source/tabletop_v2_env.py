"""v2专用真实Panda环境；在物理子步监测过程，v1推进路径不变。"""

from __future__ import annotations

import numpy as np

from .axis import MujocoAxisEnv
from .base import TaskSourceError
from .tabletop_program import ProgramMonitor


class ComposedMujocoAxisEnv(MujocoAxisEnv):
    def __init__(self, package, payload, runtime):
        super().__init__(package, payload, runtime)
        if self.model.neq or self._grasp_eqs:
            raise TaskSourceError("v2 requires physical contacts, without grasp welds or equality constraints")
        self.program = ProgramMonitor(package.task["task_definition"])

    def reset(self):
        self.program.reset()
        super().reset()
        # Reject the entire generated instance, never resample a convenient one.
        for c in self.data.contact:
            names = [self._contact_body(int(g)) for g in [c.geom1, c.geom2]]
            if c.dist < -0.001 and any(n in {o["id"] for o in self.program.definition["objects"]} for n in names):
                raise TaskSourceError(f"initial_penetration: {names}, depth={-c.dist:g}; retain the failing seed")
        self.program.update(self._physical_state(), 0)
        self._initial = self._state()
        return self._initial

    def _contact_body(self, geom):
        mujoco = self.mujoco
        if geom < 0:
            return "unknown"
        body = int(self.model.geom_bodyid[geom])
        if body == 0:
            return mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_GEOM, geom) or "world"
        return mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_BODY, body) or f"body_{body}"

    def _physical_state(self):
        state = super()._state()
        state.pop("tabletop_goal_hold_steps", None)
        state["contacts"] = []
        for i, c in enumerate(self.data.contact):
            force = np.zeros(6)
            self.mujoco.mj_contactForce(self.model, self.data, i, force)
            frame = np.asarray(c.frame).reshape(3, 3)
            world_force = frame.T @ force[:3]
            state["contacts"].append({
                "a": self._contact_body(int(c.geom1)),
                "b": self._contact_body(int(c.geom2)),
                "distance_m": float(c.dist),
                "point": [float(v) for v in c.pos],
                "force_on_b": [float(v) for v in world_force],
                "normal_on_b": [float(v) for v in frame[0]],
            })
        state["centers_of_mass"] = {
            name: self.data.xipos[i].tolist()
            for i in range(self.model.nbody)
            if (name := self.mujoco.mj_id2name(self.model, self.mujoco.mjtObj.mjOBJ_BODY, i))
        }
        return state

    def _state(self):
        state = self._physical_state()
        state["tabletop_program"] = self.program.snapshot()
        return state

    def step(self, action):
        import math

        values = [float(v) for v in action]
        if len(values) != len(self._actuator_ids) or not all(math.isfinite(v) for v in values):
            raise TaskSourceError("v2 actions require nine finite absolute joint targets")
        for actuator, joint, value in zip(self._actuator_ids, self._joint_ids, values):
            if self.model.jnt_limited[joint]:
                lower, upper = self.model.jnt_range[joint]
                value = min(float(upper), max(float(lower), value))
            self.data.ctrl[actuator] = value
        for _ in range(self.steps_per_control):
            self.mujoco.mj_step(self.model, self.data)
            # Query pose/contact/force at the same integrated tick.
            self.mujoco.mj_forward(self.model, self.data)
            self.program.update(self._physical_state(), self.program.tick + 1)
        return self._state()
