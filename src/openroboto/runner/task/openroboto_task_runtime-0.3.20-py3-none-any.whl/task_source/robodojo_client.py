"""RoboDojo 运行期准入执行器：官方 Isaac Sim client 适配器。

准入引擎只认 :class:`task_source.base.EpisodeRunner`：``run(task, instance,
mode=...)`` 返回一集的 ``ReplayResult``。RoboDojo 的官方仓库没有「参考解动作
轨迹」这一形态，官方能执行一集的入口是 ``scripts/robodojo.sh`` 的
server/client 对（pinned ``9226f48e``）：

- ``server``：XPolicyLab 策略服务（Pi_0.5 / Pi_0，``--policy-dir`` + ``--ckpt``）；
- ``client``：Isaac Sim 仿真端，``--eval-num`` 个 layout，结果写进
  ``eval_result/.../_result.json`` 的 ``details[*].success``。

因此这里的语义是**真实执行官方 client**，不是伪造 success：

- ``oracle``：用配置的官方参考策略跑一遍；同一实例被引擎调用两次时，分别
  用两次独立 batch（``oracle:a`` / ``oracle:b``），让确定性检查比较两次真实
  物理运行，而不是同一份缓存。
- ``noise``：在参考策略服务前加一层动作扰动代理（``task_source.
  robodojo_policy_server --mode noise``），按 profile 的幅度扰动关节目标。
- ``nop``：用空策略服务（``--mode null``）返回「保持当前关节」的动作，
  让官方判据自己判；不猜 success。

一个 batch 只启动一次 server/client，按 ``_result.json`` 的 ``details``
覆盖整道题的全部 layout；额外的进程内采集器将真实初末物理态写入独立 sidecar，
校验 task/run/layout/seed 与源码身份后才传给准入。引擎逐实例调用时命中同一 batch 缓存。真实 GPU
执行仍必须在 A100 + Isaac Sim 5.1 上完成；在普通机器上本模块只会抛
``RuntimeUnavailable``（准入记 ``infra_download``），不会把缺运行时当成通过。

配置入口::

    "robodojo": {
      "factory": "task_source.robodojo:RoboDojoSource",
      "options": {
        "package_root": "samples/robodojo",
        "runner_factory": "task_source.robodojo_client:make_runner"
      }
    }

机器相关的路径 / GPU / checkpoint 走环境变量（见 ``docs/admission-worker.md``），
不写进仓库配置。
"""

from __future__ import annotations

import atexit
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol

from .base import ReplayResult, RuntimeUnavailable, TaskSourceError, TaskSpec, state_digest
from .registry import VALIDATOR_ROOT
from .robodojo_capture import EVAL_ENV_SHA256, OFFICIAL_REVISION, SCHEMA, state_structure, validate_state

DEFAULT_ENV_CFG = "arx_x5"
DEFAULT_ACTION_TYPE = "joint"
DEFAULT_EVAL_ENV = "RoboDojo"
DEFAULT_POLICY_NAME = "Pi_05"


# ---------------------------------------------------------------------------
# 配置
# ---------------------------------------------------------------------------


def _env(name: str) -> str | None:
    value = os.environ.get(name)
    return value if value else None


def _option(options: Mapping[str, Any], key: str, env: str | None = None, default: Any = None) -> Any:
    value = options.get(key)
    if value not in (None, ""):
        return value
    if env:
        value = _env(env)
        if value:
            return value
    return default


def _as_int(value: Any, label: str, default: int | None = None) -> int:
    if value in (None, ""):
        if default is None:
            raise TaskSourceError(f"RoboDojo runner requires {label}")
        return default
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise TaskSourceError(f"RoboDojo runner {label} must be an integer, got {value!r}") from exc


@dataclass(frozen=True)
class RunnerConfig:
    robodojo_dir: str
    policy_dir: str | None
    policy_name: str
    checkpoint: str | None
    checkpoint_label: str | None
    policy_env: str
    eval_env: str
    policy_gpu: int
    env_gpu: int
    env_cfg: str
    action_type: str
    layout_seed: int
    episodes: int | None
    server_timeout_s: float
    client_timeout_s: float
    work_dir: str
    noise_enabled: bool

    @property
    def requires_reference(self) -> bool:
        return self.policy_dir is None or self.checkpoint is None


def _config_from_options(options: Mapping[str, Any]) -> RunnerConfig:
    robodojo_dir = _option(
        options,
        "robodojo_dir",
        "ROBODOJO_DIR",
        str(VALIDATOR_ROOT / "third_party" / "RoboDojo"),
    )
    policy_dir = _option(options, "policy_dir", "ROBODOJO_POLICY_DIR")
    policy_name = _option(options, "policy_name", "ROBODOJO_POLICY_NAME")
    if not policy_name and policy_dir:
        policy_name = os.path.basename(str(policy_dir).rstrip("/"))
    checkpoint = _option(options, "checkpoint", "ROBODOJO_CKPT")
    checkpoint_label = _option(options, "checkpoint_label", "ROBODOJO_CKPT_LABEL") or checkpoint
    gpu = _as_int(_option(options, "gpu", "ROBODOJO_GPU"), "gpu", 0)
    policy_gpu = _as_int(_option(options, "policy_gpu", "ROBODOJO_POLICY_GPU"), "policy_gpu", gpu)
    env_gpu = _as_int(_option(options, "env_gpu", "ROBODOJO_ENV_GPU"), "env_gpu", gpu)
    return RunnerConfig(
        robodojo_dir=str(robodojo_dir),
        policy_dir=str(policy_dir) if policy_dir else None,
        policy_name=str(policy_name or DEFAULT_POLICY_NAME),
        checkpoint=str(checkpoint) if checkpoint else None,
        checkpoint_label=str(checkpoint_label) if checkpoint_label else None,
        policy_env=str(_option(options, "policy_env", "ROBODOJO_POLICY_ENV", "uv")),
        eval_env=str(_option(options, "eval_env", "ROBODOJO_EVAL_ENV", DEFAULT_EVAL_ENV)),
        policy_gpu=policy_gpu,
        env_gpu=env_gpu,
        env_cfg=str(_option(options, "env_cfg", "ROBODOJO_ENV_CFG", DEFAULT_ENV_CFG)),
        action_type=str(_option(options, "action_type", "ROBODOJO_ACTION_TYPE", DEFAULT_ACTION_TYPE)),
        layout_seed=_as_int(
            _option(options, "layout_seed", "ROBODOJO_LAYOUT_SEED"), "layout_seed", 0
        ),
        episodes=(
            _as_int(_option(options, "episodes", "ROBODOJO_EPISODES"), "episodes")
            if _option(options, "episodes", "ROBODOJO_EPISODES") not in (None, "")
            else None
        ),
        server_timeout_s=float(_option(options, "server_timeout_s", "ROBODOJO_SERVER_TIMEOUT_S", 900)),
        client_timeout_s=float(_option(options, "client_timeout_s", "ROBODOJO_CLIENT_TIMEOUT_S", 3600)),
        work_dir=str(
            _option(
                options,
                "work_dir",
                "ROBODOJO_ADMISSION_DIR",
                str(VALIDATOR_ROOT / "var" / "robodojo_admission"),
            )
        ),
        noise_enabled=str(_option(options, "noise_enabled", "ROBODOJO_NOISE", "1")).lower()
        not in {"0", "false", "no", "off"},
    )


# ---------------------------------------------------------------------------
# 官方命令与结果
# ---------------------------------------------------------------------------


def _free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def build_server_command(config: RunnerConfig, task_id: str, port: int) -> list[str]:
    if config.policy_dir is None or config.checkpoint is None:
        raise RuntimeUnavailable(
            "RoboDojo oracle/noise requires a reference policy: set ROBODOJO_POLICY_DIR "
            "(XPolicyLab/policy/<NAME>) and ROBODOJO_CKPT"
        )
    return [
        "conda",
        "run",
        "--no-capture-output",
        "-n",
        config.eval_env,
        "bash",
        os.path.join(config.robodojo_dir, "scripts", "robodojo.sh"),
        "server",
        "--policy-dir",
        config.policy_dir,
        "--task",
        task_id,
        "--ckpt",
        str(config.checkpoint),
        "--env-cfg",
        config.env_cfg,
        "--action-type",
        config.action_type,
        "--seed",
        str(config.layout_seed),
        "--policy-gpu",
        str(config.policy_gpu),
        "--policy-env",
        config.policy_env,
        "--policy-port",
        str(port),
        "--bind-host",
        "127.0.0.1",
    ]


def build_client_command(
    config: RunnerConfig,
    task_id: str,
    port: int,
    episodes: int,
    run_id: str,
) -> list[str]:
    return [
        "conda",
        "run",
        "--no-capture-output",
        "-n",
        config.eval_env,
        "bash",
        os.path.join(config.robodojo_dir, "scripts", "robodojo.sh"),
        "client",
        "--task",
        task_id,
        "--policy-name",
        config.policy_name,
        "--policy-host",
        "127.0.0.1",
        "--policy-port",
        str(port),
        "--env-cfg",
        config.env_cfg,
        "--seed",
        str(config.layout_seed),
        "--env-gpu",
        str(config.env_gpu),
        "--ckpt",
        str(config.checkpoint_label or "external"),
        "--action-type",
        config.action_type,
        "--eval-num",
        str(episodes),
    ]


def expected_result_path(config: RunnerConfig, task_id: str, run_id: str) -> str:
    """官方 client 的结果文件路径（与 ``src/eval_client/eval_env.py`` 一致）。"""
    return os.path.join(
        config.robodojo_dir,
        "eval_result",
        "RoboDojo",
        task_id,
        config.policy_name,
        config.env_cfg,
        f"{config.layout_seed}_ckpt_name={config.checkpoint_label or 'external'},action_type={config.action_type}",
        run_id,
        "_result.json",
    )


def _strict_success(entry: Mapping[str, Any], path: str, label: str) -> bool:
    if "success" not in entry:
        raise RuntimeUnavailable(f"{path}: {label} has no 'success'")
    value = entry["success"]
    if not isinstance(value, bool):
        raise RuntimeUnavailable(
            f"{path}: {label} 'success' must be a JSON boolean, got {type(value).__name__} {value!r}"
        )
    return value


def _strict_layout(entry: Mapping[str, Any], path: str, label: str) -> int:
    if "layout_id" not in entry:
        raise RuntimeUnavailable(f"{path}: {label} has no 'layout_id'")
    value = entry["layout_id"]
    if isinstance(value, bool) or not isinstance(value, int):
        raise RuntimeUnavailable(
            f"{path}: {label} 'layout_id' must be an integer, got {type(value).__name__} {value!r}"
        )
    if value < 0:
        raise RuntimeUnavailable(f"{path}: {label} 'layout_id' must be non-negative, got {value}")
    return value


def _strict_score(entry: Mapping[str, Any], path: str, label: str) -> float | None:
    if "score" not in entry or entry["score"] is None:
        return None
    value = entry["score"]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise RuntimeUnavailable(
            f"{path}: {label} 'score' must be a finite number or null, got "
            f"{type(value).__name__} {value!r}"
        )
    value = float(value)
    if not math.isfinite(value):
        raise RuntimeUnavailable(f"{path}: {label} 'score' must be finite, got {value!r}")
    return value


def validate_physical_state(value: Any) -> dict[str, Any] | None:
    """校验并规范化执行器带回的物理状态。

    只认明确的物理字段：``qpos`` 必填，非空、扁平、全是有限数字；
    ``qvel`` 可选，若存在必须同长度且全是有限数字。其它字段原样保留
    （未知字段由 ``compare_states`` 按类型比较）。

    只有一个判定摘要（如 ``{"success": true, "score": 1.0}``）、空对象或
    未知格式时返回 ``None``，表示**没有可验证的物理状态**，由上层 fail-closed；
    不靠字段名 ``final_state`` / ``state`` 或对象非空来认证。``qpos`` 存在但
    为 null/空/非数字/NaN/Inf、``qvel`` 形状不符时直接 ``RuntimeUnavailable``。
    """
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise RuntimeUnavailable("physical state must be an object")
    if not value:
        return None
    if "qpos" not in value:
        # 只有 success/score 之类的判定摘要，或未知格式；不要猜物理状态。
        return None

    normalized = dict(value)
    lengths: dict[str, int] = {}
    for key in ("qpos", "qvel"):
        if key not in value:
            continue
        series = value[key]
        if not isinstance(series, (list, tuple)) or not series:
            raise RuntimeUnavailable(f"physical state {key!r} must be a non-empty array")
        numbers: list[float] = []
        for index, item in enumerate(series):
            if isinstance(item, bool) or not isinstance(item, (int, float)):
                raise RuntimeUnavailable(
                    f"physical state {key!r}[{index}] must be a finite number, got "
                    f"{type(item).__name__} {item!r}"
                )
            number = float(item)
            if not math.isfinite(number):
                raise RuntimeUnavailable(f"physical state {key!r}[{index}] must be finite, got {number!r}")
            numbers.append(number)
        normalized[key] = numbers
        lengths[key] = len(numbers)
    if "qvel" in lengths and lengths["qvel"] != lengths["qpos"]:
        raise RuntimeUnavailable(
            f"physical state qpos/qvel length mismatch: {lengths['qpos']} != {lengths['qvel']}"
        )
    return normalized


def _strict_state(entry: Mapping[str, Any], path: str, label: str) -> tuple[Mapping[str, Any] | None, str | None]:
    """官方结果如果带**可验证**物理状态（``final_state`` / ``state``），保留它。"""
    for key in ("final_state", "state"):
        if key not in entry:
            continue
        value = entry[key]
        if not isinstance(value, Mapping):
            raise RuntimeUnavailable(f"{path}: {label} {key!r} must be an object")
        if not value:
            raise RuntimeUnavailable(f"{path}: {label} {key!r} is empty")
        physical = validate_physical_state(value)
        if physical is None:
            # 只有成绩/未知格式：不是物理证据，交给 runtime fail-closed。
            return None, None
        return physical, f"official_result.{key}"
    return None, None


def parse_result_file(path: str) -> dict[int, dict[str, Any]]:
    """把官方 ``_result.json`` 的 ``details`` 解析成 ``{layout_id: outcome}``。

    严格 fail-closed：``success`` 必须是 JSON boolean（字符串 ``"false"``
    不能变成 True）；``layout_id`` 必须是唯一的非负整数；同一 layout 出现
    两次、缺字段、``score`` 非有限数字都直接拒绝。官方合法结果的行为不变。
    """
    try:
        with open(path, encoding="utf-8") as handle:
            payload = json.loads(handle.read())
    except FileNotFoundError as exc:
        raise RuntimeUnavailable(f"RoboDojo client did not write {path}") from exc
    except (OSError, ValueError) as exc:
        raise RuntimeUnavailable(f"RoboDojo result {path} is not readable JSON: {exc}") from exc
    if not isinstance(payload, Mapping):
        raise RuntimeUnavailable(f"RoboDojo result {path} must be a JSON object")
    details = payload.get("details")
    if not isinstance(details, Mapping):
        raise RuntimeUnavailable(f"RoboDojo result {path} has no 'details' object")
    outcomes: dict[int, dict[str, Any]] = {}
    for index, (key, entry) in enumerate(details.items()):
        label = f"details[{key!r}]"
        if not isinstance(entry, Mapping):
            raise RuntimeUnavailable(f"{path}: {label} must be an object")
        layout = _strict_layout(entry, path, label)
        if layout in outcomes:
            raise RuntimeUnavailable(f"{path}: duplicate layout_id {layout} in details")
        success = _strict_success(entry, path, label)
        score = _strict_score(entry, path, label)
        final_state, state_source = _strict_state(entry, path, label)
        outcomes[layout] = {
            "success": success,
            "score": score,
            "layout_id": layout,
            "final_state": final_state,
            "state_source": state_source,
            "detail_index": index,
        }
    if not outcomes:
        raise RuntimeUnavailable(f"RoboDojo result {path} contains no per-layout outcomes")
    return outcomes


def verify_capture_source(root: str) -> None:
    """Refuse a drifted checkout before starting any GPU process."""
    try:
        revision = subprocess.check_output(["git", "-C", root, "rev-parse", "HEAD"], text=True).strip()
        clean = subprocess.run(["git", "-C", root, "diff", "--quiet", "HEAD", "--"], check=False)
        digest = hashlib.sha256(Path(root, "src/eval_client/eval_env.py").read_bytes()).hexdigest()
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeUnavailable(f"cannot verify RoboDojo collector source: {exc}") from exc
    if revision != OFFICIAL_REVISION or clean.returncode != 0 or digest != EVAL_ENV_SHA256:
        raise RuntimeUnavailable("RoboDojo physics capture requires the clean pinned official checkout")


def prepare_capture(work_dir: str, run_id: str) -> tuple[Path, str, str]:
    """A fresh bootstrap and output directory, private to one client invocation."""
    directory = Path(work_dir).expanduser().resolve() / run_id / "physics"
    directory.mkdir(parents=True, exist_ok=False)
    bootstrap = directory.parent / "bootstrap"
    bootstrap.mkdir()
    collector = Path(__file__).with_name("robodojo_capture.py")
    shutil.copyfile(collector, bootstrap / collector.name)
    (bootstrap / "sitecustomize.py").write_text(
        "from robodojo_capture import install\ninstall()\n", encoding="utf-8"
    )
    return directory, uuid.uuid4().hex, hashlib.sha256(collector.read_bytes()).hexdigest()


def attach_captured_states(
    outcomes: dict[int, dict[str, Any]], directory: Path, *, task_id: str, run_id: str,
    layout_seed: int, capture_token: str, collector_sha256: str, batch_kind: str, perturbation_seed: int,
) -> None:
    """Read only this process's fresh, complete, identity-bound engine evidence."""
    expected_files = {f"{layout}.json" for layout in outcomes}
    try:
        actual_files = {path.name for path in directory.iterdir()}
    except OSError as exc:
        raise RuntimeUnavailable(f"RoboDojo physics sidecars unavailable: {exc}") from exc
    if actual_files != expected_files:
        raise RuntimeUnavailable("RoboDojo physics sidecars missing or contain unexpected layouts")
    for layout, outcome in outcomes.items():
        path = directory / f"{layout}.json"
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            expected = {
                "schema": SCHEMA, "official_revision": OFFICIAL_REVISION,
                "eval_env_sha256": EVAL_ENV_SHA256, "collector_sha256": collector_sha256,
                "capture_token": capture_token, "task_id": task_id, "run_id": run_id,
                "layout_seed": layout_seed, "layout_id": layout,
                "batch_kind": batch_kind, "perturbation_seed": perturbation_seed,
            }
            if not isinstance(payload, dict) or any(
                type(payload.get(key)) is not type(value) or payload[key] != value
                for key, value in expected.items()
            ):
                raise ValueError("physics sidecar identity mismatch")
            env_index = payload["env_index"]
            if isinstance(env_index, bool) or not isinstance(env_index, int) or env_index < 0:
                raise ValueError("invalid captured env_index")
            detail = payload["official_detail"]
            if not isinstance(detail, Mapping) or set(detail) != {"layout_id", "success", "score"}:
                raise ValueError("incomplete official result detail")
            normalized_detail = {
                "layout_id": _strict_layout(detail, str(path), "official_detail"),
                "success": _strict_success(detail, str(path), "official_detail"),
                "score": _strict_score(detail, str(path), "official_detail"),
            }
            expected_detail = {"layout_id": layout, "success": outcome["success"], "score": outcome["score"]}
            if normalized_detail != expected_detail:
                raise ValueError("physics sidecar differs from official result detail")
            initial, final = validate_state(payload["initial_state"]), validate_state(payload["final_state"])
            if state_structure(initial) != payload["inventory"] or state_structure(final) != payload["inventory"]:
                raise ValueError("captured initial/terminal entity inventory mismatch")
        except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
            raise RuntimeUnavailable(f"invalid RoboDojo physics sidecar {path}: {exc}") from exc
        outcome.update(
            initial_state=initial, final_state=final,
            state_source="isaac_engine.physics_sidecar", state_path=str(path),
            state_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        )


# ---------------------------------------------------------------------------
# batch 执行器
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BatchRequest:
    task_id: str
    kind: str  # oracle:a / oracle:b / noise:<variant> / nop
    server_mode: str  # reference / noise / null
    episodes: int
    config: RunnerConfig
    noise: Mapping[str, Any] | None = None
    #: noise 批次的完整受控 seed（引擎的 perturbation_seed，不做取模合并）。
    #: oracle/nop 不用；它参与 server 身份、batch 缓存和代理 RNG，避免不同
    #: seed/trial 被缓存吞掉。
    seed: int = 0


@dataclass
class BatchOutcome:
    outcomes: dict[int, dict[str, Any]]
    result_path: str
    run_id: str
    log_paths: dict[str, str] = field(default_factory=dict)


class BatchExecutor(Protocol):
    def execute(self, request: BatchRequest) -> BatchOutcome: ...

    def close(self) -> None: ...


def _tail(path: str, lines: int = 40) -> str:
    try:
        content = open(path, encoding="utf-8", errors="replace").read().splitlines()
    except OSError:
        return ""
    return "\n".join(content[-lines:])


class _PolicyServer:
    def __init__(self, process: subprocess.Popen, log_path: str, port: int, mode: str) -> None:
        self.process = process
        self.log_path = log_path
        self.port = port
        self.mode = mode

    def stop(self) -> None:
        if self.process.poll() is not None:
            return
        try:
            os.killpg(self.process.pid, 15)
            self.process.wait(timeout=10)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            if self.process.poll() is None:
                os.killpg(self.process.pid, 9)
                self.process.wait()


class SubprocessBatchExecutor:
    """真实执行：官方 server + client 子进程。

    server 按 ``(task_id, server_mode)`` 复用；client 每个 batch 启动一次。
    任何一个子进程失败都抛 ``RuntimeUnavailable``，绝不返回假 success。
    """

    def __init__(self, config: RunnerConfig) -> None:
        self.config = config
        self._servers: dict[tuple[str, str, str], _PolicyServer] = {}
        self._closed = False

    # -- server ------------------------------------------------------------
    def _wait_port(self, process: subprocess.Popen, port: int, log_path: str, timeout: float) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeUnavailable(
                    f"RoboDojo policy server exited with {process.returncode}:\n{_tail(log_path)}"
                )
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=1):
                    return
            except OSError:
                time.sleep(0.5)
        raise RuntimeUnavailable(
            f"RoboDojo policy server did not listen on {port} within {timeout:.0f}s:\n{_tail(log_path)}"
        )

    def _start_server(
        self,
        task_id: str,
        server_mode: str,
        noise: Mapping[str, Any] | None = None,
        seed: int = 0,
    ) -> _PolicyServer:
        signature = ""
        if server_mode == "noise":
            # seed 和 noise 配置共同决定代理的 RNG；不同 seed 不能复用同一个服务。
            signature = hashlib.sha256(
                json.dumps(
                    {"seed": int(seed), "noise": dict(noise or {})},
                    sort_keys=True,
                    default=str,
                ).encode("utf-8")
            ).hexdigest()[:12]
        key = (task_id, server_mode, signature)
        existing = self._servers.get(key)
        if existing is not None:
            if existing.process.poll() is None:
                return existing
            # 上一次 attempt 的 server 已经退出；不要拿死端口去启 client。
            self._servers.pop(key, None)
            existing.stop()
        os.makedirs(self.config.work_dir, exist_ok=True)
        port = _free_port()
        stamp = time.strftime("%Y%m%d_%H%M%S")
        log_path = os.path.join(
            self.config.work_dir, f"server-{task_id}-{server_mode}-{stamp}-{uuid.uuid4().hex[:8]}.log"
        )
        env = dict(os.environ)
        env.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
        if server_mode == "reference":
            command = build_server_command(self.config, task_id, port)
        else:
            command = build_null_or_proxy_server_command(
                self.config,
                server_mode,
                port,
                upstream_port=self._upstream_port(task_id) if server_mode == "noise" else None,
                noise=noise,
                seed=seed,
            )
        log_file = open(log_path, "w", encoding="utf-8")
        # 官方 server 必须在 pinned checkout 里跑；null/noise 服务是本仓库模块，
        # 从 validator 根目录跑并把根目录放进 PYTHONPATH。
        if server_mode == "reference":
            cwd = self.config.robodojo_dir
        else:
            cwd = str(VALIDATOR_ROOT)
            env["PYTHONPATH"] = os.pathsep.join(
                part for part in (str(VALIDATOR_ROOT), env.get("PYTHONPATH")) if part
            )
        try:
            process = subprocess.Popen(
                command,
                cwd=cwd,
                env=env,
                stdout=log_file,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        except OSError as exc:
            log_file.close()
            raise RuntimeUnavailable(f"cannot start RoboDojo {server_mode} server: {exc}") from exc
        log_file.close()
        server = _PolicyServer(process, log_path, port, server_mode)
        self._servers[key] = server
        try:
            self._wait_port(process, port, log_path, self.config.server_timeout_s)
        except RuntimeUnavailable:
            self._servers.pop(key, None)
            server.stop()
            raise
        return server

    def _upstream_port(self, task_id: str) -> int:
        return self._start_server(task_id, "reference").port

    # -- client ------------------------------------------------------------
    def _run_client(
        self, request: BatchRequest, port: int, run_id: str, capture_dir: Path, capture_token: str,
    ) -> tuple[str, dict[str, str]]:
        stamp = time.strftime("%Y%m%d_%H%M%S")
        log_path = os.path.join(
            self.config.work_dir,
            f"client-{request.task_id}-{request.kind.replace(':', '-')}-{stamp}-{uuid.uuid4().hex[:8]}.log",
        )
        result_path = expected_result_path(self.config, request.task_id, run_id)
        env = dict(os.environ)
        env.update(
            {
                "OMNI_KIT_ACCEPT_EULA": "YES",
                "ROBODOJO_RUN_ID": run_id,
                "ROBODOJO_FATAL_RESTART_COUNT": "0",
                "ROBODOJO_CAPTURE_DIR": str(capture_dir),
                "ROBODOJO_CAPTURE_TOKEN": capture_token,
                "ROBODOJO_CAPTURE_ROOT": os.path.realpath(self.config.robodojo_dir),
                "ROBODOJO_CAPTURE_BATCH": request.kind,
                "ROBODOJO_CAPTURE_PERTURBATION_SEED": str(request.seed),
            }
        )
        env["PYTHONPATH"] = os.pathsep.join(
            part for part in (str(capture_dir.parent / "bootstrap"), env.get("PYTHONPATH")) if part
        )
        command = build_client_command(
            self.config, request.task_id, port, request.episodes, run_id
        )
        with open(log_path, "w", encoding="utf-8") as log_file:
            try:
                process = subprocess.Popen(
                    command,
                    cwd=self.config.robodojo_dir,
                    env=env,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                )
            except OSError as exc:
                raise RuntimeUnavailable(
                    f"cannot start RoboDojo client ({request.kind}): {exc}"
                ) from exc
            try:
                returncode = process.wait(timeout=self.config.client_timeout_s)
            except subprocess.TimeoutExpired as exc:
                # 仿真端会派生 conda/Isaac 子进程；必须整组杀掉，不能只杀顶层。
                try:
                    os.killpg(process.pid, 15)
                    process.wait(timeout=10)
                except (ProcessLookupError, subprocess.TimeoutExpired):
                    if process.poll() is None:
                        os.killpg(process.pid, 9)
                        process.wait()
                raise RuntimeUnavailable(
                    f"RoboDojo client exceeded {self.config.client_timeout_s:.0f}s "
                    f"({request.kind}):\n{_tail(log_path)}"
                ) from exc
        if returncode != 0:
            raise RuntimeUnavailable(
                f"RoboDojo client exited with {returncode} ({request.kind}):\n{_tail(log_path)}"
            )
        if not os.path.isfile(result_path):
            raise RuntimeUnavailable(
                f"RoboDojo client exited 0 but did not write {result_path}:\n{_tail(log_path)}"
            )
        return result_path, {"client": log_path}

    def execute(self, request: BatchRequest) -> BatchOutcome:
        if self._closed:
            raise RuntimeUnavailable("RoboDojo executor is closed")
        if not os.path.isdir(self.config.robodojo_dir):
            raise RuntimeUnavailable(
                f"ROBODOJO_DIR does not exist: {self.config.robodojo_dir}; run setup_robodojo.sh first"
            )
        if not os.path.isfile(
            os.path.join(self.config.robodojo_dir, "scripts", "robodojo.sh")
        ):
            raise RuntimeUnavailable(
                f"{self.config.robodojo_dir} is not a RoboDojo checkout (scripts/robodojo.sh missing)"
            )
        verify_capture_source(self.config.robodojo_dir)
        run_id = f"admission-{request.task_id}-{request.kind.replace(':', '-')}-{uuid.uuid4().hex[:10]}"
        capture_dir, capture_token, collector_sha256 = prepare_capture(self.config.work_dir, run_id)
        server = self._start_server(request.task_id, request.server_mode, request.noise, request.seed)
        result_path, logs = self._run_client(request, server.port, run_id, capture_dir, capture_token)
        logs["server"] = server.log_path
        outcomes = parse_result_file(result_path)
        attach_captured_states(
            outcomes, capture_dir, task_id=request.task_id, run_id=run_id,
            layout_seed=self.config.layout_seed, capture_token=capture_token,
            collector_sha256=collector_sha256,
            batch_kind=request.kind, perturbation_seed=request.seed,
        )
        return BatchOutcome(
            outcomes=outcomes,
            result_path=result_path,
            run_id=run_id,
            log_paths=logs,
        )

    def begin_admission(self) -> None:
        """停掉上一个准入留下的 server；题目之间不共享 GPU 上下文。"""
        for server in self._servers.values():
            server.stop()
        self._servers.clear()

    def close(self) -> None:
        self._closed = True
        self.begin_admission()


def build_null_or_proxy_server_command(
    config: RunnerConfig,
    server_mode: str,
    port: int,
    *,
    upstream_port: int | None = None,
    noise: Mapping[str, Any] | None = None,
    seed: int = 0,
) -> list[str]:
    command = [
        sys.executable,
        "-m",
        "task_source.robodojo_policy_server",
        "--mode",
        "null" if server_mode == "null" else "noise",
        "--port",
        str(port),
        "--seed",
        str(int(seed)),
    ]
    if server_mode == "noise":
        if upstream_port is None:
            raise RuntimeUnavailable("noise proxy requires the reference policy server port")
        command += ["--upstream-host", "127.0.0.1", "--upstream-port", str(upstream_port)]
        command += ["--noise-json", json.dumps(dict(noise or {}), sort_keys=True, default=str)]
    return command


# ---------------------------------------------------------------------------
# EpisodeRunner
# ---------------------------------------------------------------------------


class RoboDojoClientRunner:
    """官方 client 的 ``EpisodeRunner`` 适配器。"""

    def __init__(
        self,
        options: Mapping[str, Any] | None = None,
        *,
        executor: BatchExecutor | None = None,
    ) -> None:
        options = dict(options or {})
        self.config = _config_from_options(options)
        self._executor = executor or SubprocessBatchExecutor(self.config)
        self._batches: dict[tuple[str, str, str], BatchOutcome] = {}
        self._oracle_calls: dict[tuple[str, int], int] = {}
        self._closed = False
        atexit.register(self.close)

    def begin_admission(self) -> None:
        """一次新准入：丢弃上一次 attempt 的 batch，强制重新执行官方 client。"""
        self._batches.clear()
        self._oracle_calls.clear()
        # 上一个题目的策略服务可能还占着 GPU；新准入开始时全部停掉，避免
        # 连续准入多道题时把 8 张卡的显存堆满。同一道题内部的 4 个 batch
        # 仍然复用 server。
        begin = getattr(self._executor, "begin_admission", None)
        if callable(begin):
            begin()

    # -- public ------------------------------------------------------------
    def run(
        self,
        task: TaskSpec,
        instance: int,
        *,
        mode: str = "oracle",
        seed: int = 0,
        noise: Mapping[str, Any] | None = None,
    ) -> ReplayResult:
        if self._closed:
            raise RuntimeUnavailable("RoboDojo runner is closed")
        instance = int(instance)
        if mode not in {"oracle", "noise", "nop"}:
            raise RuntimeUnavailable(f"RoboDojo runner does not support mode {mode!r}")
        if mode == "noise" and not self.config.noise_enabled:
            raise RuntimeUnavailable("RoboDojo noise proxy is disabled by configuration")
        if mode in {"oracle", "noise"} and self.config.requires_reference:
            raise RuntimeUnavailable(
                "RoboDojo reference policy is not configured: set ROBODOJO_POLICY_DIR "
                "and ROBODOJO_CKPT (see docs/admission-worker.md)"
            )

        kind = self._batch_kind(task, instance, mode, noise, seed)
        # noise 配置也属于 batch 身份；不同 profile 不能复用同一批结果。
        noise_signature = ""
        if mode == "noise":
            noise_signature = hashlib.sha256(
                json.dumps(dict(noise or {}), sort_keys=True, default=str).encode("utf-8")
            ).hexdigest()[:12]
        key = (task.task_id, kind, noise_signature)
        batch = self._batches.get(key)
        if batch is None:
            batch = self._execute_batch(task, kind, mode, noise, seed)
            self._batches[key] = batch

        outcome = batch.outcomes.get(instance)
        if outcome is None:
            raise RuntimeUnavailable(
                f"RoboDojo {kind} batch did not produce layout {instance} "
                f"(official run covered layouts {sorted(batch.outcomes)[:5]}...); "
                f"result={batch.result_path}"
            )
        # 真实 SubprocessBatchExecutor 强制校验 sidecar；自定义执行器缺状态时
        # 仍保持 state_verified=False，不能用 success/score 代替物理复现。
        reported_state = outcome.get("final_state")
        state_source = outcome.get("state_source")
        physical_state = validate_physical_state(reported_state)
        if physical_state is not None:
            final_state = dict(physical_state)
            state_verified = True
        else:
            final_state = {}
            state_verified = False
            state_source = None
        final_state.update(
            {
                "success": bool(outcome["success"]),
                "score": outcome.get("score"),
                "layout_id": instance,
                "layout_seed": self.config.layout_seed,
            }
        )
        return ReplayResult(
            final_state=final_state,
            initial_state=dict(outcome.get("initial_state") or {}, success=False, layout_id=instance),
            state_digest=state_digest(final_state),
            actions=1,
            detail={
                "source": "robodojo-client",
                "mode": mode,
                "batch": kind,
                "run_id": batch.run_id,
                "result_path": batch.result_path,
                "logs": dict(batch.log_paths),
                "policy_gpu": self.config.policy_gpu,
                "env_gpu": self.config.env_gpu,
                "layout_seed": self.config.layout_seed,
                "state_verified": state_verified,
                "state_source": state_source,
                "state_path": outcome.get("state_path"),
                "state_sha256": outcome.get("state_sha256"),
            },
            state_verified=state_verified,
            state_source=state_source,
        )

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._executor.close()

    # -- internals ---------------------------------------------------------
    def _episodes(self, task: TaskSpec) -> int:
        return int(self.config.episodes or len(task.instances) or 1)

    @staticmethod
    def _is_generalization(task: TaskSpec) -> bool:
        return str(task.metadata.get("dimension") or "") == "generalization"

    def _execute_batch(
        self,
        task: TaskSpec,
        kind: str,
        mode: str,
        noise: Mapping[str, Any] | None,
        seed: int = 0,
    ) -> BatchOutcome:
        """执行一个准入 batch。

        Generalization 题在官方协议里拆成 ``<task>``（standard）和
        ``<task>_random``（random layout）两次 client 运行：样题的实例
        0..24 来自前者，25..49 来自后者。这里把两次官方运行合并成
        「source task 的全部实例」，不能只跑 base task 然后抱怨缺 layout。
        """
        server_mode = self._server_mode(kind)
        episodes = self._episodes(task)
        batch_seed = int(seed) if mode == "noise" else 0
        if not self._is_generalization(task) or episodes < 2:
            return self._executor.execute(
                BatchRequest(
                    task_id=task.task_id,
                    kind=kind,
                    server_mode=server_mode,
                    episodes=episodes,
                    config=self.config,
                    noise=noise,
                    seed=batch_seed,
                )
            )
        half = min(episodes // 2, len(task.instances) // 2)
        if half <= 0:
            raise RuntimeUnavailable(
                f"RoboDojo generalization task {task.task_id!r} has no standard/random split"
            )
        standard = self._executor.execute(
            BatchRequest(
                task_id=task.task_id,
                kind=f"{kind}:standard",
                server_mode=server_mode,
                episodes=half,
                config=self.config,
                noise=noise,
                seed=batch_seed,
            )
        )
        random = self._executor.execute(
            BatchRequest(
                task_id=f"{task.task_id}_random",
                kind=f"{kind}:random",
                server_mode=server_mode,
                episodes=episodes - half,
                config=self.config,
                noise=noise,
                seed=batch_seed,
            )
        )
        outcomes = {layout: outcome for layout, outcome in standard.outcomes.items() if layout < half}
        for layout, outcome in random.outcomes.items():
            mapped = half + layout
            if mapped < episodes:
                outcomes[mapped] = dict(outcome, layout_id=mapped)
        return BatchOutcome(
            outcomes=outcomes,
            result_path=f"{standard.result_path}|{random.result_path}",
            run_id=f"{standard.run_id}|{random.run_id}",
            log_paths={**standard.log_paths, **{f"random:{key}": value for key, value in random.log_paths.items()}},
        )

    def _batch_kind(
        self,
        task: TaskSpec,
        instance: int,
        mode: str,
        noise: Mapping[str, Any] | None,
        seed: int = 0,
    ) -> str:
        if mode == "nop":
            return "nop"
        if mode == "noise":
            # runtime 的 perturbation_seed = instance_seed * 1009 + trial + 1。
            # 完整保留 seed，不做取模合并：seed=1 与 seed=1010 是不同批次。
            return f"noise:{int(seed)}"
        # oracle：引擎对同一实例连续调两次。第一次用独立 batch a，第二次用
        # 独立 batch b，确定性检查比较两次真实物理运行。
        key = (task.task_id, instance)
        index = self._oracle_calls.get(key, 0)
        self._oracle_calls[key] = index + 1
        return "oracle:a" if index % 2 == 0 else "oracle:b"

    @staticmethod
    def _server_mode(kind: str) -> str:
        if kind.startswith("oracle"):
            return "reference"
        if kind.startswith("noise"):
            return "noise"
        return "null"


def make_runner(options: Mapping[str, Any] | None = None) -> RoboDojoClientRunner:
    """``runner_factory`` 入口（``module:function``）。"""
    return RoboDojoClientRunner(options)


__all__ = [
    "BatchExecutor",
    "BatchOutcome",
    "BatchRequest",
    "RoboDojoClientRunner",
    "RunnerConfig",
    "SubprocessBatchExecutor",
    "build_client_command",
    "build_null_or_proxy_server_command",
    "build_server_command",
    "expected_result_path",
    "make_runner",
    "parse_result_file",
]
