"""Pure scene-program text and exact instruction consistency for state mode.

The caller supplies the installed renderer's source bytes from its trusted
runtime manifest. This module hashes those bytes without reading files. Callers
must independently authenticate that implementation binding and still perform
the other admission checks. A rendered or consistent instruction grants only
this text check. Long complete texts remain available as unsupported results.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from dataclasses import asdict, dataclass, replace
from types import SimpleNamespace

from openroboto_protocol import scene_contract
from openroboto_protocol.scene_schema import SceneTask
from openroboto_protocol.tabletop_assets import canonical_digest
from pydantic import ValidationError

from .scene_runtime import validated_definition

POLICY_VERSION = "scene-instruction-admission/2"
LEGACY_POLICY_VERSION = "scene-instruction-admission/1"
RENDERER_VERSION = "scene-program-text/1"
_LEGACY_PROFILE = {
    "id": "panda-open-scene-v1",
    "version": "2.0.0",
    "digest": "052ede59310a10eecdaefb43584f06340bc3ad461dbca8579cdb23b8ec4ad3d5",
}
_PROFILE = {
    "id": "panda-open-scene-v1",
    "version": "2.1.0",
    "digest": "9badf61d742ed5787e7af4ad19adc90b616147ee4c62159915bddeff53f9a1a2",
}
_POLICIES = {
    LEGACY_POLICY_VERSION: (_LEGACY_PROFILE, 1000),
    POLICY_VERSION: (_PROFILE, 16384),
}
OPERATORS = (
    "all",
    "any",
    "not",
    "in_zone",
    "matching",
    "pose",
    "stable",
    "released",
    "supported_by",
    "no_contact",
)

__all__ = [
    "InstructionResult",
    "LEGACY_POLICY_VERSION",
    "POLICY_VERSION",
    "RENDERER_VERSION",
    "check_instruction",
    "policy_document",
    "render_instruction",
]


def policy_document(policy_version=POLICY_VERSION):
    """The independent instruction policy, exported verbatim as deployment JSON."""
    try:
        profile, limit = _POLICIES[policy_version]
    except (KeyError, TypeError) as exc:
        raise ValueError("scene_instruction_policy_unsupported") from exc
    return {
        "schema_version": 1,
        "policy_version": policy_version,
        "renderer": RENDERER_VERSION,
        "execution_profile": dict(profile),
        "task_schema_version": 3,
        "execution_contract_version": 3,
        "observation": "state",
        "operators": list(OPERATORS),
        "max_instruction_characters": limit,
        "comparison": "exact_unicode_characters",
        "numbers": "lossless_typed_json_numbers",
        "definition": "scene_runtime.validated_definition",
        "render_input": "typed_definition+scene+robot+environment+profile+observation",
        "implementation": "sha256_of_caller_authenticated_installed_source_bytes",
        "unsupported": [
            "vision",
            "unknown_policy",
            "unknown_renderer",
            "missing_binding",
            "complete_text_over_" + str(limit),
        ],
        "model_fallback": False,
        "rewrite_execution_bytes": False,
        "other_admission_checks": "independently_required",
    }


@dataclass(frozen=True)
class InstructionResult:
    """A text-policy finding, with full text and independent content bindings."""

    accepted: bool
    code: str
    schema_valid: bool | None = None
    text: str | None = None
    character_count: int | None = None
    max_characters: int | None = None
    program_digest: str | None = None
    render_input_digest: str | None = None
    expected_instruction_digest: str | None = None
    actual_instruction_digest: str | None = None
    delivered_instruction_digest: str | None = None
    delivery_checked: bool = False
    policy_version: str = POLICY_VERSION
    renderer_version: str = RENDERER_VERSION
    policy_digest: str | None = None
    renderer_implementation_digest: str | None = None

    def to_dict(self):
        """Serialize only public goal text and text-policy audit bindings."""
        return asdict(self)


def _json(value):
    # Quoted identifiers cannot become additional lines or goal operators.
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False)


def _text_digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _pose(value):
    pose = [value["position_m"], value["quaternion_xyzw"]]
    identity = [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0, 1.0]]
    return "I" if _json(pose) == _json(identity) else pose


def _predicate(value, used):
    kind = value["type"]
    if kind not in OPERATORS:
        raise ValueError("scene_instruction_operator_unsupported")
    used.add(kind)
    if kind in {"all", "any"}:
        return kind + "(" + ",".join(_predicate(p, used) for p in value["children"]) + ")"
    if kind == "not":
        return "not(" + _predicate(value["child"], used) + ")"
    if kind == "matching":
        args = [value["object_ids"], value["zone_ids"]]
    else:
        args = [value["object_id"]]
        for field in ("zone_id", "quaternion", "support_id", "other_id"):
            if field in value:
                args.append(value[field])
    return kind + "(" + ",".join(_json(a) for a in args) + ")"


def _symbols(task, definition, used):
    scene = task["scene"]
    assets = {a["id"]: a for a in scene["assets"]}
    geometry = bool(used & {"in_zone", "matching"})
    contacts = bool(used & {"supported_by", "no_contact", "released"})
    objects = []
    for obj in definition["objects"]:
        row = [obj["id"], obj["body"], obj["body_frame"], obj["asset"]["id"], _pose(obj["asset_pose_in_body"])]
        if contacts:
            row.append(obj["collision_geoms"])
        objects.append(row)
    lines = ["O(id,body,frame,asset,A" + (",part:geom" if contacts else "") + ")=" + _json(objects)]
    asset_rows = []
    for asset in assets.values():
        row = [asset["id"], asset["version"], asset["digest"]]
        if "pose" in used:
            symmetry = asset["symmetry"]
            if symmetry["category"] == "none":
                row.append("identity")
            elif symmetry["category"] == "isotropic":
                row.append("isotropic")
            elif symmetry["category"] == "axial_unsigned":
                row.append(["axial_unsigned", symmetry["axis_xyz"]])
            else:
                row.append(symmetry["rotations_xyzw"])
        if "supported_by" in used:
            row.extend([asset["physics"]["mass_kg"], asset["physics"]["center_of_mass_m"]])
        if geometry:
            row.append([
                [p["id"], p["kind"], p["size"], p["mesh_path"], _pose(p["pose_in_asset"])]
                for p in asset["collision"]["parts"]
            ])
        asset_rows.append(row)
    fields = "id,version,digest"
    if "pose" in used:
        fields += ",sym"
    if "supported_by" in used:
        fields += ",mass_kg,assetCOM"
    if geometry:
        fields += ",parts(id,kind,size,mesh,poseInAsset)"
    lines.append("Asset(" + fields + ")=" + _json(asset_rows))
    lines.append(
        "F(id,parent,pose)=" + _json([[f["id"], f["parent"], _pose(f["pose_in_parent"])] for f in scene["frames"]])
    )
    lines.append("pose=[xyz,xyzw]\nA=asset into body\nF=reset child into parent\nworld root.")
    if geometry:
        lines.append(
            "Zone(id,worldXY,radius,capacity,exactAccepts)="
            + _json([[z["id"], z["position"], z["radius_m"], z["capacity"], z["accepts"]] for z in definition["zones"]])
        )
        lines.append(
            "Collision sizes use XYZ box half-extents, sphere radius, cylinder/capsule radius and straight "
            "half-length along part Z, mesh XYZ scale and compiled convex hull of bound file."
        )
        mesh_paths = {p["mesh_path"] for a in assets.values() for p in a["collision"]["parts"] if p["mesh_path"]}
        if mesh_paths:
            lines.append(
                "Mesh(path,sha256)="
                + _json([[d["path"], d["sha256"]] for d in scene["dependencies"] if d["path"] in mesh_paths])
            )
    if contacts:
        lines.append(
            "Target(id,owner,exactGeomSubset)="
            + _json([[t["id"], t["entity_id"], t["geom_names"]] for t in scene["contact_targets"]])
        )
        lines.append(
            "Entity targets use their own declared geoms. Aliases use exact subsets with descendants excluded. "
            "robot=registered Panda collision set. table=platform geom named table."
        )
    return lines


def _operator_meanings(used, symmetry_categories):
    success = scene_contract.profile_catalog()["success"]
    lines = []
    if used & {"all", "any", "not"}:
        lines.append("all=all children\nany=at least one\nnot=negate its subtree\nchild order adds no requirement.")
    if used & {"in_zone", "matching"}:
        lines.append(
            "in_zone(o,z)=exact asset accepted AND the entire actual world-XY collision projection "
            "lies within z.radius of z.XY."
        )
    if "matching" in used:
        lines.append(
            "matching(O,Z)=assign each listed object once to a listed accepting zone, using in_zone and "
            "per-zone assignment count<=capacity."
        )
    if "pose" in used:
        lines.append(
            "pose(o,q)=orientation error<="
            + _json(success["pose_tolerance_rad"])
            + "rad. Qbody=measured world body xyzw. R=active xyzw rotation. "
            "angle(M)=acos(clamp((trace(M)-1)/2,-1,1))."
        )
        if symmetry_categories - {"axial_unsigned", "isotropic"}:
            lines.append(
                "Finite symmetry error=min_g angle((R(Qbody)R(A))^T R(q)R(A)R(g)). "
                "g ranges over the listed xyzw quaternions. Identity uses [0.0,0.0,0.0,1.0]."
            )
        if "axial_unsigned" in symmetry_categories:
            lines.append("Axial error=acos(clamp(abs((R(Qbody)R(A)a) dot (R(q)R(A)a)),-1,1))\na=declared asset axis.")
        if "isotropic" in symmetry_categories:
            lines.append("Isotropic orientation error=0.")
    if "stable" in used:
        lines.append(
            "stable(o)=L2(linear velocity)<="
            + _json(success["max_linear_speed_m_s"])
            + "m/s AND L2(angular velocity)<="
            + _json(success["max_angular_speed_rad_s"])
            + "rad/s."
        )
    if "released" in used:
        lines.append(
            "released(o)=both Panda finger joints>="
            + _json(success["finger_open_min_m"])
            + "m AND no_contact(o,robot)."
        )
    if used & {"no_contact", "released"}:
        lines.append(
            "no_contact(o,t)=no selected contact with (distance<=0m OR L2(force)>"
            + _json(success["contact_force_min_n"])
            + "N)."
        )
    if "supported_by" in used:
        lines.append(
            "supported_by(o,t) requires sum>=nativeMass(o)*9.81*"
            + _json(success["support_min_weight_fraction"])
            + "N. Sum force-on-o Z over unique contacts with Fz>0,normal-on-o Z>=0.5,point.Z<=measured COM.Z. "
            "Mass and COM are native measurements. Aliases never duplicate contacts."
        )
    return lines


def _render(task, definition):
    used = set()
    episode = [_predicate(p, used) for p in definition["invariants"]]
    stages = []
    for stage in definition["stages"]:
        goal = _predicate(stage["goal"], used)
        invariants = [_predicate(p, used) for p in stage["invariants"]]
        stages.append(
            "Stage "
            + _json(stage["id"])
            + " requires="
            + _json(stage["requires"])
            + ",N="
            + _json(stage["hold_ticks"])
            + ",early="
            + _json(stage["reject_early"])
            + ",goal="
            + goal
            + ",inv=["
            + ",".join(invariants)
            + "]"
        )
    lines = [
        "State-known\nRH Z-up world m/rad\nbody-origin xyzw poses.",
        "dt=0.002s\ntick0 checks invariants,no hold\ninvalid sample/false invariant latches failure.",
        "Requires=all done on earlier ticks\nHold=consecutive active goal-true elapsed ticks,else0\n"
        "Complete at N,persistent\nStage inv=active and incomplete at tick start\nEpisode inv=every tick.",
        "early=true forbids goal before active,false allows\n"
        "Pass=all complete,no failure,each leaf's current hold>=N\nleaf=never required.",
        "I=[[0.0,0.0,0.0],[0.0,0.0,0.0,1.0]].",
    ]
    lines.extend(_symbols(task, definition, used))
    lines.extend(_operator_meanings(used, {a["symmetry"]["category"] for a in task["scene"]["assets"]}))
    lines.append("Episode=[" + ",".join(episode) + "]")
    lines.extend(stages)
    return "\n".join(lines)


def render_instruction(task, *, renderer_source=None, policy_version=POLICY_VERSION, renderer_version=RENDERER_VERSION):
    """Return complete canonical text or an explicit unsupported/input finding.

    renderer_source must come from the caller's authenticated installed module,
    separately compared with its fixed runtime manifest. Author-provided source
    is insufficient. instruction and public_summary are schema-checked but never
    enter the rendered body or render-input digest. No private input is accepted.
    """
    try:
        policy = policy_document(policy_version)
    except ValueError:
        return InstructionResult(False, "scene_instruction_policy_unsupported", policy_version=policy_version)
    result = InstructionResult(
        False,
        "scene_instruction_missing_binding",
        policy_version=policy["policy_version"],
        renderer_version=renderer_version,
        policy_digest=canonical_digest(policy),
        max_characters=policy["max_instruction_characters"],
    )
    if not isinstance(renderer_source, bytes) or not renderer_source:
        return result
    result = replace(result, renderer_implementation_digest=hashlib.sha256(renderer_source).hexdigest())
    if renderer_version != RENDERER_VERSION:
        return replace(result, code="scene_instruction_renderer_unsupported")
    if scene_contract.profile_ref() != policy["execution_profile"]:
        return replace(result, code="scene_instruction_profile_unsupported")
    if isinstance(task, SceneTask):
        task = task.model_dump(mode="json")
    if not isinstance(task, Mapping):
        return replace(result, code="scene_instruction_invalid_input")
    raw_profile = task.get("execution_profile")
    if isinstance(raw_profile, Mapping) and dict(raw_profile) != policy["execution_profile"]:
        return replace(result, code="scene_instruction_profile_unsupported")
    try:
        parsed = SceneTask.model_validate(dict(task))
    except ValidationError as exc:
        binding_fields = {"scene", "task_definition", "execution_profile", "robot", "environment"}
        missing = any(
            e["type"] == "missing" and e["loc"] and e["loc"][0] in binding_fields
            for e in exc.errors(include_input=False, include_context=False)
        )
        return replace(
            result,
            schema_valid=False,
            code="scene_instruction_missing_binding" if missing else "scene_instruction_invalid_input",
        )
    typed = parsed.model_dump(mode="json")
    result = replace(result, schema_valid=True)
    if typed["execution_profile"] != policy["execution_profile"]:
        return replace(result, code="scene_instruction_profile_unsupported")
    definition = validated_definition(SimpleNamespace(task=parsed))
    render_input = {
        "definition": definition,
        "scene": typed["scene"],
        "robot": typed["robot"],
        "environment": typed["environment"],
        "execution_profile": typed["execution_profile"],
        "observation": definition["observation"],
    }
    result = replace(
        result, program_digest=canonical_digest(definition), render_input_digest=canonical_digest(render_input)
    )
    if definition["observation"] != "state":
        return replace(result, code="scene_instruction_vision_unsupported")
    try:
        text = _render(typed, definition)
    except KeyError:
        return replace(result, code="scene_instruction_missing_binding")
    except ValueError:
        return replace(result, code="scene_instruction_semantics_unsupported")
    result = replace(result, text=text, character_count=len(text), expected_instruction_digest=_text_digest(text))
    if len(text) > policy["max_instruction_characters"]:
        return replace(result, code="scene_instruction_length_unsupported")
    return replace(result, accepted=True, code="scene_instruction_rendered")


def check_instruction(
    task,
    *,
    renderer_source=None,
    policy_version=POLICY_VERSION,
    renderer_version=RENDERER_VERSION,
    delivered_instruction=None,
):
    """Compare the E-resident text verbatim, optionally also the delivered text.

    delivery_checked is false until an actual delivered string is supplied. The
    runtime must bind this finding and all remaining policy gates independently.
    """
    result = render_instruction(
        task, renderer_source=renderer_source, policy_version=policy_version, renderer_version=renderer_version
    )
    actual = (
        task.instruction
        if isinstance(task, SceneTask)
        else task.get("instruction")
        if isinstance(task, Mapping)
        else None
    )
    try:
        if isinstance(actual, str):
            result = replace(result, actual_instruction_digest=_text_digest(actual))
        if isinstance(delivered_instruction, str):
            result = replace(result, delivered_instruction_digest=_text_digest(delivered_instruction))
    except UnicodeError:
        return replace(result, accepted=False, code="scene_instruction_invalid_text")
    if not result.accepted:
        return result
    if actual != result.text:
        return replace(result, accepted=False, code="reject_instruction_mismatch")
    if delivered_instruction is not None:
        if not isinstance(delivered_instruction, str):
            return replace(result, accepted=False, code="scene_instruction_delivery_invalid")
        result = replace(result, delivery_checked=True)
        if delivered_instruction != result.text:
            return replace(result, accepted=False, code="scene_instruction_delivery_mismatch")
    return replace(result, code="scene_instruction_consistent")
