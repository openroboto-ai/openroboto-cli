"""Trusted native scene + P03 model boundary integration, no provider calls.

The bounded local process probe is not a production model gateway or a server
admission assertion. It proves the native tool/observation bridge with the
operator-selected offline adapter; no author code is loaded from E/P.
"""

from __future__ import annotations

import math
from pathlib import Path
import time

from agent_harness.runtimes import AxisToolRuntime

from .execution_contract import verify_execution_runtime
from .scene_authoring import SceneAuthoringError, _source, _task, _write
from .scene_instruction_runtime import require, require_messages
from .scene_views import AdmissionView, ExecutionView, ModelBoundary, materialize_execution, run_isolated_python


def run_scene_process(
    view,
    *,
    instance,
    adapter_code,
    forbidden_roots,
    evidence_directory,
    timeout_s=10.0,
    cpu_seconds=5,
    max_requests=None,
):
    """Run one real native episode behind a verified P03 E-only projection.

    view is supplied by the trusted caller's verify_admission_view or
    verify_execution_view (registered receipt trust), never by model requests.
    The local launcher currently supports at most 60s; this probe does not
    register or silently replace the task's agent wall budget with that limit.
    CPU/model budgets and server publication remain separate policy gates.
    """
    execution = view.execution if type(view) is AdmissionView else view
    if type(execution) is not ExecutionView:
        raise SceneAuthoringError("verified_execution_view_required")
    contract = execution.contract
    if type(timeout_s) not in (int, float) or not math.isfinite(timeout_s) or not 0 < timeout_s <= 60:
        raise SceneAuthoringError("local_process_wall_unsupported", capability="resource_unavailable")
    if not forbidden_roots:
        raise SceneAuthoringError("local_process_material_roots_required")
    limit = contract["budget"]["max_api_calls"]
    if max_requests is not None:
        if type(max_requests) is not int or not 0 < max_requests <= limit:
            raise SceneAuthoringError("local_process_request_cap_invalid")
        limit = max_requests
    evidence = Path(evidence_directory)
    if any(
        evidence.resolve().is_relative_to(Path(root).resolve())
        or Path(root).resolve().is_relative_to(evidence.resolve())
        for root in forbidden_roots
    ):
        raise SceneAuthoringError("output_layout_invalid", capability="resource_unavailable")
    evidence.mkdir(parents=True, mode=0o700, exist_ok=False)
    started = time.monotonic()
    deadline = started + min(timeout_s, contract["budget"]["wall_seconds"])
    audit = []
    with materialize_execution(execution) as frozen:
        source = _source(frozen, deadline=deadline)
        task = _task(source)
        runtime = AxisToolRuntime(task, instance, source, max_steps=contract["budget"]["max_steps"])
        try:
            verify_execution_runtime(contract, runtime)
            boundary = ModelBoundary(execution, audit=audit.append)
            initial = {"messages": boundary.initial_messages(runtime.observe()), "tools": boundary.tools}
            finding = require_messages(execution.task, initial["messages"])
            _write(evidence / "instruction-delivery.json", finding)
            _write(evidence / "model-input.json", initial)
            remaining = deadline - time.monotonic()
            runtime.env.check_deadline()

            def dispatch(request):
                response = boundary.dispatch(runtime, request)
                if response.get("ok"):
                    audit.append({
                        "instruction_delivery": require(
                            execution.task, delivered_instruction=response["observation"]["instruction"]
                        ),
                    })
                return response

            process = run_isolated_python(
                adapter_code,
                input_messages=initial,
                forbidden_roots=[*forbidden_roots, evidence, frozen],
                timeout_s=min(timeout_s, remaining),
                cpu_seconds=cpu_seconds,
                max_requests=limit,
                request_handler=dispatch,
            )
            outcome = {
                "mechanism": process.mechanism,
                "returncode": process.returncode,
                "timed_out": process.timed_out,
                "host_uid": process.host_uid,
                "cwd": process.cwd,
                "environment": process.environment,
                "ipc": list(process.ipc),
                "policy": process.policy,
                "local_probe_wall_limit_s": timeout_s,
                "contract_agent_budget": contract["budget"],
                "control_steps": runtime.step_count,
                "business_model_calls": 0,
                "instruction_delivery": finding,
                "success": runtime.success()[0],
                "final_state": dict(runtime.env.state()),
            }
            (evidence / "stdout.bin").write_bytes(process.stdout)
            (evidence / "stderr.bin").write_bytes(process.stderr)
            _write(evidence / "process.json", outcome)
            return outcome
        finally:
            _write(evidence / "private-audit.json", audit)
            runtime.close()
