"""Trusted parent glue between existing daemons, transport and P02 runtime.

No simulator, model runner, reference format or admission criteria live here.
Registration is operator configuration; ZIP bytes cannot select trust or code.
"""

from __future__ import annotations

import math
import hashlib
import pathlib
import importlib
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, TYPE_CHECKING, Protocol

from openroboto_protocol.scene_contract import profile_catalog

from task_source.scene_transport import (
    EvaluationLease,
    NodeIdentity,
    ReceiptAuthority,
    SceneTask,
    SceneTransportClient,
    SceneTransportError,
)
from task_source.scene_views import AdmissionView, ExecutionView, ReceiptTrust
from task_source.scene_views.identity import decode, encoded

if TYPE_CHECKING:
    from agent_harness.result import RunResult
    from benchmark_worker.reference_panel.config import MemberSpec, ReferencePanelConfig
    from task_source.runtime import Verdict
    from task_source.scene_episode_delegate import SceneEpisodeCaller, SceneEpisodeRequest


def require(condition, code, *, category="authorization"):
    if not condition:
        raise SceneTransportError(code, category=category)


def epoch(value):
    try:
        if isinstance(value, str):
            value = datetime.fromisoformat(value.replace("Z", "+00:00"))
            require(value.tzinfo is not None, "scene_expiry_invalid")
            value = value.timestamp()
        require(type(value) in (int, float) and math.isfinite(value), "scene_expiry_invalid")
        return value
    except (ValueError, OverflowError, TypeError):
        raise SceneTransportError("scene_expiry_invalid", category="authorization") from None


def same_environment(value, expected) -> bool:
    """Environment identity is (id, version); the digest covers every task_source file.

    A content-level comparison would invalidate every admitted package on an
    unrelated source edit while the registered environment version stays the same.
    """
    return (
        type(value) is dict
        and value.get("id") == expected["id"]
        and value.get("version") == expected["version"]
    )


@dataclass(frozen=True)
class SceneRegistration:
    """Immutable operator registration snapshot; not proof of server readiness."""

    _bytes: bytes = field(repr=False)

    @classmethod
    def parse(cls, document):
        require(isinstance(document, dict) and document.get("schema_version") == 1, "scene_registration_invalid")
        require(
            document.get("execution_profile") == profile_catalog()["execution_profile"], "scene_profile_unregistered"
        )
        envs = document.get("environments")
        require(isinstance(envs, list) and 0 < len(envs) <= 64, "scene_environment_unregistered")
        for env in envs:
            require(_artifact(env), "scene_environment_unregistered")
        require(_artifact(document.get("runtime")), "scene_runtime_unregistered")
        require(
            isinstance(document.get("config_digest"), str)
            and re.fullmatch("[0-9a-f]{64}", document["config_digest"]) is not None,
            "scene_config_unregistered",
        )
        require(
            isinstance(document.get("policy_version"), str) and document["policy_version"], "scene_policy_unregistered"
        )
        competitions = document.get("competition_ids")
        require(
            isinstance(competitions, list) and competitions and all(type(v) is int and v > 0 for v in competitions),
            "scene_competition_unregistered",
        )
        epoch(document.get("valid_until"))
        return cls(encoded(document))

    @property
    def document(self):
        return decode(self._bytes)

    def identity(self, node_id, signer):
        data = self.document
        require(data.get("node_id") == node_id and data.get("key_id") == signer.key_id, "scene_node_unregistered")
        return NodeIdentity(node_id, signer, data.get("public_key_hex"), epoch(data["valid_until"]))

    def validate_task(self, task, now):
        data, row = self.document, task.document
        require(data.get("retired", False) is False and epoch(data["valid_until"]) > now, "scene_registration_expired")
        require(row["execution_profile"] == data["execution_profile"], "scene_profile_unregistered")
        require(row["environment"] in data["environments"], "scene_environment_unregistered")
        require(row["competition_id"] in data["competition_ids"], "scene_competition_unregistered")

    def receipt_trust(self):
        data = self.document
        return ReceiptTrust(
            node_id=data["node_id"],
            key_id=data["key_id"],
            public_key_hex=data["public_key_hex"],
            runtime=data["runtime"],
            policy_version=data["policy_version"],
            provenance="server_registered",
        )


def receipt_authority(document, now):
    """Only call on the authenticated backend metadata, never on ZIP JSON."""
    require(isinstance(document, dict), "scene_receipt_authority_missing")
    require(document.get("algorithm") == "ed25519", "scene_receipt_authority_invalid")
    require(document.get("provenance") == "server_registered", "scene_receipt_authority_invalid")
    try:
        trust = ReceiptTrust(**{
            k: document[k] for k in ("node_id", "key_id", "public_key_hex", "runtime", "policy_version", "provenance")
        })
        authority = ReceiptAuthority(trust, epoch(document["valid_until"]), document.get("retired", False))
        authority.validate(now)
        return authority
    except (ValueError, KeyError, TypeError):
        raise SceneTransportError("scene_receipt_authority_invalid", category="authorization") from None


def frozen_context(work, frozen):
    """Normalize backend de61b273's authenticated FrozenSceneTask, not ZIP JSON."""
    require(
        isinstance(frozen, dict) and frozen.get("package_layout") == "scene", "scene_authenticated_metadata_missing"
    )
    try:
        row, assignment = frozen["scene_registration"], frozen["assignment"]
        identity, authority = row["identity"], frozen["receipt_authority"]
        task_id = frozen["task_id"]
        require(
            task_id == row["task_id"]
            and frozen["source"] == "axis"
            and frozen["package_digest"] == row["execution_package_digest"]
            and frozen["submission_digest"] == row["submission_digest"]
            and frozen["execution_profile"] == identity["execution_profile"]
            and frozen["package_url"] == f"/api/v1/tasks/{task_id}/scene-package/evaluation"
            and assignment["run_id"] == work["run_id"]
            and assignment["config_digest"] == work["config_digest"]
            and epoch(assignment["lease_expires_at"]) == epoch(work["lease_expires_at"])
            and type(authority["valid_until"]) in (int, float)
            and epoch(authority["valid_until"]) <= epoch(work["lease_expires_at"])
            and row["execution_contract_digest"] == hashlib.sha256(encoded(row["execution_contract"])).hexdigest()
            and type(row["attempt"]) is int
            and row["attempt"] > 0,
            "scene_frozen_task_mismatch",
        )
        pin = {
            **{
                k: row[k]
                for k in (
                    "task_id",
                    "package_repo",
                    "package_commit",
                    "execution_package_digest",
                    "private_package_digest",
                    "submission_digest",
                    "attempt",
                )
            },
            "competition_id": frozen["competition_id"],
            "execution_profile": identity["execution_profile"],
            "environment": identity["environment"],
            "package_url": f"/api/v1/tasks/{task_id}/scene-package/admission",
        }
        SceneTask.from_queue(pin, competition_id=frozen["competition_id"])
        require(
            isinstance(authority["receipt_digest"], str)
            and re.fullmatch("[0-9a-f]{64}", authority["receipt_digest"]) is not None,
            "scene_receipt_digest_missing",
        )
        return {
            **{k: assignment[k] for k in ("run_id", "worker_id", "node_id", "config_digest", "lease_expires_at")},
            "scene_task": pin,
            "identity": identity,
            "execution_contract": row["execution_contract"],
            "receipt_authority": {
                **authority["trust"],
                "valid_until": authority["valid_until"],
                "retired": authority["retired"],
            },
            "receipt_digest": authority["receipt_digest"],
        }
    except (KeyError, ValueError, TypeError):
        raise SceneTransportError("scene_authenticated_metadata_invalid", category="authorization") from None


def normalize_scene_work(work):
    """Keep the authenticated raw DTO and add existing daemon transport pins."""
    context = frozen_context(work, work["task"])
    pin = context["scene_task"]
    result = {
        **work,
        "task": {**work["task"], "package_repo": pin["package_repo"], "package_commit": pin["package_commit"]},
    }
    if not {"package_repo", "package_commit"} & work["task"].keys():
        # Preserve the authenticated DTO BEFORE adding legacy daemon aliases.
        # Old journals with aliases but no original DTO cannot invent it here.
        result["_scene_frozen_task"] = decode(encoded(work["task"]))
    return result


def original_frozen_task(work):
    original = work.get("_scene_frozen_task")
    require(type(original) is dict, "scene_authenticated_original_task_missing")
    require(not {"package_repo", "package_commit"} & original.keys(), "scene_authenticated_original_task_invalid")
    current = {key: value for key, value in work["task"].items() if key not in {"package_repo", "package_commit"}}
    require(encoded(original) == encoded(current), "scene_authenticated_original_task_changed")
    return decode(encoded(original))


def bind_scene_context(work, metadata):
    """Pin immutable claim identity; accept only authenticated current deadlines.

    The caller obtains metadata with the existing owner proof from the backend.
    Deadline refresh is not a claim, renewal, or client-derived extension.
    """
    require(isinstance(metadata, Mapping), "scene_authenticated_metadata_missing")
    expected = frozen_context(work, work["task"])
    try:
        authority = metadata["receipt_authority"]
        require(
            type(authority["valid_until"]) in (int, float)
            and epoch(authority["valid_until"]) <= epoch(metadata["lease_expires_at"]),
            "scene_context_expiry_invalid",
        )
        projected = {
            **expected,
            "lease_expires_at": metadata["lease_expires_at"],
            "receipt_authority": {**expected["receipt_authority"], "valid_until": authority["valid_until"]},
        }
        require(encoded(dict(metadata)) == encoded(projected), "scene_claim_context_mismatch")
        return metadata
    except (KeyError, ValueError, TypeError):
        raise SceneTransportError("scene_context_invalid", category="authorization") from None


def refreshed_context(work, data):
    """Decode the agreed scene-context wire shape, without alias/ZIP fallback."""
    try:
        require(
            isinstance(data, dict)
            and set(data) == {"run_id", "worker_id", "node_id", "lease_expires_at", "scene_task", "receipt_authority"},
            "scene_context_invalid",
        )
        expected = frozen_context(work, work["task"])
        task, authority = data["scene_task"], data["receipt_authority"]
        require(
            isinstance(task, dict)
            and set(task)
            == set(expected["scene_task"]) | {"identity", "execution_contract", "execution_contract_digest"}
            and isinstance(authority, dict)
            and set(authority) == {"trust", "receipt_digest", "valid_until", "retired"}
            and isinstance(authority["trust"], dict)
            and set(authority["trust"])
            == {"node_id", "key_id", "algorithm", "public_key_hex", "runtime", "policy_version", "provenance"}
            and authority["trust"]["algorithm"] == "ed25519"
            and authority["trust"]["provenance"] == "server_registered"
            and authority["retired"] is False
            and task["execution_contract_digest"] == work["task"]["scene_registration"]["execution_contract_digest"]
            and task["execution_contract_digest"] == hashlib.sha256(encoded(task["execution_contract"])).hexdigest(),
            "scene_context_invalid",
        )
        metadata = {
            **{k: data[k] for k in ("run_id", "worker_id", "node_id", "lease_expires_at")},
            "config_digest": expected["config_digest"],
            "scene_task": {k: task[k] for k in expected["scene_task"]},
            "identity": task["identity"],
            "execution_contract": task["execution_contract"],
            "receipt_authority": {
                **authority["trust"],
                "valid_until": authority["valid_until"],
                "retired": authority["retired"],
            },
            "receipt_digest": authority["receipt_digest"],
        }
        return bind_scene_context(work, metadata)
    except (KeyError, ValueError, TypeError):
        raise SceneTransportError("scene_context_invalid", category="authorization") from None


class SceneAdapter:
    """Credential-owning parent adapter, not a model or sandbox dependency."""

    def __init__(
        self,
        transport: SceneTransportClient,
        registration: SceneRegistration,
        *,
        admission: SceneAdmissionRuntime | None = None,
        evaluation: SceneEvaluationRuntime | None = None,
    ):
        self.transport, self.registration = transport, registration
        self.admission_runtime, self.evaluation_runtime = admission, evaluation

    def list_queue(self, competition_id, limit):
        data = self.registration.document
        require(
            data.get("retired", False) is False and epoch(data["valid_until"]) > self.transport._clock(),
            "scene_registration_expired",
        )
        require(competition_id in data["competition_ids"], "scene_competition_unregistered")
        tasks = self.transport.list_queue(competition_id, limit)
        for task in tasks:
            self.validate_task(task)
        return tasks

    def validate_task(self, task):
        self.transport._identity.validate(self.transport._clock())
        self.registration.validate_task(task, self.transport._clock())

    def admission_task(self, item):
        task = SceneTask.from_queue(item, competition_id=item.get("competition_id"))
        self.validate_task(task)
        return task

    def evaluation_context(self, work, metadata):
        require(isinstance(metadata, Mapping), "scene_authenticated_metadata_missing")
        # Metadata must be obtained by the credential-owning PanelClient, with
        # its current lease, rather than copied from a cached/downloaded ZIP.
        row = work["task"]
        require(row.get("source") == "axis", "scene_source_unsupported")
        # Bind the FIRST context to the complete authenticated claim too. A
        # self-consistent E-only package cannot replace the claim's P/joint,
        # receipt authority or frozen identity before state has been saved.
        bind_scene_context(work, metadata)
        require(isinstance(metadata.get("scene_task"), dict), "scene_authenticated_metadata_missing")
        task = SceneTask.from_queue(metadata["scene_task"], competition_id=row.get("competition_id"))
        pin = task.document
        require(
            all(
                pin[k] == row.get(k)
                for k in ("task_id", "competition_id", "package_repo", "package_commit", "execution_profile")
            )
            and pin["execution_package_digest"] == row.get("package_digest"),
            "scene_frozen_task_mismatch",
        )
        require(metadata.get("run_id") == work["run_id"], "scene_frozen_task_mismatch")
        require(metadata.get("config_digest") == work.get("config_digest"), "scene_frozen_config_mismatch")
        require(
            isinstance(metadata.get("receipt_digest"), str)
            and re.fullmatch("[0-9a-f]{64}", metadata["receipt_digest"]) is not None,
            "scene_receipt_digest_missing",
        )
        require(
            isinstance(metadata.get("identity"), dict)
            and isinstance(metadata.get("execution_contract"), dict)
            and metadata["execution_contract"] == work.get("config", {}).get("execution_contract"),
            "scene_authenticated_identity_missing",
        )
        self.validate_task(task)
        authority = receipt_authority(metadata.get("receipt_authority"), self.transport._clock())
        require(
            authority.trust.document["runtime"] == self.registration.document["runtime"], "scene_runtime_unregistered"
        )
        lease = EvaluationLease(
            pin["task_id"],
            pin["execution_package_digest"],
            work["run_id"],
            metadata.get("worker_id"),
            metadata.get("node_id"),
            pin["package_repo"],
            pin["package_commit"],
            work["lease_token"],
            epoch(metadata.get("lease_expires_at")),
        )
        lease.payload(task, self.transport._identity.node_id, self.transport._clock())
        return task, lease, authority

    def download_evaluation(self, work, metadata):
        task, lease, authority = self.evaluation_context(work, metadata)
        require(
            isinstance(metadata.get("identity"), dict) and isinstance(metadata.get("execution_contract"), dict),
            "scene_authenticated_identity_missing",
        )
        package = self.transport.download_evaluation(task, lease, authority)
        require(
            package.view.identity == metadata["identity"] and package.view.contract == metadata["execution_contract"],
            "scene_frozen_identity_mismatch",
        )
        require(
            isinstance(metadata.get("receipt_digest"), str)
            and hashlib.sha256(encoded(decode(package.receipt_bytes))).hexdigest() == metadata["receipt_digest"],
            "scene_receipt_digest_mismatch",
        )
        return package


def load_scene_adapter(path, *, backend_url, api_key, signer, node_id, admission=None, evaluation=None):
    """Explicit operator file; never creates/registers a key or reads ZIP trust."""
    data = pathlib.Path(path).read_bytes()
    require(len(data) <= 1_000_000, "scene_registration_invalid")
    registration = SceneRegistration.parse(decode(data))
    identity = registration.identity(node_id, signer)
    transport = SceneTransportClient(backend_url, api_key, identity)
    identity.validate(transport._clock())
    return SceneAdapter(transport, registration, admission=admission, evaluation=evaluation)


def scene_runtime():
    """The P02 owner supplies this module. No fallback to a legacy source."""
    try:
        return importlib.import_module("task_source.scene_runtime")
    except ImportError:
        raise SceneTransportError("scene_runtime_unavailable", category="infra") from None


@dataclass(frozen=True)
class SceneAdmissionContext:
    """Trusted runtime inputs; callback must not forward credentials/P to tools."""

    task: SceneTask
    profile: Mapping[str, Any]
    node_id: str
    attempt: int
    config_digest: str
    registration: Mapping[str, Any] = field(repr=False)


@dataclass(frozen=True)
class SceneEpisodeContext:
    """Daemon-side binding passed to the registered dedicated parent launcher.

    The parent adds independent trust, policy and gateway inputs to construct
    SceneEpisodeCaller. This object alone cannot authorize an inline runtime.
    """

    work: Mapping[str, Any] = field(repr=False)
    config: ReferencePanelConfig = field(repr=False)
    member: MemberSpec
    trial: int
    instance: int
    spec_path: pathlib.Path
    result_path: pathlib.Path
    evidence_path: pathlib.Path
    host_config: pathlib.Path = field(repr=False)
    lease_file: pathlib.Path
    signer: Any = field(repr=False)
    registration: Mapping[str, Any] = field(repr=False)
    receipt_bytes: bytes | None = field(default=None, repr=False)
    recovery_commitment: Mapping[str, Any] | None = field(default=None, repr=False)


class SceneAdmissionRuntime(Protocol):
    def __call__(self, view: AdmissionView, *, context: SceneAdmissionContext) -> Verdict: ...


class SceneEvaluationRuntime(Protocol):
    """Dedicated-parent ABI; binding validation does not prove OS availability."""

    def prepare_scene_episode(self, view: ExecutionView, *, context: SceneEpisodeCaller) -> dict: ...

    def validate_scene_episode_context(
        self, view: ExecutionView, *, context: SceneEpisodeCaller
    ) -> SceneEpisodeRequest: ...

    def execute_scene_episode(self, view: ExecutionView, *, context: SceneEpisodeCaller) -> RunResult: ...


def _artifact(ref):
    return (
        isinstance(ref, dict)
        and set(ref) == {"id", "version", "digest"}
        and all(isinstance(ref[k], str) and 0 < len(ref[k]) <= 200 for k in ("id", "version"))
        and isinstance(ref["digest"], str)
        and re.fullmatch("[0-9a-f]{64}", ref["digest"]) is not None
    )
