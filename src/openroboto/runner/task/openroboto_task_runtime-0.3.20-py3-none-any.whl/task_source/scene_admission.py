"""Registered scene admission, using verified P and the one native replay engine.

No author code, provider, legacy template or legacy fingerprint index is called.
The trusted parent signs the returned Verdict and handles P07 human clearance.
"""

from __future__ import annotations

import hashlib
import math
import time
from collections.abc import Mapping
from contextlib import contextmanager
from dataclasses import replace
from datetime import datetime
from pathlib import Path
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Protocol

from openroboto_protocol.scene_contract import profile_catalog, profile_ref
from openroboto_protocol.scene_schema import PrivateReferenceBinding, SubmissionManifest, submission_issues
from openroboto_protocol.tabletop_assets import canonical_digest

from .base import AdmissionCheck, RuntimeUnavailable, TaskSourceError
from .scene_views import (
    AdmissionView,
    SceneViewError,
    load_private_reference,
    materialize_execution,
    reference_identity,
)
from .scene_views.identity import _execution, decode, digest_contents, encoded

if TYPE_CHECKING:
    from .runtime import Verdict

POLICY_VERSION = "scene-admission/1"
_POLICY = Path(__file__).parent / "data/scene_admission_v1.json"
_POLICY_SHA256 = "120f9b75876edc478c1ffccab184578f2811ce7b750736d61382051073c37b77"
_REVIEW_DIGEST = "56192cbda65c77820724066519e1f5851de9a6434d39b88c0d2612356e064e31"


class SceneAdmissionCaller(Protocol):
    """P08 SceneAdmissionContext already has these operator-owned fields."""

    task: Any  # authenticated SceneTask.document, not task.json
    profile: Mapping[str, Any]
    node_id: str
    attempt: int
    config_digest: str
    registration: Mapping[str, Any]


class _Unavailable(RuntimeUnavailable):
    pass


def _require(condition, code):
    if not condition:
        raise _Unavailable(code)


def _copy(value):
    return decode(encoded(value))


def policy_identity():
    if _POLICY.is_symlink() or not _POLICY.is_file():
        raise _Unavailable("scene_admission_policy_unavailable")
    raw = _POLICY.read_bytes()
    if hashlib.sha256(raw).hexdigest() != _POLICY_SHA256:
        raise _Unavailable("scene_admission_policy_unavailable")
    document = decode(raw)
    return {
        "version": POLICY_VERSION,
        "digest": canonical_digest(document),
        "document_sha256": _POLICY_SHA256,
        "implementation_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "configuration": document,
    }


def _artifact(value):
    return (
        isinstance(value, dict)
        and set(value) == {"id", "version", "digest"}
        and all(isinstance(value[k], str) and value[k] for k in value)
        and len(value["digest"]) == 64
        and all(c in "0123456789abcdef" for c in value["digest"])
    )


def _corpus(snapshot):
    from .scene_review import FEATURE_SCHEMA

    _require(
        isinstance(snapshot, dict)
        and set(snapshot) == {"schema_version", "scope", "revision", "complete", "features"}
        and type(snapshot["schema_version"]) is int
        and snapshot["schema_version"] == 1
        and snapshot["scope"] == "registered-scene-corpus"
        and isinstance(snapshot["revision"], str)
        and bool(snapshot["revision"])
        and snapshot["complete"] is True
        and isinstance(snapshot["features"], list),
        "scene_review_corpus_unavailable",
    )
    ids = []
    for item in snapshot["features"]:
        _require(
            isinstance(item, dict)
            and item.get("feature_schema") == FEATURE_SCHEMA
            and item.get("execution_profile") == profile_ref()
            and isinstance(item.get("task_id"), str)
            and bool(item["task_id"]),
            "scene_review_corpus_unavailable",
        )
        ids.append(item["task_id"])
    _require(len(ids) == len(set(ids)), "scene_review_corpus_unavailable")
    return snapshot


def build_config(*, runtime, profile, corpus):
    """Pure operator config builder; no registration, signature or activation.

    The caller stores this document as registration.scene_admission_config,
    its canonical digest as registration/context.config_digest, and the corpus
    snapshot separately as registration.scene_review_corpus. No self-reference.
    """
    from agent_harness import agent_binding
    from .scene_instruction_runtime import policy_identity as instruction_policy
    from .scene_observation import policy_identity as observation_policy
    from .scene_review import FEATURE_SCHEMA, policy as review_policy
    from .scene_runtime import RUNTIME_VERSION, registry_refs

    identity = policy_identity()
    profile, runtime, corpus = _copy(profile), _copy(runtime), _corpus(_copy(corpus))
    _require(_artifact(runtime) and runtime["version"] == RUNTIME_VERSION, "scene_runtime_unregistered")
    _require(profile.get("runtime") == identity["configuration"]["runtime_checks"], "scene_runtime_policy_mismatch")
    review = review_policy()
    _require(
        review.get("policy_version") == FEATURE_SCHEMA and canonical_digest(review) == _REVIEW_DIGEST,
        "scene_review_policy_unavailable",
    )
    return {
        "schema_version": 1,
        "policy_version": POLICY_VERSION,
        "runtime": runtime,
        "execution_profile": profile_ref(),
        "environment": registry_refs()["environment"],
        "agent": agent_binding(),
        "admission_policy": identity,
        "observation_policy": observation_policy(),
        "instruction_policy": instruction_policy(),
        "profile": profile,
        "review_policy": {"version": FEATURE_SCHEMA, "digest": _REVIEW_DIGEST},
        "corpus_digest": canonical_digest(corpus),
    }


def _expiry(value):
    if isinstance(value, str):
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        _require(parsed.tzinfo is not None, "scene_registration_unavailable")
        value = parsed.timestamp()
    _require(type(value) in (int, float) and math.isfinite(value), "scene_registration_unavailable")
    return value


def _context(context, started):
    try:
        registration = _copy(dict(context.registration))
        pin = _copy(dict(context.task.document))
        profile = _copy(dict(context.profile))
        corpus = _corpus(registration["scene_review_corpus"])
        expected = build_config(runtime=registration["runtime"], profile=profile, corpus=corpus)
        digest = canonical_digest(expected)
        _require(
            registration["scene_admission_config"] == expected
            and registration["config_digest"] == context.config_digest == digest
            and registration["policy_version"] == POLICY_VERSION
            and registration["node_id"] == context.node_id
            and isinstance(context.node_id, str)
            and bool(context.node_id)
            and registration.get("retired", False) is False
            and registration["execution_profile"] == profile_ref()
            and expected["environment"] in registration["environments"]
            and type(context.attempt) is int
            and context.attempt > 0
            and type(pin["attempt"]) is int
            # Queue attempt counts completed reports; the caller binds the next report.
            and pin["attempt"] + 1 == context.attempt
            and type(pin["competition_id"]) is int
            and pin["competition_id"] in registration["competition_ids"],
            "scene_admission_context_unavailable",
        )
        expiry = _expiry(registration["valid_until"])
        _require(
            isinstance(pin.get("task_id"), str)
            and bool(pin["task_id"])
            and isinstance(pin.get("package_repo"), str)
            and bool(pin["package_repo"])
            and isinstance(pin.get("package_commit"), str)
            and len(pin["package_commit"]) == 40
            and all(c in "0123456789abcdef" for c in pin["package_commit"]),
            "scene_admission_context_unavailable",
        )
        remaining = expiry - time.time()
        _require(remaining > 0, "scene_registration_expired")
        deadline = min(
            started + expected["admission_policy"]["configuration"]["runtime_checks"]["timeout_s"],
            time.monotonic() + remaining,
        )
        if hasattr(context, "deadline"):
            _require(
                type(context.deadline) in (int, float) and math.isfinite(context.deadline), "scene_deadline_unavailable"
            )
            deadline = min(deadline, context.deadline)
        return pin, expected, corpus, deadline
    except _Unavailable:
        raise
    except Exception as exc:
        raise _Unavailable("scene_admission_context_unavailable") from exc


def _snapshot_contents(view, pin):
    """Recheck immutable bytes, never reread an original mutable E/P directory."""
    from .scene_import.resources import MAX_FILES, relative_path

    if type(view) is not AdmissionView:
        raise SceneViewError("admission_view_required")
    e = MappingProxyType(dict(view.execution.contents))
    p = MappingProxyType(dict(view.private_contents))
    for contents in (e, p):
        if len(contents) > MAX_FILES or any(type(k) is not str or type(v) is not bytes for k, v in contents.items()):
            raise SceneViewError("scene_snapshot_invalid")
        for name in contents:
            relative_path(name, name)
    execution = _execution(e, view.execution.manifest, pin["submission_digest"])
    if execution != view.execution:
        raise SceneViewError("execution_snapshot_mismatch")
    if (
        pin["execution_package_digest"] != execution.manifest["execution_package_digest"]
        or pin["private_package_digest"] != execution.manifest["private_package_digest"]
        or pin["execution_profile"] != execution.identity["execution_profile"]
        or pin["environment"] != execution.identity["environment"]
    ):
        raise SceneViewError("scene_registered_identity_mismatch")
    maximum = profile_catalog()["resources"][execution.identity["resource_profile"]]["max_package_bytes"]
    if sum(map(len, e.values())) + sum(map(len, p.values())) > maximum:
        raise SceneViewError("package_resource_limit")
    binding = PrivateReferenceBinding.model_validate(decode(p["reference-binding.json"]))
    issues = submission_issues(
        SubmissionManifest.model_validate(execution.manifest),
        binding,
        execution_package_digest=digest_contents(e),
        private_package_digest=digest_contents(p),
        execution_contract=execution.contract,
    )
    if issues or encoded(binding.model_dump()) != view.binding_bytes:
        raise SceneViewError("scene_private_binding_mismatch")
    result = AdmissionView(execution, p, encoded(binding.model_dump()))
    load_private_reference(result)
    return result


def _snapshot(view, pin):
    try:
        return _snapshot_contents(view, pin)
    except SceneViewError:
        raise
    except Exception as exc:
        raise SceneViewError("scene_snapshot_invalid") from exc


def _review(view, corpus, task_id):
    from .scene_review import FEATURE_SCHEMA, comparison, extract, policy

    e = view.execution
    features = extract(
        e.task,
        execution_package_digest=e.manifest["execution_package_digest"],
        submission_digest=e.manifest["submission_digest"],
    )
    features["task_id"] = task_id
    comparisons = sorted(
        [comparison(features, candidate) for candidate in corpus["features"] if candidate["task_id"] != task_id],
        key=lambda candidate: (-candidate["score"], candidate["task_id"]),
    )[: policy()["base"]["thresholds"]["candidate_limit"]]
    return AdmissionCheck(
        "dedup",
        True,
        {
            "feature_schema": FEATURE_SCHEMA,
            "policy_digest": _REVIEW_DIGEST,
            "query_digest": canonical_digest(features),
            "corpus_digest": canonical_digest(corpus),
            "comparison_digest": canonical_digest(comparisons),
            "candidates": comparisons,
            "manual_review_required": True,
            "clearance_granted": False,
            "rule": "P07 evidence only; distinct is not originality; no automatic physical rejection or reward",
        },
        "runtime",
    )


@contextmanager
def _native_task(view, deadline):
    from .scene_authoring import _source, _task

    reference = load_private_reference(view)
    with materialize_execution(view.execution) as root:
        source = _source(root, reference=reference, deadline=deadline)
        try:
            yield source, _task(source)
        finally:
            close = getattr(source, "close", None)
            if callable(close):
                close()


def _physics(task, source, policy, deadline, config_digest):
    from .runtime import _run_runtime_checks
    from .scene_observation import runtime_policy

    # The entire policy/installed implementation is ALREADY in the registered
    # config preimage. Use that exact digest for the P03/P08 signing contract,
    # not local authoring's separately nested config digest.
    runtime = runtime_policy(_copy(policy), task=task)
    runtime["tool_reference"] = {
        "execution_contract": task.metadata["execution_contract"],
        "config_digest": config_digest,
    }
    return _run_runtime_checks(task, source, source.checker(task), runtime, deadline)


def run_scene_admission(view: AdmissionView, *, context: SceneAdmissionCaller) -> Verdict:
    """Real source path; a missing operator registration never starts native work."""
    from .runtime import AdmissionTimeout, Verdict, _classify_checks, _classify_structural
    from .admission import admit_loaded
    from .manifest import CHECK_NAMES, manifest_inputs
    from .scene_instruction_runtime import SceneInstructionError, require
    from .scene_observation import SceneObservationPolicyError, require_policy_scope
    from .scene_env import SceneDeadlineExceeded
    from .scene_import import SceneImportError
    from .scene_views.receipt import _validate_proof

    checks, inputs = [], {}
    task_id, profile, public_summary = "unknown", None, None
    started = time.monotonic()
    try:
        candidate_id = context.task.document.get("task_id")
        if type(candidate_id) is str and candidate_id:
            task_id = candidate_id
    except Exception:
        pass

    def finish(code, *, unavailable=False):
        return Verdict(
            "axis",
            task_id,
            code is None,
            code,
            code,
            tuple(checks),
            "unavailable" if unavailable else "ready",
            None,
            inputs,
            profile,
            public_summary,
        )

    def active(deadline):
        if time.monotonic() >= deadline:
            raise AdmissionTimeout("scene shared deadline")

    try:
        pin, config, corpus, deadline = _context(context, started)
        task_id = str(pin["task_id"])
        profile = pin["execution_profile"]
        active(deadline)
        view = _snapshot(view, pin)
        e = view.execution
        public_summary = e.task["public_summary"]
        _require(
            e.identity["environment"] == config["environment"] and e.contract["agent"] == config["agent"],
            "scene_environment_or_agent_unavailable",
        )
        require_policy_scope(e.task)
        instruction = require(e.task)
        checks.append(AdmissionCheck("instruction_consistency", True, instruction, "runtime"))
        try:
            checks.append(_review(view, corpus, task_id))
        except Exception as exc:
            raise _Unavailable("scene_review_corpus_unavailable") from exc
        active(deadline)
        with _native_task(view, deadline) as (source, task):
            active(deadline)
            # Same immutable bytes and source/context for structure AND physics.
            if task.metadata["execution_package_digest"] != e.manifest["execution_package_digest"]:
                raise SceneViewError("execution_native_binding_mismatch")
            if task.metadata["environment"] != config["environment"]:
                raise _Unavailable("scene_environment_unavailable")
            package = task.metadata["package"]
            base = manifest_inputs(task, profile=config["profile"], package=package)
            binding = {
                "registration": canonical_digest(config),
                "authenticated_task": pin,
                "submission": e.manifest,
                "reference": reference_identity(view),
                "review_corpus": config["corpus_digest"],
            }
            inputs = {
                name: canonical_digest({"base": base[name], "scene": binding, "check": name}) for name in CHECK_NAMES
            }
            structural = admit_loaded(package, source=source, task=task)
            checks.extend(structural.checks)
            if not structural.accepted:
                return finish(_classify_structural(structural)[0])
            active(deadline)
            runtime = _physics(task, source, config["profile"]["runtime"], deadline, context.config_digest)
            active(deadline)
            by_name = {check.name: check for check in runtime}
            required = {
                "runtime.solvable",
                "runtime.deterministic",
                "runtime.noise",
                "runtime.nop",
                "runtime.visibility",
            }
            if len(by_name) != len(runtime) or required != by_name.keys():
                raise _Unavailable("scene_physics_checks_incomplete")
            # The existing engine exposes the exact canonical digest comparison
            # as well as tolerance diagnostics. This same-worker lane requires it.
            deterministic = by_name["runtime.deterministic"]
            if deterministic.detail.get("bitwise_reproducible") is not True:
                runtime = [replace(c, passed=False) if c.name == deterministic.name else c for c in runtime]
            checks.extend(runtime)
            proof = by_name["runtime.solvable"].detail.get("tool_reference_proof")
            if not isinstance(proof, dict):
                raise _Unavailable("scene_tool_proof_unavailable")
            if proof.get("resource_error") is not None:
                raise SceneDeadlineExceeded("scene tool proof shared deadline")
            code, _ = _classify_checks(checks)
            if code is not None:
                return finish(code)
            if proof.get("verified") is not True:
                raise _Unavailable("scene_tool_reference_unavailable")
            if not all(check.passed for check in checks):
                raise _Unavailable("scene_checks_incomplete")
            # P03 applies exactly this validator again before an admitted receipt
            # can be signed. No cached proof attached to P is consumed here.
            verdict = finish(None)
            payload = {**verdict.verdict(), "scene_reference_binding": reference_identity(view)}
            try:
                _validate_proof(view, payload, context.config_digest)
            except SceneViewError as exc:
                raise _Unavailable("scene_reference_proof_binding_unavailable") from exc
            active(deadline)
            return verdict
    except (AdmissionTimeout, SceneDeadlineExceeded):
        checks.append(AdmissionCheck("runtime.timeout", False, {"code": "runtime.timeout"}, "runtime"))
        return finish("infra_crash", unavailable=True)
    except (_Unavailable, RuntimeUnavailable, SceneObservationPolicyError) as exc:
        code = getattr(exc, "code", None) or str(exc)
        if not isinstance(exc, _Unavailable) and not isinstance(exc, SceneObservationPolicyError):
            code = "scene_runtime_unavailable"
        checks.append(AdmissionCheck("scene.availability", False, {"code": code}, "runtime"))
        return finish("infra_scene_runtime_unavailable", unavailable=True)
    except SceneInstructionError as exc:
        checks.append(AdmissionCheck("instruction_consistency", False, exc.finding, "runtime"))
        reject = exc.code.startswith("reject_")
        return finish("reject_instruction" if reject else "infra_scene_instruction_unavailable", unavailable=not reject)
    except SceneViewError as exc:
        unavailable = exc.status == "resource_unavailable"
        checks.append(
            AdmissionCheck("scene.material", False, {"code": exc.code}, "runtime" if unavailable else "structural")
        )
        return finish("infra_scene_runtime_unavailable" if unavailable else "reject_drift", unavailable=unavailable)
    except SceneImportError as exc:
        unavailable = exc.status != "invalid_package"
        checks.append(AdmissionCheck("scene.import", False, {"code": exc.issues[0].code}, "runtime"))
        return finish("infra_scene_runtime_unavailable" if unavailable else "reject_drift", unavailable=unavailable)
    except OSError:
        checks.append(AdmissionCheck("scene.availability", False, {"code": "scene_runtime_io_unavailable"}, "runtime"))
        return finish("infra_scene_runtime_unavailable", unavailable=True)
    except (KeyError, TypeError, ValueError, TaskSourceError):
        checks.append(AdmissionCheck("scene.runtime", False, {"code": "scene_admission_incomplete"}, "runtime"))
        return finish("infra_scene_runtime_failed", unavailable=True)
    except Exception:
        checks.append(AdmissionCheck("scene.runtime", False, {"code": "scene_runtime_crash"}, "runtime"))
        return finish("infra_crash", unavailable=True)
