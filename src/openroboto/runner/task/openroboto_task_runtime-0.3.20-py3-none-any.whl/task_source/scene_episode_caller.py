"""P08 trusted-child caller adapter for the fixed P02 three-call interface.

Only data/context construction lives here. Preparation, opaque single-use
tokens, physics, instruction checks, gateway supervision and scoring remain in
the fixed P02/P03 implementation. Independent deployment pins are mandatory.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass, field
from pathlib import Path
import os
import threading
import time
from types import MappingProxyType
from typing import Any

from task_source.scene_episode_scope import require
from task_source.scene_episode_launcher import digest, trusted_file
from task_source.scene_views import ExecutionView, ReceiptTrust, materialize_execution, verify_execution_view
from task_source.scene_views.identity import decode, encoded


@dataclass
class TrustedSceneEpisodeCaller:
    work: dict = field(repr=False)
    config: Any = field(repr=False)
    member: Any
    trial: int
    instance: int
    spec_path: Path
    result_path: Path
    evidence_path: Path
    host_config: Path = field(repr=False)
    lease_file: Path
    signer: Any = field(repr=False)
    registration: dict = field(repr=False)
    frozen_task: dict = field(repr=False)
    receipt: dict = field(repr=False)
    receipt_trust: ReceiptTrust = field(repr=False)
    episode_policy: dict = field(repr=False)
    gateway_factory: Any = field(repr=False)
    worker_id: str
    node_id: str
    cancellation: threading.Event = field(repr=False)
    subscription_ledger_directory: Path
    private_evidence_directory: Path
    receipt_bytes: bytes = field(repr=False)
    prepared_scene_episode: Any = field(default=None, repr=False)


def load_scene_episode_caller(request, *, deployment, episode_policy):
    """Root-owned deployment chooses every expected pin/key/credential source.

    Request E/manifest/receipt are candidates. They never select policy, trust,
    host/model digests or keys. All I/O is private parent bootstrap; native gets
    only P03's public IPC and sealed E. Nothing is run/installed by importing.
    """
    from agent_evidence.signing import Signer
    from task_source.panel_worker import validate_work, validate_host, model_key_env
    from task_source.scene_adapter import bind_scene_context, original_frozen_task, SceneRegistration
    from task_source.scene_views.episode_gateway import SceneAGatewayFactory
    from task_source.scene_episode_parent import frozen_paths
    from task_source.scene_views.episode_watchdog import MEMORY_EVIDENCE_MODES, MEMORY_PEAK_REQUIRED

    registered_policy = deployment.get("episode_policy")
    require(
        type(episode_policy) is dict
        and type(registered_policy) is dict
        and episode_policy.get("memory_evidence_mode", MEMORY_PEAK_REQUIRED) in MEMORY_EVIDENCE_MODES
        and episode_policy.get("memory_evidence_mode", MEMORY_PEAK_REQUIRED)
        == registered_policy.get("memory_evidence_mode", MEMORY_PEAK_REQUIRED),
        "scene_episode_memory_evidence_mismatch",
    )

    require(
        type(request) is dict
        and set(request)
        == {
            "schema_version",
            "work",
            "commitment",
            "frozen_task",
            "metadata",
            "execution_contents",
            "submission_manifest",
            "receipt",
            "receipt_bytes",
            "caller",
        }
    )
    require(request["schema_version"] == "scene-parent-request-v1")
    work, metadata, raw_caller = request["work"], request["metadata"], request["caller"]
    require(type(work) is dict and type(metadata) is dict and type(raw_caller) is dict)
    require(work["config"] == deployment["panel_config"])
    config = validate_work(work)
    require(config.digest == episode_policy["config_digest"])
    bind_scene_context(work, metadata)
    from task_source.scene_commitment import validate_receipt as validate_commitment

    validate_commitment(
        request["commitment"],
        work,
        backend=deployment["backend_url"],
        worker_id=deployment["worker_id"],
        node_id=deployment["node_id"],
    )
    require(encoded(request["frozen_task"]) == encoded(original_frozen_task(work)))
    require(work["task"]["competition_id"] in deployment["competition_ids"])
    require(metadata["worker_id"] == deployment["worker_id"] and metadata["node_id"] == deployment["node_id"])
    require(raw_caller["registration"] == deployment["registration"])
    registration = SceneRegistration.parse(deployment["registration"])
    root, _, _ = frozen_paths(request, deployment)
    host_path = Path(raw_caller["host_config"])
    host = decode(host_path.read_bytes())
    require(digest(host) == deployment["host_digest"])
    validate_host(host, config)
    members = {member.id: member for member in config.settlement.members}
    member = members[raw_caller["member_id"]]
    model = {**member.model_config(), **host["providers"][member.provider]}
    expected_model = deployment["model_digests"][member.id]
    require(digest(model) == expected_model)
    trust_doc = deployment["receipt_trust"]
    require(trust_doc["algorithm"] == "ed25519" and trust_doc["provenance"] == "server_registered")
    trust = ReceiptTrust(**{
        k: trust_doc[k]
        for k in (
            "node_id",
            "key_id",
            "public_key_hex",
            "runtime",
            "policy_version",
            "provenance",
        )
    })
    authority = metadata["receipt_authority"]
    require(trust.document == {key: authority[key] for key in trust.document})
    # Sender's public manifest is still untrusted until P03 verifies its roots.
    contents = {name: base64.b64decode(raw, validate=True) for name, raw in request["execution_contents"].items()}
    candidate = ExecutionView(
        MappingProxyType(contents),
        encoded(request["submission_manifest"]),
        contents["task.json"],
        encoded(metadata["execution_contract"]),
        encoded(metadata["identity"]),
    )
    with materialize_execution(candidate) as execution:
        view = verify_execution_view(
            execution,
            request["submission_manifest"],
            request["receipt"],
            expected_submission_digest=metadata["scene_task"]["submission_digest"],
            trust=trust,
        )
    require(view.identity == metadata["identity"] and view.contract == metadata["execution_contract"])
    require(digest(request["receipt"]) == metadata["receipt_digest"])
    receipt_bytes = base64.b64decode(request["receipt_bytes"], validate=True)
    require(decode(receipt_bytes) == request["receipt"], "scene_episode_authenticated_receipt_mismatch")
    for key in ("execution_package_digest", "private_package_digest", "submission_digest"):
        require(view.manifest[key] == metadata["scene_task"][key])
    # Executor identity is selected from the root deployment, never the wire.
    signer_doc = decode(trusted_file(deployment["executor_key_file"], private=True))
    require(signer_doc.get("algorithm", "ed25519") == "ed25519")
    signer = Signer(signer_doc["party"], signer_doc["key_id"], bytes.fromhex(signer_doc["seed"]))
    registration.identity(deployment["node_id"], signer).validate(time.time())
    factory = SceneAGatewayFactory.from_registered_config(
        host,
        expected_host_digest=deployment["host_digest"],
        frozen_model=model,
        expected_model_digest=expected_model,
        config_digest=config.digest,
        expected_factory_digest=episode_policy["gateway_factory_digest"],
        lease_file=raw_caller["lease_file"],
        ledger_directory=root / "subscription",
        provider_policy=deployment["provider_policies"][member.id],
        expected_provider_policy_digest=deployment["provider_policy_digests"][member.id],
        native_registration=deployment.get("native_provider_registrations", {}).get(member.id),
    )
    # Model credential env names are restricted by the existing worker rule.
    # Neither Validator/HF/Operator nor R credentials are loaded into native.
    for name, path in deployment["model_key_files"].items():
        require(model_key_env(name) == name)
        value = trusted_file(path, limit=16384, private=True).decode().strip()
        require(value and "\x00" not in value)
        os.environ[name] = value  # Root parent only; P03 native uses --clearenv.
    require(not model.get("api_key_env") or model["api_key_env"] in deployment["model_key_files"])
    require(
        model.get("api_key_env") or deployment.get("allow_anonymous_models") is True,
        "scene_episode_model_credential_unavailable",
    )
    frozen = decode(encoded(request["frozen_task"]))
    # Only the two current deadlines may be projected from the independently
    # authenticated scene-context. Preserve the original nested DTO/trust and
    # timestamp representation; do not reconstruct it from normalized aliases.
    frozen["assignment"]["lease_expires_at"] = metadata["lease_expires_at"]
    frozen["receipt_authority"]["valid_until"] = authority["valid_until"]
    return view, TrustedSceneEpisodeCaller(
        work,
        config,
        member,
        raw_caller["trial"],
        raw_caller["instance"],
        *(Path(raw_caller[key]) for key in ("spec_path", "result_path", "evidence_path", "host_config", "lease_file")),
        signer,
        registration.document,
        frozen,
        request["receipt"],
        trust,
        episode_policy,
        factory,
        deployment["worker_id"],
        deployment["node_id"],
        threading.Event(),
        root / "subscription",
        root / "private-scene" / f"{member.id}-{raw_caller['trial']}",
        receipt_bytes,
    )
