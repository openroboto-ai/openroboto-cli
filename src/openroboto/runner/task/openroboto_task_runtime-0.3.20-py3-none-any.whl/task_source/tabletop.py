"""首版受限桌面方案：真实 Panda，固定物品、物理与准确的放置目标。

这里只接受按公开定义重建后逐文件一致的场景。声明 profile、能加载 XML、
或者参考操作能成功，都不能替代平台对机器人和物理设置的授权检查。
"""

from __future__ import annotations

import copy
import hashlib
import itertools
import json
import math
import pathlib
import random
import xml.etree.ElementTree as ET
from typing import Any, Mapping

from .base import CheckResult, TaskSourceError
from .package import TaskPackage, canonical_json_sha256, read_json

DATA = pathlib.Path(__file__).resolve().parent / "data" / "panda_tabletop_v1"
CHECKER_TYPE = "TabletopZoneChecker"
JOINT_ORDER = (
    "franka/panda_finger_joint1",
    "franka/panda_finger_joint2",
    *(f"franka/panda_joint{i}" for i in range(1, 8)),
)
INITIAL_ARM = (
    0.28690052886200346,
    0.08149039732564702,
    0.2620620604194804,
    -1.8598469048683912,
    -0.02259771589638919,
    1.938482609738647,
    -0.22915138388782952,
)
RUNTIME = {
    "action_semantics": "absolute joint-position targets in observation_joint_order",
    "observation_joint_order": list(JOINT_ORDER),
    "control_period_s": 0.2,
    "camera": "camera0",
    "settle_control_steps": 5,
}
COLORS = ((0.95, 0.4, 0.1, 1.0), (0.15, 0.35, 0.9, 1.0))


def _contract():
    try:
        from openroboto_protocol import task_contract
    except ImportError as exc:
        raise TaskSourceError("panda-tabletop-v1 requires the task-contract protocol release") from exc
    return task_contract


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def _numbers(values: Any) -> str:
    return " ".join(format(float(v), ".12g") for v in values)


def profile_ref() -> dict[str, Any]:
    return dict(_contract().execution_profile_ref())


def _profile_document() -> Mapping[str, Any]:
    return _contract().task_profile_catalog()[0]


def verify_platform_assets() -> dict[str, str]:
    """平台自身资产也与协议发布的摘要核对，不能任意换掉机器人。"""
    manifest = read_json(DATA / "manifest.json")
    files = manifest.get("files")
    if not isinstance(files, Mapping):
        raise TaskSourceError("platform scene asset manifest is invalid")
    digest = hashlib.sha256(_canonical(files)).hexdigest()
    expected = _profile_document().get("scene_manifest_sha256")
    if digest != expected:
        raise TaskSourceError("platform scene manifest does not match the frozen execution profile")
    for relative, sha in files.items():
        p = DATA / relative
        if p.is_symlink() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != sha:
            raise TaskSourceError(f"platform asset mismatch: {relative}")
    return dict(files)


def definition_instruction(definition: Mapping[str, Any]) -> str:
    pieces = [
        f"Place {goal['object_id']} completely inside its marked target zone at "
        f"({goal['target_position'][0]:g}, {goal['target_position'][1]:g}) metres"
        for goal in definition["goals"]
    ]
    return "; ".join(pieces) + ". Release both gripper fingers and keep every object at rest in its zone for 1 second."


def checker_config(definition: Mapping[str, Any]) -> dict[str, Any]:
    return {"checker": {"type": CHECKER_TYPE, "goals": copy.deepcopy(definition["goals"])}}


def _scene(definition: Mapping[str, Any]) -> str:
    asset = _profile_document()["assets"][0]
    root = ET.fromstring((DATA / "scene.xml").read_text())
    world = root.find("worldbody")
    assert world is not None
    for index, obj in enumerate(definition["objects"]):
        body = ET.SubElement(world, "body", {"name": obj["id"], "pos": _numbers(obj["position"])})
        ET.SubElement(body, "freejoint", {"name": obj["id"] + "_free"})
        ET.SubElement(
            body,
            "geom",
            {
                "name": obj["id"] + "_geom",
                "type": "box",
                "size": _numbers(v / 2 for v in asset["size_m"]),
                "mass": str(asset["mass_kg"]),
                "friction": "1 .005 .0001",
                "contype": "2",
                "conaffinity": "3",
                "rgba": _numbers(COLORS[index]),
                "solref": ".004 1",
                "solimp": ".998 .998 .001",
            },
        )
    for index, goal in enumerate(definition["goals"]):
        x, y, _ = goal["target_position"]
        body = ET.SubElement(world, "body", {"name": f"target_zone_{index}", "pos": _numbers((x, y, 0.7505))})
        ET.SubElement(
            body,
            "geom",
            {
                "type": "cylinder",
                "size": f"{_profile_document()['success']['xy_radius_m']} .0005",
                "contype": "0",
                "conaffinity": "0",
                "rgba": _numbers((*COLORS[index][:3], 0.5)),
            },
        )
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="unicode") + "\n"


def _initial(definition: Mapping[str, Any], instance: int) -> dict[str, Any]:
    # 初态变化也是平台规则：每轴最多 2 mm；seed 是题目固定输入，不按模型变化。
    rng = random.Random(int(definition["seed"]) * 1009 + instance)
    positions = [obj["position"] for obj in definition["objects"]]
    limits = _profile_document()["limits"]["position_m"]
    dx = (
        min(
            limits["x"][1] - max(p[0] for p in positions),
            max(limits["x"][0] - min(p[0] for p in positions), rng.uniform(-0.002, 0.002)),
        )
        if instance
        else 0
    )
    dy = (
        min(
            limits["y"][1] - max(p[1] for p in positions),
            max(limits["y"][0] - min(p[1] for p in positions), rng.uniform(-0.002, 0.002)),
        )
        if instance
        else 0
    )
    objects = {}
    for obj in definition["objects"]:
        position = list(obj["position"])
        position[0] += dx
        position[1] += dy
        objects[obj["id"]] = {"pos": position, "rot": [0, 0, 0, 1]}
    return {
        "objects": objects,
        "robots": {"franka": {"dof_pos": dict(zip(JOINT_ORDER, (0.04, 0.04, *INITIAL_ARM)))}},
    }


def package_documents(task_id: str, title: str, definition: Mapping[str, Any], *, public_summary: Any = None):
    """生成定义的唯一展开方式；准入重新展开并比较，而不是信任 CLI。"""
    contract = _contract()
    issues = contract.task_definition_issues(definition)
    if issues:
        raise TaskSourceError("; ".join(f"{i.code}: {i.message}" for i in issues))
    # These names belong to the actual robot / generated target bodies. This
    # compiler boundary also protects callers using the released 0.14 protocol.
    if any(obj["id"] == "franka" or obj["id"].startswith("target_zone_") for obj in definition["objects"]):
        raise TaskSourceError("reserved_object_id: object name belongs to the platform scene")
    verify_platform_assets()
    instruction = definition_instruction(definition)
    checker = checker_config(definition)
    task: dict[str, Any] = {
        "schema_version": 1,
        "source": "axis",
        "task_id": task_id,
        "title": title,
        "instruction": instruction,
        "checker": checker,
        "runtime": copy.deepcopy(RUNTIME),
        "execution_profile": profile_ref(),
        "task_definition": copy.deepcopy(dict(definition)),
        "reference_solution": "reference.json",
    }
    if public_summary is not None:
        try:
            task["public_summary"] = contract.parse_public_summary(public_summary, expected_profile=profile_ref())
        except ValueError as exc:
            raise TaskSourceError(str(exc)) from exc
    docs: dict[str, Any] = {"task.json": task}
    variants = []
    for instance in range(definition["instance_count"]):
        payload = {
            "id": task_id,
            "name": instruction,
            "instance": instance,
            "seed": int(definition["seed"]) * 1009 + instance,
            "initial_state": _initial(definition, instance),
            "checker_config": checker,
            "scene": "runtime/scene.xml",
        }
        relative = f"payloads/{instance:02d}.json"
        docs[relative] = payload
        variants.append({
            "instance": instance,
            "payload_path": relative,
            "seed": payload["seed"],
            "payload_canonical_sha256": canonical_json_sha256(payload),
            "checker_sha256": canonical_json_sha256(checker),
            "initial_state_sha256": canonical_json_sha256(payload["initial_state"]),
        })
    first = docs["payloads/00.json"]
    docs["benchmark.json"] = {
        "schema_version": 1,
        "name": "openroboto-panda-tabletop-v1",
        "runtime": copy.deepcopy(RUNTIME),
        "protocol": {"max_control_steps_per_trial": _profile_document()["limits"]["max_control_steps_per_trial"]},
        "tasks": [
            {
                "task_id": task_id,
                "instruction": instruction,
                "checker_sha256": canonical_json_sha256(checker),
                "initial_state_sha256": canonical_json_sha256(first["initial_state"]),
            }
        ],
    }
    docs["randomization.json"] = {"schema_version": 1, "tasks": [{"task_id": task_id, "variants": variants}]}
    return docs


def validate_package(package: TaskPackage, *, expected_execution_profile: Any = None) -> dict[str, Any] | None:
    """新包严格重建核对；旧包只在运营明确要求新方案时拒绝。"""
    task = package.task
    if "execution_profile" not in task and "task_definition" not in task and expected_execution_profile is None:
        return None
    contract = _contract()
    issues = contract.validate_task_document(
        task,
        expected_execution_profile=expected_execution_profile,
        require_profile=expected_execution_profile is not None,
    )
    if issues:
        raise TaskSourceError("; ".join(f"{i.code}: {i.message}" for i in issues))
    definition = task["task_definition"]
    expected = package_documents(
        package.task_id, str(task.get("title") or ""), definition, public_summary=task.get("public_summary")
    )
    for relative, value in expected.items():
        actual = read_json(package.path(relative))
        if actual != value:
            raise TaskSourceError(f"execution-profile: frozen generated definition differs: {relative}")
    scene = package.path("runtime/scene.xml")
    if scene.read_text() != _scene(definition):
        raise TaskSourceError("execution-profile: scene changes robot, physics, assets or generated layout")
    asset_files = verify_platform_assets()
    allowed = set(expected) | {"reference.json", "runtime/scene.xml", ".gitattributes"}
    for relative, sha in asset_files.items():
        if relative == "scene.xml":
            continue
        name = "runtime/" + relative
        allowed.add(name)
        p = package.path(name)
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != sha:
            raise TaskSourceError(f"execution-profile: unapproved runtime asset {name}")
    total = 0
    for p in package.directory.rglob("*"):
        if p.is_symlink():
            raise TaskSourceError("execution-profile: symlinks are not allowed")
        if p.is_file():
            relative = p.relative_to(package.directory).as_posix()
            if relative not in allowed:
                raise TaskSourceError(f"execution-profile: undeclared package file {relative}")
            if relative == ".gitattributes" and p.stat().st_size > 8192:
                raise TaskSourceError("execution-profile: repository attributes exceed the 8 KB metadata bound")
            total += p.stat().st_size
    if total > 5_000_000:
        raise TaskSourceError("execution-profile: package exceeds the fixed 5 MB bound")
    return {"execution_profile": profile_ref(), "public_summary": task.get("public_summary")}


def zone_condition(config: Mapping[str, Any], state: Mapping[str, Any], *, require_hold: bool = True) -> CheckResult:
    """检查整个刚体投影、实际高度、松爪、线/角速度与连续保持时间。"""
    profile = _profile_document()
    success = profile["success"]
    positions = state.get("positions") or {}
    orientations = state.get("orientations") or {}
    linear = state.get("linear_velocities") or {}
    angular = state.get("angular_velocities") or {}
    joints = state.get("joints") or {}
    fingers = [float(joints.get(name, joints.get(name.rsplit("/", 1)[-1], -1))) for name in JOINT_ORDER[:2]]
    details: list[dict[str, Any]] = []
    passed = all(math.isfinite(v) and v >= success["finger_open_min_m"] for v in fingers)
    for goal in config.get("goals") or []:
        name = str(goal.get("object_id"))
        pos, quat = positions.get(name), orientations.get(name)
        lv, av = linear.get(name), angular.get(name)
        good = all(isinstance(v, (list, tuple)) and len(v) == n for v, n in ((pos, 3), (quat, 4), (lv, 3), (av, 3)))
        radius = float("inf")
        if good:
            values = [float(x) for v in (pos, quat, lv, av) for x in v]
            good = all(math.isfinite(x) for x in values)
        if good:
            from .axis import _quat_rotate

            target = goal["target_position"]
            half = [float(v) / 2 for v in profile["assets"][0]["size_m"]]
            corners = [_quat_rotate(quat, corner) for corner in itertools.product(*[(-v, v) for v in half])]
            radius = max(math.hypot(pos[0] + p[0] - target[0], pos[1] + p[1] - target[1]) for p in corners)
            good = (
                radius <= success["xy_radius_m"]
                and abs(pos[2] - target[2]) <= success["z_tolerance_m"]
                and math.sqrt(sum(x * x for x in lv)) <= success["max_linear_speed_m_s"]
                and math.sqrt(sum(x * x for x in av)) <= success["max_angular_speed_rad_s"]
            )
        passed = passed and good
        details.append({
            "object_id": name,
            "passed": bool(good),
            "max_corner_radius_m": radius if math.isfinite(radius) else None,
        })
    passed = passed and bool(details)
    hold = state.get("tabletop_goal_hold_steps", 0)
    if require_hold:
        passed = passed and type(hold) is int and hold >= success["hold_control_steps"]
    return CheckResult(
        bool(passed),
        {
            "checker_type": CHECKER_TYPE,
            "passed": bool(passed),
            "objects": details,
            "fingers": fingers,
            "hold_steps": hold,
        },
    )
