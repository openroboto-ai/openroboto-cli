"""开发样本 / 正式确认样本的确定性划分与冻结摘要（OPE-228）。

本模块只回答**结构问题**：

- 划分是否确定、可复现；
- dev 与 confirm 是否不重叠、并集是否覆盖全部规定初态；
- 确认样本是否都有参考解覆盖；
- 划分内容是否被冻结摘要锁定。

它**不**做物理可解性回放。确认样本仍必须用与开发样本相同的 profile、工具、
权限和预算跑完整准入；本模块不提供任何“隐藏样本可跳过可解性验证”的捷径。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .base import TaskSpec, canonical_sha256

SCHEMA_VERSION = 1
POLICY_VERSION = "split-v1"


@dataclass(frozen=True)
class SplitPolicy:
    """划分策略。改了比例或顺序必须升版本。"""

    version: str = POLICY_VERSION
    confirm_fraction: float = 0.2
    minimum_confirm: int = 1
    minimum_dev: int = 1

    def digest(self) -> str:
        return canonical_sha256({
            "version": self.version,
            "confirm_fraction": self.confirm_fraction,
            "minimum_confirm": self.minimum_confirm,
            "minimum_dev": self.minimum_dev,
        })


def _instance_ids(task: TaskSpec) -> list[int]:
    return [int(item.instance) for item in task.instances]


def split_instances(task: TaskSpec, *, policy: SplitPolicy | None = None) -> dict[str, Any]:
    """确定性划分：按实例号排序，最后 N 个进确认集。

    不用随机：同一题包在任何机器、任何时间得到同一份划分；换划分必须换
    策略版本并留下记录。
    """

    policy = policy or SplitPolicy()
    identifiers = sorted(_instance_ids(task))
    if len(identifiers) < policy.minimum_confirm + policy.minimum_dev:
        raise ValueError(
            f"task {task.task_id} has {len(identifiers)} instances; "
            f"need at least {policy.minimum_confirm + policy.minimum_dev} for dev/confirm split"
        )
    confirm_count = max(policy.minimum_confirm, int(round(len(identifiers) * policy.confirm_fraction)))
    confirm_count = min(confirm_count, len(identifiers) - policy.minimum_dev)
    dev = identifiers[:-confirm_count]
    confirm = identifiers[-confirm_count:]
    return {
        "schema_version": SCHEMA_VERSION,
        "policy_version": policy.version,
        "policy_digest": policy.digest(),
        "task_id": task.task_id,
        "source": task.source,
        "execution_profile": task.metadata.get("execution_profile"),
        "dev": dev,
        "confirm": confirm,
    }


def validate_split(task: TaskSpec, split: Mapping[str, Any]) -> list[str]:
    """结构校验：不重叠、并集完整、确认集非空。返回错误列表。"""

    errors: list[str] = []
    identifiers = sorted(_instance_ids(task))
    dev = split.get("dev")
    confirm = split.get("confirm")
    if not isinstance(dev, list) or not isinstance(confirm, list):
        return ["split.dev and split.confirm must be lists"]
    dev_values = [int(value) for value in dev]
    confirm_values = [int(value) for value in confirm]
    if len(set(dev_values)) != len(dev_values):
        errors.append("split.dev contains duplicates")
    if len(set(confirm_values)) != len(confirm_values):
        errors.append("split.confirm contains duplicates")
    overlap = set(dev_values) & set(confirm_values)
    if overlap:
        errors.append(f"dev and confirm overlap: {sorted(overlap)}")
    if sorted(dev_values + confirm_values) != identifiers:
        errors.append(
            f"dev+confirm must cover every instance exactly once; "
            f"missing={sorted(set(identifiers) - set(dev_values + confirm_values))}, "
            f"extra={sorted(set(dev_values + confirm_values) - set(identifiers))}"
        )
    if not confirm_values:
        errors.append("split.confirm is empty")
    if not dev_values:
        errors.append("split.dev is empty")
    return errors


def validate_confirm_reference(task: TaskSpec, split: Mapping[str, Any]) -> list[str]:
    """确认样本必须有参考解覆盖；不证明物理可解，只证明证据存在。"""

    errors: list[str] = []
    reference = task.reference or {}
    instances = reference.get("instances")
    if not isinstance(instances, Mapping):
        return ["task has no reference.instances; confirmation sample cannot be justified"]
    for value in split.get("confirm") or []:
        entry = instances.get(str(value))
        if not isinstance(entry, Mapping):
            errors.append(f"confirm instance {value} has no reference entry")
            continue
        if not entry.get("final_state") and not entry.get("tool_actions"):
            errors.append(f"confirm instance {value} has neither final_state nor tool_actions")
    return errors


def freeze_split(task: TaskSpec, split: Mapping[str, Any], *, package_digest: str) -> dict[str, Any]:
    """把划分与题包摘要绑定成一个可复验的冻结记录。"""

    errors = validate_split(task, split) + validate_confirm_reference(task, split)
    if errors:
        raise ValueError("; ".join(errors))
    payload = {
        "schema_version": SCHEMA_VERSION,
        "policy_version": str(split.get("policy_version") or POLICY_VERSION),
        "policy_digest": str(split.get("policy_digest") or SplitPolicy().digest()),
        "task_id": task.task_id,
        "source": task.source,
        "execution_profile": task.metadata.get("execution_profile"),
        "package_digest": package_digest,
        "dev": list(split.get("dev") or []),
        "confirm": list(split.get("confirm") or []),
    }
    return {**payload, "split_digest": canonical_sha256(payload)}


def verify_frozen_split(
    task: TaskSpec,
    frozen: Mapping[str, Any],
    *,
    package_digest: str,
) -> list[str]:
    """重算冻结摘要并核对题包摘要；不匹配就是拒跑，不是警告。"""

    errors: list[str] = []
    if frozen.get("package_digest") != package_digest:
        errors.append(f"package_digest changed: frozen {frozen.get('package_digest')!r}, current {package_digest!r}")
    expected = canonical_sha256({
        "schema_version": frozen.get("schema_version"),
        "policy_version": frozen.get("policy_version"),
        "policy_digest": frozen.get("policy_digest"),
        "task_id": frozen.get("task_id"),
        "source": frozen.get("source"),
        "execution_profile": frozen.get("execution_profile"),
        "package_digest": frozen.get("package_digest"),
        "dev": list(frozen.get("dev") or []),
        "confirm": list(frozen.get("confirm") or []),
    })
    if frozen.get("split_digest") != expected:
        errors.append("split_digest does not match the frozen split payload")
    split = {
        "dev": frozen.get("dev"),
        "confirm": frozen.get("confirm"),
    }
    errors.extend(validate_split(task, split))
    errors.extend(validate_confirm_reference(task, split))
    return errors


__all__ = [
    "POLICY_VERSION",
    "SCHEMA_VERSION",
    "SplitPolicy",
    "freeze_split",
    "split_instances",
    "validate_confirm_reference",
    "validate_split",
    "verify_frozen_split",
]
