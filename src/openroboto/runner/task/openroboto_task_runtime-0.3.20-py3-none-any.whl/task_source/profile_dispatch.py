"""精确版本分派：未知引用由对应校验器拒绝，旧任务不补新默认。"""

from openroboto_protocol.task_profiles import is_v2

from . import tabletop, tabletop_v2


def validate_package(package, *, expected_execution_profile=None):
    reference = package.task.get("execution_profile")
    if isinstance(reference, dict) and reference.get("id") == "panda-open-scene-v1":
        from .scene_runtime import validate_package as validate_scene

        return validate_scene(package, expected_execution_profile=expected_execution_profile)
    declared_v2 = isinstance(reference, dict) and reference.get("id") == "panda-tabletop-v2"
    module = tabletop_v2 if declared_v2 else tabletop
    return module.validate_package(package, expected_execution_profile=expected_execution_profile)


def package_profile(package):
    ref = package.task.get("execution_profile")
    if isinstance(ref, dict) and ref.get("id") == "panda-open-scene-v1":
        from openroboto_protocol import scene_contract

        scene_contract.profile_document(ref)
        return ref
    return ref if is_v2(ref) else tabletop.profile_ref()
