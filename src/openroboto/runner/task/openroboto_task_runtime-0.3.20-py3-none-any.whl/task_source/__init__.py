"""可替换的题源适配层（AXIS / RoboDojo）。

上层只依赖 :class:`TaskSource` / :class:`Checker` / :class:`Env` 三个协议；
具体实现由 ``configs/task_sources.json`` 决定。切换题源只改配置。
"""

from .base import (
    AdmissionCheck,
    AdmitResult,
    Checker,
    CheckResult,
    Env,
    EpisodeRunner,
    InstanceSpec,
    MissingReferenceTrajectory,
    ReplayResult,
    RuntimeUnavailable,
    Space,
    TaskSource,
    TaskSourceError,
    TaskSpec,
    UnknownTask,
    checker_body_names,
    perturb_actions,
    state_digest,
)
from .package import TaskPackage, canonical_json_sha256, discover_packages, load_package
from .fingerprint import DedupIndex, fingerprint
from .instruction import InstructionCheck, check_instruction
from .registry import (
    create_checker,
    get_source,
    load_config,
    register_checker,
    register_source,
    registered_checkers,
    registered_sources,
)
from .runtime import Verdict, get_profile, load_profiles, run_admission

__all__ = [
    "AdmissionCheck",
    "AdmitResult",
    "CheckResult",
    "Checker",
    "DedupIndex",
    "Env",
    "EpisodeRunner",
    "InstanceSpec",
    "InstructionCheck",
    "MissingReferenceTrajectory",
    "ReplayResult",
    "RuntimeUnavailable",
    "Space",
    "TaskPackage",
    "TaskSource",
    "TaskSourceError",
    "TaskSpec",
    "UnknownTask",
    "Verdict",
    "canonical_json_sha256",
    "check_instruction",
    "checker_body_names",
    "create_checker",
    "discover_packages",
    "fingerprint",
    "get_profile",
    "get_source",
    "load_config",
    "load_package",
    "load_profiles",
    "perturb_actions",
    "register_checker",
    "register_source",
    "registered_checkers",
    "registered_sources",
    "run_admission",
    "state_digest",
]
