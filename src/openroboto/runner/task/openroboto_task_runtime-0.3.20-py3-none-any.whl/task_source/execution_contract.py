"""A 难题参考解与模型执行共用的显式条件，缺省不产生难题资格。"""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Mapping
from typing import Any

SENSORS = ("image", "proprioception", "object_positions", "state", "success")


def _object(raw: Any, keys: set[str], name: str) -> Mapping[str, Any]:
    if not isinstance(raw, Mapping) or set(raw) != keys:
        raise ValueError(f"{name} must contain exactly {sorted(keys)}")
    return raw


def _positive_number(raw: Any, name: str) -> float:
    if type(raw) not in (int, float):
        raise ValueError(f"{name} must be a positive finite number")
    try:
        value = float(raw)
        if not math.isfinite(value) or value <= 0:
            raise ValueError("not positive finite")
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{name} must be a positive finite number") from exc
    return value


def parse_execution_contract(raw: Any) -> dict[str, Any]:
    """严格解析 v1；首版只证明完整 privileged 观察、动作推进的 headless 工具。"""
    if isinstance(raw, Mapping) and raw.get("version") == 3:
        from openroboto_protocol.scene_contract import parse_execution_contract as parse_scene

        return parse_scene(raw)
    if isinstance(raw, Mapping) and raw.get("version") == 2:
        from openroboto_protocol.composed_execution import parse_execution_contract as parse_v2

        return parse_v2(raw)
    raw = _object(raw, {"version", "harness", "agent", "permissions", "budget", "timing"}, "execution_contract")
    if type(raw["version"]) is not int or raw["version"] != 1:
        raise ValueError("execution_contract.version must be 1")
    harness = _object(raw["harness"], {"name"}, "harness")
    if harness["name"] != "headless":
        raise ValueError("execution_contract requires the headless harness")
    agent = _object(raw["agent"], {"harness_commit", "system_prompt_digest", "tools_digest"}, "agent")
    for key, size in (("harness_commit", 40), ("system_prompt_digest", 64), ("tools_digest", 64)):
        if not isinstance(agent[key], str) or not re.fullmatch(r"[0-9a-f]{" + str(size) + "}", agent[key]):
            raise ValueError(f"agent.{key} must be {size} lowercase hex characters")
    permissions = _object(raw["permissions"], {"mode", "allowed_sensors"}, "permissions")
    sensors = permissions["allowed_sensors"]
    if (
        permissions["mode"] != "privileged"
        or not isinstance(sensors, list)
        or len(sensors) != len(SENSORS)
        or any(not isinstance(sensor, str) for sensor in sensors)
        or set(sensors) != set(SENSORS)
    ):
        raise ValueError("execution_contract requires the complete privileged sensor list without duplicates")
    budget = _object(raw["budget"], {"max_api_calls", "max_steps", "wall_seconds"}, "budget")
    for key in ("max_api_calls", "max_steps"):
        if type(budget[key]) is not int or budget[key] <= 0:
            raise ValueError(f"budget.{key} must be a positive integer")
    wall = _positive_number(budget["wall_seconds"], "budget.wall_seconds")
    timing = _object(raw["timing"], {"control_step_seconds", "clock_mode", "s"}, "timing")
    if timing["clock_mode"] != "sim" or type(timing["s"]) not in (int, float) or timing["s"] != 0:
        raise ValueError("execution_contract requires clock_mode=sim and s=0")
    control = _positive_number(timing["control_step_seconds"], "timing.control_step_seconds")
    return {
        "version": 1,
        "harness": {"name": "headless"},
        "agent": dict(agent),
        "permissions": {"mode": "privileged", "allowed_sensors": sorted(SENSORS)},
        "budget": {"max_api_calls": budget["max_api_calls"], "max_steps": budget["max_steps"], "wall_seconds": wall},
        "timing": {"control_step_seconds": control, "clock_mode": "sim", "s": 0.0},
    }


def execution_contract_digest(raw: Any) -> str:
    canonical = json.dumps(
        parse_execution_contract(raw), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    )
    return hashlib.sha256(canonical.encode()).hexdigest()


def verify_execution_runtime(contract: Any, runtime: Any) -> dict[str, Any]:
    """v1 只认本地真实 AXIS 物理时钟，spec 中的声明不能替代环境实值。"""
    from agent_harness.runtimes import AxisToolRuntime

    parsed = parse_execution_contract(contract)
    expected = parsed["timing"]["control_step_seconds"]
    if type(runtime) is not AxisToolRuntime:
        raise ValueError("A execution_contract requires the physical AxisToolRuntime")
    actual = _positive_number(
        getattr(getattr(runtime, "env", None), "control_period_s", None), "runtime.control_period_s"
    )
    if actual != expected:
        raise ValueError(
            f"A execution_contract control_step_seconds={expected} "
            f"differs from physical runtime.control_period_s={actual}"
        )
    physical_definition = runtime.task.metadata.get("runtime", {}).get("tabletop_v2_definition")
    if getattr(runtime.env, "scene_contract", False):
        if (
            parsed["version"] != 3
            or runtime.task.metadata.get("execution_profile") != parsed["execution_profile"]
            or runtime.task.metadata.get("resource_profile") != parsed["resource_profile"]
            or runtime.env.observation_contract != parsed["observation_contract"]
            or runtime.max_steps != parsed["budget"]["max_steps"]
        ):
            raise ValueError("physical scene runtime differs from its frozen execution conditions")
        return {"name": "AxisToolRuntime", "control_period_s": actual}
    if parsed["version"] == 3:
        raise ValueError("a scene execution contract requires the native scene runtime")
    if isinstance(physical_definition, Mapping) and parsed["version"] != 2:
        raise ValueError("a composed v2 task requires an explicit v2 execution contract")
    if parsed["version"] == 2:
        definition = runtime.task.metadata.get("runtime", {}).get("tabletop_v2_definition")
        if (
            not isinstance(definition, Mapping)
            or definition["observation"] != parsed["observation_contract"]
            or definition["resource_profile"] != parsed["resource_profile"]
            or runtime.task.metadata.get("execution_profile") != parsed["execution_profile"]
            or runtime.max_steps != parsed["budget"]["max_steps"]
        ):
            raise ValueError("physical v2 runtime does not match its frozen observation/resource contract")
    return {"name": "AxisToolRuntime", "control_period_s": actual}
