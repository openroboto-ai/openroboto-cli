"""开放场景近重复证据适配；不决定准入、计奖、隔离或恢复。"""

from __future__ import annotations

import json
from copy import deepcopy
import math
from pathlib import Path

from openroboto_protocol.scene_schema import SceneTask
from openroboto_protocol.tabletop_assets import canonical_digest

from .near_duplicate import NearDuplicatePolicy, compare
from .scene_review_names import canonical_scene

FEATURE_SCHEMA = "scene-nd-v2"
POLICY_PATH = Path(__file__).resolve().parents[1] / "configs" / "scene_review_policy.json"
if not POLICY_PATH.is_file():
    # Standalone runtime installs retain the exact P07 policy bytes. Algorithm,
    # normalization, thresholds and manual-clearance semantics are unchanged.
    POLICY_PATH = Path(__file__).parent / "data" / "scene_review_policy_v2.json"


def policy():
    return json.loads(POLICY_PATH.read_text())


def _types(value):
    if isinstance(value, dict):
        found = [value["type"]] if "type" in value else []
        return found + [t for v in value.values() for t in _types(v)]
    if isinstance(value, list):
        return [t for v in value for t in _types(v)]
    return []


def extract(task, *, execution_package_digest, submission_digest):
    """只处理已经核验过的快照；静态声明不证明MuJoCo中的物理真相。"""
    task = SceneTask.model_validate(task).model_dump(mode="json")
    definition, scene = task["task_definition"], task["scene"]
    objects = definition["objects"]
    normalized = canonical_scene(task)
    canonical_definition, canonical = normalized["task_definition"], normalized["scene"]
    assets = {a["id"]: a for a in canonical["assets"]}
    entity_shapes = [{k: v for k, v in obj.items() if k != "asset"} for obj in canonical_definition["objects"]]
    collision = [
        {k: v for k, v in assets[o["asset"]["id"]]["collision"].items() if k != "digest"}
        for o in canonical_definition["objects"]
    ]
    physics = [
        {k: v for k, v in assets[o["asset"]["id"]]["physics"].items() if k != "digest"}
        for o in canonical_definition["objects"]
    ]
    predicates = {k: v for k, v in canonical_definition.items() if k not in {"objects", "resource_profile", "template"}}
    dimensions = {
        "robot": task["robot"],
        "environment": task["environment"],
        "control_mapping": task["robot"]["control_mapping"],
        "scene_entities": {
            "objects": entity_shapes,
            "platform_groups": canonical["platform_groups"],
            "contact_targets": canonical["contact_targets"],
            "camera": canonical["camera"],
        },
        "joints": canonical["joints"],
        "initial_states": canonical["initial_states"],
        "predicates": predicates,
        "asset_physics": physics,
        "asset_collision": collision,
        "frames": canonical["frames"],
        "dependencies": scene["dependencies"],
        "execution_contract": task["execution_contract"],
    }
    # 初态全部保留；召回几何使用每个初态的相对位置，不假设抖动模板。
    distances, orientations, heights = [], [], []
    relative_states = []
    for state in canonical["initial_states"]:
        positions = [s["pose"]["position_m"] for s in state["objects"]]
        anchor = [min(p[a] for p in positions) for a in range(3)] if positions else [0, 0, 0]
        relative = deepcopy(state)
        for entry in relative["objects"]:
            entry["pose"]["position_m"] = [round(x - anchor[a], 6) for a, x in enumerate(entry["pose"]["position_m"])]
            orientations.append(entry["pose"]["quaternion_xyzw"])
        relative_states.append(relative)
        heights.extend(sorted(round(p[2] - anchor[2], 6) for p in positions))
        distances.extend(sorted(round(math.dist(a, b), 6) for i, a in enumerate(positions) for b in positions[i + 1 :]))
    feature = {
        "schema_version": 1,
        "feature_schema": FEATURE_SCHEMA,
        "task_id": task["task_id"],
        "source": task["source"],
        "execution_profile": task["execution_profile"],
        "binding": {"execution_package_digest": execution_package_digest, "submission_digest": submission_digest},
        "object_count": len(objects),
        "assets": [canonical_digest(c) for c in collision],
        "predicates": sorted(_types(predicates)),
        "mechanism_digest": canonical_digest(predicates),
        "instruction_tokens": sorted(set(task["instruction"].lower().split())),
        "geometry": {
            "distances": distances,
            "heights": heights,
            "max_distance": max(distances, default=0),
            "orientations": orientations,
            "sizes": [],
        },
        "dimensions": dimensions,
    }
    feature["fingerprint"] = canonical_digest({
        "predicates": predicates,
        "entities": entity_shapes,
        "collision": collision,
        "physics": physics,
        "joints": canonical["joints"],
        "relative_states": relative_states,
    })
    return feature


def comparison(query, candidate):
    config = policy()
    if query.get("feature_schema") != FEATURE_SCHEMA or candidate.get("feature_schema") != FEATURE_SCHEMA:
        raise ValueError("scene_review_feature_schema_obsolete: re-extract the exact registered materials")
    result = compare(query, candidate, policy=NearDuplicatePolicy.from_mapping(config["base"]["thresholds"])).to_dict()
    same = [k for k in query["dimensions"] if query["dimensions"][k] == candidate["dimensions"].get(k)]
    different = [k for k in query["dimensions"] if k not in same]
    # 旧指纹不覆盖机器人、关节、物理身份等维度，不能抹去这些差异。
    if result["classification"] == "identical_fingerprint" and different:
        result["classification"] = "same_mechanism"
    return {
        "task_id": candidate["task_id"],
        "feature_digest": canonical_digest(candidate),
        "classification": result["classification"],
        "score": result["score"],
        "components": {**result["components"], "scene_equal": same},
        "matched": sorted(set(result["matched"] + same)),
        "differing": sorted(set(result["differing"] + different)),
        "warnings": sorted(
            set(
                result["warnings"]
                + ["declared_physics_only", "distinct_is_not_originality", "corpus_is_not_external_sources"]
            )
        ),
    }


def report(view, *, task_id, node_id, key_id, runtime, issued_at, candidates, sign):
    """view必须来自P03核验快照；签名由可信节点注入，不接受包内密钥。"""
    e = view.execution
    features = extract(
        e.task,
        execution_package_digest=e.manifest["execution_package_digest"],
        submission_digest=e.manifest["submission_digest"],
    )
    features["task_id"] = task_id
    comparisons = sorted(
        [comparison(features, c) for c in candidates if c["task_id"] != task_id],
        key=lambda c: (-c["score"], c["task_id"]),
    )[: policy()["base"]["thresholds"]["candidate_limit"]]
    raw = {
        "domain": "openroboto:scene-review:v1",
        "task_id": task_id,
        "node_id": node_id,
        "key_id": key_id,
        "algorithm": "ed25519",
        "issued_at": issued_at,
        **{k: e.manifest[k] for k in ("execution_package_digest", "private_package_digest", "submission_digest")},
        "execution_contract_digest": canonical_digest(e.contract),
        "identity": e.identity,
        "runtime": runtime,
        "policy_version": policy()["policy_version"],
        "policy_digest": canonical_digest(policy()),
        "features": features,
        "candidates": comparisons,
        "corpus_digest": canonical_digest([
            {"task_id": c["task_id"], "feature_digest": c["feature_digest"]} for c in comparisons
        ]),
    }
    return {**raw, "signature": sign(raw)}
