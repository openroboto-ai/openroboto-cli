"""Constructed declaration attacks for static review diagnostics, never admission evidence."""

import copy
import json
from openroboto_protocol.tabletop_assets import canonical_digest


def mutate(raw, mode):
    raw = copy.deepcopy(raw)
    if mode == "rename":
        # Replace all graph identifiers, preserving their references.
        body = raw["task_definition"]["objects"][0]
        old = body["id"]
        raw = json.loads(json.dumps(raw).replace('"' + old + '"', '"renamed_object"'))
    elif mode == "recolor":
        raw["public_summary"]["title"] = "A different title"
        raw["scene"]["dependencies"][0]["sha256"] = "c" * 64
    elif mode == "translate":
        for state in raw["scene"]["initial_states"]:
            for item in state["objects"]:
                item["pose"]["position_m"][0] += 0.2
    elif mode == "robot":
        raw["robot"]["artifact"]["digest"] = "d" * 64
    elif mode == "environment":
        raw["environment"]["digest"] = "e" * 64
    elif mode == "physics":
        raw["scene"]["assets"][0]["physics"]["mass_kg"] *= 1.2
    elif mode == "joint":
        raw["scene"]["joints"][0]["range"][1] *= 0.8
    elif mode == "predicate":
        raw["task_definition"]["stages"][0]["hold_ticks"] += 1
    elif mode == "mechanism":
        obj = raw["task_definition"]["stages"][0]["goal"]["object_id"]
        raw["task_definition"]["stages"][0]["goal"] = {"type": "pose", "object_id": obj, "quaternion": [0, 0, 0, 1]}
    elif mode == "quantity":
        obj = copy.deepcopy(next(o for o in raw["task_definition"]["objects"] if o["motion"] == "free"))
        previous = obj["id"]
        obj["id"] = "extra_object"
        obj["body"] = "extra_body"
        obj["body_frame"] = "extra_frame"
        obj["free_joint_name"] = "extra_free_joint"
        obj["collision_geoms"] = {k: "extra_" + v for k, v in obj["collision_geoms"].items()}
        raw["scene"]["frames"].append({
            "id": "extra_frame",
            "parent": "world",
            "pose_in_parent": {"position_m": [0, 0, 0], "quaternion_xyzw": [0, 0, 0, 1]},
        })
        raw["task_definition"]["objects"].append(obj)
        for state in raw["scene"]["initial_states"]:
            entry = copy.deepcopy(next(e for e in state["objects"] if e["object_id"] == previous))
            entry["object_id"] = "extra_object"
            entry["pose"]["position_m"][0] += 0.1
            state["objects"].append(entry)
    elif mode == "rotate":
        raw["scene"]["initial_states"][0]["objects"][0]["pose"]["quaternion_xyzw"] = [0, 0, 1, 0]
    elif mode == "size":
        raw["scene"]["assets"][0]["collision"]["parts"][0]["size"][0] *= 1.1
    elif mode == "later_initial_state":
        raw["scene"]["initial_states"][-1]["joints"][0]["position"] += 0.01
    for asset in raw["scene"]["assets"]:
        for field in ("visual", "collision", "physics", "symmetry", "provenance"):
            asset[field]["digest"] = canonical_digest({k: v for k, v in asset[field].items() if k != "digest"})
        asset["digest"] = canonical_digest({k: v for k, v in asset.items() if k != "digest"})
        for obj in raw["task_definition"]["objects"]:
            if obj["asset"]["id"] == asset["id"]:
                obj["asset"]["digest"] = asset["digest"]
    raw["checker"]["checker"]["definition"] = copy.deepcopy(raw["task_definition"])
    return raw
