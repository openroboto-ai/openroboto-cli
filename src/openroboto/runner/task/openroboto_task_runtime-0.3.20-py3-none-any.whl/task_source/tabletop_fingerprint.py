"""v2精确结构去重：保留资产/过程/阶段，忽略名字、种子与整体平移。"""

from copy import deepcopy

from openroboto_protocol.tabletop_assets import canonical_digest


def fingerprint(definition, profile):
    value = deepcopy(definition)
    anchor = min(tuple(obj["position"]) for obj in value["objects"])
    objects = sorted(value["objects"], key=lambda obj: (obj["asset_id"], obj["position"], obj["quaternion"]))
    zones = sorted(
        value["zones"], key=lambda zone: (zone["position"], zone["radius_m"], zone["capacity"], sorted(zone["accepts"]))
    )
    roles = {obj["id"]: f"object_{i}" for i, obj in enumerate(objects)}
    roles.update({zone["id"]: f"zone_{i}" for i, zone in enumerate(zones)})
    roles.update({stage["id"]: f"stage_{i}" for i, stage in enumerate(value["stages"])})

    def translate(node, key=None):
        if isinstance(node, dict):
            result = {k: translate(v, k) for k, v in node.items()}
            if "position" in node:
                result["position"] = [round(float(p) - anchor[i], 2) for i, p in enumerate(node["position"])]
            return result
        if isinstance(node, list):
            return [translate(v, key) for v in node]
        if isinstance(node, str) and key in {
            "id",
            "object_id",
            "object_ids",
            "zone_id",
            "zone_ids",
            "support_id",
            "other_id",
            "requires",
        }:
            return roles.get(node, node)
        return node

    value["objects"], value["zones"] = objects, zones
    value.pop("seed")
    value.pop("instance_count")
    return canonical_digest({"profile": profile, "composed_relations": translate(value)})
