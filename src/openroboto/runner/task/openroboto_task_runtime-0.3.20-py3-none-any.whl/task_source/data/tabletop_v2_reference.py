"""Physical 40 mm cube example; authors provide their own composed-task solver.

The worker replays recorded joint/tool actions and never executes this script.
This example does not prove arbitrary assets, stages or initial states solvable.
"""


def solve(runtime, task, instance):
    definition = task.metadata["package"].task["task_definition"]
    if (
        len(definition["objects"]) != 1
        or len(definition["zones"]) != 1
        or definition["objects"][0]["asset_id"] != "cube-40mm-v2"
    ):
        raise ValueError("the v2 example moves one 40 mm cube; supply an explicit local solve script for other tasks")
    name = definition["objects"][0]["id"]
    x, y, z = runtime.env.state()["positions"][name]
    gx, gy = definition["zones"][0]["position"]
    runtime.move_to(x, y, 1.08, gripper=1, steps=25)
    runtime.move_to(x, y, z, gripper=1, steps=25)
    runtime.grasp(steps=20)
    runtime.move_to(x, y, 1.04, gripper=0, steps=25)
    runtime.move_to(gx, gy, 1.04, gripper=0, steps=40)
    runtime.move_to(gx, gy, z, gripper=0, steps=25)
    runtime.release(steps=20)
    runtime.move_to(gx, gy, 1.08, gripper=1, steps=25)
