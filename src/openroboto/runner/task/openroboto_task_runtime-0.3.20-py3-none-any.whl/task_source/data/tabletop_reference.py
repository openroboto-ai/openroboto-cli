"""本地参考操作示例：真实 Panda 推动方块，不调用模型、不上传脚本。

它不是任意场景求解器。失败时 record-reference 不写成功参考解；作者需要
修改自己的操作，而不能绕过验题。正式执行者只回放最终保存的动作 JSON。
"""

import math


def solve(runtime, task, instance):
    definition = task.metadata["package"].task["task_definition"]
    if len(definition["objects"]) != 1:
        raise ValueError("this example solves one cube; supply your own multi-object reference script")
    goal = definition["goals"][0]
    name = goal["object_id"]
    gx, gy, _ = goal["target_position"]
    for _ in range(3):
        cx, cy, cz = runtime.env.state()["positions"][name]
        distance = math.hypot(gx - cx, gy - cy)
        if distance < 0.018:
            break
        ux, uy = (gx - cx) / distance, (gy - cy) / distance
        bx, by = cx - 0.065 * ux, cy - 0.065 * uy
        runtime.move_to(bx, by, 1.08, gripper=0, steps=25)
        # TCP is the fingertip, not the centre of the contact pad. Push lower
        # so the released pad still contacts the cube after vertical noise.
        runtime.move_to(bx, by, cz - 0.015, gripper=0, steps=20)
        runtime.grasp(steps=4)
        # 闭指接触后的释放会继续把方块推一小段；这只是此固定物品的示范控制。
        reach = min(0.29, max(0.015, distance - 0.055))
        runtime.move_to(cx + ux * reach, cy + uy * reach, cz - 0.015, gripper=0, steps=50)
        runtime.release(steps=30)
        tcp = runtime._runner.proprioception()["tcp"]
        runtime.move_to(tcp[0], tcp[1], 1.08, gripper=1, steps=25)
