"""P02 typed A-episode bridge to P03's one owned supervisor.

Preparation is a software binding gate, never an OS availability certificate.
The dedicated parent executes the already prepared request; no file reload or
new nonce precedes P03's first-line episode clock/resource baseline.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
import math
from pathlib import Path
import threading
import time
from typing import Any, Protocol

from agent_evidence.signing import Signer
from agent_harness.result import RunResult
from agent_harness.spec import HarnessSpec

from .scene_instruction_runtime import require as require_instruction
from .scene_observation import require_policy_scope
from .scene_views import ExecutionView, ReceiptTrust, SceneViewError
from .scene_views.episode import EpisodeBinding, EpisodeError, EpisodePolicy, validate_scene_episode
from .scene_views.episode_gateway import SceneAGatewayFactory
from .scene_views.identity import decode, encoded

_SEAL = object()


class SceneEpisodeCaller(Protocol):
    work: Mapping[str, Any]
    config: Any
    member: Any
    trial: int
    instance: int
    spec_path: Path
    result_path: Path
    evidence_path: Path
    host_config: Path
    lease_file: Path
    signer: Signer
    registration: Mapping[str, Any]
    # From independent authenticated parent/operator sources, never from E.
    frozen_task: Mapping[str, Any]
    receipt_bytes: bytes
    receipt_trust: ReceiptTrust
    episode_policy: Mapping[str, Any] | EpisodePolicy
    gateway_factory: SceneAGatewayFactory
    worker_id: str
    node_id: str
    cancellation: threading.Event
    subscription_ledger_directory: Path
    private_evidence_directory: Path
    prepared_scene_episode: SceneEpisodeRequest | None


def _require(condition, code="scene_episode_parent_context_unavailable"):
    if not condition:
        raise EpisodeError(code, status="resource_unavailable")


def _path(value):
    path = Path(value)
    _require(path.is_absolute() and ".." not in path.parts and not path.is_symlink())
    return path


def _overlap(a, b):
    return a == b or a.is_relative_to(b) or b.is_relative_to(a)


@dataclass(frozen=True)
class _Parent:
    frozen_task: dict = field(repr=False)
    receipt: dict = field(repr=False)
    receipt_bytes: bytes = field(repr=False)
    trust: ReceiptTrust = field(repr=False)
    policy: EpisodePolicy = field(repr=False)
    factory: SceneAGatewayFactory = field(repr=False)
    signer: Signer = field(repr=False)
    cancellation: threading.Event = field(repr=False)
    private_directory: Path = field(repr=False)
    result_path: Path
    spec_path: Path
    evidence_path: Path
    worker_id: str
    node_id: str
    registration: dict = field(repr=False)
    valid_until: float


def _operator_expiry(value):
    if type(value) is str:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        _require(parsed.tzinfo is not None)
        value = parsed.timestamp()
    _require(type(value) in (int, float) and math.isfinite(value) and time.time() < value)
    return float(value)


def require_parent_context(context: SceneEpisodeCaller) -> _Parent:
    """No kernel/gateway probe, keyfile read, model call or directory creation."""
    try:
        registration = decode(encoded(dict(context.registration)))
        valid_until = _operator_expiry(registration["valid_until"])
        value = context.episode_policy
        policy = (
            value
            if type(value) is EpisodePolicy
            else EpisodePolicy.from_registered_config(decode(encoded(dict(value))))
        )
        receipt_bytes = context.receipt_bytes
        _require(type(receipt_bytes) is bytes, "scene_episode_authenticated_receipt_missing")
        receipt = decode(receipt_bytes)
        _require(type(receipt) is dict, "scene_episode_authenticated_receipt_missing")
        if hasattr(context, "receipt"):
            _require(encoded(context.receipt) == encoded(receipt), "scene_episode_receipt_snapshot_mismatch")
        trust, factory, signer = context.receipt_trust, context.gateway_factory, context.signer
        _require(type(trust) is ReceiptTrust and type(factory) is SceneAGatewayFactory and type(signer) is Signer)
        _require(type(context.cancellation) is threading.Event)
        _require(
            policy.config_digest == context.config.digest == context.work["config_digest"]
            and dict(policy.runtime) == registration["runtime"] == trust.document["runtime"]
            and policy.policy_version == registration["policy_version"] == trust.document["policy_version"]
            and context.node_id == registration["node_id"]
            and signer.key_id == registration["key_id"]
            and signer.public_key_hex == registration["public_key_hex"]
            and registration.get("retired", False) is False
            and type(context.worker_id) is str
            and bool(context.worker_id)
            and type(context.node_id) is str
            and bool(context.node_id)
        )
        spec_path, result, evidence = map(_path, (context.spec_path, context.result_path, context.evidence_path))
        private = _path(context.private_evidence_directory)
        original_ledger = _path(context.subscription_ledger_directory)
        # This is the existing A panel_episode convention. Never allocate a
        # fresh ledger to make quota available for the scene lane.
        _require(original_ledger == result.parent.parent / "subscription")
        _require(
            _path(factory.lease_file) == _path(context.lease_file)
            and _path(factory.ledger_directory) == original_ledger
            and factory.config_digest == policy.config_digest
        )
        _require(
            not any(_overlap(private, p) for p in (spec_path, result, evidence, Path(policy.rootfs)))
            and not private.exists()
            and not result.exists(),
            "scene_episode_output_unavailable",
        )
        if context.cancellation.is_set():
            raise EpisodeError("scene_episode_lease_cancelled", status="timeout")
        return _Parent(
            decode(encoded(dict(context.frozen_task))),
            receipt,
            receipt_bytes,
            trust,
            policy,
            factory,
            Signer("executor", signer.key_id, signer.seed),
            context.cancellation,
            private,
            result,
            spec_path,
            evidence,
            context.worker_id,
            context.node_id,
            registration,
            valid_until,
        )
    except EpisodeError:
        raise
    except Exception as exc:
        raise EpisodeError("scene_episode_parent_context_unavailable") from exc


@dataclass(frozen=True)
class SceneEpisodeRequest:
    """Opaque, single-use parent token. P03 repeats full validation in its scope.

    Private parsed documents stay in the trusted parent, never model messages.
    P08 must construct this from the SAVED spec before its started marker,
    including when an old spec already exists. It is not persisted as JSON.
    """

    caller_view: ExecutionView = field(repr=False)
    binding: EpisodeBinding = field(repr=False)
    spec_bytes: bytes = field(repr=False)
    spec: HarnessSpec = field(repr=False)
    parent: _Parent = field(repr=False)
    episode: dict = field(repr=False)
    _seal: object = field(repr=False, compare=False)
    _use_lock: Any = field(default_factory=threading.Lock, repr=False, compare=False)
    _used: list = field(default_factory=list, repr=False, compare=False)


def _prepare(view, context, spec_bytes, parent):
    from .panel_worker import validate_episode_spec, validate_host
    from .scene_adapter import same_environment
    from .scene_runtime import registry_refs

    _require(type(view) is ExecutionView, "scene_episode_execution_view_required")
    _require(
        same_environment(view.identity["environment"], registry_refs()["environment"])
        and any(
            same_environment(environment, view.identity["environment"])
            for environment in parent.registration["environments"]
        )
        and view.identity["execution_profile"] == parent.registration["execution_profile"],
        "scene_episode_environment_unavailable",
    )
    require_policy_scope(view.task)
    require_instruction(view.task)
    raw = decode(spec_bytes)
    host = decode(_path(context.host_config).read_bytes())
    validate_host(host, context.config)
    _require(encoded(host) == parent.factory.host_bytes, "scene_episode_host_pin_mismatch")
    provider = host["providers"][context.member.provider]
    spec = validate_episode_spec(
        raw,
        context.work,
        context.config,
        context.member,
        context.trial,
        list(range(view.identity["instances"])),
        parent.evidence_path,
        provider,
    )
    _require(
        context.work["task"].get("submission_digest") == view.manifest["submission_digest"]
        and type(context.instance) is int
        and context.instance == spec.instance,
        "scene_episode_work_pin_mismatch",
    )
    episode = {
        "run_id": context.work["run_id"],
        "attempt_id": spec.attempt_id,
        "member_id": context.member.id,
        "worker_id": parent.worker_id,
        "node_id": parent.node_id,
        "trial": context.trial,
        "instance": context.instance,
    }
    binding = validate_scene_episode(
        view,
        frozen_task=parent.frozen_task,
        receipt=parent.receipt,
        receipt_bytes=parent.receipt_bytes,
        trust=parent.trust,
        episode=episode,
        policy=parent.policy,
        spec=spec,
        gateway_factory=parent.factory,
    )
    _require(
        binding.document["competition_id"] in parent.registration["competition_ids"]
        and parent.valid_until >= binding.document["lease_expires_at"],
        "scene_episode_registration_scope_unavailable",
    )
    return SceneEpisodeRequest(view, binding, spec_bytes, spec, parent, episode, _SEAL)


def validate_candidate_spec(view, *, context, raw_spec, parent):
    """Used by prepare BEFORE P08 saves a spec; does not authorize execution."""
    try:
        _prepare(view, context, encoded(raw_spec), parent)
    except EpisodeError:
        raise
    except SceneViewError as exc:
        raise EpisodeError(exc.code, status=exc.status) from exc
    except Exception as exc:
        raise EpisodeError("scene_episode_parent_context_unavailable") from exc


def prepare_delegate_request(view: ExecutionView, *, context: SceneEpisodeCaller) -> SceneEpisodeRequest:
    """Read the single frozen spec once; no re-prepare, new nonce or OS launch."""
    parent = require_parent_context(context)
    try:
        _require(parent.spec_path.is_file(), "scene_episode_frozen_spec_unavailable")
        return _prepare(view, context, parent.spec_path.read_bytes(), parent)
    except EpisodeError:
        raise
    except SceneViewError as exc:
        raise EpisodeError(exc.code, status=exc.status) from exc
    except Exception as exc:
        raise EpisodeError("scene_episode_parent_context_unavailable") from exc


def delegate_scene_episode(request: SceneEpisodeRequest) -> RunResult:
    """The dedicated parent calls P03 directly; no fallback or file parsing.

    Source integration is not deployment approval. P03 checks the actual
    exclusive Linux parent scope before native/gateway startup and may refuse.
    """
    from .scene_views.episode import run_scene_episode

    _require(type(request) is SceneEpisodeRequest and request._seal is _SEAL, "scene_episode_preflight_required")
    with request._use_lock:
        _require(not request._used, "scene_episode_request_already_used")
        request._used.append(True)
    p = request.parent
    return run_scene_episode(
        request.binding.view,
        frozen_task=p.frozen_task,
        receipt=p.receipt,
        receipt_bytes=p.receipt_bytes,
        trust=p.trust,
        episode=request.episode,
        policy=p.policy,
        spec=request.spec,
        gateway_factory=p.factory,
        evidence_directory=p.private_directory,
        signer=p.signer,
        cancellation=p.cancellation,
    )


def execute_scene_episode(view: ExecutionView, *, context: SceneEpisodeCaller) -> RunResult:
    """P08 compatible raw result/events/root; preflight token is mandatory.

    Parent result persistence is the existing controller stage after P03's
    owned episode returns. No cached result, fabricated score or re-signing.
    """
    started = time.monotonic()
    request = getattr(context, "prepared_scene_episode", None)
    _require(type(request) is SceneEpisodeRequest and request.caller_view is view, "scene_episode_preflight_required")
    _require(
        Path(context.result_path) == request.parent.result_path
        and Path(context.spec_path) == request.parent.spec_path
        and Path(context.evidence_path) == request.parent.evidence_path,
        "scene_episode_preflight_context_mismatch",
    )
    result = delegate_scene_episode(request)
    _require(type(result) is RunResult, "scene_episode_result_unavailable")
    _require(
        (result.run_id, result.attempt_id, result.task_id, result.instance, result.evidence_path)
        == (
            request.spec.run_id,
            request.spec.attempt_id,
            request.spec.task_id,
            request.spec.instance,
            request.spec.evidence_path,
        ),
        "scene_episode_result_binding_mismatch",
    )
    _require(
        result.extra.get("scene_episode", {}).get("binding") == request.binding.document
        and result.extra.get("signing", {}).get("signed") is True,
        "scene_episode_result_binding_mismatch",
    )
    if request.parent.cancellation.is_set():
        raise EpisodeError("scene_episode_lease_cancelled", status="timeout")
    if time.time() >= request.parent.valid_until:
        raise EpisodeError("scene_episode_registration_expired", status="timeout")
    from .panel_state import read, write
    from .scene_views.episode_authority import wire_epoch

    try:
        lease = read(Path(request.parent.factory.lease_file))
        if lease.get("allowed") is not True or wire_epoch(lease["expires_at"]) <= time.time():
            raise EpisodeError("scene_episode_lease_cancelled", status="timeout")
    except EpisodeError as exc:
        if exc.code == "scene_episode_lease_cancelled":
            raise
        raise EpisodeError("scene_episode_lease_unavailable") from exc
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise EpisodeError("scene_episode_lease_unavailable") from exc
    row = result.to_dict()
    row["wall_s"] = time.monotonic() - started
    host = decode(request.parent.factory.host_bytes)
    if host["mode"] == "subscription":
        cleanups = [e for e in result.events if e.get("type") == "scene_episode_cleanup"]
        _require(len(cleanups) == 1, "scene_episode_subscription_route_unavailable")
        route = cleanups[0]["payload"].get("a_gateway", {}).get("subscription_route")
        called = any(event.get("type") == "model_call" for event in result.events)
        confirmed = isinstance(route, dict) and bool(route)
        # P03 deliberately avoids route/quota I/O after a fatal cancellation.
        # Return that original signed error, including its terminal evidence;
        # its existing panel error excludes it from valid evaluation. A normal
        # completion still needs both an actual response event and its route.
        _require(
            result.status == "error" or (called and confirmed),
            "scene_episode_subscription_route_unavailable",
        )
        if called and confirmed:
            row["subscription_route"] = route
    try:
        write(request.parent.result_path, row, exclusive=True)
    except (OSError, ValueError, TypeError) as exc:
        raise EpisodeError("scene_episode_result_output_unavailable") from exc
    return result
