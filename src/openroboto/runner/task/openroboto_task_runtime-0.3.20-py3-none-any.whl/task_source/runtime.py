"""出题赛事的运行期准入（OPE-99）。

结构检查在 :mod:`task_source.admission`（哈希、词表、参考解覆盖、checker 层
可解/不白送）。这里做**需要仿真**的四项，加上两项不需要仿真的业务检查：

===============  ============================================================
检查             做法
===============  ============================================================
solvable         每个实例回放参考解动作轨迹，Checker 必须通过
deterministic    同一实例回放两遍：布尔判定一致；状态 digest 逐位一致，
                 跨机时按 profile 预登记的容差比较
noise            按类别预登记的幅度扰动轨迹（位置 ±1.5 cm、朝向 ±8°、
                 快慢 0.75–1.35×），每个实例仍必须成功
nop              全程不动，所有实例都必须失败（0 成功）
visibility       开局目标 body 在主相机里可见（像素数 + 遮挡）
instruction      指令与判定语义一致（OPE-112，LLM）
dedup            指纹与题库比对（OPE-111）
===============  ============================================================

**失败分类是这里唯一的分类点**（后端 `domain/task_pool.classify_verdict`
只认前缀）：

- ``infra_*``：我们这边没跑完（进程 / 仿真崩溃 / 超时 / 运行时缺失 / LLM
  不可用）→ 后端回队列重试，**不判矿工不合格**。
- ``reject_*``：题的问题（哈希漂移、白送、不可解、不确定、刀刃题、重复、
  指令不符、不可见）→ 业务拒绝。

引擎里不出现题源名字：回放走 ``TaskSource.replay()``，可见性走
``ReplayResult.visibility``。
"""

from __future__ import annotations

import json
import math
import pathlib
import time
from concurrent.futures import Future, ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeoutError
from dataclasses import dataclass, field, replace
from typing import Any, Callable, Mapping, Sequence

from .admission import admit_loaded
from .base import (
    AdmissionCheck,
    AdmitResult,
    Checker,
    MissingReferenceTrajectory,
    RuntimeUnavailable,
    TaskSourceError,
    TaskSpec,
)
from .fingerprint import DedupIndex, fingerprint
from .instruction import (
    DEFAULT_PROVIDER_TIMEOUT_S,
    InstructionCheck,
    check_instruction,
)
from .package import TASK_FILE, load_package, read_json
from .registry import VALIDATOR_ROOT, get_source, load_config

PROFILE_CONFIG_PATH = VALIDATOR_ROOT / "configs" / "admission_profiles.json"
if not PROFILE_CONFIG_PATH.is_file():
    # The standalone wheel has no repository-level configs directory. Select
    # its release policy once; a subsequently missing selected file is fatal.
    PROFILE_CONFIG_PATH = pathlib.Path(__file__).resolve().parent / "data" / "admission_profiles.json"

#: LLM 比对在 provider 自身超时之外再等这么久；超过就按「不出结论」走重试。
#: 它只约束指令检查自己的墙钟，不占用 ``runtime.timeout_s`` 的回放预算。
INSTRUCTION_TIMEOUT_GRACE_S = 5.0
#: 指令一致性证据必须完整回传（OPE-112 要求可复查），不做 500 字截断。
INSTRUCTION_DETAIL_LIMIT: int | None = None

#: 预登记的确定性容差（跨机回放的兜底；同一 worker 上要求 digest 逐位一致）。
DEFAULT_DETERMINISM = {
    "position_tolerance": 1e-3,
    "angle_tolerance": 1e-3,
}


class AdmissionTimeout(Exception):
    """整个题包的准入超过预算。属于基础设施失败（``infra_crash``）。"""


@dataclass(frozen=True)
class Verdict:
    """一次准入的最终结论。``code`` 为空 = 通过。"""

    source: str
    task_id: str
    accepted: bool
    code: str | None
    reason: str | None
    checks: tuple[AdmissionCheck, ...] = ()
    runtime_status: str = "not_run"
    skill: str | None = None
    #: 八项检查的输入摘要（OPE-118）。只在跑完的路径上有值；失败路径由
    #: manifest 构建器用题包摘要兜底。
    manifest_inputs: Mapping[str, str] = field(default_factory=dict)
    execution_profile: Mapping[str, Any] | None = None
    public_summary: Mapping[str, Any] | None = None

    @property
    def passed(self) -> bool:
        return self.accepted

    def verdict(self) -> dict[str, Any]:
        """``POST /task/admit`` 的 ``verdict`` 字段（后端契约）。"""
        result = {
            "passed": self.accepted,
            "code": self.code,
            "reason": self.reason,
            "skill": self.skill,
            "checks": [
                {
                    "name": check.name,
                    "ok": check.passed,
                    "detail": _detail_text(check.name, check.detail),
                }
                for check in self.checks
            ],
        }
        if self.execution_profile is not None:
            result["execution_profile"] = dict(self.execution_profile)
        if self.public_summary is not None:
            result["public_summary"] = dict(self.public_summary)
        return result

    def to_dict(self) -> dict[str, Any]:
        result = {
            "source": self.source,
            "task_id": self.task_id,
            "accepted": self.accepted,
            "code": self.code,
            "reason": self.reason,
            "runtime_status": self.runtime_status,
            "checks": [
                {"name": check.name, "passed": check.passed, "kind": check.kind, "detail": dict(check.detail)}
                for check in self.checks
            ],
        }
        if self.execution_profile is not None:
            result["execution_profile"] = dict(self.execution_profile)
        if self.public_summary is not None:
            result["public_summary"] = dict(self.public_summary)
        return result


def _detail_text(name: str, detail: Mapping[str, Any]) -> str:
    """回传给后端的 ``checks[].detail``。

    普通检查截到 500 字，避免把整份运行期明细塞进 verdict；指令一致性检查是
    OPE-112 的审计证据（模型版本 / prompt 版本 / 原始输出），完整保留。
    """
    if name == "runtime.solvable" and "tool_reference_proof" in detail:
        return _short_detail(detail, limit=None)
    if name == "instruction_consistency":
        return _short_detail(detail, limit=INSTRUCTION_DETAIL_LIMIT)
    if name == "dedup" and detail.get("feature_schema") == "scene-nd-v2":
        # Registered scene evidence is signed by the parent; do not truncate its
        # canonical comparisons into unparsable JSON. Legacy dedup stays as-is.
        return _short_detail(detail, limit=None)
    return _short_detail(detail)


def _short_detail(detail: Mapping[str, Any], *, limit: int | None = 500) -> str:
    text = json.dumps(detail, ensure_ascii=False, sort_keys=True, default=str)
    if limit is None or len(text) <= limit:
        return text
    return text[: limit - 3] + "..."


def load_profiles(path: str | pathlib.Path | None = None) -> dict[str, Any]:
    path = pathlib.Path(path or PROFILE_CONFIG_PATH).expanduser()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise TaskSourceError(f"admission profile config not found: {path}") from exc
    except ValueError as exc:
        raise TaskSourceError(f"admission profile config is not valid JSON: {path}: {exc}") from exc
    if data.get("schema_version") != 1 or not isinstance(data.get("profiles"), Mapping):
        raise TaskSourceError(f"{path}: unsupported admission profile config")
    return data


def get_profile(name: str, path: str | pathlib.Path | None = None) -> dict[str, Any]:
    profiles = load_profiles(path)["profiles"]
    profile = profiles.get(name)
    if not isinstance(profile, Mapping):
        raise TaskSourceError(f"unknown admission profile {name!r}; configured: {sorted(profiles)}")
    return dict(profile)


def _check(name: str, passed: bool, detail: Mapping[str, Any] | None = None) -> AdmissionCheck:
    return AdmissionCheck(name, passed, dict(detail or {}), kind="runtime")


# ---------------------------------------------------------------------------
# 状态比较
# ---------------------------------------------------------------------------


def _numeric_leaves(value: Any, prefix: str = "") -> dict[str, float]:
    found: dict[str, float] = {}
    if isinstance(value, Mapping):
        for key in sorted(value, key=str):
            found.update(_numeric_leaves(value[key], f"{prefix}.{key}" if prefix else str(key)))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            found.update(_numeric_leaves(item, f"{prefix}[{index}]"))
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        found[prefix] = float(value)
    return found


def compare_states(
    left: Mapping[str, Any],
    right: Mapping[str, Any],
    *,
    tolerance: float,
) -> tuple[bool, float, str | None]:
    """逐数值比较两个状态，返回 ``(在容差内, 最大偏差, 偏差最大的键)``。

    布尔值、字符串这类非数值叶子必须完全相等；数值叶子按 ``tolerance``。
    """
    left_flat = _numeric_leaves(left)
    right_flat = _numeric_leaves(right)
    if set(left_flat) != set(right_flat):
        missing = sorted(set(left_flat) ^ set(right_flat))[:3]
        return False, float("inf"), f"state shape differs at {missing}"
    # NaN / Infinity 不能当「未超差」放过；物理状态非有限即 fail-closed。
    # 必须分别检查左右两边：直接合并字典会让右侧覆盖左侧的同名 NaN。
    non_finite = sorted(
        key for key in left_flat if not math.isfinite(left_flat[key]) or not math.isfinite(right_flat[key])
    )
    if non_finite:
        return False, float("inf"), f"non-finite state value at {non_finite[0]}"
    worst = 0.0
    worst_key = None
    for key, value in left_flat.items():
        deviation = abs(value - right_flat[key])
        if deviation > worst:
            worst, worst_key = deviation, key
    # 布尔 / 字符串叶子（如 RoboDojo 的 success）逐项相等。
    for key, value in _non_numeric_leaves(left).items():
        if _non_numeric_leaves(right).get(key) != value:
            return False, max(worst, float("inf")), key
    return worst <= tolerance, worst, worst_key


def _non_numeric_leaves(value: Any, prefix: str = "") -> dict[str, Any]:
    found: dict[str, Any] = {}
    if isinstance(value, Mapping):
        for key in sorted(value, key=str):
            found.update(_non_numeric_leaves(value[key], f"{prefix}.{key}" if prefix else str(key)))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            found.update(_non_numeric_leaves(item, f"{prefix}[{index}]"))
    elif isinstance(value, bool) or isinstance(value, str):
        found[prefix] = value
    return found


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------


def run_admission(
    directory: str | pathlib.Path,
    *,
    profile: Mapping[str, Any] | str = "axis-cpu",
    config: Mapping[str, Any] | None = None,
    source: Any | None = None,
    chat_fn: Callable[..., dict[str, Any]] | None = None,
    dedup_index: DedupIndex | None = None,
    submitted_at: str | None = None,
    commit_block: int | None = None,
    submission_id: str | None = None,
) -> Verdict:
    """对一个题包跑完整准入（结构 + 八项里的业务/运行期检查）。

    调用方没有传 ``source`` 时由引擎自己解析；这种一次性 source（例如 RoboDojo
    的 runner 持有官方 server 子进程）必须在返回前关掉，否则连续准入会累积
    策略服务进程。
    """
    resolved_holder: list[Any] = []
    task_holder: list[TaskSpec] = []
    try:
        result = _run_admission(
            directory,
            profile=profile,
            config=config,
            source=source,
            chat_fn=chat_fn,
            dedup_index=dedup_index,
            submitted_at=submitted_at,
            commit_block=commit_block,
            submission_id=submission_id,
            _resolved_holder=resolved_holder,
            _task_holder=task_holder,
        )
        if task_holder:
            task = task_holder[0]
            if task.metadata.get("execution_profile"):
                result = replace(
                    result,
                    execution_profile=task.metadata["execution_profile"],
                    public_summary=task.metadata.get("public_summary"),
                )
        return result
    finally:
        if source is None and resolved_holder:
            close = getattr(resolved_holder[0], "close", None)
            if callable(close):
                close()


def _run_admission(
    directory: str | pathlib.Path,
    *,
    profile: Mapping[str, Any] | str = "axis-cpu",
    config: Mapping[str, Any] | None = None,
    source: Any | None = None,
    chat_fn: Callable[..., dict[str, Any]] | None = None,
    dedup_index: DedupIndex | None = None,
    submitted_at: str | None = None,
    commit_block: int | None = None,
    submission_id: str | None = None,
    _resolved_holder: list[Any] | None = None,
    _task_holder: list[TaskSpec] | None = None,
) -> Verdict:
    """``run_admission`` 的实现；``_resolved_holder`` 只用于关闭一次性 source。"""
    if isinstance(profile, str):
        profile = get_profile(profile)
    directory = pathlib.Path(directory).expanduser().resolve()
    runtime = dict(profile.get("runtime") or {})
    timeout_s = float(runtime.get("timeout_s") or 180.0)
    deadline = time.monotonic() + timeout_s

    # 题包只读一次：结构准入、去重、指令检查、运行期检查共用同一个
    # ``TaskPackage`` / ``TaskSpec``。去重（OPE-111）不再触发第二次加载。
    try:
        raw_task = read_json(directory / TASK_FILE)
        is_scene = isinstance(raw_task, Mapping) and raw_task.get("schema_version") == 3
        if is_scene:
            # A scene needs its verified private view and a registered semantic
            # and dedup policy; it cannot inherit v1's goal-template shortcut.
            check = _check(
                "scene.admission_policy",
                False,
                {
                    "code": "scene_admission_policy_unregistered",
                    "local_entry": "task_source.runtime.run_scene_physics_checks",
                },
            )
            return Verdict(
                str(raw_task.get("source", "axis")),
                str(raw_task.get("task_id", directory.name)),
                False,
                "infra_scene_policy",
                "scene server admission policy is not registered on this entry",
                (check,),
                "unavailable",
            )
        package = load_package(directory)
        expected_profile = profile.get("expected_execution_profile")
        if expected_profile is not None:
            from .profile_dispatch import validate_package as validate_tabletop

            validate_tabletop(package, expected_execution_profile=expected_profile)
    except TaskSourceError as exc:
        task_json: Mapping[str, Any] = {}
        try:
            candidate = read_json(directory / TASK_FILE)
            if isinstance(candidate, Mapping):
                task_json = candidate
        except TaskSourceError:
            pass
        check = _check("package", False, {"error": str(exc)})
        return Verdict(
            str(task_json.get("source") or "unknown"),
            str(task_json.get("task_id") or directory.name),
            False,
            "reject_drift",
            f"package cannot be loaded for admission: {exc}",
            (check,),
            "not_run",
        )

    try:
        config_data = dict(config) if config is not None else load_config()
        resolved = source or get_source(package.source, config_data, root=directory)
        if _resolved_holder is not None and source is None:
            _resolved_holder.append(resolved)
        task = resolved.load_task(package.task_id)
        # 供外层把同一次加载且已验证的公开摘要加入签名前 verdict。
        if _task_holder is not None:
            _task_holder.append(task)
        # 每次准入都是新的一次 attempt：题源不能复用上一次缓存的物理结果。
        begin_admission = getattr(resolved, "begin_admission", None)
        if callable(begin_admission):
            begin_admission()
    except TaskSourceError as exc:
        check = _check("task_load", False, {"error": str(exc)})
        return Verdict(
            package.source,
            package.task_id,
            False,
            "reject_drift",
            f"package cannot be loaded for admission: {exc}",
            (check,),
            "not_run",
        )

    structural = admit_loaded(package, source=resolved, task=task)
    checks: list[AdmissionCheck] = list(structural.checks)
    if not structural.accepted:
        code, reason = _classify_structural(structural)
        return Verdict(
            structural.source,
            structural.task_id,
            False,
            code,
            reason,
            tuple(checks),
            structural.runtime_status,
        )

    try:
        checker = resolved.checker(task)
    except TaskSourceError as exc:
        checks.append(_check("checker_registered", False, {"error": str(exc)}))
        return Verdict(
            structural.source,
            structural.task_id,
            False,
            "reject_drift",
            f"checker cannot be constructed: {exc}",
            tuple(checks),
            structural.runtime_status,
        )

    # 1) 去重（OPE-111）：指纹不匹配只代表「不是已知重复」，不是自动通过。
    try:
        index = dedup_index or _index_from_profile(profile)
        if task.metadata.get("execution_profile"):
            if index is None or index.path is None or not index.path.is_file():
                raise ValueError("new-profile admission requires an explicitly initialized persistent dedup index")
            # Do not trust an in-memory object whose on-disk authority disappeared.
            index = DedupIndex(index.path, strict=True)
    except (ValueError, OSError) as exc:
        checks.append(_check("dedup", False, {"error": str(exc)}))
        return Verdict(package.source, package.task_id, False, "infra_dedup", str(exc), tuple(checks), "unavailable")
    if index is not None:
        dedup_check = _dedup_check(task, package, index, submitted_at, commit_block, submission_id)
        checks.append(dedup_check)
        if not dedup_check.passed:
            return Verdict(
                structural.source,
                structural.task_id,
                False,
                "reject_duplicate",
                _dedup_reason(dedup_check),
                tuple(checks),
                structural.runtime_status,
            )

    # 2) 指令与判定一致（OPE-112）。LLM 在独立线程里跑：它的墙钟上限与
    #    ``runtime.timeout_s`` 分开，既不挤占回放预算，也不让回放拖长 LLM 调用。
    instruction = _instruction_from_profile(profile)
    if task.metadata.get("execution_profile"):
        # 新方案的指令和判据来自同一受限目标模板，load_task 已逐字段重建验证。
        # 不再把任意自由题面交给模型猜语义，也不产生额外模型调用。
        instruction = None
        checks.append(_check("instruction_consistency", True, {"rule": "frozen_goal_template"}))
    instruction_future: Future | None = None
    instruction_executor: ThreadPoolExecutor | None = None
    if instruction is not None:
        instruction_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="instruction-check")
        instruction_future = instruction_executor.submit(_run_instruction, task, instruction, chat_fn)

    # 3) 运行期四项。失败先记下来，等指令检查结算后再决定回报哪种结论：
    #    指令不符是题目本身的问题（reject），优先于运行期的 infra 重试。
    runtime_checks: list[AdmissionCheck] | None = None
    runtime_failure: tuple[str, str, AdmissionCheck, str] | None = None
    try:
        try:
            runtime_checks = _run_runtime_checks(task, resolved, checker, runtime, deadline)
        except MissingReferenceTrajectory as exc:
            runtime_failure = (
                "reject_unsolvable",
                str(exc),
                _check("runtime.solvable", False, {"error": str(exc)}),
                structural.runtime_status,
            )
        except RuntimeUnavailable as exc:
            runtime_failure = (
                "infra_download",
                f"runtime unavailable: {exc}",
                _check("runtime", False, {"error": str(exc)}),
                "unavailable",
            )
        except AdmissionTimeout as exc:
            runtime_failure = (
                "infra_crash",
                f"admission exceeded the {timeout_s:.0f}s budget: {exc}",
                _check("runtime.timeout", False, {"error": str(exc), "budget_s": timeout_s}),
                structural.runtime_status,
            )
        except TaskSourceError as exc:
            runtime_failure = (
                "reject_drift",
                f"task cannot be replayed: {exc}",
                _check("runtime", False, {"error": str(exc)}),
                structural.runtime_status,
            )
        except Exception as exc:  # noqa: BLE001 —— 仿真崩溃是基础设施问题
            runtime_failure = (
                "infra_crash",
                f"simulator crashed: {type(exc).__name__}: {exc}",
                _check("runtime", False, {"error": f"{type(exc).__name__}: {exc}"}),
                structural.runtime_status,
            )

        settled = _settle_instruction(
            instruction_future,
            instruction,
            checks,
            source=structural.source,
            task_id=structural.task_id,
            runtime_status=structural.runtime_status,
        )
    finally:
        if instruction_executor is not None:
            instruction_executor.shutdown(wait=False)

    if settled is not None:
        return settled
    if runtime_failure is not None:
        code, reason, check, status = runtime_failure
        checks.append(check)
        return Verdict(
            structural.source,
            structural.task_id,
            False,
            code,
            reason,
            tuple(checks),
            status,
        )

    checks.extend(runtime_checks or [])
    code, reason = _classify_checks(checks)
    accepted = code is None
    from .manifest import manifest_inputs

    return Verdict(
        structural.source,
        structural.task_id,
        accepted,
        code,
        reason,
        tuple(checks),
        structural.runtime_status,
        _skill_of(task),
        manifest_inputs(
            task,
            profile=profile,
            package=package,
            submitted_at=submitted_at,
            commit_block=commit_block,
            submission_id=submission_id,
        ),
    )


def _index_from_profile(profile: Mapping[str, Any]) -> DedupIndex | None:
    dedup = profile.get("dedup")
    if not isinstance(dedup, Mapping):
        return None
    index_path = dedup.get("index")
    if not index_path:
        return None
    candidate = pathlib.Path(str(index_path)).expanduser()
    if not candidate.is_absolute():
        candidate = VALIDATOR_ROOT / candidate
    return DedupIndex(candidate)


def _instruction_from_profile(profile: Mapping[str, Any]) -> Mapping[str, Any] | None:
    instruction = profile.get("instruction")
    if not isinstance(instruction, Mapping):
        return None
    if instruction.get("mode", "llm") == "disabled":
        return None
    return instruction


def _run_instruction(
    task: TaskSpec,
    instruction: Mapping[str, Any],
    chat_fn: Callable[..., dict[str, Any]] | None,
) -> tuple[AdmissionCheck, str | None]:
    try:
        result: InstructionCheck = check_instruction(task, instruction, chat_fn=chat_fn)
    except Exception as exc:  # noqa: BLE001 —— provider 不可用不是题的错
        return _check("instruction_consistency", False, {"error": f"{type(exc).__name__}: {exc}"}), str(exc)
    detail = result.to_dict()
    check = AdmissionCheck("instruction_consistency", result.consistent, detail, kind="runtime")
    if result.available is False:
        return check, result.reason or "provider unavailable"
    return check, None


def _instruction_wait_s(instruction: Mapping[str, Any] | None) -> float:
    """等 LLM 结果的墙钟上限：provider 自己的 timeout + 少量余量。"""
    timeout = DEFAULT_PROVIDER_TIMEOUT_S
    model = instruction.get("model") if isinstance(instruction, Mapping) else None
    if isinstance(model, Mapping):
        try:
            timeout = float(model.get("timeout_s") or DEFAULT_PROVIDER_TIMEOUT_S)
        except (TypeError, ValueError):
            timeout = DEFAULT_PROVIDER_TIMEOUT_S
    return max(1.0, timeout + INSTRUCTION_TIMEOUT_GRACE_S)


def _settle_instruction(
    future: Future | None,
    instruction: Mapping[str, Any] | None,
    checks: list[AdmissionCheck],
    *,
    source: str,
    task_id: str,
    runtime_status: str,
) -> Verdict | None:
    """等 LLM 结论并把它变成准入结论。

    返回 ``None`` 表示「检查通过，继续走其余检查」；返回 ``Verdict`` 表示
    已经可以收尾。LLM 不可用一律是 ``infra_download``（后端重试），**不是**
    拒绝；只有 ``consistent=False`` 且过了规则阈值才返回
    ``reject_instruction_mismatch``。
    """
    if future is None:
        return None

    wait_s = _instruction_wait_s(instruction)
    try:
        instruction_check, unavailable = future.result(timeout=wait_s)
    except FutureTimeoutError:
        reason = f"instruction check exceeded its {wait_s:.0f}s wall-clock budget"
        instruction_check = _check(
            "instruction_consistency",
            False,
            {"available": False, "reason": reason, "timeout_s": wait_s},
        )
        unavailable = reason
    except Exception as exc:  # noqa: BLE001 —— 线程本身出错也不能当成矿工的问题
        reason = f"{type(exc).__name__}: {exc}"
        instruction_check = _check(
            "instruction_consistency",
            False,
            {"available": False, "reason": reason},
        )
        unavailable = reason

    checks.append(instruction_check)
    if unavailable is not None:
        return Verdict(
            source,
            task_id,
            False,
            "infra_download",
            f"instruction check unavailable: {unavailable}",
            tuple(checks),
            runtime_status,
        )
    if not instruction_check.passed:
        reason = instruction_check.detail.get("reason") or "mismatch"
        return Verdict(
            source,
            task_id,
            False,
            "reject_instruction_mismatch",
            f"instruction does not match the checker: {reason}",
            tuple(checks),
            runtime_status,
        )
    return None


def _dedup_check(
    task: TaskSpec,
    package: Any,
    index: DedupIndex,
    submitted_at: str | None,
    commit_block: int | None,
    submission_id: str | None,
) -> AdmissionCheck:
    task_fingerprint = fingerprint(task, package=package)
    # 后端队列的 task_id 与题包 task.json 的 task_id 不是同一个值：账本记的是
    # 前者（`task_<hotkey>_r<n>_v<m>`），同一提交的重跑必须按它排除自己。
    identity = submission_id or task.task_id
    match = index.find(
        task_fingerprint,
        submitted_at=submitted_at,
        commit_block=commit_block,
        task_id=identity,
    )
    return AdmissionCheck(
        "dedup",
        match is None,
        {
            "fingerprint": task_fingerprint,
            "submission_id": identity,
            "matched_task_id": None if match is None else match.task_id,
            "matched_submitted_at": None if match is None else match.submitted_at,
            "matched_commit_block": None if match is None else match.commit_block,
            "submitted_at": submitted_at,
            "commit_block": commit_block,
        },
        kind="runtime",
    )


def _dedup_reason(check: AdmissionCheck) -> str:
    matched = check.detail.get("matched_task_id")
    if not matched:
        return "duplicate task"
    block = check.detail.get("commit_block")
    matched_block = check.detail.get("matched_commit_block")
    if block is not None and matched_block is not None:
        return f"duplicate of task {matched}, which was committed earlier (block {matched_block} < {block})"
    return f"duplicate of task {matched}, which was submitted earlier"


def _skill_of(task: TaskSpec) -> str | None:
    skill = task.metadata.get("skill")
    return skill if isinstance(skill, str) and skill.strip() else None


def _run_runtime_checks(
    task: TaskSpec,
    source: Any,
    checker: Checker,
    runtime: Mapping[str, Any],
    deadline: float,
) -> list[AdmissionCheck]:
    noise_profile = _noise_for(task, runtime.get("noise") or {})
    trials = max(1, int(noise_profile.get("trials") or 1))
    determinism = dict(DEFAULT_DETERMINISM)
    determinism.update(runtime.get("determinism") or {})
    tolerance = float(determinism.get("position_tolerance", 1e-3))
    visibility_enabled = runtime.get("visibility", True) is not False
    visibility_options = dict(runtime.get("visibility") or {}) if visibility_enabled else {}
    scene = "imported_scene" in task.metadata
    if scene:
        visibility_options["width"], visibility_options["height"] = task.metadata["imported_scene"].bindings["camera"][
            "image_size"
        ]
    scene_observation_policy = runtime.get("scene_observation_policy") if scene else None
    state_accessibility = False
    if scene_observation_policy is not None:
        from .scene_observation import policy_document, policy_identity, scene_state_policy, require_policy_scope

        if scene_observation_policy != {**policy_identity(), "configuration": policy_document()}:
            raise RuntimeUnavailable("scene observation admission policy identity differs")
        require_policy_scope(task)
        state_accessibility = scene_state_policy(task)
    visibility_targets = [str(name) for name in source.target_bodies(task)] if visibility_enabled else []

    solvable_failures: list[dict[str, Any]] = []
    determinism_failures: list[dict[str, Any]] = []
    noise_failures: list[dict[str, Any]] = []
    nop_successes: list[dict[str, Any]] = []
    visibility_failures: list[dict[str, Any]] = []
    observation_failures: list[dict[str, Any]] = []
    observation_evidence: list[dict[str, Any]] = []
    native_visibility: list[dict[str, Any]] = []
    visibility_observed = False
    visibility_min_pixels: float | None = None
    visibility_min_ratio: float | None = None
    visibility_min_fraction: float | None = None
    bitwise = True
    run_nop = bool(runtime.get("nop", True))

    for item in task.instances:
        if time.monotonic() > deadline:
            raise AdmissionTimeout(f"stopped before instance {item.instance}")
        initial = item.initial_state
        seed = int(item.seed if item.seed is not None else item.instance)

        first = source.replay(
            task,
            item.instance,
            mode="oracle",
            seed=seed,
            visibility_options=visibility_options,
        )
        second = source.replay(task, item.instance, mode="oracle", seed=seed)
        first_verdict = checker.evaluate({"current": first.final_state, "initial": first.initial_state or initial})
        second_verdict = checker.evaluate({"current": second.final_state, "initial": second.initial_state or initial})
        if not first_verdict.passed:
            solvable_failures.append({"instance": item.instance, "detail": dict(first_verdict.detail)})
        elif scene:
            from .base import state_digest

            recorded = (task.reference_for(item.instance) or {}).get("final_state")
            if recorded is None or state_digest(recorded) != first.state_digest:
                solvable_failures.append({"instance": item.instance, "reason": "raw_recording_mismatch"})

        same_digest = first.state_digest == second.state_digest
        within_tolerance, worst, worst_key = compare_states(first.final_state, second.final_state, tolerance=tolerance)
        state_verified = bool(getattr(first, "state_verified", True)) and bool(getattr(second, "state_verified", True))
        if not same_digest:
            bitwise = False
        if not state_verified:
            # 只有 success/score 这类判定结果、没有真实物理状态时，两次
            # 「成绩相同」不能证明物理可复现；必须 fail-closed。
            bitwise = False
            determinism_failures.append({
                "instance": item.instance,
                "state_verified": False,
                "reason": "runner did not provide verifiable physical state; "
                "success/score equality cannot establish deterministic replay",
                "state_sources": [
                    getattr(first, "state_source", None),
                    getattr(second, "state_source", None),
                ],
                "digest_equal": same_digest,
                "boolean_equal": first_verdict.passed == second_verdict.passed,
            })
        elif first_verdict.passed != second_verdict.passed or not within_tolerance:
            determinism_failures.append({
                "instance": item.instance,
                "state_verified": True,
                "digest_equal": same_digest,
                "max_deviation": worst,
                "worst_key": worst_key,
                "boolean_equal": first_verdict.passed == second_verdict.passed,
            })

        for trial in range(trials):
            perturbation_seed = (seed * 1009 + trial + 1) & 0x7FFFFFFF
            replay = source.replay(
                task,
                item.instance,
                mode="noise",
                seed=perturbation_seed,
                noise=noise_profile,
            )
            verdict = checker.evaluate({"current": replay.final_state, "initial": replay.initial_state or initial})
            if not verdict.passed:
                noise_failures.append({"instance": item.instance, "trial": trial, "detail": dict(verdict.detail)})

        if run_nop:
            nop = source.replay(task, item.instance, mode="nop", seed=seed)
            nop_verdict = checker.evaluate({"current": nop.final_state, "initial": nop.initial_state or initial})
            if nop_verdict.passed:
                nop_successes.append({"instance": item.instance, "detail": dict(nop_verdict.detail)})

        if first.visibility is not None:
            visibility_observed = True
            if scene_observation_policy is not None:
                native_visibility.append({"instance": item.instance, "entities": dict(first.visibility)})
            reported = set(first.visibility)
            for name in visibility_targets:
                if name not in reported:
                    visibility_failures.append({
                        "instance": item.instance,
                        "body": name,
                        "visible": False,
                        "reason": "no visibility result from the source runtime",
                    })
            for name, info in first.visibility.items():
                if "pixels" in info:
                    value = float(info["pixels"])
                    visibility_min_pixels = (
                        value if visibility_min_pixels is None else min(visibility_min_pixels, value)
                    )
                if "pixel_ratio" in info:
                    value = float(info["pixel_ratio"])
                    visibility_min_ratio = value if visibility_min_ratio is None else min(visibility_min_ratio, value)
                if "visible_fraction" in info:
                    value = float(info["visible_fraction"])
                    visibility_min_fraction = (
                        value if visibility_min_fraction is None else min(visibility_min_fraction, value)
                    )
                if not info.get("visible"):
                    visibility_failures.append({"instance": item.instance, "body": name, **dict(info)})
        if scene_observation_policy is not None:
            observation = first.detail.get("scene_observation")
            if not isinstance(observation, Mapping) or observation.get("passed") is not True:
                observation_failures.append({"instance": item.instance, "observation": observation})
            if isinstance(observation, Mapping):
                observation_evidence.append({"instance": item.instance, **dict(observation)})

    total = len(task.instances)
    from .tool_reference import verify_tool_reference

    solvable_detail = {"passed": total - len(solvable_failures), "total": total, "failures": solvable_failures}
    if "tool_reference" in runtime:
        solvable_detail["tool_reference_proof"] = verify_tool_reference(
            task, source, runtime["tool_reference"], deadline=deadline
        )
    checks = [
        _check(
            "runtime.solvable",
            not solvable_failures,
            solvable_detail,
        ),
        _check(
            "runtime.deterministic",
            not determinism_failures,
            {
                "bitwise_reproducible": bitwise,
                "tolerance": tolerance,
                "failures": determinism_failures,
            },
        ),
        _check(
            "runtime.noise",
            not noise_failures,
            {
                "passed": total * trials - len(noise_failures),
                "total": total * trials,
                "trials": trials,
                "profile": noise_profile,
                "failures": noise_failures,
            },
        ),
    ]
    if run_nop:
        checks.append(
            _check(
                "runtime.nop",
                not nop_successes,
                {"successes": len(nop_successes), "total": total, "failures": nop_successes},
            )
        )
    if visibility_enabled:
        # 题源声明了目标 body 却拿不到可见性结果 = 这一项没验，不能冒充通过。
        visibility_ok = not visibility_failures and (visibility_observed or not visibility_targets)
        effective_failures = visibility_failures
        scene_detail = {}
        if scene_observation_policy is not None:
            if state_accessibility:
                # The state sensor is the declared source of object knowledge.
                # Keep the original image findings verbatim; a missing native
                # segmentation result is still an unavailable camera check.
                missing = [
                    {"instance": item.instance, "reason": "native_visibility_coverage"}
                    for item in task.instances
                    if not any(
                        row["instance"] == item.instance and set(row["entities"]) == set(visibility_targets)
                        for row in native_visibility
                    )
                ]
                effective_failures = [*missing, *observation_failures]
            else:
                effective_failures = [*visibility_failures, *observation_failures]
            visibility_ok = not effective_failures
            scene_detail = {
                "policy": scene_observation_policy,
                "mode": "state_accessibility" if state_accessibility else "image_visibility",
                "image_visibility_passed": not visibility_failures and visibility_observed,
                "image_failures": visibility_failures,
                "native_visibility": native_visibility,
                "observations": observation_evidence,
            }
        checks.append(
            _check(
                "runtime.visibility",
                visibility_ok,
                {
                    "observed": visibility_observed,
                    "targets": visibility_targets,
                    "frame_margin": float(visibility_options.get("frame_margin", 0.45)),
                    "min_pixels": float(visibility_options.get("min_pixels", 1.5)),
                    "min_pixel_ratio": float(visibility_options.get("min_pixel_ratio", 0.00018)),
                    "min_visible_fraction": float(visibility_options.get("min_visible_fraction", 0.6)),
                    "min_observed_pixels": visibility_min_pixels,
                    "min_observed_pixel_ratio": visibility_min_ratio,
                    "min_observed_visible_fraction": visibility_min_fraction,
                    "failures": effective_failures,
                    **scene_detail,
                },
            )
        )
    return checks


def run_scene_physics_checks(task, source, *, deadline, config_digest, policy=None):
    """Schema3 native checks through the existing authoritative replay pipeline.

    Operator-only local/admission building block, not a complete admission or a
    signed receipt. The caller first verifies E/P and loads the typed private
    reference; semantic/dedup policies and server provenance remain separate.
    No instruction provider or business model is called by this function.
    """
    if "imported_scene" not in task.metadata or task.reference is None:
        raise TaskSourceError("scene checks require a verified native scene and private reference")
    from .scene_authoring import source_deadline

    from .scene_observation import runtime_policy as scene_runtime_policy
    from .scene_instruction_runtime import require_task
    from openroboto_protocol.tabletop_assets import canonical_digest

    instruction_binding = require_task(task)
    runtime_policy = scene_runtime_policy(
        policy if policy is not None else get_profile("axis-cpu")["runtime"], task=task
    )
    bound_config_digest = canonical_digest({
        "caller_config_digest": config_digest,
        "runtime_policy": runtime_policy,
        "environment": task.metadata["environment"],
        "instruction_binding": instruction_binding,
    })
    runtime_policy["tool_reference"] = {
        "execution_contract": task.metadata["execution_contract"],
        "config_digest": bound_config_digest,
    }
    try:
        with source_deadline(source, deadline):
            checks = _run_runtime_checks(task, source, source.checker(task), runtime_policy, deadline)
            proof = next(c.detail["tool_reference_proof"] for c in checks if c.name == "runtime.solvable")
            if proof.get("resource_error") is not None:
                from .scene_env import SceneDeadlineExceeded

                error = SceneDeadlineExceeded("scene independent tool proof exceeded its actual wall deadline")
                error.partial_checks = tuple(checks)
                raise error
            return checks
    except AdmissionTimeout as exc:
        from .scene_env import SceneDeadlineExceeded

        raise SceneDeadlineExceeded(str(exc)) from exc


def _noise_for(task: TaskSpec, noise: Mapping[str, Any]) -> dict[str, Any]:
    """按 checker 类别取预登记幅度；没有类别条目时用默认值。"""
    base = {key: value for key, value in noise.items() if key != "by_category"}
    by_category = noise.get("by_category") or {}
    root_type = _root_checker_type(task.checker_config)
    override = by_category.get(root_type) if isinstance(by_category, Mapping) else None
    if isinstance(override, Mapping):
        base.update(override)
    if root_type == "TabletopProgramChecker":
        # New Panda programs use the same registered physical Cartesian transform.
        base["action_transform"] = "panda_tcp_fk_ik_v1"
    base["category"] = root_type
    return base


def _root_checker_type(config: Mapping[str, Any]) -> str:
    node: Any = config
    while isinstance(node, Mapping) and isinstance(node.get("checker"), Mapping):
        node = node["checker"]
    if isinstance(node, Mapping) and isinstance(node.get("type"), str):
        return str(node["type"])
    return "unknown"


def _classify_structural(result: AdmitResult) -> tuple[str, str]:
    failed = [check for check in result.checks if not check.passed]
    names = [check.name for check in failed]
    details = "; ".join(f"{check.name}: {_short_detail(check.detail)}" for check in failed[:3])
    if "solvable" in names:
        return "reject_unsolvable", f"reference solution does not satisfy the checker: {details}"
    if "not_freebie" in names:
        return "reject_freebie", f"the goal is already satisfied at the initial state: {details}"
    if "deterministic" in names:
        return "reject_nondeterministic", f"checker verdict is not deterministic: {details}"
    return "reject_drift", f"package does not match its frozen definition: {details}"


def _classify_checks(checks: Sequence[AdmissionCheck]) -> tuple[str | None, str | None]:
    by_name = {check.name: check for check in checks}
    if not by_name.get("runtime.solvable", AdmissionCheck("", True)).passed:
        failures = by_name["runtime.solvable"].detail.get("failures") or []
        instances = [str(item.get("instance")) for item in failures][:20]
        return "reject_unsolvable", f"reference replay failed on instances: {', '.join(instances)}"
    if not by_name.get("runtime.deterministic", AdmissionCheck("", True)).passed:
        return "reject_nondeterministic", "two replays of the same instance disagree (verdict or physics state)"
    if not by_name.get("runtime.noise", AdmissionCheck("", True)).passed:
        return "reject_brittle", "the reference solution fails when replayed with the pre-registered noise"
    if "runtime.nop" in by_name and not by_name["runtime.nop"].passed:
        successes = by_name["runtime.nop"].detail.get("successes")
        return "reject_freebie", f"the goal is satisfied without doing anything ({successes} instances)"
    if "runtime.visibility" in by_name and not by_name["runtime.visibility"].passed:
        failures = by_name["runtime.visibility"].detail.get("failures") or []
        bodies = sorted({str(item.get("body")) for item in failures})
        return "reject_invisible", f"target object not visible from the main camera: {', '.join(bodies)}"
    return None, None


__all__ = [
    "AdmissionTimeout",
    "PROFILE_CONFIG_PATH",
    "Verdict",
    "compare_states",
    "get_profile",
    "load_profiles",
    "run_admission",
]
