"""判定词表的人类可读语义。

给指令一致性检查（OPE-112）的 prompt 用；也是运维理解「这道题判什么」的
唯一一份说明。新增 checker 类型时同时改这里和注册表。
"""

from __future__ import annotations

CHECKER_SEMANTICS = {
    "TabletopZoneChecker": (
        "For the fixed Panda tabletop profile only: every corner of each supported rigid cube "
        "projects inside its marked target circle, the cube is at table height and at rest, "
        "both fingers are open, and all conditions hold for the profile's continuous control steps. "
        "This is placement inside a marked zone, not containment inside a physical vessel."
    ),
    "CompositeChecker": (
        "Combines child checkers with operator AND / OR / NOT. AND requires every child; "
        "OR requires at least one; NOT requires the single child to fail."
    ),
    "RelativeCylinderChecker": (
        "The object named objName must be inside a vertical cylinder centred on refName: "
        "horizontal distance < xyRadius and heightMin < dz < heightMax. Used for 'put X into Y' "
        "or 'put X on Y'."
    ),
    "RelativePositionBoundsChecker": (
        "The object named objName must be positioned relative to refName within the given "
        "x/y/z ranges. Used for 'put X next to / to the left of Y'."
    ),
    "DirectedRotationChecker": (
        "The body named bodyName must be rotated, relative to its initial orientation, by "
        "targetAngleDeg around the local upright axis, within angleToleranceDeg, and tilted no "
        "more than maxTiltDeg. Used for 'rotate X by N degrees'."
    ),
    "GripperOpenChecker": (
        "At least one finger/gripper joint must be open by at least threshold. Used for 'open the gripper'."
    ),
    "DrawerBBoxChecker": (
        "The cabinet drawer joint named jointName must have displaced, and objName must be "
        "inside the drawer bounding box (halfSize) relative to the displaced cabinet frame. "
        "Used for 'open the drawer and put X inside'."
    ),
    "FrameBBoxChecker": (
        "The object named objName must be inside the local bounding box [lower, upper] of the "
        "frame object named frameName. Used for 'put X inside the frame'."
    ),
    "SamplePositionDeltaChecker": (
        "The body named sampleBodyName must have moved relative to its initial position by at "
        "least minDeltaX/Z and/or at most maxDeltaX/Z. Used for 'lift X by N centimetres' or "
        "'move X by N centimetres'."
    ),
    "RoboDojoOfficialChecker": (
        "The official RoboDojo task success criterion: the official client's _result.json "
        "success boolean for the named official task. The official task definition is the "
        "authority; the instruction is the official task instruction."
    ),
}

__all__ = ["CHECKER_SEMANTICS"]
