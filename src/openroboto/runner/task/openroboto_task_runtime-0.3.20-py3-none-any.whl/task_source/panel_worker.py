"""Persistent A worker: claim -> gated package -> signed episodes -> progress -> report.

    python -m task_source.panel_worker --backend-url https://api-dev.openroboto.ai \
      --competition 13 --worker-id cpu-a --node-id registered-node \
      --signing-key /secure/validator.json --model-config /etc/openroboto/models.json \
      --state-root /var/lib/openroboto/a

VALIDATOR_API_KEY authenticates backend traffic; HF_READ_TOKEN is the official
HF account used only for reads. Prefer a read-only token; wider permissions are
reported, never silently represented as read-only. Credentials never enter
checkpoints or child task tools.
"""

from __future__ import annotations
import argparse
import copy
import hashlib
import logging
import math
import os
import pathlib
import re
import secrets
import subprocess
import sys
import threading
import time
import urllib.parse
from datetime import datetime, UTC
from task_source.panel_client import PanelClient, PanelAPIError
from task_source.panel_state import complete_reported_work, read, write, single_owner
from task_source.scene_dispatch import is_scene_task

LOG = logging.getLogger("task_source.panel_worker")
HEX64 = re.compile(r"^[0-9a-f]{64}$")
HEX40 = re.compile(r"^[0-9a-f]{40}$")


class WorkRejected(ValueError):
    pass


def validate_work(work: dict):
    from benchmark_worker.reference_panel.config import parse_config, canonical_sha256
    from agent_harness import agent_binding

    if not isinstance(work, dict) or not isinstance(work.get("task"), dict):
        raise WorkRejected("CLAIM_SHAPE_INVALID")
    task = work["task"]
    try:
        config = parse_config(work["config"])
    except ValueError:
        if is_scene_task(task):
            raise WorkRejected("SCENE_CONFIG_OR_RUNTIME_UNAVAILABLE") from None
        raise
    if type(work.get("trials_per_member")) is not int or work["trials_per_member"] < 1:
        raise WorkRejected("CLAIM_TRIALS_INVALID")
    if "trials_per_member" in work["config"] and work["trials_per_member"] != work["config"]["trials_per_member"]:
        raise WorkRejected("CLAIM_TRIAL_COUNT_MISMATCH")
    if work["config_digest"] != config.digest or work["config_version"] != config.version:
        raise WorkRejected("CLAIM_CONFIG_MISMATCH")
    expected_registry = canonical_sha256({**config.canonical_form(), "trials_per_member": work["trials_per_member"]})
    if work.get("registry_digest") != expected_registry:
        raise WorkRejected("CLAIM_REGISTRY_MISMATCH")
    if not config.execution_contract or config.execution_contract["agent"] != agent_binding():
        raise WorkRejected("HARNESS_BINDING_MISMATCH")
    if any(not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", m.id) for m in config.settlement.members):
        raise WorkRejected("UNSAFE_MEMBER_ID")
    if any(m.kind != "agent" or m.harness != "headless" for m in config.settlement.members):
        raise WorkRejected("UNSUPPORTED_PANEL_MEMBER")
    if not HEX64.fullmatch(str(task.get("package_digest", ""))) or not HEX40.fullmatch(
        str(task.get("package_commit", ""))
    ):
        raise WorkRejected("PACKAGE_BINDING_INVALID")
    access_fields = ("task_id", "source", "package_repo") + (() if is_scene_task(task) else ("hf_grant_to",))
    if not all(isinstance(task.get(k), str) and task[k] for k in access_fields):
        raise WorkRejected("PACKAGE_ACCESS_POLICY_MISSING")
    if not all(isinstance(work.get(k), str) and work[k] for k in ("run_id", "lease_token", "lease_expires_at")):
        raise WorkRejected("LEASE_BINDING_MISSING")
    return config


def model_key_env(name):
    if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise WorkRejected("MODEL_SECRET_SCOPE_INVALID")
    upper = name.upper()
    if any(
        part in upper
        for part in (
            "ADMIN",
            "OPERATOR",
            "RECOVERY",
            "VALIDATOR",
            "HF_",
            "HUGGINGFACE",
            "HUGGING_FACE",
            "LEASE",
            "SIGNING",
            "PRIVATE_KEY",
        )
    ):
        raise WorkRejected("MODEL_SECRET_SCOPE_INVALID")
    return name


def validate_host(host: dict, config):
    if host.get("mode") not in ("api", "subscription"):
        raise WorkRejected("MODEL_MODE_MISSING")
    options = host.get("providers")
    calibration = host.get("budget_calibration", {"reserve_fraction": 0.25})
    if (
        not isinstance(calibration, dict)
        or set(calibration) != {"reserve_fraction"}
        or type(calibration["reserve_fraction"]) not in (int, float)
        or not math.isfinite(calibration["reserve_fraction"])
        or calibration["reserve_fraction"] <= 0
    ):
        raise WorkRejected("BUDGET_CALIBRATION_POLICY_INVALID")
    if not isinstance(options, dict):
        raise WorkRejected("MODEL_PROVIDER_CONFIG_MISSING")
    for member in config.settlement.members:
        provider = options.get(member.provider)
        if not isinstance(provider, dict) or not provider.get("endpoint"):
            raise WorkRejected("MODEL_PROVIDER_CONFIG_MISSING")
        if set(provider) - {
            "endpoint",
            "api_format",
            "api_key_env",
            "max_tokens",
            "max_tokens_param",
            "timeout_s",
            "stream",
            "anthropic_version",
        }:
            raise WorkRejected("UNREGISTERED_MODEL_OVERRIDE")
        if provider.get("api_key_env"):
            model_key_env(provider["api_key_env"])
        endpoint = urllib.parse.urlsplit(provider["endpoint"])
        if (
            endpoint.scheme not in ("http", "https")
            or not endpoint.hostname
            or endpoint.username
            or endpoint.password
            or endpoint.query
            or endpoint.fragment
        ):
            raise WorkRejected("MODEL_ENDPOINT_INVALID")
    if host["mode"] == "subscription":
        s = host.get("subscription", {})
        if type(s.get("max_calls_per_member")) is not int or s["max_calls_per_member"] < 1:
            raise WorkRejected("SUBSCRIPTION_CAP_REQUIRED")
        budget = config.execution_contract["budget"]["max_api_calls"]
        if s.get("max_calls_per_episode") != budget or s["max_calls_per_member"] < budget:
            raise WorkRejected("SUBSCRIPTION_CAP_MISMATCH")
        if (
            not isinstance(s.get("min_remaining"), (int, float))
            or isinstance(s.get("min_remaining"), bool)
            or not 0 <= s["min_remaining"] <= 100
        ):
            raise WorkRejected("SUBSCRIPTION_FLOOR_REQUIRED")


def read_only_hf_identity(identity: dict, account: str) -> bool:
    if identity.get("name") != account:
        return False
    access = (identity.get("auth") or {}).get("accessToken", {})
    if access.get("role") == "read":
        return True
    if access.get("role") != "fineGrained":
        return False
    fine = access.get("fineGrained")
    if not isinstance(fine, dict):
        return False
    allowed = {"repo.content.read", "repo.info.read", "repo.discussions.read", "repo.gated-repos.read"}
    permissions = fine.get("global", [])
    scoped = fine.get("scoped", [])
    if not isinstance(permissions, list) or not isinstance(scoped, list):
        return False
    permissions = list(permissions)
    for item in scoped:
        if not isinstance(item, dict) or not isinstance(item.get("permissions"), list):
            return False
        permissions.extend(item["permissions"])
    if any(not isinstance(p, str) or p not in allowed for p in permissions):
        return False
    return fine.get("canReadGatedRepos") is True or bool(
        set(permissions) & {"repo.content.read", "repo.gated-repos.read"}
    )


def download_official_package(task: dict, cache: pathlib.Path, token: str):
    if not token:
        raise WorkRejected("OFFICIAL_HF_READ_TOKEN_REQUIRED")
    from huggingface_hub import HfApi

    api = HfApi(token=token)
    identity = api.whoami()
    if identity.get("name") != task["hf_grant_to"]:
        raise WorkRejected("OFFICIAL_HF_ACCOUNT_MISMATCH")
    if not read_only_hf_identity(identity, task["hf_grant_to"]):
        LOG.warning("HF token has permissions beyond verified read-only; worker uses it only for downloads")
    info = api.repo_info(task["package_repo"], revision=task["package_commit"], repo_type="model")
    if info.private or info.gated != "manual":
        raise WorkRejected("TASK_REPOSITORY_NOT_MANUAL_GATED")
    from task_source.frozen import resolve_frozen_package

    package = resolve_frozen_package(
        source=task["source"],
        task_id=task["task_id"],
        version_digest=task["package_digest"],
        package_repo=task["package_repo"],
        package_commit=task["package_commit"],
        cache_root=cache,
        token=token,
        allow_local=False,
    )
    from task_source.registry import get_source

    task_spec = get_source(task["source"], root=package.directory).load_task(package.task_id)
    return package, task_spec


def validate_episode_spec(raw, work, config, member, trial, instances, evidence_path, provider, *, historical=False):
    from agent_harness import parse_spec, agent_binding
    from task_source.execution_contract import execution_contract_digest

    task = work["task"]
    contract = config.execution_contract
    if historical:
        from task_source.scene_views.identity import encoded

        frozen_contract_digest = hashlib.sha256(encoded(contract)).hexdigest()
    else:
        frozen_contract_digest = execution_contract_digest(contract)
    expected_task = {
        "source": task["source"],
        "task_id": task["task_id"],
        "instance": instances[trial % len(instances)],
        "version_digest": task["package_digest"],
        "package_repo": task["package_repo"],
        "package_commit": task["package_commit"],
        "execution_profile": task["execution_profile"],
    }
    for k, v in expected_task.items():
        if raw.get("task", {}).get(k) != v:
            raise WorkRejected("EPISODE_TASK_BINDING_MISMATCH")
    if "package_root" in raw["task"]:
        raise WorkRejected("EPISODE_LOCAL_PACKAGE_FORBIDDEN")
    expected_panel = {
        "run_id": work["run_id"],
        "panel": config.settlement_panel,
        "member": member.id,
        "kind": member.kind,
        "trial": trial,
        "package_digest": task["package_digest"],
        "version_digest": task["package_digest"],
        "config_version": config.version,
        "config_digest": config.digest,
        "settlement": True,
        "execution_contract": contract,
        "execution_contract_digest": frozen_contract_digest,
    }
    if raw.get("panel_binding") != expected_panel:
        raise WorkRejected("EPISODE_PANEL_BINDING_MISMATCH")
    if (
        raw.get("budget") != contract["budget"]
        or raw.get("permissions") != contract["permissions"]
        or raw.get("timing") != contract["timing"]
        or raw.get("agent") != (contract["agent"] if historical else agent_binding())
    ):
        raise WorkRejected("EPISODE_CONTRACT_MISMATCH")
    if raw.get("model") != {**member.model_config(), **provider}:
        raise WorkRejected("EPISODE_MODEL_MISMATCH")
    if (
        raw.get("run_id") != work["run_id"]
        or raw.get("attempt_id") != f"{work['run_id']}:{member.id}:{trial}"
        or raw.get("episode") != trial
        or raw.get("binding", {}).get("job_id") != work["run_id"]
    ):
        raise WorkRejected("EPISODE_RUN_BINDING_MISMATCH")
    if raw.get("evidence", {}).get("path") != str(evidence_path):
        raise WorkRejected("EPISODE_EVIDENCE_PATH_MISMATCH")
    if historical:
        if not HEX64.fullmatch(str(raw.get("evidence", {}).get("job_digest", ""))):
            raise WorkRejected("EPISODE_SPEC_DIGEST_MISMATCH")
        return None  # Read-only original verification, never a launchable spec.
    spec = parse_spec(raw)
    if raw["evidence"].get("job_digest") != spec.job_digest:
        raise WorkRejected("EPISODE_SPEC_DIGEST_MISMATCH")
    return spec


class LeaseKeeper:
    def __init__(
        self,
        client,
        work,
        file,
        interval,
        *,
        detail=None,
        stage="downloading",
        allow_models=True,
        progress_observer=None,
    ):
        self.client, self.work, self.file, self.interval = client, work, file, interval
        self.allow_models = allow_models
        self.progress_observer = progress_observer
        self.stage = stage
        self.detail = detail or {
            "completed_trials": 0,
            "total_trials": work["trials_per_member"]
            * len(work["config"]["panels"][work["config"]["settlement_panel"]]["members"]),
        }
        self.failed = False
        self.lock = threading.Lock()
        self.io_lock = threading.Lock()
        self.stop = threading.Event()

    def update(self, stage, detail):
        with self.lock:
            self.stage, self.detail = stage, dict(detail)
        self.beat()

    def beat(self):
        # Serialize heartbeats and latch failures: a later successful response must
        # never re-open model access after an earlier lease uncertainty.
        with self.io_lock:
            if self.failed:
                raise WorkRejected("LEASE_HEARTBEAT_FAILED")
            with self.lock:
                stage, detail = self.stage, dict(self.detail)
            try:
                response = self.client.progress(self.work, stage, detail)
                if self.progress_observer is not None:
                    self.progress_observer(stage, detail)
                expiry = response.get("lease_expires_at", self.work["lease_expires_at"])
                write(self.file, {"allowed": self.allow_models, "expires_at": expiry})
            except Exception:
                self.failed = True
                write(self.file, {"allowed": False, "expires_at": self.work["lease_expires_at"]})
                raise

    def _run(self):
        while not self.stop.wait(self.interval):
            try:
                self.beat()
            except Exception:
                LOG.error("A progress heartbeat failed; no further model calls permitted")
                return

    def __enter__(self):
        self.beat()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.stop.set()
        self.thread.join(timeout=self.interval + 5)


class PanelWorker:
    def __init__(
        self,
        client,
        *,
        state_root,
        signing_key,
        model_config,
        hf_read_token,
        heartbeat_s=30,
        episode_launcher=None,
        scene_adapter=None,
        task_kind="legacy",
        scene_adapter_loader=None,
        scene_report_registration=None,
        scene_episode_launcher=None,
    ):
        self.client = client
        self.root = pathlib.Path(state_root)
        self.signing_key = pathlib.Path(signing_key)
        self.model_config = pathlib.Path(model_config)
        self.hf_read_token = hf_read_token
        self.heartbeat_s = heartbeat_s
        self.launcher = episode_launcher or self._launch
        self.scene = scene_adapter
        self.scene_adapter_loader = scene_adapter_loader
        self.scene_report_registration = scene_report_registration
        self.scene_episode_launcher = scene_episode_launcher
        self.scene_recovery_reader = None
        if task_kind == "scene":
            from task_source.scene_episode_launcher import RegisteredSceneLauncher
            from task_source.scene_recovery_bootstrap import RegisteredRecoveryReader

            if type(scene_episode_launcher) is RegisteredSceneLauncher:
                self.scene_recovery_reader = RegisteredRecoveryReader(scene_episode_launcher, self)
        self.task_kind = task_kind
        if self.scene is not None and (
            self.scene.transport._base != client.base_url.rstrip("/")
            or self.scene.transport._identity.node_id != client.node_id
        ):
            raise WorkRejected("SCENE_TRANSPORT_SCOPE_MISMATCH")
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.root.chmod(0o700)

    def _launch(self, spec_path, host_config, lease_file, result_path, wall_seconds):
        config = read(host_config)
        allowed = {
            "PATH",
            "HOME",
            "LANG",
            "LC_ALL",
            "TMPDIR",
            "SSL_CERT_FILE",
            "SSL_CERT_DIR",
            "REQUESTS_CA_BUNDLE",
            "HTTP_PROXY",
            "HTTPS_PROXY",
            "NO_PROXY",
            "MUJOCO_GL",
            "TASK_SOURCE_CONFIG",
        }
        for provider in config["providers"].values():
            if provider.get("api_key_env"):
                allowed.add(model_key_env(provider["api_key_env"]))
        env = {k: v for k, v in os.environ.items() if k in allowed}
        env.update(
            TASK_PACKAGE_CACHE=str(self.root / "packages"),
            HF_HUB_OFFLINE="1",
            HF_HUB_DISABLE_IMPLICIT_TOKEN="1",
            PYTHONDONTWRITEBYTECODE="1",
        )
        cmd = [
            sys.executable,
            "-m",
            "task_source.panel_episode",
            "--spec",
            str(spec_path),
            "--host-config",
            str(host_config),
            "--signing-key",
            str(self.signing_key),
            "--lease-file",
            str(lease_file),
            "--result",
            str(result_path),
        ]
        with spec_path.with_suffix(".log").open("ab") as log:
            child = subprocess.Popen(
                cmd, cwd=pathlib.Path(__file__).resolve().parents[1], env=env, stdout=log, stderr=subprocess.STDOUT
            )
            try:
                code = child.wait(timeout=wall_seconds + 90)
            except subprocess.TimeoutExpired:
                child.terminate()
                child.wait(timeout=15)
                raise WorkRejected("EPISODE_PROCESS_TIMEOUT") from None
        if code != 0:
            stop = result_path.parent.parent / "stops" / (result_path.stem + ".json")
            if stop.exists():
                record = read(stop)
                spec = read(spec_path)
                if (
                    record.get("code") == "SUBSCRIPTION_QUOTA_FLOOR"
                    and record.get("run_id") == spec["run_id"]
                    and record.get("attempt_id") == spec["attempt_id"]
                    and record.get("spec_sha256") == hashlib.sha256(spec_path.read_bytes()).hexdigest()
                ):
                    raise WorkRejected("SUBSCRIPTION_QUOTA_FLOOR")
            raise WorkRejected("EPISODE_PROCESS_FAILED")

    def _state(self, value):
        write(self.root / "state.json", value)

    def _check_binding(self, state, competition_id):
        binding = {
            "backend": self.client.base_url,
            "worker_id": self.client.worker_id,
            "node_id": self.client.node_id,
            "competition_id": competition_id,
        }
        if state and state["binding"] != binding:
            raise WorkRejected("WORKER_STATE_SCOPE_MISMATCH")
        return binding

    def _original_report_pending(self, state):
        if not state or state.get("phase") not in {"reporting", "held"}:
            return False
        work = state.get("work", {})
        if self.task_kind != "scene" or not is_scene_task(work.get("task", {})):
            return False
        directory = self.root / "runs" / hashlib.sha256(work["run_id"].encode()).hexdigest()[:24]
        return bool(state.get("scene_report_sha256")) or (directory / "report.json").exists()

    def confirm_original_scene_report(self, competition_id):
        """Main owns worker.lock; only original-byte ACK, with no live adapter."""
        from task_source.scene_report_ack import report_with_ack

        state = read(self.root / "state.json")
        self._check_binding(state, competition_id)
        if not self._original_report_pending(state):
            raise WorkRejected("SCENE_REPORT_ORIGINAL_REQUIRED")
        directory = self.root / "runs" / hashlib.sha256(state["work"]["run_id"].encode()).hexdigest()[:24]
        return report_with_ack(self, state, directory, ack_only=True)

    def poll_once(self, competition_id):
        path = self.root / "state.json"
        state = read(path) if path.exists() else None
        binding = self._check_binding(state, competition_id)
        if state and state["phase"] == "scene_resuming":
            from task_source.scene_recovery import finish_scene_resume

            return finish_scene_resume(self, state)
        if state and state["phase"] == "recovering":
            if is_scene_task(state.get("work", {}).get("task", {})):
                state.update(phase="held", error_code="SCENE_EXPLICIT_RECOVERY_REQUIRED")
                self._state(state)
                return "held"
            from task_source.panel_recovery import finish_recovery

            state = finish_recovery(self, state)
        if state and state["phase"] == "held":
            if state.get("error_code") == "SCENE_REVIEW_REQUIRED" and "work" not in state:
                state["phase"] = "claiming"
                self._state(state)
            elif self._original_report_pending(state):
                outcome = self.confirm_original_scene_report(competition_id)
                if outcome != "not_completed":
                    return outcome
                return "held"
            else:
                return "held"
        if not state or state["phase"] in ("completed", "idle"):
            # Persist the claim secret before the request. A dropped first response
            # can then retrieve the same server-side lease without creating work.
            state = {"binding": binding, "phase": "claiming", "pending_lease_token": secrets.token_urlsafe(32)}
            if self.task_kind == "scene":
                state["pending_scene_recovery_token"] = secrets.token_urlsafe(48)
            self._state(state)
        if state["phase"] == "claiming":
            claim_options = {"lease_token": state["pending_lease_token"]}
            if self.task_kind == "scene":
                recovery = state.get("pending_scene_recovery_token")
                if (
                    not isinstance(recovery, str)
                    or not 32 <= len(recovery) <= 200
                    or recovery == state["pending_lease_token"]
                ):
                    state.update(phase="held", error_code="SCENE_RECOVERY_CREDENTIAL_REQUIRED")
                    self._state(state)
                    return "held"
                claim_options["scene_recovery_token"] = recovery
            try:
                work = self.client.claim(competition_id, **claim_options)
            except PanelAPIError as exc:
                if exc.code == "SCENE_REVIEW_REQUIRED" or exc.status in (None, 429) or exc.status >= 500:
                    return "retry"
                state.update(phase="held", error_code=exc.code)
                self._state(state)
                return "held"
            if work is None:
                self._state({"binding": binding, "phase": "idle"})
                return "idle"
            if work.get("lease_token") != state["pending_lease_token"]:
                state.update(phase="held", error_code="CLAIM_TOKEN_MISMATCH")
                self._state(state)
                return "held"
            initial_recovery = state.get("pending_scene_recovery_token")
            state = {"binding": binding, "work": work, "phase": "claimed", "progress": self._initial_progress(work)}
            if self.task_kind == "scene":
                state.update(scene_recovery_token=initial_recovery, scene_recovery_generation=0)
            self._state(state)
        work = state["work"]
        directory = self.root / "runs" / hashlib.sha256(work["run_id"].encode()).hexdigest()[:24]
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        scene = False
        try:
            if work["task"].get("competition_id") != competition_id:
                raise WorkRejected("CLAIM_COMPETITION_MISMATCH")
            scene = is_scene_task(work["task"])
            if scene and self.task_kind == "scene" and state["phase"] == "reporting":
                return self._report(state, directory)
            if scene and (self.scene is None or self.task_kind != "scene"):
                raise WorkRejected("SCENE_PROFILE_UNREGISTERED")
            if not scene and self.task_kind == "scene":
                raise WorkRejected("SCENE_PROFILE_MISMATCH")
            if scene:
                self._scene_context(state)
            config = validate_work(work)
            host = read(self.model_config)
            validate_host(host, config)
            if state.get("authorized_host_sha256"):
                from agent_eval.subscription_gateway import _sha

                if _sha(host) != state["authorized_host_sha256"]:
                    raise WorkRejected("MODEL_HOST_CHANGED")
            if state["phase"] == "reporting":
                if scene:
                    # Read-only context can reauthorize an unexpired completed
                    # run for original-report retry. Do not heartbeat/renew or
                    # reenter download/runtime from this state.
                    return self._report(state, directory)
                with LeaseKeeper(
                    self.client,
                    work,
                    directory / "lease.json",
                    self.heartbeat_s,
                    detail=state["progress"],
                    stage="reporting",
                ):
                    return self._report(state, directory)
            # Rebuild progress from signed complete originals before the first
            # heartbeat. A restart never resets the backend's monotonic counter.
            completed = self._completed_count(work, directory, config, host)
            previous = state.get("progress", self._initial_progress(work))
            if completed < previous["completed_trials"]:
                raise WorkRejected("COMPLETED_EVIDENCE_MISSING")
            state["progress"] = {"completed_trials": completed, "total_trials": previous["total_trials"]}
            self._state(state)
            with LeaseKeeper(
                self.client,
                work,
                directory / "lease.json",
                self.heartbeat_s,
                detail=state["progress"],
                progress_observer=(
                    self._scene_progress_observer(work, directory) if self.scene_recovery_reader else None
                ),
            ) as lease:
                return self._evaluate(state, directory, config, host, lease)
        except PanelAPIError as exc:
            if exc.status in (None, 429) or exc.status >= 500:
                LOG.warning("A evaluation API retry: %s (HTTP %s)", exc.code, exc.status)
                return "retry"
            return self._hold(state, directory, exc.code)
        except Exception as exc:
            # Hold paths rewrite the code; keep the raised cause in the journal.
            LOG.error("A evaluation raised: %s: %s", type(exc).__name__, exc)
            if scene:
                from task_source.scene_transport import SceneTransportError
                from task_source.scene_episode_scope import SceneLaunchError

                if isinstance(exc, SceneLaunchError):
                    state["error_category"] = "resource_unavailable"
                    return self._hold(state, directory, str(exc).upper())

                if isinstance(exc, SceneTransportError):
                    if exc.retryable:
                        state.update(error_code=exc.code, error_category=exc.category)
                        self._state(state)
                        return "retry"
                    state["error_category"] = exc.category
                    code = exc.code.upper()
                    return self._hold(state, directory, code if code.startswith("SCENE_") else "SCENE_" + code)
            if not isinstance(exc, WorkRejected):
                # Hold keeps the public code stable; the journal still needs the
                # real cause, which is otherwise erased by WORKER_FAILED.
                LOG.error(
                    "A evaluation failed: %s code=%s", type(exc).__name__, getattr(exc, "code", None) or repr(str(exc))
                )
            code = str(exc) if isinstance(exc, WorkRejected) else "WORKER_FAILED"
            if code == "SCENE_CONFIG_OR_RUNTIME_UNAVAILABLE":
                state["error_category"] = "resource_unavailable"
            return self._hold(state, directory, code)

    def _scene_context(self, state):
        from task_source.scene_adapter import bind_scene_context

        metadata = self.client.scene_context(state["work"])
        # Enforce the claim pin at the daemon boundary, before delegating to
        # any adapter or persisting its very first context snapshot.
        bind_scene_context(state["work"], metadata)
        task, _, authority = self.scene.evaluation_context(state["work"], metadata)
        if state.get("scene_task") is not None and state["scene_task"] != task.document:
            raise WorkRejected("SCENE_FROZEN_METADATA_CHANGED")
        trust = authority.trust.document
        if state.get("scene_receipt_trust") is not None and state["scene_receipt_trust"] != trust:
            raise WorkRejected("SCENE_RECEIPT_AUTHORITY_CHANGED")
        for key in ("identity", "execution_contract"):
            if state.get("scene_" + key) is not None and state["scene_" + key] != metadata[key]:
                raise WorkRejected("SCENE_FROZEN_METADATA_CHANGED")
        if state.get("scene_receipt_digest") is not None and state["scene_receipt_digest"] != metadata.get(
            "receipt_digest"
        ):
            raise WorkRejected("SCENE_RECEIPT_CHANGED")
        state.update(
            scene_task=task.document,
            scene_receipt_trust=trust,
            scene_identity=metadata["identity"],
            scene_execution_contract=metadata["execution_contract"],
            scene_receipt_digest=metadata.get("receipt_digest"),
        )
        self._state(state)
        return metadata

    @staticmethod
    def _scene_progress_observer(work, directory):
        from task_source.scene_commitment import observe_progress

        return lambda stage, detail: observe_progress(work, directory, stage, detail)

    @staticmethod
    def _initial_progress(work):
        return {
            "completed_trials": 0,
            "total_trials": work["trials_per_member"]
            * len(work["config"]["panels"][work["config"]["settlement_panel"]]["members"]),
        }

    def _completed_count(self, work, directory, config, host, *, signer=None, historical=False):
        from agent_evidence.signing import Signer
        from task_source.panel_report import episode_row

        signer = signer or Signer.from_keyfile(self.signing_key)
        count = 0
        for trial in range(work["trials_per_member"]):
            for member in config.settlement.members:
                stem = f"{member.id}-{trial}"
                result = directory / "results" / f"{stem}.json"
                if not result.exists():
                    continue
                spec_path = directory / "specs" / f"{stem}.json"
                raw = read(spec_path)
                instances = read(directory / "package.json")["instance_ids"]
                validate_episode_spec(
                    raw,
                    work,
                    config,
                    member,
                    trial,
                    instances,
                    directory / "episodes" / f"{config.settlement_panel}-{member.id}-{trial}.jsonl",
                    host["providers"][member.provider],
                    historical=historical,
                )
                marker = read(directory / "started" / f"{stem}.json")
                if marker["spec_sha256"] != hashlib.sha256(spec_path.read_bytes()).hexdigest():
                    raise WorkRejected("EPISODE_SPEC_CHANGED")
                if is_scene_task(work["task"]) and not historical:
                    from task_source.scene_episode_scope import require

                    require(self.scene_episode_launcher is not None, "scene_episode_launcher_unavailable")
                    request = read(directory / "launches" / f"{stem}.request.json")
                    require(marker.get("launcher_request_digest") == request["request_digest"])
                    receipt_path = directory / "launches" / f"{stem}.json"
                    require(
                        receipt_path.is_file() and not receipt_path.is_symlink(), "scene_episode_launch_receipt_missing"
                    )
                    self.scene_episode_launcher.verify_completed(
                        receipt_path,
                        request_digest=request["request_digest"],
                        spec_sha256=marker["spec_sha256"],
                    )
                episode_row(raw, read(result), signer)
                count += 1
        return count

    def _hold(self, state, directory, code):
        if not re.fullmatch("[A-Z][A-Z0-9_:-]{0,79}", code):
            # The public code stays stable, but a rejected internal code must
            # remain diagnosable in the journal instead of vanishing.
            LOG.error("A hold code rejected: %r", code)
            code = "WORKER_FAILED"
        state.update(phase="held", error_code=code)
        self._state(state)
        try:
            self.client.progress(
                state["work"],
                "held",
                {**state.get("progress", self._initial_progress(state["work"])), "error_code": code},
            )
        except Exception:
            pass
        LOG.error("A evaluation held: %s", code)
        return "held"

    def _report(self, state, directory):
        work = state["work"]
        if is_scene_task(work["task"]):
            from task_source.scene_report_ack import report_with_ack

            return report_with_ack(self, state, directory)
        else:
            total = work["trials_per_member"] * len(
                work["config"]["panels"][work["config"]["settlement_panel"]]["members"]
            )
            self.client.progress(work, "reporting", {"completed_trials": total, "total_trials": total})
        if hasattr(self.client, "report_archive"):
            response = self.client.report_archive(work, directory / "report.json", directory / "transfers/report.json")
        else:
            response = self.client.report(work, read(directory / "report.json"))
        if not response.get("evidence_ok"):
            raise WorkRejected("REPORT_EVIDENCE_REJECTED")
        write(directory / "report-response.json", response)
        complete_reported_work(self.root, work, state["binding"])
        return "completed"

    def _verify_scene_report(self, state, directory, *, historical=False):
        """Verify the persisted original and its signed manifest without resigning."""
        from agent_evidence.signing import Signer
        from benchmark_worker.reference_panel.manifest import build_manifest, verify_manifest
        from task_source.panel_report import episode_row

        path = directory / "report.json"
        if (
            path.is_symlink()
            or not path.is_file()
            or state.get("scene_report_sha256") != hashlib.sha256(path.read_bytes()).hexdigest()
        ):
            raise WorkRejected("REPORT_ORIGINAL_CHANGED")
        report, work = read(path), state["work"]
        if historical:
            from task_source.scene_report_ack import historical_inputs

            config, host, signer = historical_inputs(self, state, directory)
        else:
            config = validate_work(work)
            host = read(self.model_config)
            signer = Signer.from_keyfile(self.signing_key)
            self.scene.registration.identity(self.client.node_id, signer).validate(self.scene.transport._clock())
        total = work["trials_per_member"] * len(config.settlement.members)
        if self._completed_count(work, directory, config, host, signer=signer, historical=historical) != total:
            raise WorkRejected("COMPLETED_EVIDENCE_MISSING")
        members = [
            {
                "member": member.id,
                "member_kind": member.kind,
                "trials": [
                    episode_row(
                        read(directory / "specs" / f"{member.id}-{trial}.json"),
                        read(directory / "results" / f"{member.id}-{trial}.json"),
                        signer,
                    )
                    for trial in range(work["trials_per_member"])
                ],
            }
            for member in config.settlement.members
        ]
        binding = {
            "task_id": work["task"]["task_id"],
            "run_id": work["run_id"],
            "package_digest": work["task"]["package_digest"],
            "config_version": work["config_version"],
            "config_digest": work["config_digest"],
            "panel": config.settlement_panel,
            "node_id": self.client.node_id,
            "roles": dict(config.settlement.roles),
        }
        expected = build_manifest(**binding, settlement=True, key_id=signer.key_id, members=members)
        manifest = report["manifest"]
        if (
            any(report.get(k) != v for k, v in binding.items())
            or report.get("members") != members
            or report.get("task_source") != work["task"]["source"]
            or {k: v for k, v in manifest.items() if k != "signature"} != expected
            or not verify_manifest(manifest, signer.public_key_hex)
        ):
            raise WorkRejected("REPORT_ORIGINAL_CHANGED")

    def _evaluate(self, state, directory, config, host, lease):
        if is_scene_task(state["work"]["task"]):
            return self._evaluate_scene(state, directory, config, host, lease)
        from agent_harness import build_spec, parse_spec
        from agent_evidence.signing import Signer
        from task_source.panel_report import build_report, episode_row
        from task_source.execution_contract import execution_contract_digest

        work = state["work"]
        task = work["task"]
        n = work["trials_per_member"]
        members = config.settlement.members
        total = n * len(members)
        done = state["progress"]["completed_trials"]
        lease.update("downloading", {"completed_trials": done, "total_trials": total})
        package, task_spec = download_official_package(task, self.root / "packages", self.hf_read_token)
        instance_ids = [i.instance for i in task_spec.instances]
        if not instance_ids:
            raise WorkRejected("TASK_INSTANCES_MISSING")
        if task_spec.metadata.get("execution_profile") != task["execution_profile"]:
            raise WorkRejected("PACKAGE_EXECUTION_PROFILE_MISMATCH")
        signer = Signer.from_keyfile(self.signing_key)
        write(
            directory / "work.json",
            {
                "work": work,
                "binding": state["binding"],
                "public_key": {"key_id": signer.key_id, "public_key_hex": signer.public_key_hex},
            },
        )
        write(
            directory / "package.json",
            {
                "directory": str(package.directory),
                "package_digest": package.digest,
                "source_task_id": package.task_id,
                "instance_ids": instance_ids,
            },
        )
        for name in ("specs", "results", "started", "episodes"):
            (directory / name).mkdir(exist_ok=True)
        effective_host = directory / "model-host.json"
        if not effective_host.exists():
            host = copy.deepcopy(host)
            host["session_prefix"] = (
                "a-" + hashlib.sha256((self.client.worker_id + work["run_id"]).encode()).hexdigest()[:24]
            )
            write(effective_host, host, exclusive=True)
        elif read(effective_host) != {
            **host,
            "session_prefix": "a-" + hashlib.sha256((self.client.worker_id + work["run_id"]).encode()).hexdigest()[:24],
        }:
            raise WorkRejected("MODEL_HOST_CHANGED")
        contract = config.execution_contract
        from task_source.panel_calibration import calibrate
        from task_source.registry import get_source

        calibration_path = directory / "budget-calibration.json"
        if calibration_path.exists():
            calibration = read(calibration_path)
            from agent_harness.canonical import canonical_sha256

            if (
                calibration.get("package_digest") != task["package_digest"]
                or calibration.get("execution_contract") != contract
                or calibration.get("config_digest") != config.digest
                or calibration.get("reserve_fraction")
                != host.get("budget_calibration", {}).get("reserve_fraction", 0.25)
                or calibration.get("sha256")
                != canonical_sha256({k: v for k, v in calibration.items() if k != "sha256"})
            ):
                raise WorkRejected("BUDGET_CALIBRATION_BINDING_MISMATCH")
        else:
            calibration = calibrate(
                task_spec,
                get_source(task["source"], root=package.directory),
                contract,
                config.digest,
                reserve_fraction=host.get("budget_calibration", {}).get("reserve_fraction", 0.25),
            )
            write(calibration_path, calibration, exclusive=True)
        if not calibration.get("ready"):
            raise WorkRejected("TASK_BUDGET_CALIBRATION_FAILED")
        for trial in range(n):
            for member in members:
                stem = f"{member.id}-{trial}"
                spec_path = directory / "specs" / f"{stem}.json"
                result_path = directory / "results" / f"{stem}.json"
                started = directory / "started" / f"{stem}.json"
                detail = {
                    "completed_trials": done,
                    "total_trials": total,
                    "current_member": member.id,
                    "current_trial": trial,
                }
                if result_path.exists():
                    if not spec_path.exists():
                        raise WorkRejected("RESULT_SPEC_MISSING")
                    raw = read(spec_path)
                    validate_episode_spec(
                        raw,
                        work,
                        config,
                        member,
                        trial,
                        instance_ids,
                        directory / "episodes" / f"{config.settlement_panel}-{member.id}-{trial}.jsonl",
                        host["providers"][member.provider],
                    )
                    marker = read(started)
                    if marker["spec_sha256"] != hashlib.sha256(spec_path.read_bytes()).hexdigest():
                        raise WorkRejected("EPISODE_SPEC_CHANGED")
                    episode_row(raw, read(result_path), signer)
                    self._enqueue_video(work, config, directory, member.id, trial, signer)
                    continue
                if started.exists():
                    raise WorkRejected("PAID_EPISODE_INTERRUPTED")
                lease.update("evaluating", detail)
                if lease.failed:
                    raise WorkRejected("LEASE_HEARTBEAT_FAILED")
                if spec_path.exists():
                    raw = read(spec_path)
                else:
                    model = {**member.model_config(), **host["providers"][member.provider]}
                    raw = build_spec(
                        source=task["source"],
                        task_id=task["task_id"],
                        instance=instance_ids[trial % len(instance_ids)],
                        episode=trial,
                        version_digest=task["package_digest"],
                        package_repo=task["package_repo"],
                        package_commit=task["package_commit"],
                        model=model,
                        mode=contract["permissions"]["mode"],
                        sensors=contract["permissions"]["allowed_sensors"],
                        run_id=work["run_id"],
                        max_turns=contract["budget"]["max_api_calls"],
                        max_steps=contract["budget"]["max_steps"],
                        wall_seconds=contract["budget"]["wall_seconds"],
                        timing=contract["timing"],
                        evidence_path=str(
                            directory / "episodes" / f"{config.settlement_panel}-{member.id}-{trial}.jsonl"
                        ),
                        binding={"job_id": work["run_id"], "nonce": secrets.token_hex(16)},
                        runtime={"override": "task_source"},
                        signing_mode="single",
                        panel_binding={
                            "run_id": work["run_id"],
                            "panel": config.settlement_panel,
                            "member": member.id,
                            "kind": member.kind,
                            "trial": trial,
                            "package_digest": task["package_digest"],
                            "version_digest": task["package_digest"],
                            "config_version": config.version,
                            "config_digest": config.digest,
                            "settlement": True,
                            "execution_contract": contract,
                            "execution_contract_digest": execution_contract_digest(contract),
                        },
                    )
                    raw["attempt_id"] = f"{work['run_id']}:{member.id}:{trial}"
                    raw["task"]["execution_profile"] = task["execution_profile"]
                    raw["evidence"]["job_digest"] = parse_spec(raw).job_digest
                    write(spec_path, raw, exclusive=True)
                validate_episode_spec(
                    raw,
                    work,
                    config,
                    member,
                    trial,
                    instance_ids,
                    directory / "episodes" / f"{config.settlement_panel}-{member.id}-{trial}.jsonl",
                    host["providers"][member.provider],
                )
                write(
                    started,
                    {
                        "spec_sha256": hashlib.sha256(spec_path.read_bytes()).hexdigest(),
                        "started_at": datetime.now(UTC).isoformat(),
                    },
                    exclusive=True,
                )
                self.launcher(
                    spec_path,
                    effective_host,
                    directory / "lease.json",
                    result_path,
                    float(contract["budget"]["wall_seconds"]),
                )
                if lease.failed:
                    raise WorkRejected("LEASE_HEARTBEAT_FAILED")
                row = episode_row(raw, read(result_path), signer)
                self._enqueue_video(work, config, directory, member.id, trial, signer)
                done += 1
                state["progress"] = {"completed_trials": done, "total_trials": total}
                self._state(state)
                lease.update(
                    "evaluating",
                    {
                        "completed_trials": done,
                        "total_trials": total,
                        "current_member": member.id,
                        "current_trial": trial,
                        "last_status": "error" if row["error"] else "ok",
                    },
                )
        payload = build_report(work, config, directory, signer, self.client.node_id)
        report_path = directory / "report.json"
        if report_path.exists():
            if read(report_path) != payload:
                raise WorkRejected("REPORT_ORIGINAL_CHANGED")
        else:
            write(report_path, payload, exclusive=True)
        state["phase"] = "reporting"
        self._state(state)
        lease.update("reporting", {"completed_trials": done, "total_trials": total})
        return self._report(state, directory)

    def _evaluate_scene(self, state, directory, config, host, lease):
        """Existing panel lifecycle/evidence, with E-only P02 typed callbacks."""
        from agent_evidence.signing import Signer
        from task_source.panel_report import build_report, episode_row
        from task_source.scene_adapter import SceneEpisodeContext
        from task_source.scene_transport import SceneTransportError
        from task_source.scene_episode_launcher import request_document, stable_request_digest, digest
        from task_source.scene_views.identity import decode

        work, task = state["work"], state["work"]["task"]
        metadata = self._scene_context(state)
        package = self.scene.download_evaluation(work, metadata)
        view = package.view
        if view.contract != config.execution_contract:
            raise WorkRejected("SCENE_PANEL_CONTRACT_MISMATCH")
        instances = list(range(len(view.task["scene"]["initial_states"])))
        if not instances:
            raise WorkRejected("TASK_INSTANCES_MISSING")
        signer = Signer.from_keyfile(self.signing_key)
        self.scene.registration.identity(self.client.node_id, signer).validate(self.scene.transport._clock())
        write(
            directory / "work.json",
            {
                "work": work,
                "binding": state["binding"],
                "public_key": {"key_id": signer.key_id, "public_key_hex": signer.public_key_hex},
            },
        )
        write(directory / "package.json", {"package_digest": task["package_digest"], "instance_ids": instances})
        for name in ("specs", "results", "started", "episodes", "launches", "private-scene"):
            (directory / name).mkdir(exist_ok=True)
        subscription = directory / "subscription"
        if not subscription.exists():
            if any((directory / "started").iterdir()) or any((directory / "results").iterdir()):
                raise WorkRejected("SCENE_RECOVERY_SUBSCRIPTION_ORIGINAL_MISSING")
            subscription.mkdir(mode=0o700)  # Original run/member namespace, never a replacement ledger.
        if subscription.is_symlink() or not subscription.is_dir():
            raise WorkRejected("SCENE_RECOVERY_SUBSCRIPTION_ORIGINAL_INVALID")
        host_path = directory / "model-host.json"
        if host_path.exists() and read(host_path) != host:
            raise WorkRejected("MODEL_HOST_CHANGED")
        if not host_path.exists():
            write(host_path, host, exclusive=True)
        commitment = None
        if self.scene_recovery_reader is not None:
            from task_source.scene_commitment import ensure_commitment

            commitment = ensure_commitment(self, state, directory)
        total = work["trials_per_member"] * len(config.settlement.members)
        done = state["progress"]["completed_trials"]
        for trial in range(work["trials_per_member"]):
            for member in config.settlement.members:
                stem = f"{member.id}-{trial}"
                spec_path, result_path = directory / "specs" / f"{stem}.json", directory / "results" / f"{stem}.json"
                started = directory / "started" / f"{stem}.json"
                context = SceneEpisodeContext(
                    work,
                    config,
                    member,
                    trial,
                    instances[trial % len(instances)],
                    spec_path,
                    result_path,
                    directory / "episodes" / f"{config.settlement_panel}-{member.id}-{trial}.jsonl",
                    host_path,
                    directory / "lease.json",
                    signer,
                    self.scene.registration.document,
                    receipt_bytes=package.receipt_bytes,
                    recovery_commitment=commitment,
                )
                if not result_path.exists() and started.exists():
                    raise WorkRejected("PAID_EPISODE_INTERRUPTED")
                launcher = self.scene_episode_launcher
                if launcher is None:
                    raise SceneTransportError("scene_episode_launcher_unavailable", category="infra")
                if not result_path.exists():
                    # The heartbeat renews the run, but a spec freezes the
                    # deadlines it was built with. Re-read the authenticated
                    # context before every paid launch, or a work with more than
                    # one member/trial dies at the claim-time lease.
                    metadata = self._scene_context(state)
                request = request_document(view, context, metadata, decode(package.receipt_bytes))
                request_path = directory / "launches" / f"{stem}.request.json"
                receipt_path = directory / "launches" / f"{stem}.json"
                if result_path.exists():
                    saved = read(request_path)
                    if saved["stable_digest"] != stable_request_digest(request):
                        raise WorkRejected("SCENE_EPISODE_LAUNCH_BINDING_CHANGED")
                    raw = read(spec_path)
                    spec_sha256 = hashlib.sha256(spec_path.read_bytes()).hexdigest()
                    if read(started)["spec_sha256"] != spec_sha256:
                        raise WorkRejected("EPISODE_SPEC_CHANGED")
                    launcher.verify_completed(
                        receipt_path, request_digest=saved["request_digest"], spec_sha256=spec_sha256
                    )
                    episode_row(raw, read(result_path), signer)
                    continue
                with launcher.open(
                    view, context=context, metadata=metadata, receipt=decode(package.receipt_bytes)
                ) as parent:
                    if parent.request_digest != digest(request):
                        raise WorkRejected("SCENE_EPISODE_LAUNCH_BINDING_CHANGED")
                    raw = parent.candidate()
                    if not spec_path.is_file() or spec_path.is_symlink():
                        raise WorkRejected("SCENE_EPISODE_SAVED_SPEC_MISSING")
                    if read(spec_path) != raw:
                        raise WorkRejected("EPISODE_SPEC_CHANGED")
                    validate_episode_spec(
                        raw,
                        work,
                        config,
                        member,
                        trial,
                        instances,
                        context.evidence_path,
                        host["providers"][member.provider],
                    )
                    spec_sha256 = hashlib.sha256(spec_path.read_bytes()).hexdigest()
                    parent.saved(spec_sha256)  # Child has its token + real scope/factory checks, still no paid marker.
                    lease.update("evaluating", {"completed_trials": done, "total_trials": total})
                    if lease.failed:
                        raise WorkRejected("LEASE_HEARTBEAT_FAILED")
                    write(
                        request_path,
                        {"request_digest": digest(request), "stable_digest": stable_request_digest(request)},
                    )
                    write(
                        started,
                        {
                            "spec_sha256": spec_sha256,
                            "started_at": datetime.now(UTC).isoformat(),
                            "launcher_request_digest": digest(request),
                        },
                        exclusive=True,
                    )
                    parent.execute(receipt_path)  # GO, same child consumes its single-use prepared token.
                if lease.failed:
                    raise WorkRejected("LEASE_HEARTBEAT_FAILED")
                episode_row(raw, read(result_path), signer)
                done += 1
                state["progress"] = {"completed_trials": done, "total_trials": total}
                self._state(state)
                lease.update("evaluating", state["progress"])
        payload = build_report(work, config, directory, signer, self.client.node_id)
        report_path = directory / "report.json"
        if report_path.exists():
            if read(report_path) != payload:
                raise WorkRejected("REPORT_ORIGINAL_CHANGED")
        else:
            write(report_path, payload, exclusive=True)
        state["phase"] = "reporting"
        state["scene_report_sha256"] = hashlib.sha256(report_path.read_bytes()).hexdigest()
        state["scene_report_signer"] = {
            "node_id": self.client.node_id,
            "key_id": signer.key_id,
            "public_key_hex": signer.public_key_hex,
        }
        self._state(state)
        lease.update("reporting", {"completed_trials": done, "total_trials": total})
        return self._report(state, directory)

    def _enqueue_video(self, work, config, directory, member, trial, signer):
        from dataclasses import asdict

        from task_source.panel_media import VideoOptions, enqueue_video

        enqueue_video(
            self.root,
            directory,
            work,
            member,
            trial,
            {"key_id": signer.key_id, "public_key_hex": signer.public_key_hex},
            render_options=asdict(VideoOptions()),
        )


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("backend-url", "worker-id", "node-id", "signing-key", "model-config", "state-root"):
        p.add_argument("--" + name, required=True)
    p.add_argument("--competition", required=True, type=int)
    p.add_argument("--task-kind", choices=["legacy", "scene"], default="legacy")
    p.add_argument("--scene-registration", help="operator registered scene identity/profile JSON")
    p.add_argument("--scene-parent-launcher", help="root-owned public launcher deployment JSON; no inline fallback")
    p.add_argument("--poll-interval", type=float, default=30)
    p.add_argument("--heartbeat-interval", type=float, default=30)
    p.add_argument(
        "--report-timeout", type=float, default=600, help="upload/response timeout in seconds for evidence reports"
    )
    p.add_argument("--max-tasks", type=int, default=None)
    p.add_argument("--resume-unspent", action="store_true", help="resume only a verified zero-wire quota refusal")
    p.add_argument("--resume-reason", help="operator reason for the explicit zero-wire recovery")
    p.add_argument("--scene-resume", action="store_true", help="explicit same-run scene credential recovery")
    p.add_argument(
        "--scene-resume-unstarted",
        action="store_true",
        help="explicit Operator-attested generation-0 recovery; requires registered root launcher",
    )
    p.add_argument(
        "--scene-recovery-token-file",
        type=pathlib.Path,
        help="private initial R already authorized by an external Operator",
    )
    a = p.parse_args(argv)
    if a.scene_resume_unstarted:
        if a.scene_resume or a.task_kind != "scene" or a.resume_unspent or not a.scene_parent_launcher:
            p.error("--scene-resume-unstarted requires scene/root launcher and no other recovery mode")
        a.scene_resume = True
    if a.poll_interval < 1 or a.heartbeat_interval < 1 or (a.max_tasks is not None and a.max_tasks < 1):
        p.error("intervals and max-tasks must be positive")
    if a.resume_unspent != bool(a.resume_reason):
        p.error("--resume-unspent and --resume-reason must be provided together")
    if a.scene_resume and (a.task_kind != "scene" or a.resume_unspent):
        p.error("--scene-resume requires scene and cannot use --resume-unspent")
    if a.scene_recovery_token_file and not a.scene_resume:
        p.error("--scene-recovery-token-file requires --scene-resume")
    if a.task_kind == "scene" and a.resume_unspent:
        p.error("scene recovery requires --scene-resume; legacy zero-wire recovery is unavailable")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    client = PanelClient(
        a.backend_url,
        os.environ.get("VALIDATOR_API_KEY", ""),
        a.worker_id,
        a.node_id,
        report_timeout_s=a.report_timeout,
    )
    scene_loader = None
    if a.task_kind == "scene":
        if not a.scene_registration:
            p.error("scene requires --scene-registration")
        from agent_evidence.signing import Signer
        from task_source.scene_adapter import load_scene_adapter

        def scene_loader():
            return load_scene_adapter(
                a.scene_registration,
                backend_url=a.backend_url,
                api_key=os.environ.get("VALIDATOR_API_KEY", ""),
                signer=Signer.from_keyfile(a.signing_key),
                node_id=a.node_id,
            )

    elif a.scene_registration:
        p.error("--scene-registration requires --task-kind scene")
    if a.task_kind == "legacy" and not os.environ.get("HF_READ_TOKEN"):
        p.error("HF_READ_TOKEN is required for the configured official account")
    with single_owner(pathlib.Path(a.state_root)):
        try:
            saved = read(pathlib.Path(a.state_root) / "state.json")
        except FileNotFoundError:
            saved = {}
        # Decide this only after the same persisted owner/backend/competition
        # binding is checked, before loading current operator/private material.
        expected_binding = {
            "backend": client.base_url,
            "worker_id": client.worker_id,
            "node_id": client.node_id,
            "competition_id": a.competition,
        }
        if saved and saved["binding"] != expected_binding:
            LOG.error("WORKER_STATE_SCOPE_MISMATCH")
            return 3  # Do not mutate another saved owner or load current private material.
        saved_work = saved.get("work", {})
        historical_start = (
            a.task_kind == "scene"
            and saved.get("phase") in {"reporting", "held"}
            and is_scene_task(saved_work.get("task", {}))
            and (
                bool(saved.get("scene_report_sha256"))
                or (
                    pathlib.Path(a.state_root)
                    / "runs"
                    / hashlib.sha256(saved_work["run_id"].encode()).hexdigest()[:24]
                    / "report.json"
                ).exists()
            )
        )
        scene = scene_loader() if scene_loader is not None and not historical_start else None
        public_registration = None
        if historical_start and saved.get("scene_report_signer") is None:
            from task_source.scene_views.identity import decode

            try:
                raw = pathlib.Path(a.scene_registration).read_bytes()
                if len(raw) > 1_000_000:
                    raise ValueError("public registration limit")
                public_registration = decode(raw)  # Public key only, no live profile/TTL selection.
            except (OSError, ValueError):
                saved.update(phase="held", error_code="SCENE_REPORT_ORIGINAL_KEY_REQUIRED")
                write(pathlib.Path(a.state_root) / "state.json", saved)
                LOG.error("SCENE_REPORT_ORIGINAL_KEY_REQUIRED")
                return 3
        from task_source.scene_episode_launcher import RegisteredSceneLauncher

        worker = PanelWorker(
            client,
            state_root=a.state_root,
            signing_key=a.signing_key,
            model_config=a.model_config,
            hf_read_token=os.environ.get("HF_READ_TOKEN", ""),
            heartbeat_s=a.heartbeat_interval,
            scene_adapter=scene,
            task_kind=a.task_kind,
            scene_adapter_loader=scene_loader,
            scene_report_registration=public_registration,
            scene_episode_launcher=(
                RegisteredSceneLauncher(a.scene_parent_launcher) if a.scene_parent_launcher else None
            ),
        )
        if historical_start:
            while True:
                outcome = worker.confirm_original_scene_report(a.competition)
                if outcome == "completed":
                    return 0  # This recovery never falls through into a new claim.
                if outcome == "held":
                    return 3
                if outcome == "retry":
                    time.sleep(a.poll_interval)
                    continue  # Retry this read only, without touching current live dependencies.
                if a.scene_resume:
                    try:
                        worker.scene = scene_loader()
                    except Exception:
                        from task_source.scene_recovery import held

                        held(worker, read(worker.root / "state.json"), "SCENE_REPORT_LIVE_CONTEXT_REQUIRED")
                        return 3
                else:
                    current = read(worker.root / "state.json")
                    if current.get("work") != saved.get("work") or current.get("binding") != saved.get("binding"):
                        return 3
                    current.update(phase="held", error_code="SCENE_REPORT_EXPLICIT_RECOVERY_REQUIRED")
                    worker._state(current)
                    LOG.error("SCENE_REPORT_EXPLICIT_RECOVERY_REQUIRED")
                    return 3  # Negative ACK never implicitly sends, renews or restores this cold run.
                break  # Only an explicit --scene-resume enters the R8 gates below.
        if a.resume_unspent:
            from task_source.panel_recovery import resume_unspent

            resume_unspent(worker, a.resume_reason)
        if a.scene_resume:
            from task_source.scene_recovery import prepare_scene_resume

            if (
                prepare_scene_resume(
                    worker, credential_file=a.scene_recovery_token_file, unstarted=a.scene_resume_unstarted
                )
                == "held"
            ):
                return 3
        completed = 0
        while True:
            outcome = worker.poll_once(a.competition)
            LOG.info("A worker: %s", outcome)
            if outcome == "completed":
                completed += 1
                if historical_start:
                    return 0  # Historical confirmation never starts a new claim.
            if a.max_tasks is not None and completed >= a.max_tasks:
                return 0
            if outcome == "held":
                return 3
            time.sleep(a.poll_interval)


if __name__ == "__main__":
    raise SystemExit(main())
