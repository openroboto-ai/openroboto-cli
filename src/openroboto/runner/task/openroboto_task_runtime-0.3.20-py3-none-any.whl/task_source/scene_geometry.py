"""Per-imported-scene geometry and contact resolution for the shared program."""

from __future__ import annotations

import itertools
import math

import numpy as np
from openroboto_protocol.tabletop_v2 import profile_catalog

from .tabletop_geometry import _ellipse_radius, rotation, valid_state


def pose_matrix(pose):
    result = np.eye(4)
    result[:3, :3] = rotation(pose["quaternion_xyzw"])
    result[:3, 3] = pose["position_m"]
    return result


class SceneResolver:
    """Bound to one verified import; never changes the controlled asset catalog."""

    def __init__(self, imported):
        self.objects = {o.id: o.model_dump(mode="json") for o in imported.task.task_definition.objects}
        self.inspection = imported.inspection
        self.targets = {name: set(ids) for name, ids in imported.bindings["contact_targets"].items()}
        self.targets.update({name: set(parts.values()) for name, parts in imported.bindings["geoms"].items()})
        self.targets["robot"] = set(imported.bindings["platform_groups"]["robot"])
        # Ownership includes the floor; the longstanding table support target
        # means the actual table, not everything owned by that platform group.
        table_ids = imported.bindings["platform_groups"]["table"]
        import mujoco

        self.targets["table"] = {
            g for g in table_ids if mujoco.mj_id2name(imported.model, mujoco.mjtObj.mjOBJ_GEOM, g) == "table"
        }
        if len(self.targets["table"]) != 1:
            raise ValueError("the trusted Panda needs one exact table collision geom")
        self.ngeom = imported.model.ngeom
        self.success = profile_catalog()["success"]
        self.shapes = {}
        for name, obj in self.objects.items():
            asset_in_body = pose_matrix(obj["asset_pose_in_body"])
            parts = []
            for shape in self.inspection[name]["collision_shapes"]:
                kind = shape["kind"]
                transform = asset_in_body @ np.asarray(shape["pose"])
                part = {"kind": kind, "transform": transform, "size": shape["size"]}
                if kind == "mesh":
                    # These native hull vertices already include the part pose.
                    vertices = np.asarray(shape["vertices"])
                    part["vertices"] = vertices @ asset_in_body[:3, :3].T + asset_in_body[:3, 3]
                elif kind == "box":
                    vertices = np.asarray(list(itertools.product(*[(-s, s) for s in shape["size"]])))
                    part["vertices"] = vertices @ transform[:3, :3].T + transform[:3, 3]
                parts.append(part)
            self.shapes[name] = parts

    def valid(self, state, definition):
        if not valid_state(state, definition):
            return False
        try:
            return all(
                type(c["id"]) is int
                and c["id"] >= 0
                and all(type(c[k]) is int and 0 <= c[k] < self.ngeom for k in ("geom1", "geom2"))
                and len(c["normal_on_b"]) == 3
                and all(math.isfinite(v) for v in c["normal_on_b"])
                for c in state["contacts"]
            )
        except (KeyError, TypeError, ValueError):
            return False

    def projection_radius(self, name, state, target):
        body_rotation = rotation(state["orientations"][name])
        center = np.asarray(state["positions"][name])
        target = np.asarray(target)
        radii = []
        for part in self.shapes[name]:
            kind = part["kind"]
            if "vertices" in part:
                points = part["vertices"] @ body_rotation.T + center
                radii.append(float(np.linalg.norm(points[:, :2] - target, axis=1).max()))
                continue
            transform = part["transform"]
            part_center = (body_rotation @ transform[:3, 3] + center)[:2] - target
            radius = part["size"][0]
            if kind == "sphere":
                radii.append(float(np.linalg.norm(part_center)) + radius)
                continue
            axes = body_rotation @ transform[:3, :3]
            half = part["size"][1]
            if kind == "capsule":
                radii.append(
                    max(float(np.linalg.norm(part_center + sign * half * axes[:2, 2])) for sign in (-1, 1)) + radius
                )
            elif abs(float(axes[2, 2])) > 1 - 1e-12:
                radii.append(float(np.linalg.norm(part_center)) + radius)
            else:
                radii.append(
                    max(
                        _ellipse_radius(
                            part_center + sign * half * axes[:2, 2], radius * axes[:2, 0], radius * axes[:2, 1]
                        )
                        for sign in (-1, 1)
                    )
                )
        return max(radii)

    def support(self, name, state, direction):
        direction = np.asarray(direction, dtype=float)
        body_rotation = rotation(state["orientations"][name])
        local = body_rotation.T @ direction
        offsets = []
        for part in self.shapes[name]:
            if "vertices" in part:
                offsets.append(float(np.max(part["vertices"] @ local)))
                continue
            transform = part["transform"]
            point = float(transform[:3, 3] @ local)
            axis = transform[:3, :3].T @ local
            radius = part["size"][0]
            if part["kind"] == "sphere":
                extent = radius * float(np.linalg.norm(axis))
            elif part["kind"] == "capsule":
                extent = part["size"][1] * abs(float(axis[2])) + radius * float(np.linalg.norm(axis))
            else:
                extent = part["size"][1] * abs(float(axis[2])) + radius * float(np.linalg.norm(axis[:2]))
            offsets.append(point + extent)
        return float(np.asarray(state["positions"][name]) @ direction) + max(offsets)

    def center(self, name, state):
        return [(self.support(name, state, axis) - self.support(name, state, -axis)) / 2 for axis in np.eye(3)]

    def pose_error(self, name, current, target):
        obj = self.objects[name]
        asset_rotation = pose_matrix(obj["asset_pose_in_body"])[:3, :3]
        first, second = rotation(current) @ asset_rotation, rotation(target) @ asset_rotation
        symmetry = self.inspection[name]["asset"]["symmetry"]
        if symmetry["category"] == "isotropic":
            return 0.0
        if symmetry["category"] == "axial_unsigned":
            axis = np.asarray(symmetry["axis_xyz"])
            return math.acos(np.clip(abs(float((first @ axis) @ (second @ axis))), -1, 1))
        cosine = max((float(np.trace(first.T @ second @ rotation(q))) - 1) / 2 for q in symmetry["rotations_xyzw"])
        return math.acos(np.clip(cosine, -1, 1))

    def contacts(self, state, name, other):
        first, second = self.targets[name], self.targets[other]
        seen = set()
        for contact in state["contacts"]:
            key = (contact["id"], contact["geom1"], contact["geom2"])
            if key in seen:
                continue
            seen.add(key)
            if contact["geom1"] in first and contact["geom2"] in second:
                yield contact, -1
            elif contact["geom2"] in first and contact["geom1"] in second:
                yield contact, 1

    def evaluate(self, predicate, state, definition):
        kind = predicate["type"]

        def recurse(p):
            return self.evaluate(p, state, definition)

        if kind == "all":
            return all(recurse(p) for p in predicate["children"])
        if kind == "any":
            return any(recurse(p) for p in predicate["children"])
        if kind == "not":
            return not recurse(predicate["child"])
        zones = {z["id"]: z for z in definition["zones"]}
        if kind == "matching":
            slots = [z for z in predicate["zone_ids"] for _ in range(zones[z]["capacity"])]
            assigned = {}

            def assign(name, visited):
                for i, zone in enumerate(slots):
                    if i in visited or not recurse({"type": "in_zone", "object_id": name, "zone_id": zone}):
                        continue
                    visited.add(i)
                    if i not in assigned or assign(assigned[i], visited):
                        assigned[i] = name
                        return True
                return False

            return all(assign(name, set()) for name in predicate["object_ids"])
        name = predicate["object_id"]
        if kind == "in_zone":
            zone = zones[predicate["zone_id"]]
            return (
                self.objects[name]["asset"] in zone["accepts"]
                and self.projection_radius(name, state, zone["position"]) <= zone["radius_m"]
            )
        if kind == "pose":
            return (
                self.pose_error(name, state["orientations"][name], predicate["quaternion"])
                <= self.success["pose_tolerance_rad"]
            )
        if kind == "stable":
            return (
                math.dist(state["linear_velocities"][name], [0, 0, 0]) <= self.success["max_linear_speed_m_s"]
                and math.dist(state["angular_velocities"][name], [0, 0, 0]) <= self.success["max_angular_speed_rad_s"]
            )
        if kind == "released":
            fingers = [state.get("joints", {}).get(f"franka/panda_finger_joint{i}", -1) for i in (1, 2)]
            return all(
                type(v) in (int, float) and math.isfinite(v) and v >= self.success["finger_open_min_m"] for v in fingers
            ) and recurse({"type": "no_contact", "object_id": name, "other_id": "robot"})
        if kind == "no_contact":
            return not any(
                c["distance_m"] <= 0 or math.dist(c["force_on_b"], [0, 0, 0]) > self.success["contact_force_min_n"]
                for c, _ in self.contacts(state, name, predicate["other_id"])
            )
        if kind == "supported_by":
            center = state["centers_of_mass"][name]
            upward = sum(
                sign * c["force_on_b"][2]
                for c, sign in self.contacts(state, name, predicate["support_id"])
                if sign * c["force_on_b"][2] > 0 and sign * c["normal_on_b"][2] >= 0.5 and c["point"][2] <= center[2]
            )
            return upward >= self.inspection[name]["mass_kg"] * 9.81 * self.success["support_min_weight_fraction"]
        raise ValueError(f"unknown scene predicate {kind!r}")
