"""Replay published reference tools and measure headroom before a new model run."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from agent_harness.canonical import canonical_sha256
from task_source.tool_reference import verify_tool_reference


def calibrate(task, source, contract, config_digest, *, reserve_fraction=0.25):
    if type(reserve_fraction) not in (int, float) or not math.isfinite(reserve_fraction) or reserve_fraction <= 0:
        raise ValueError("calibration reserve_fraction must be positive and finite")
    proof = verify_tool_reference(task, source, {"config_digest": config_digest, "execution_contract": contract})
    budget = contract["budget"]
    rows = []
    for row in proof.get("instances", []):
        calls = len(row["tool_actions"])
        steps = row["steps"]
        wall = row["wall_s"]
        required = {
            "max_api_calls": calls + max(1, math.ceil(calls * reserve_fraction)),
            "max_steps": steps + max(1, math.ceil(steps * reserve_fraction)),
            "wall_seconds": wall * (1 + reserve_fraction),
        }
        rows.append({
            "instance": row["instance"],
            "reference_calls": calls,
            "reference_steps": steps,
            "reference_wall_s": wall,
            "minimum_with_correction_margin": required,
            "within_frozen_budget": all(budget[key] >= value for key, value in required.items()),
        })
    result = {
        "format": "a-budget-calibration/v1",
        "task_id": task.task_id,
        "package_digest": proof.get("package_digest"),
        "config_digest": config_digest,
        "execution_contract": contract,
        "reserve_fraction": reserve_fraction,
        "reference_verified": proof.get("verified") is True,
        "reference_reason": proof.get("reason"),
        "instances": rows,
        "ready": proof.get("verified") is True
        and bool(rows)
        and len(rows) == len(task.instances)
        and all(row["within_frozen_budget"] for row in rows),
    }
    result["sha256"] = canonical_sha256(result)
    return result


def main(argv=None):
    from agent_harness import parse_spec
    from agent_harness.runtimes import load_task
    from task_source.panel_state import write

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--reserve-fraction", type=float, default=0.25)
    args = parser.parse_args(argv)
    raw = json.loads(args.spec.read_text())
    spec = parse_spec(raw)
    source, task = load_task(spec)
    result = calibrate(
        task,
        source,
        raw["panel_binding"]["execution_contract"],
        raw["panel_binding"]["config_digest"],
        reserve_fraction=args.reserve_fraction,
    )
    write(args.output, result, exclusive=True)
    print(json.dumps({"ready": result["ready"], "sha256": result["sha256"], "instances": result["instances"]}))
    return 0 if result["ready"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
