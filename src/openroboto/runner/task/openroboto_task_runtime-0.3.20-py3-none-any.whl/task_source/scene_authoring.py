"""Schema-3 local authoring on immutable E and private P, never business models.

The explicit author script runs only locally. Replays execute recorded JSON tools
and native nine-joint targets; worker admission never executes author code.
Reports are private diagnostics outside E/P, not server admission receipts.
"""

from __future__ import annotations

import contextlib
import importlib.util
import inspect
import itertools
import json
import math
import os
from pathlib import Path
import time

from openroboto_protocol.tabletop_assets import canonical_digest

from .base import RuntimeUnavailable, TaskSourceError
from .scene_env import SceneDeadlineExceeded
from .scene_views import (
    SceneViewError,
    load_private_reference,
    materialize_execution,
    reference_identity,
    verify_admission_view,
    write_private_reference,
)


class SceneAuthoringError(TaskSourceError):
    def __init__(self, code, *, capability="invalid_package"):
        self.code, self.capability = code, capability
        super().__init__(code)


def public_summary(result):
    """CLI channel excludes raw proof, checker diagnostics and exception text."""
    allowed = {
        "ok",
        "accepted",
        "reference_ready",
        "capability",
        "code",
        "instances",
        "steps",
        "report_path",
        "private_root",
        "manifest_path",
        "evidence",
        "server_admission",
        "reward_status",
        "business_model_calls",
        "wall_s",
        "physical_checks_complete",
    }
    return {key: result[key] for key in sorted(allowed & result.keys())}


def _json(value):
    return json.loads(json.dumps(value, allow_nan=False))


def _write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w") as file:
        json.dump(value, file, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        file.write("\n")


def _outputs(execution, private, manifest, report):
    paths = [Path(p).absolute() for p in (execution, private, manifest, report)]
    e, p, m, r = [path.resolve() for path in paths]
    evidence = r.with_suffix(r.suffix + ".evidence")
    for a, b in itertools.combinations((e, p, m, r, evidence), 2):
        if a == b or a.is_relative_to(b) or b.is_relative_to(a):
            raise SceneAuthoringError("output_layout_invalid", capability="resource_unavailable")
    for path in (paths[3], evidence):
        if path.exists() or path.is_symlink():
            raise SceneAuthoringError("output_exists", capability="resource_unavailable")
    evidence.mkdir(parents=True, exist_ok=False, mode=0o700)
    return e, p, m, r, evidence


def _timeout(timeout_s):
    if type(timeout_s) not in (int, float) or not math.isfinite(timeout_s) or timeout_s <= 0:
        raise SceneAuthoringError("invalid_local_timeout", capability="resource_unavailable")
    return time.monotonic() + timeout_s


@contextlib.contextmanager
def source_deadline(source, deadline):
    previous = source.scene_deadline
    source.scene_deadline = min(previous, deadline)
    try:
        yield
    finally:
        source.scene_deadline = previous


def _source(execution, *, reference=None, deadline=math.inf):
    from .axis import AxisSource
    from .scene_runtime import import_context

    return AxisSource({
        "package_root": str(execution),
        "scene_context": import_context(),
        "scene_reference": reference,
        "scene_deadline": deadline,
    })


def _task(source):
    packages = source._packages()
    if len(packages) != 1:
        raise SceneAuthoringError("scene_execution_root_required")
    package = next(iter(packages.values()))
    if "scene" not in package.task or package.task.get("schema_version") != 3:
        raise SceneAuthoringError("scene_schema_required")
    return source.load_task(package.task_id)


def _identity(task):
    from .scene_runtime import RUNTIME_VERSION, registry_document
    from .scene_observation import policy_identity, policy_document, require_policy_scope
    from .scene_instruction_runtime import policy_identity as instruction_identity

    require_policy_scope(task)
    return {
        "runtime_version": RUNTIME_VERSION,
        "execution_profile": task.metadata["execution_profile"],
        "environment": task.metadata["environment"],
        "registry": registry_document(),
        "execution_contract": task.metadata["execution_contract"],
        "execution_package_digest": task.metadata["execution_package_digest"],
        "source": "native_mujoco_local_cpu",
        "observation_admission_policy": {**policy_identity(), "configuration": policy_document()},
        "instruction_admission_policy": instruction_identity(),
    }


def _error(exc):
    from .scene_import import SceneImportError
    from .scene_instruction_runtime import SceneInstructionError
    from .scene_observation import SceneObservationPolicyError

    if isinstance(exc, SceneDeadlineExceeded):
        return {"code": "runtime.timeout", "capability": "resource_unavailable"}
    if isinstance(exc, SceneAuthoringError):
        return {"code": exc.code, "capability": exc.capability}
    if isinstance(exc, SceneInstructionError):
        return {"code": exc.code, "capability": exc.capability, "instruction": exc.finding}
    if isinstance(exc, SceneObservationPolicyError):
        return {"code": exc.code, "capability": "resource_unavailable"}
    if isinstance(exc, SceneViewError):
        return {"code": exc.code, "capability": exc.status}
    if isinstance(exc, SceneImportError):
        return {"code": exc.issues[0].code, "capability": exc.status}
    if isinstance(exc, RuntimeUnavailable):
        if str(exc) == "scene_observation_policy_scope_unregistered":
            return {"code": str(exc), "capability": "resource_unavailable"}
        return {"code": "scene_runtime_unavailable", "capability": "resource_unavailable"}
    if isinstance(exc, OSError):
        return {"code": "scene_authoring_io", "capability": "resource_unavailable"}
    if isinstance(exc, TaskSourceError):
        return {"code": "scene_recording_failed", "capability": "failed"}
    return {"code": "scene_authoring_crash", "capability": "resource_unavailable"}


def _load_solver(script, roots):
    script = Path(script).resolve()
    if not script.is_file() or any(script.is_relative_to(root) for root in roots):
        raise SceneAuthoringError("external_reference_script_required")
    spec = importlib.util.spec_from_file_location("explicit_local_scene_solution", script)
    if spec is None or spec.loader is None:
        raise SceneAuthoringError("reference_script_unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not callable(getattr(module, "solve", None)):
        raise SceneAuthoringError("reference_solve_required")
    return module.solve


@contextlib.contextmanager
def private_author_stdio(evidence):
    """Author prints are private diagnostics, never the CLI JSON channel."""
    path = Path(evidence) / "author-stdio.log"
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w") as stream:
        with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
            yield


def _record_instance(task, source, instance, solve, evidence, *, max_steps):
    from agent_harness.runtimes import AxisToolRuntime
    from .execution_contract import verify_execution_runtime
    from .tool_reference import _tool_action

    budget = task.metadata["execution_contract"]["budget"]
    actions, tools = [], []
    attempted_control = None
    started = time.monotonic()
    runtime = None
    outcome = {"instance": instance.instance, "state_id": instance.metadata["scene_state_id"], "success": False}
    try:
        with source_deadline(source, started + budget["wall_seconds"]):
            runtime = AxisToolRuntime(task, instance.instance, source, max_steps=budget["max_steps"])
        outcome["execution_runtime"] = verify_execution_runtime(task.metadata["execution_contract"], runtime)
        original_step = runtime.env.step

        def capture_step(action):
            nonlocal attempted_control
            if len(actions) >= max_steps:
                raise SceneAuthoringError("reference_step_budget", capability="failed")
            values = [float(v) for v in action]
            attempted_control = values
            result = original_step(action)
            actions.append(values)
            attempted_control = None
            return result

        runtime.env.step = capture_step
        depth = 0

        def tool_wrapper(name, method):
            signature = inspect.signature(method)

            def invoke(*args, **kwargs):
                nonlocal depth
                outer = depth == 0
                if outer:
                    runtime.env.check_deadline()
                    if len(tools) >= budget["max_api_calls"]:
                        raise SceneAuthoringError("reference_tool_budget", capability="failed")
                    bound = signature.bind(*args, **kwargs)
                    bound.apply_defaults()
                    request = {"name": name, "args": _json(dict(bound.arguments))}
                    _tool_action(request)
                    tools.append(request)
                depth += 1
                try:
                    return method(*args, **kwargs)
                finally:
                    depth -= 1

            return invoke

        for name in ("observe", "move_to", "grasp", "release", "step"):
            setattr(runtime, name, tool_wrapper(name, getattr(runtime, name)))
        solve(runtime, task, instance.instance)
        runtime.env.check_deadline()
        success, detail = runtime.success()
        outcome.update(success=bool(success), checker_detail=dict(detail))
        if not actions or not tools or success is not True:
            raise SceneAuthoringError("reference_instance_failed", capability="failed")
    finally:
        outcome.update(actions=actions, tool_actions=tools, wall_s=time.monotonic() - started)
        if runtime is not None:
            outcome["final_state"] = dict(runtime.env.state())
            outcome["instruction_delivery"] = getattr(runtime.env, "instruction_finding", None)
            outcome["charged_control_steps"] = runtime.step_count
            outcome["attempted_control_action"] = attempted_control
            runtime.close()
        _write(evidence / f"record-instance-{instance.instance}.json", outcome)
    return {
        "state_id": outcome["state_id"],
        "actions": actions,
        "tool_actions": tools,
        "final_state": outcome["final_state"],
        "success": outcome["success"],
    }


def record_reference(
    execution_root,
    *,
    script,
    private_root,
    manifest_path,
    report_path,
    timeout_s=900.0,
    max_reference_steps=None,
):
    """Record all frozen states, verify tools independently, create NEW P+manifest.

    max_reference_steps is an optional LOWER local exploration cap; it never
    raises the contract budget. A fresh report/evidence/P/manifest is required.
    Returns a public-safe summary; full attempts/proof are private files.
    """
    e, p, m, report, evidence = _outputs(execution_root, private_root, manifest_path, report_path)
    started = time.monotonic()
    result = {"ok": False, "reference_ready": False, "server_admission": "not_run", "business_model_calls": 0}
    try:
        if p.exists() or p.is_symlink() or m.exists() or m.is_symlink():
            raise SceneAuthoringError("output_exists", capability="resource_unavailable")
        source = _source(e, deadline=_timeout(timeout_s))
        task = _task(source)
        result.update(_identity(task))
        from .scene_instruction_runtime import require_task

        result["instruction"] = require_task(task)
        limit = task.metadata["execution_contract"]["budget"]["max_steps"]
        if max_reference_steps is not None:
            if type(max_reference_steps) is not int or not 0 < max_reference_steps <= limit:
                raise SceneAuthoringError("invalid_local_step_cap", capability="resource_unavailable")
            limit = max_reference_steps
        rows, failures = {}, []
        with private_author_stdio(evidence):
            solve = _load_solver(script, (e, p))
            for instance in task.instances:
                try:
                    rows[instance.instance] = _record_instance(task, source, instance, solve, evidence, max_steps=limit)
                except SceneDeadlineExceeded:
                    # A depleted shared deadline cannot authorize another reset.
                    raise
                except Exception as exc:
                    failures.append({"instance": instance.instance, **_error(exc), "detail": str(exc)})
        result["record_attempts"] = [
            {"instance": instance.instance, "success": instance.instance in rows} for instance in task.instances
        ]
        if failures:
            _write(evidence / "failed-instances.json", failures)
            capability = (
                "resource_unavailable" if any(f["capability"] == "resource_unavailable" for f in failures) else "failed"
            )
            raise SceneAuthoringError("reference_instances_failed", capability=capability)
        view = finalize_recordings(task, source, rows, private_root=p, manifest_path=m, evidence=evidence)
        result.update(
            ok=True,
            reference_ready=True,
            instances=len(rows),
            submission=view.execution.manifest,
            steps={str(k): len(row["actions"]) for k, row in rows.items()},
            capability="local_physics",
        )
    except Exception as exc:
        result.update(_error(exc))
        _write(evidence / "failure.json", {**_error(exc), "type": type(exc).__name__, "detail": str(exc)})
    result.update(
        report_path=str(report),
        private_root=str(p),
        manifest_path=str(m),
        evidence=str(evidence),
        wall_s=time.monotonic() - started,
    )
    _write(report, result)
    return result


def finalize_recordings(task, source, rows, *, private_root, manifest_path, evidence):
    """Same finalizer for one-shot CLI recording and registered staged research.

    Rows alone never earn a private binding. All frozen states must be solved
    again through the formal tools and match the recorded controls/terminal
    state exactly, under the same E/runtime/budget identity.
    """
    p, m = Path(private_root), Path(manifest_path)
    # Independent reset, formal tool dispatch, original observation/render,
    # identical native controls and final state are all required before P.
    from dataclasses import replace
    from .tool_reference import verify_tool_reference
    from .scene_observation import policy_document
    from .scene_instruction_runtime import policy_identity as instruction_identity, require_task

    instruction_binding = require_task(task)

    reference = {"schema_version": 1, "task_id": task.task_id, "instances": {str(k): v for k, v in rows.items()}}
    # The explicit local solver can access Python objects; independent proof
    # must not inherit any mutable native model it touched. Reload the frozen
    # execution bytes through the same trusted importer and exact registry.
    proof_source = _source(task.package_dir, deadline=source.scene_deadline)
    proof_task = _task(proof_source)
    for key in ("execution_package_digest", "scene_import_digest", "environment", "execution_contract"):
        if proof_task.metadata[key] != task.metadata[key]:
            raise SceneAuthoringError("reference_execution_changed")
    reference_task = replace(proof_task, reference=reference)
    proof = verify_tool_reference(
        reference_task,
        proof_source,
        {
            "execution_contract": task.metadata["execution_contract"],
            "config_digest": canonical_digest({
                "scope": "local-scene-authoring/1",
                "runtime": task.metadata["environment"],
                "observation_policy": policy_document(),
                "instruction_policy": instruction_identity(),
                "instruction_binding": instruction_binding,
            }),
        },
        deadline=source.scene_deadline,
    )
    _write(evidence / "tool-reference-proof.json", proof)
    if proof.get("resource_error") is not None:
        raise SceneDeadlineExceeded("scene independent tool proof exceeded its actual wall deadline")
    if proof["verified"] is not True:
        raise SceneAuthoringError("reference_tool_proof_failed", capability="failed")
    view = write_private_reference(
        task.package_dir,
        expected_execution_digest=task.metadata["execution_package_digest"],
        instances=rows,
        private_root=p,
        manifest_path=m,
        evidence_files={
            "tool-reference-proof.json": json.dumps(
                proof, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
            ).encode()
        },
    )
    load_private_reference(view)
    return view


def self_test(execution_root, private_root, manifest, *, expected_submission_digest, report_path, timeout_s=180.0):
    """Real all-state reference/repeat/noise/nop/visibility/tool verification.

    The local physics result does not claim semantic review, dedup, trusted
    server admission or reward eligibility. Default registered noise is reused.
    """
    manifest_path = (
        Path(manifest) if not isinstance(manifest, dict) else Path(report_path).with_suffix(".input-manifest")
    )
    e, p, _, report, evidence = _outputs(execution_root, private_root, manifest_path, report_path)
    started = time.monotonic()
    result = {
        "ok": False,
        "accepted": False,
        "server_admission": "not_run",
        "reward_status": "not_evaluated",
        "business_model_calls": 0,
        "scope": "local_physics_only",
        "physical_checks_complete": False,
    }
    try:
        submission = json.loads(manifest_path.read_bytes()) if not isinstance(manifest, dict) else manifest
        view = verify_admission_view(e, p, submission, expected_submission_digest=expected_submission_digest)
        reference = load_private_reference(view)
        deadline = _timeout(timeout_s)
        with materialize_execution(view.execution) as frozen:
            source = _source(frozen, reference=reference, deadline=deadline)
            task = _task(source)
            result.update(_identity(task))
            from .scene_instruction_runtime import require_task

            result["instruction"] = require_task(task)
            static = list(source.static_checks(task))
            _write(evidence / "static-checks.json", static)
            if not all(passed for _, passed, _ in static):
                raise SceneAuthoringError("scene_static_checks_failed")
            from .runtime import _noise_for, get_profile, run_scene_physics_checks

            policy = get_profile("axis-cpu")["runtime"]
            result["noise_policy"] = _noise_for(task, policy["noise"])
            calls = {}

            def replay_sink(instance, mode, replay):
                count = calls.get((instance, mode), 0)
                calls[(instance, mode)] = count + 1
                _write(
                    evidence / f"instance-{instance}-{mode}-{count}.json",
                    {
                        "mode": mode,
                        "state_digest": replay.state_digest,
                        "steps": replay.actions,
                        "visibility": replay.visibility,
                        "initial_state": replay.initial_state,
                        "final_state": replay.final_state,
                        "detail": dict(replay.detail),
                    },
                )

            source.scene_replay_sink = replay_sink
            checks = run_scene_physics_checks(
                task,
                source,
                deadline=deadline,
                config_digest=canonical_digest({"scope": "local-scene-authoring/1", "runtime": result["environment"]}),
                policy=policy,
            )
            proof = next(c.detail["tool_reference_proof"] for c in checks if c.name == "runtime.solvable")
            _write(evidence / "tool-reference-proof.json", proof)
            result.update(
                checks=[{"name": c.name, "passed": c.passed, "detail": dict(c.detail)} for c in checks],
                tool_reference_verified=proof["verified"],
                scene_reference_binding=reference_identity(view),
            )
            result["accepted"] = all(c.passed for c in checks) and proof["verified"] is True
            result.update(ok=True, capability="local_physics", physical_checks_complete=True)
        # Re-read original roots after execution. A changed E/P cannot retain an
        # apparently successful local report under the registered identity.
        verify_admission_view(e, p, submission, expected_submission_digest=expected_submission_digest)
    except Exception as exc:
        partial = getattr(exc, "partial_checks", ())
        if partial:
            result.update(
                checks=[{"name": c.name, "passed": c.passed, "detail": dict(c.detail)} for c in partial],
                tool_reference_verified=False,
            )
            proof = next(c.detail["tool_reference_proof"] for c in partial if c.name == "runtime.solvable")
            _write(evidence / "tool-reference-proof.json", proof)
        result.update(_error(exc), accepted=False)
        _write(evidence / "failure.json", {**_error(exc), "type": type(exc).__name__, "detail": str(exc)})
    result.update(report_path=str(report), evidence=str(evidence), wall_s=time.monotonic() - started)
    _write(report, result)
    return result
