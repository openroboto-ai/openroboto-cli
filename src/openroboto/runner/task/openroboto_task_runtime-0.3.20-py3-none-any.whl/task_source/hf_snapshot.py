"""Trusted HF download boundary shared by admission and frozen execution.

Only repository bytes enter the materialized tree. SDK cache metadata stays
outside it; repository dotfiles are retained and the digest rule is unchanged.
"""

from __future__ import annotations

import os
import pathlib
import shutil
import stat


class SnapshotError(Exception):
    def __init__(self, message: str, *, code: str = "unreadable"):
        super().__init__(message)
        self.code = code


def download_materialized_snapshot(
    repo_id: str,
    commit: str,
    destination: pathlib.Path,
    *,
    token: str | None = None,
    cache_dir: pathlib.Path | None = None,
) -> pathlib.Path:
    """Download at a fixed revision, then copy into a new ordinary-file tree."""
    try:
        from huggingface_hub import snapshot_download
    except ImportError as exc:
        raise SnapshotError("huggingface_hub is not installed", code="unavailable") from exc
    try:
        snapshot = snapshot_download(
            repo_id=repo_id,
            revision=commit,
            repo_type="model",
            token=token,
            cache_dir=str(cache_dir) if cache_dir is not None else None,
        )
    except Exception as exc:  # SDK errors are infrastructure failures.
        raise SnapshotError(
            f"cannot download {repo_id}@{commit[:12]}: {type(exc).__name__}: {exc}",
            code="unavailable",
        ) from exc
    return materialize_snapshot(pathlib.Path(snapshot), repo_id, commit, destination, cache_dir=cache_dir)


def materialize_snapshot(
    snapshot: pathlib.Path,
    repo_id: str,
    commit: str,
    destination: pathlib.Path,
    *,
    cache_dir: pathlib.Path | None = None,
) -> pathlib.Path:
    """Accept only snapshot -> repo blob [-> shared blob] file links."""
    from huggingface_hub.constants import HF_HUB_CACHE

    created = False
    try:
        if snapshot.is_symlink():
            raise SnapshotError("HF snapshot root must not be a symlink", code="unsafe_symlink")
        root = snapshot.resolve(strict=True)
        if not root.is_dir():
            raise SnapshotError("HF snapshot root is not a directory")
        trusted_cache = pathlib.Path(cache_dir or HF_HUB_CACHE).resolve()
        blob_root = None
        if (
            root.name == commit
            and root.parent.name == "snapshots"
            and root.parent.parent.name == f"models--{repo_id.replace('/', '--')}"
            and root.parent.parent.parent == trusted_cache
        ):
            blobs = root.parent.parent / "blobs"
            if blobs.is_dir() and not blobs.is_symlink():
                blob_root = blobs.resolve(strict=True)
        # Do not descend through directory aliases, including cycles.
        for current, directories, files in os.walk(root, followlinks=False):
            for name in directories + files:
                path = pathlib.Path(current) / name
                mode = path.lstat().st_mode
                if stat.S_ISLNK(mode):
                    if blob_root is None or not _is_hf_blob_link(path, blob_root, trusted_cache):
                        raise SnapshotError(
                            f"unsafe HF snapshot symlink: {path.relative_to(root)}",
                            code="unsafe_symlink",
                        )
                elif not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
                    raise SnapshotError(f"non-regular repository file: {path.relative_to(root)}")
        resolved_destination = destination.resolve()
        if resolved_destination.is_relative_to(root) or resolved_destination.is_relative_to(trusted_cache):
            raise SnapshotError("materialized package must be outside the HF snapshot and SDK cache")
        if destination.exists() or destination.is_symlink():
            raise SnapshotError("materialization destination already exists")
        destination.parent.mkdir(parents=True, exist_ok=True)
        created = True
        shutil.copytree(root, destination, symlinks=False)
        return destination.resolve()
    except (OSError, RuntimeError, shutil.Error, SnapshotError) as exc:
        if created:
            shutil.rmtree(destination, ignore_errors=True)
        if isinstance(exc, SnapshotError):
            raise
        raise SnapshotError(f"cannot materialize {repo_id}@{commit[:12]}: {exc}") from exc


def _is_hf_blob_link(path: pathlib.Path, blob_root: pathlib.Path, trusted_cache: pathlib.Path) -> bool:
    # Resolve '..' lexically first, without granting arbitrary host-file access.
    blob = pathlib.Path(os.path.abspath(path.parent / os.readlink(path)))
    if blob.parent != blob_root:
        return False
    if blob.is_symlink():
        target = pathlib.Path(os.path.abspath(blob.parent / os.readlink(blob)))
        shared = trusted_cache / "blobs"
        if shared.is_symlink() or not target.is_relative_to(shared):
            return False
        if target.is_symlink() or target.resolve(strict=True) != target:
            return False
        for parent in target.parents:
            if parent == shared:
                break
            if parent.is_symlink():
                return False
        blob = target
    return stat.S_ISREG(blob.lstat().st_mode)
