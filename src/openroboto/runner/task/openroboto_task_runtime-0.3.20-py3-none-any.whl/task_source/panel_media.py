"""Independent signed-episode video queue and native-resolution action replay."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import pathlib
import re
import subprocess
import shutil
from dataclasses import asdict, dataclass
from types import SimpleNamespace

from agent_harness.canonical import canonical_sha256
from benchmark_worker.reference_panel import parse_config
from task_source.panel_state import complete_reported_work, read, write, single_owner


class MediaRejected(ValueError):
    pass


@dataclass(frozen=True)
class VideoOptions:
    width: int = 1280
    height: int = 720
    fps: float | None = None
    camera_distance: float = 2.6
    camera_azimuth: float = 135
    camera_elevation: float = -25
    camera_lookat: tuple[float, float, float] = (0.35, 0.0, 0.85)
    lighting: str = "studio"
    shadow_samples: int = 4

    def validate(self):
        if type(self.width) is not int or type(self.height) is not int or self.width < 1280 or self.height < 720:
            raise MediaRejected("HD_NATIVE_DIMENSIONS_REQUIRED")
        if self.width % 2 or self.height % 2:
            raise MediaRejected("VIDEO_DIMENSIONS_MUST_BE_EVEN")
        if self.fps is not None and (not math.isfinite(self.fps) or self.fps <= 0):
            raise MediaRejected("VIDEO_FPS_INVALID")
        camera_values = (self.camera_distance, self.camera_azimuth, self.camera_elevation, *self.camera_lookat)
        if len(self.camera_lookat) != 3 or any(not math.isfinite(value) for value in camera_values):
            raise MediaRejected("VIDEO_CAMERA_INVALID")
        if self.camera_distance <= 0 or not -89 <= self.camera_elevation <= 89:
            raise MediaRejected("VIDEO_CAMERA_INVALID")
        if self.lighting not in ("scene", "studio") or self.shadow_samples not in (1, 4):
            raise MediaRejected("VIDEO_LIGHTING_INVALID")
        return self


def run_directory(state_root, work):
    return pathlib.Path(state_root) / "runs" / hashlib.sha256(work["run_id"].encode()).hexdigest()[:24]


def _member(work, member, trial):
    config = parse_config(work["config"])
    found = next((item for item in config.settlement.members if item.id == member), None)
    if (
        found is None
        or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", member)
        or type(trial) is not int
        or not 0 <= trial < work["trials_per_member"]
    ):
        raise MediaRejected("VIDEO_FROZEN_MEMBER_OR_TRIAL_INVALID")
    if config.digest != work["config_digest"] or config.version != work["config_version"]:
        raise MediaRejected("VIDEO_CONFIG_BINDING_INVALID")
    return config, found


def signed_episode(directory, work, member, trial, public_key):
    from task_source.panel_report import episode_row
    from agent_evidence.signing import build_bundle

    config, designated = _member(work, member, trial)
    raw = read(directory / "specs" / f"{member}-{trial}.json")
    result = read(directory / "results" / f"{member}-{trial}.json")
    task = work["task"]
    contract = config.execution_contract
    binding = raw.get("panel_binding", {})
    expected = {
        "run_id": work["run_id"],
        "panel": config.settlement_panel,
        "member": member,
        "trial": trial,
        "config_digest": config.digest,
        "config_version": config.version,
        "package_digest": task["package_digest"],
    }
    if any(binding.get(key) != value for key, value in expected.items()):
        raise MediaRejected("VIDEO_EPISODE_BINDING_MISMATCH")
    if (
        raw.get("agent") != contract["agent"]
        or raw.get("budget") != contract["budget"]
        or raw.get("permissions") != contract["permissions"]
        or raw.get("timing") != contract["timing"]
    ):
        raise MediaRejected("VIDEO_EXECUTION_CONTRACT_MISMATCH")
    for key, expected_value in (
        ("task_id", task["task_id"]),
        ("source", task["source"]),
        ("version_digest", task["package_digest"]),
        ("package_repo", task["package_repo"]),
        ("package_commit", task["package_commit"]),
    ):
        if raw["task"].get(key) != expected_value:
            raise MediaRejected("VIDEO_PACKAGE_BINDING_MISMATCH")
    if (
        raw["model"].get("provider") != designated.provider
        or raw["model"].get("model") != designated.model
        or raw["model"].get("effort") != designated.effort
    ):
        raise MediaRejected("VIDEO_MODEL_BINDING_MISMATCH")
    path = directory / "episodes" / f"{config.settlement_panel}-{member}-{trial}.jsonl"
    if raw["evidence"]["path"] != str(path):
        raise MediaRejected("VIDEO_EVIDENCE_PATH_MISMATCH")
    row = episode_row(raw, result, SimpleNamespace(**public_key))
    root = read(path.with_name(path.name + ".root.json"))
    if read(path.with_name(path.name + ".bundle.json")) != build_bundle([root], mode="single"):
        raise MediaRejected("VIDEO_ROOT_BUNDLE_MISMATCH")
    return raw, result, row


def enqueue_video(state_root, directory, work, member, trial, public_key, *, variant=None, render_options=None):
    raw, result, row = signed_episode(directory, work, member, trial, public_key)
    identity = {
        "run_id": work["run_id"],
        "member": member,
        "trial": trial,
        "source_child_root": row["child_root"],
        "events_digest": row["events_digest"],
    }
    snapshot = None
    if render_options is not None:
        snapshot = json.loads(json.dumps(asdict(VideoOptions(**render_options).validate()), allow_nan=False))
        snapshot_digest = canonical_sha256(snapshot)
        if variant is not None and variant != snapshot_digest:
            raise MediaRejected("MEDIA_VARIANT_OPTIONS_MISMATCH")
        variant = snapshot_digest
    if variant is not None and (not isinstance(variant, str) or not re.fullmatch(r"[0-9a-f]{64}", variant)):
        raise MediaRejected("MEDIA_VARIANT_INVALID")
    item_id = canonical_sha256({**identity, "variant": variant} if variant is not None else identity)
    path = pathlib.Path(state_root) / "media" / "items" / (item_id + ".json")
    if path.exists():
        old = read(path)
        if old["identity"] != identity or old.get("variant") != variant or old.get("render_options") != snapshot:
            raise MediaRejected("MEDIA_QUEUE_CONFLICT")
        return path
    version = {"variant": variant, "render_options": snapshot} if variant is not None else {}
    write(
        path,
        {
            "identity": identity,
            "directory": str(directory),
            "public_key": public_key,
            "status": "pending",
            "attempts": 0,
            **version,
        },
        exclusive=True,
    )
    return path


class NativeCamera:
    """A copied model/data and separate renderer leave agent observations untouched."""

    def __init__(self, runtime, options):
        import mujoco
        from PIL import Image

        self.mujoco = mujoco
        self.image = Image
        self.output_size = (options.width, options.height)
        self.model = copy.copy(runtime.env.model)
        render_width, render_height = options.width * 2, options.height * 2
        self.model.vis.global_.offwidth = max(self.model.vis.global_.offwidth, render_width)
        self.model.vis.global_.offheight = max(self.model.vis.global_.offheight, render_height)
        self.model.vis.quality.numslices = 128
        self.model.vis.quality.numstacks = 64
        self.model.vis.quality.shadowsize = 8192
        self.data = mujoco.MjData(self.model)
        self.renderer = mujoco.Renderer(self.model, render_height, render_width)
        self.camera = mujoco.MjvCamera()
        self.camera.type = mujoco.mjtCamera.mjCAMERA_FREE
        self.camera.lookat[:] = options.camera_lookat
        self.camera.distance = options.camera_distance
        self.camera.azimuth = options.camera_azimuth
        self.camera.elevation = options.camera_elevation
        self.runtime = runtime
        self.options = options

    def frame(self):
        self.mujoco.mj_copyData(self.data, self.model, self.runtime.env.data)
        self.renderer.update_scene(self.data, camera=self.camera)
        pixels = self.renderer.render() if self.options.lighting == "scene" else self._studio_frame()
        return self.image.fromarray(pixels).resize(self.output_size, self.image.Resampling.LANCZOS).tobytes()

    def _studio_frame(self):
        from task_source.panel_presentation import studio_frame

        return studio_frame(self.renderer, self.model, self.data, self.camera, self.options.shadow_samples)

    def close(self):
        self.renderer.close()


def render_episode(directory, work, member, trial, public_key, output, options=VideoOptions()):
    from agent_harness import parse_spec
    from agent_harness.runtimes import AxisToolRuntime, build_tool_runtime
    from agent_harness.tools import execute_tool, filter_observation, tools_digest
    from agent_harness.loop import evidence_observation
    from task_source.panel_transfer import file_identity

    options.validate()
    raw, result, row = signed_episode(directory, work, member, trial, public_key)
    if raw["agent"]["tools_digest"] != tools_digest():
        raise MediaRejected("REPLAY_TOOL_VERSION_UNAVAILABLE")
    # This projection is used solely to load the fixed physics/tools for replay.
    # The original agent block remains in signed_episode and all saved evidence.
    projection = copy.deepcopy(raw)
    projection.pop("agent")
    spec = parse_spec(projection, strict=False)
    runtime = build_tool_runtime(spec)
    if type(runtime) is not AxisToolRuntime:
        runtime.close()
        raise MediaRejected("HD_NATIVE_RUNTIME_UNAVAILABLE")
    fps = options.fps or 1.0 / float(runtime.env.control_period_s)
    if not math.isclose(fps, 1.0 / float(runtime.env.control_period_s), rel_tol=1e-9):
        runtime.close()
        raise MediaRejected("VIDEO_FPS_MUST_MATCH_CAPTURE_STEP_RATE")
    output = pathlib.Path(output)
    output.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    temporary = output.with_name(output.stem + ".partial.mp4")
    if temporary.exists():
        temporary.unlink()
    command = [
        "ffmpeg",
        "-nostdin",
        "-hide_banner",
        "-loglevel",
        "error",
        "-n",
        "-f",
        "rawvideo",
        "-pix_fmt",
        "rgb24",
        "-s",
        f"{options.width}x{options.height}",
        "-r",
        str(fps),
        "-i",
        "pipe:0",
        "-an",
        "-c:v",
        "libx264",
        "-crf",
        "20",
        "-pix_fmt",
        "yuv420p",
        "-movflags",
        "+faststart",
        str(temporary),
    ]
    frames, checks = 0, []
    camera = process = None
    events = row["events"]

    def check(observation, expected):
        actual = canonical_sha256(evidence_observation(filter_observation(observation, spec.sensors)))
        if actual != expected:
            raise MediaRejected("REPLAY_OBSERVATION_DIVERGED")
        checks.append(actual)

    def capture():
        nonlocal frames
        process.stdin.write(camera.frame())
        frames += 1

    try:
        initial = runtime.reset()
        observation = next(event["payload"] for event in events if event["type"] == "observation")
        check(initial, observation["observation_sha256"])
        camera = NativeCamera(runtime, options)
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        capture()
        original_step = runtime.env.step

        def step(action):
            outcome = original_step(action)
            capture()
            return outcome

        runtime.env.step = step
        calls = [event["payload"] for event in events if event["type"] == "tool_call"]
        results = [event["payload"] for event in events if event["type"] == "tool_result"]
        if len(calls) != len(results):
            raise MediaRejected("REPLAY_TOOL_RESULT_COUNT_MISMATCH")
        for call, expected in zip(calls, results, strict=True):
            if call.get("call_id") != expected.get("call_id") or call["name"] != expected["name"]:
                raise MediaRejected("REPLAY_TOOL_CORRELATION_MISMATCH")
            if not expected.get("ok"):
                try:
                    execute_tool(runtime, call["name"], call["args"])
                except Exception as error:
                    if f"{type(error).__name__}: {error}" != expected.get("error"):
                        raise MediaRejected("REPLAY_TOOL_ERROR_DIVERGED") from None
                else:
                    raise MediaRejected("REPLAY_TOOL_ERROR_DIVERGED")
                if expected.get("observation_sha256") is not None:
                    raise MediaRejected("REPLAY_ERROR_OBSERVATION_INVALID")
                continue
            outcome = execute_tool(runtime, call["name"], call["args"])
            check(outcome.observation, expected["observation_sha256"])
            if outcome.success != expected["success"] or outcome.steps != expected["steps"]:
                raise MediaRejected("REPLAY_TOOL_TERMINAL_MISMATCH")
        if runtime.success()[0] != events[-1]["payload"]["success"]:
            raise MediaRejected("REPLAY_FINAL_SUCCESS_MISMATCH")
        process.stdin.close()
        if process.wait(timeout=120) != 0:
            raise MediaRejected("VIDEO_ENCODER_FAILED")
        probe = json.loads(
            subprocess.check_output([
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=width,height,r_frame_rate,nb_frames:format=duration",
                "-of",
                "json",
                str(temporary),
            ])
        )
        stream = probe["streams"][0]
        if (stream["width"], stream["height"]) != (options.width, options.height):
            raise MediaRejected("VIDEO_ENCODED_DIMENSIONS_MISMATCH")
        temporary.rename(output)
        metadata = {
            **file_identity(output),
            "member": member,
            "trial": trial,
            "width": options.width,
            "height": options.height,
            "fps": fps,
            "duration_s": frames / fps,
            "source_kind": "recorded_actions_replay",
            "source_child_root": row["child_root"],
            "events_digest": row["events_digest"],
            "matched_observations": len(checks),
            "total_observations": 1 + sum(result.get("observation_sha256") is not None for result in results),
        }
        write(output.with_suffix(".json"), metadata, exclusive=True)
        return metadata
    finally:
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        if camera is not None:
            camera.close()
        runtime.close()


def process_media_item(state_root, item_path, work, client, *, options=VideoOptions(), renderer=render_episode):
    item = read(item_path)
    if item["status"] == "available":
        return "available"
    identity = item["identity"]
    if identity["run_id"] != work["run_id"]:
        raise MediaRejected("MEDIA_QUEUE_RUN_MISMATCH")
    directory = pathlib.Path(item["directory"])
    video = pathlib.Path(state_root) / "media" / "videos" / (item_path.stem + ".mp4")
    try:
        if item.get("render_options") is not None:
            options = VideoOptions(**item["render_options"]).validate()
        metadata_path = video.with_suffix(".json")
        if metadata_path.exists():
            from task_source.panel_transfer import file_identity

            metadata = read(metadata_path)
            if file_identity(video) != {key: metadata[key] for key in ("sha256", "bytes_len", "md5_b64")}:
                raise MediaRejected("RENDERED_VIDEO_CHANGED")
        else:
            metadata = renderer(
                directory, work, identity["member"], identity["trial"], item["public_key"], video, options
            )
        item.update(status="rendered", metadata=metadata)
        write(item_path, item)
        response = client.video_archive(
            work, video, pathlib.Path(state_root) / "media/transfers" / (item_path.stem + ".json"), metadata
        )
        if response.get("status") != "available" or response.get("sha256") != metadata["sha256"]:
            raise MediaRejected("MEDIA_COMMIT_UNCONFIRMED")
        item.update(status="available")
        item.pop("error_code", None)
        write(item_path, item)
        return "available"
    except Exception as error:
        item.update(attempts=item.get("attempts", 0) + 1, error_code=getattr(error, "code", "MEDIA_RETRY_REQUIRED"))
        write(item_path, item)
        return "retry"


def import_videos(root, directory, work, public_key, source):
    from task_source.panel_transfer import file_identity

    imported = 0
    for manifest in sorted(pathlib.Path(source).glob("*.json")):
        metadata = read(manifest)
        member, trial = metadata.get("member"), metadata.get("trial")
        if member is None or trial is None:
            continue
        path = manifest.with_suffix(".mp4")
        if path.is_symlink() or not path.is_file():
            raise MediaRejected("IMPORTED_VIDEO_FILE_MISSING")
        raw, result, row = signed_episode(directory, work, member, trial, public_key)
        identity = file_identity(path)
        if (
            metadata.get("sha256") != identity["sha256"]
            or metadata.get("bytes_len") != identity["bytes_len"]
            or metadata.get("source_child_root") != row["child_root"]
            or metadata.get("events_digest") != row["events_digest"]
            or metadata.get("source_kind") != "recorded_actions_replay"
            or metadata.get("matched_observations") != metadata.get("total_observations")
            or type(metadata.get("total_observations")) is not int
            or metadata["total_observations"]
            != 1
            + sum(
                event["type"] == "tool_result" and event["payload"].get("observation_sha256") is not None
                for event in row["events"]
            )
        ):
            raise MediaRejected("IMPORTED_VIDEO_BINDING_MISMATCH")
        probe = json.loads(
            subprocess.check_output([
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=width,height,r_frame_rate:format=duration",
                "-of",
                "json",
                str(path),
            ])
        )
        stream = probe["streams"][0]
        numerator, denominator = map(float, stream["r_frame_rate"].split("/"))
        if (
            stream["width"] != metadata.get("width")
            or stream["height"] != metadata.get("height")
            or stream["width"] < 1280
            or stream["height"] < 720
            or not math.isclose(numerator / denominator, metadata.get("fps", 0))
            or abs(float(probe["format"]["duration"]) - metadata.get("duration_s", 0)) > 1.0 / metadata["fps"]
        ):
            raise MediaRejected("IMPORTED_VIDEO_ENCODING_MISMATCH")
        item_path = enqueue_video(root, directory, work, member, trial, public_key, variant=identity["sha256"])
        item = read(item_path)
        if item["status"] == "available":
            if item["metadata"]["sha256"] != identity["sha256"]:
                raise MediaRejected("MEDIA_QUEUE_CONFLICT")
            continue
        target = pathlib.Path(root) / "media/videos" / (item_path.stem + ".mp4")
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if target.exists():
            if file_identity(target) != identity:
                raise MediaRejected("MEDIA_QUEUE_CONFLICT")
        else:
            shutil.copyfile(path, target)
        allowed = (
            "member",
            "trial",
            "width",
            "height",
            "fps",
            "duration_s",
            "source_kind",
            "source_child_root",
            "events_digest",
            "matched_observations",
            "total_observations",
        )
        saved = {**identity, **{key: metadata[key] for key in allowed}}
        write(target.with_suffix(".json"), saved)
        item.update(status="rendered", metadata=saved)
        write(item_path, item)
        imported += 1
    return imported


def load_work(root, client, run_id=None):
    state = read(root / "state.json")
    if not run_id or state.get("work", {}).get("run_id") == run_id:
        work, binding = state["work"], state["binding"]
    else:
        record = read(run_directory(root, {"run_id": run_id}) / "work.json")
        work, binding = record["work"], record["binding"]
    if (
        binding["backend"] != client.base_url
        or binding["worker_id"] != client.worker_id
        or binding["node_id"] != client.node_id
    ):
        raise MediaRejected("MEDIA_OWNER_SCOPE_MISMATCH")
    record_path = run_directory(root, work) / "work.json"
    if not record_path.exists():
        # Older workers kept only the current run in state.json. Retain its
        # owner binding before the evaluation worker can claim another run.
        write(record_path, {"work": work, "binding": binding})
    return work


def rebuild_report(directory, work, signer, node_id):
    from benchmark_worker.reference_panel.manifest import verify_manifest
    from task_source.panel_report import build_report

    original = read(directory / "report.json")
    if original["manifest"]["key_id"] != signer.key_id or not verify_manifest(
        original["manifest"], signer.public_key_hex
    ):
        raise MediaRejected("REPORT_ORIGINAL_MANIFEST_INVALID")
    config = parse_config(work["config"])
    public = {"key_id": signer.key_id, "public_key_hex": signer.public_key_hex}
    for trial in range(work["trials_per_member"]):
        for member in config.settlement.members:
            signed_episode(directory, work, member.id, trial, public)
    rebuilt = build_report(work, config, directory, signer, node_id)

    def projection(report):
        return {
            **report,
            "manifest": None,
            "members": [
                {
                    **member,
                    "trials": [
                        {key: value for key, value in row.items() if key != "wall_ms"} for row in member["trials"]
                    ],
                }
                for member in report["members"]
            ],
        }

    if projection(original) != projection(rebuilt):
        raise MediaRejected("REPORT_REBUILD_CHANGED_ORIGINAL_FIELDS")
    encoded = json.dumps(rebuilt, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()
    digest = hashlib.sha256(encoded).hexdigest()
    path = directory / f"report-rebuilt-{digest}.json"
    if path.exists():
        if path.read_bytes() != encoded:
            raise MediaRejected("REPORT_REBUILD_CONTENT_CONFLICT")
    else:
        write(path, rebuilt, exclusive=True)
    return path


def main(argv=None):
    from agent_evidence.signing import Signer
    from task_source.panel_client import PanelAPIError, PanelClient
    from task_source.panel_worker import LeaseKeeper

    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("backend-url", "worker-id", "node-id", "state-root"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--signing-key", help="derive the trusted public key when supplementing an old run")
    parser.add_argument("--enqueue-existing", action="store_true")
    parser.add_argument("--import-videos", type=pathlib.Path, help="verify and enqueue pre-rendered MP4/JSON pairs")
    parser.add_argument(
        "--submit-report", action="store_true", help="upload saved original report only, without a model"
    )
    parser.add_argument(
        "--rebuild-report", action="store_true", help="rebuild a signed report revision from original episodes"
    )
    parser.add_argument("--run-id")
    parser.add_argument("--width", type=int, default=1280)
    parser.add_argument("--height", type=int, default=720)
    parser.add_argument("--fps", type=float)
    parser.add_argument("--camera-distance", type=float, default=2.6)
    parser.add_argument("--camera-azimuth", type=float, default=135)
    parser.add_argument("--camera-elevation", type=float, default=-25)
    parser.add_argument("--camera-lookat", type=float, nargs=3, default=(0.35, 0.0, 0.85))
    parser.add_argument("--lighting", choices=("scene", "studio"), default="studio")
    parser.add_argument("--shadow-samples", type=int, choices=(1, 4), default=4)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--poll-interval", type=float, default=30)
    parser.add_argument("--heartbeat-interval", type=float, default=30)
    args = parser.parse_args(argv)
    if not math.isfinite(args.heartbeat_interval) or args.heartbeat_interval < 1:
        parser.error("--heartbeat-interval must be finite and at least one second")
    if args.rebuild_report and not args.signing_key:
        parser.error("--rebuild-report requires the original registered --signing-key")
    root = pathlib.Path(args.state_root).resolve()
    os.environ.update(TASK_PACKAGE_CACHE=str(root / "packages"), HF_HUB_OFFLINE="1", HF_HUB_DISABLE_IMPLICIT_TOKEN="1")
    client = PanelClient(args.backend_url, os.environ.get("VALIDATOR_API_KEY", ""), args.worker_id, args.node_id)
    options = VideoOptions(
        args.width,
        args.height,
        args.fps,
        args.camera_distance,
        args.camera_azimuth,
        args.camera_elevation,
        tuple(args.camera_lookat),
        args.lighting,
        args.shadow_samples,
    ).validate()
    with single_owner(root / "media"):
        work = (
            load_work(root, client, args.run_id)
            if args.submit_report or args.rebuild_report or args.enqueue_existing or args.import_videos
            else None
        )
        directory = run_directory(root, work) if work else None
        report_path = directory / "report.json" if directory else None
        if args.rebuild_report:
            with single_owner(root):
                report_path = rebuild_report(directory, work, Signer.from_keyfile(args.signing_key), client.node_id)
            print(json.dumps({"rebuilt_report": str(report_path), "run_id": work["run_id"]}), flush=True)
            if not (args.submit_report or args.enqueue_existing or args.import_videos):
                return 0
        if args.submit_report:
            with single_owner(root):
                total = work["trials_per_member"] * len(
                    work["config"]["panels"][work["config"]["settlement_panel"]]["members"]
                )
                detail = {"completed_trials": total, "total_trials": total}
                report_stem = report_path.stem.removeprefix("report-rebuilt-")
                checkpoint = (
                    directory / "transfers" / (f"report-{report_stem}.json" if args.rebuild_report else "report.json")
                )
                response_path = directory / (
                    f"report-rebuilt-{report_stem}-archive-response.json"
                    if args.rebuild_report
                    else "report-archive-response.json"
                )
                try:
                    with LeaseKeeper(
                        client,
                        work,
                        directory / "report-lease.json",
                        args.heartbeat_interval,
                        stage="reporting",
                        detail=detail,
                        allow_models=False,
                    ) as lease:
                        response = client.report_archive(work, report_path, checkpoint)
                        if response.get("evidence_ok") is not True:
                            raise MediaRejected("REPORT_EVIDENCE_REJECTED")
                        write(response_path, response)
                    try:
                        lease.beat()
                    except Exception:
                        raise MediaRejected("REPORT_HEARTBEAT_FAILED") from None
                except Exception as error:
                    code = (
                        error.code
                        if isinstance(error, PanelAPIError)
                        else (str(error) if isinstance(error, MediaRejected) else "REPORT_UPLOAD_FAILED")
                    )
                    current = read(root / "state.json")
                    binding = read(directory / "work.json")["binding"]
                    if current.get("work") == work and current.get("binding") == binding:
                        current.update(phase="held", error_code=code)
                        write(root / "state.json", current)
                    try:
                        client.progress(work, "held", {**detail, "error_code": code})
                    except Exception:
                        pass
                    raise
                complete_reported_work(root, work, read(directory / "work.json")["binding"])
            print(json.dumps({"report_evidence_ok": response.get("evidence_ok"), "run_id": work["run_id"]}))
        if args.enqueue_existing or args.import_videos:
            if not args.signing_key:
                parser.error("--enqueue-existing requires the registered --signing-key")
            signer = Signer.from_keyfile(args.signing_key)
            public = {"key_id": signer.key_id, "public_key_hex": signer.public_key_hex}
            if args.enqueue_existing:
                config = parse_config(work["config"])
                render_options = asdict(options)
                variant = canonical_sha256(render_options)
                for trial in range(work["trials_per_member"]):
                    for member in config.settlement.members:
                        enqueue_video(
                            root,
                            directory,
                            work,
                            member.id,
                            trial,
                            public,
                            variant=variant,
                            render_options=render_options,
                        )
            if args.import_videos:
                print(json.dumps({"imported": import_videos(root, directory, work, public, args.import_videos)}))
        import time

        while True:
            totals = {"available": 0, "retry": 0}
            for path in sorted((root / "media/items").glob("*.json")):
                item = read(path)
                run_id = item["identity"]["run_id"]
                if not args.run_id or run_id == args.run_id:
                    item_work = load_work(root, client, run_id)
                    outcome = process_media_item(root, path, item_work, client, options=options)
                    totals[outcome] += 1
            print(json.dumps({"run_id": args.run_id, **totals}), flush=True)
            if args.once:
                return 0 if totals["retry"] == 0 else 2
            time.sleep(args.poll_interval)


if __name__ == "__main__":
    raise SystemExit(main())
