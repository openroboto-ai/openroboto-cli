"""Observer-only studio lighting and fixed display furniture."""

from __future__ import annotations

import numpy as np


def _geom(scene, kind, size, position, rgba, rotation=None):
    import mujoco

    if scene.ngeom >= scene.maxgeom:
        raise ValueError("Observer scene has no room for display furniture")
    geom = scene.geoms[scene.ngeom]
    mujoco.mjv_initGeom(
        geom,
        kind,
        np.asarray(size, dtype=float),
        np.asarray(position, dtype=float),
        np.eye(3).ravel() if rotation is None else rotation.ravel(),
        np.asarray(rgba, dtype=np.float32),
    )
    geom.category = mujoco.mjtCatBit.mjCAT_DECOR
    geom.objtype = mujoco.mjtObj.mjOBJ_UNKNOWN
    geom.objid = -1
    geom.specular = 0.12
    geom.shininess = 0.25
    scene.ngeom += 1


def studio_stage(scene, model, data, camera):
    """Display fixtures occupy the empty space below fixed robot/table mounts."""
    import mujoco

    for geom in scene.geoms[: scene.ngeom]:
        if geom.type == mujoco.mjtGeom.mjGEOM_PLANE:
            geom.rgba[:] = (0.62, 0.64, 0.67, 1.0)
    normal = np.asarray(scene.camera[0].pos, dtype=float) - np.asarray(camera.lookat)
    normal[2] = 0
    normal /= np.linalg.norm(normal)
    across = np.cross((0, 0, 1), normal)
    rotation = np.column_stack((across, np.cross(normal, across), normal))
    behind = np.asarray(camera.lookat) - normal * 5
    behind[2] = 2
    _geom(scene, mujoco.mjtGeom.mjGEOM_PLANE, (20, 20, 0.1), behind, (0.72, 0.74, 0.77, 1), rotation)
    scene.geoms[scene.ngeom - 1].emission = 0.35

    table = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, "table")
    if table >= 0 and model.geom_type[table] == mujoco.mjtGeom.mjGEOM_BOX:
        center, half = data.geom_xpos[table], model.geom_size[table]
        height = center[2] - half[2]
        if height > 0.1:
            for x in (-1, 1):
                for y in (-1, 1):
                    _geom(
                        scene,
                        mujoco.mjtGeom.mjGEOM_BOX,
                        (0.025, 0.025, height / 2),
                        (center[0] + x * (half[0] - 0.04), center[1] + y * (half[1] - 0.04), height / 2),
                        (0.35, 0.38, 0.42, 1),
                    )
    for body in range(1, model.nbody):
        name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, body) or ""
        if name.startswith("franka/") and model.body_parentid[body] == 0:
            base = data.xpos[body]
            if base[2] > 0.1:
                _geom(
                    scene,
                    mujoco.mjtGeom.mjGEOM_CYLINDER,
                    (0.13, base[2] / 2, 0),
                    (base[0], base[1], base[2] / 2),
                    (0.48, 0.51, 0.55, 1),
                )
            break


def studio_lights(scene, offset=(0.0, 0.0)):
    import mujoco

    scene.nlight = 3
    presets = (
        ((-0.7, -0.8, 3.0), (0.4 + offset[0], 0.5 + offset[1], -2.0), (0.22, 0.22, 0.23), (0.45, 0.44, 0.42), True),
        ((1.5, 0.8, 2.0), (-1.0, -0.5, -1.0), (0, 0, 0), (0.28, 0.30, 0.33), False),
        ((-0.5, 1.0, 2.5), (0.5, -0.7, -1.0), (0, 0, 0), (0.18, 0.18, 0.20), False),
    )
    for light, (position, direction, ambient, diffuse, shadow) in zip(scene.lights, presets):
        light.type = mujoco.mjtLightType.mjLIGHT_DIRECTIONAL
        light.headlight = False
        light.pos[:] = position
        light.dir[:] = np.asarray(direction) / np.linalg.norm(direction)
        light.ambient[:] = ambient
        light.diffuse[:] = diffuse
        light.specular[:] = (0.12, 0.12, 0.12)
        light.castshadow = shadow
        light.attenuation[:] = (1, 0, 0)
        light.cutoff, light.exponent = 90, 0


def studio_frame(renderer, model, data, camera, samples):
    studio_stage(renderer.scene, model, data, camera)
    offsets = (
        ((0.0, 0.0),)
        if samples == 1
        else (
            (-0.015, -0.015),
            (-0.015, 0.015),
            (0.015, -0.015),
            (0.015, 0.015),
        )
    )
    combined = None
    for offset in offsets:
        studio_lights(renderer.scene, offset)
        pixels = renderer.render().astype(np.float32)
        combined = pixels if combined is None else combined + pixels
    return np.clip(combined / len(offsets) + 0.5, 0, 255).astype(np.uint8)
