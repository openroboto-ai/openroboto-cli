"""Frozen R12 portable wire validation and original-journal reconciliation.

Rows supplied here by a parent reader MUST precede the HTTP transaction and
come from verified original spec/events/root/reservation receipts. Server rows
are evidence to reconcile, never a source for missing local expectations.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime
from importlib.resources import files

from task_source.scene_views.identity import encoded

LEDGERS = ("calls", "budget_reservations", "subscription_reservations")
VERSION = "scene-recovery-checkpoint-v1"
SCHEMA_SHA256 = "d3019a5447f4831956369d16f818b2c51048a0305d622e4ed091c409f95a6cc0"


def require(value, code="SCENE_RECOVERY_PORTABLE_INVALID"):
    if not value:
        raise ValueError(code)


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def _validate(value, definition, schema):
    if "$ref" in definition:
        return _validate(value, schema["$defs"][definition["$ref"].split("/")[-1]], schema)
    if "anyOf" in definition:
        for candidate in definition["anyOf"]:
            try:
                _validate(value, candidate, schema)
                return
            except ValueError:
                pass
        require(False)
    kind = definition.get("type")
    if kind == "object":
        require(isinstance(value, dict) and set(definition.get("required", [])) <= set(value))
        if definition.get("additionalProperties") is False:
            require(set(value) <= set(definition.get("properties", {})))
        for key, item in value.items():
            if key in definition.get("properties", {}):
                _validate(item, definition["properties"][key], schema)
    elif kind == "array":
        require(isinstance(value, list) and len(value) <= 4096)
        for item in value:
            _validate(item, definition["items"], schema)
    elif kind == "string":
        require(isinstance(value, str))
        if "pattern" in definition:
            require(re.search(definition["pattern"], value) is not None)
        require(len(value) >= definition.get("minLength", 0) and len(value) <= definition.get("maxLength", 4096))
    elif kind == "integer":
        require(type(value) is int)
        require(value >= definition.get("minimum", value))
    elif kind == "boolean":
        require(type(value) is bool)
    elif kind == "null":
        require(value is None)
    elif kind == "number":
        require(type(value) in (int, float) and math.isfinite(value))
    if "const" in definition:
        require(type(value) is type(definition["const"]) and value == definition["const"])
    if "enum" in definition:
        require(value in definition["enum"])


def scope(row):
    return row["run_id"], row["job_id"], row["attempt_id"], row["episode"]


def row_key(row, name):
    return (
        row["job_id"],
        row["attempt_id"],
        -1 if row["episode"] is None else row["episode"],
        row["seq"] if name == "calls" else row["reservation_id"],
    )


def parse_portable(value):
    require(len(encoded(value)) <= 4_000_000)
    raw_schema = files("task_source").joinpath("data/scene_recovery_checkpoint_v1.schema.json").read_bytes()
    require(hashlib.sha256(raw_schema).hexdigest() == SCHEMA_SHA256, "SCENE_RECOVERY_SCHEMA_UNAVAILABLE")
    schema = json.loads(raw_schema)
    _validate(value, schema, schema)
    calls = {}
    for name in LEDGERS:
        ledger = value[name]
        require(
            set(ledger) == {"count", "digest", "rows"}
            and ledger["count"] == len(ledger["rows"])
            and ledger["digest"] == digest(ledger["rows"])
        )
        require(ledger["rows"] == sorted(ledger["rows"], key=lambda row: row_key(row, name)))
        seen, positions = set(), set()
        for row in ledger["rows"]:
            identifier = row["call_id"] if name == "calls" else row["reservation_id"]
            require(row["run_id"] == value["run_id"] and identifier not in seen)
            seen.add(identifier)
            if name == "calls":
                position = (*scope(row), row["seq"])
                require(position not in positions)
                positions.add(position)
                calls[identifier] = row
                root = row["gateway_root"]
                if root is not None:
                    require(
                        scope(root) == scope(row)
                        and root["root"] == row["event_hash"]
                        and root["last_seq"] == row["seq"]
                    )
                    require(
                        root["signed_at"].endswith("Z")
                        and datetime.fromisoformat(root["signed_at"].replace("Z", "+00:00")).utcoffset().total_seconds()
                        == 0
                    )
            else:
                require(row["call_id"] == identifier and row["call_present"] is (identifier in calls))
                if identifier in calls:
                    require(scope(row) == scope(calls[identifier]))
            if name == "budget_reservations":
                for key in ("reserved_cost_usd", "settled_cost_usd"):
                    amount = row[key]
                    require(amount is None or re.fullmatch(r"(?:0|[1-9][0-9]*)(?:\.[0-9]*[1-9])?", amount))
    return value


def expected_ledgers(rows):
    require(isinstance(rows, dict) and set(rows) == set(LEDGERS))
    return {name: {"count": len(rows[name]), "digest": digest(rows[name]), "rows": rows[name]} for name in LEDGERS}


def verify_local_rows(work, rows, gateway_trust):
    """Uses only independent operator key data, never root-selected keys."""
    from agent_evidence import verify_root
    from agent_evidence.signing import TrustStore

    value = {
        "schema_version": VERSION,
        "run_id": work["run_id"],
        "binding_digest": "0" * 64,
        "recovery_generation": 1,
        "reconciliation_required": True,
        **expected_ledgers(rows),
    }
    parse_portable(value)
    require(
        isinstance(gateway_trust, dict)
        and set(gateway_trust) == {"provenance", "keys"}
        and gateway_trust["provenance"] == "operator_registered"
        and isinstance(gateway_trust["keys"], dict),
        "SCENE_RECOVERY_GATEWAY_TRUST_REQUIRED",
    )
    trust = TrustStore()
    for key, public in gateway_trust["keys"].items():
        require(
            isinstance(public, str) and re.fullmatch(r"[0-9a-f]{64}", public), "SCENE_RECOVERY_GATEWAY_TRUST_REQUIRED"
        )
        trust.add("gateway", key, public)
    for row in rows["calls"]:
        require(
            row["status"] == "ok" and row["decision"] == "allow" and row["gateway_root"] is not None,
            "SCENE_RECOVERY_UNRESOLVED_CALLS",
        )
        require(verify_root(row["gateway_root"], trust).ok, "SCENE_RECOVERY_GATEWAY_ROOT_INVALID")
    for row in rows["budget_reservations"]:
        require(
            row["call_present"]
            and row["state"] == "settled"
            and row["usage_status"] == "known"
            and row["settled_cost_usd"] is not None,
            "SCENE_RECOVERY_UNSETTLED_RESERVATION",
        )
    for row in rows["subscription_reservations"]:
        require(row["call_present"], "SCENE_RECOVERY_UNMATCHED_RESERVATION")


def reconcile(journal, checkpoint, *, run_id, generation, local_a=None, remote=None):
    value = parse_portable(checkpoint["portable"])
    require(
        value["run_id"] == run_id
        and value["recovery_generation"] == generation
        and value["binding_digest"] == checkpoint["binding_digest"],
        "SCENE_RECOVERY_PORTABLE_BINDING_MISMATCH",
    )
    if journal["server_binding_digest"] is not None:
        require(journal["server_binding_digest"] == value["binding_digest"], "SCENE_RECOVERY_PORTABLE_BINDING_MISMATCH")
    require(
        {key: checkpoint[key] for key in ("progress", "artifacts", "report_digest")} == journal["checkpoint_state"],
        "SCENE_RECOVERY_CHECKPOINT_MISMATCH",
    )
    if journal.get("schema_version") == "scene-unstarted-recovery-journal-v1":
        from task_source.scene_recovery_bootstrap import ParentRecoveryJournal

        require(type(remote) is ParentRecoveryJournal and local_a is None, "SCENE_RECOVERY_UNSTARTED_PARENT_REQUIRED")
        return remote.reconcile(journal, checkpoint)
    if journal.get("schema_version") == "scene-local-recovery-journal-v3":
        if remote is not None:
            from task_source.scene_recovery_bootstrap import ParentRecoveryJournal

            require(type(remote) is ParentRecoveryJournal and local_a is None, "SCENE_RECOVERY_PARENT_RECEIPT_INVALID")
            return remote.reconcile(journal, checkpoint)
        from task_source.scene_views.episode_ledger import LocalARecoveryJournal

        require(type(local_a) is LocalARecoveryJournal, "SCENE_RECOVERY_LOCAL_A_JOURNAL_REQUIRED")
        require(local_a.document == journal["local_a"], "SCENE_RECOVERY_JOURNAL_CHANGED")
        result = local_a.reconcile(value)
        return {**result, "matched": True, "local_binding_digest": journal["local_binding_digest"]}
    require(local_a is None and remote is None, "SCENE_RECOVERY_LEDGER_NAMESPACE_MISMATCH")
    for name in LEDGERS:
        require(
            encoded(value[name]) == encoded(expected_ledgers(journal["rows"])[name]), "SCENE_RECOVERY_LEDGER_MISMATCH"
        )
    return {
        "matched": True,
        "local_binding_digest": journal["local_binding_digest"],
        "execution_authorized": False,
        "rerun_authorized": False,
    }


def verify_event_bindings(work, directory, rows, original_files):
    """Every original model_call must match; no extra/server-only events."""
    expected = {row["call_id"]: row for row in rows["calls"]}
    matched = set()
    for path in sorted((directory / "episodes").glob("*.jsonl")):
        for line in path.read_text().splitlines():
            if not line.strip():
                continue
            event = json.loads(line)
            if event.get("type") != "model_call":
                continue
            require(path.relative_to(directory).as_posix() in original_files, "SCENE_RECOVERY_EVENT_JOURNAL_REQUIRED")
            payload = event["payload"]
            meta = payload["provider_meta"]
            gateway = meta["gateway"]
            identifier = gateway["call_id"]
            require(identifier in expected and identifier not in matched, "SCENE_RECOVERY_LOCAL_CALL_MISMATCH")
            row = expected[identifier]
            require(
                scope(event) == scope(row)
                and row["run_id"] == work["run_id"]
                and meta["request_id"] == row["correlation_id"]
                and gateway["event_hash"] == row["event_hash"]
                and gateway["decision"] == row["decision"]
                and gateway["root"] == row["gateway_root"]
                and digest(payload["usage"]) == row["usage_sha256"],
                "SCENE_RECOVERY_LOCAL_CALL_MISMATCH",
            )
            for field in ("seq", "prev_hash", "messages_sha256", "tools_sha256", "raw_response_sha256"):
                if field in gateway:
                    require(gateway[field] == row[field], "SCENE_RECOVERY_LOCAL_CALL_MISMATCH")
            matched.add(identifier)
    require(matched == set(expected), "SCENE_RECOVERY_EVENT_JOURNAL_REQUIRED")
