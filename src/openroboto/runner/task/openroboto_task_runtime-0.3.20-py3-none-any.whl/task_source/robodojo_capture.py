"""Process-local state collector for RoboDojo 9226f48e; no Isaac imports at startup.

Loaded only by the admission client's private sitecustomize directory. Reads
live IsaacLab/Isaac Sim tensors, never observations, layout files or scores.
Unsupported physics representations fail closed instead of recording root-only
state (notably DynamicObject and fluid, whose wrapper has no complete live API).
"""

from __future__ import annotations

import hashlib
import importlib.abc
import importlib.machinery
import json
import math
import os
from pathlib import Path
import sys

OFFICIAL_REVISION = "9226f48ea694b3f53db12d4922e8b1199f8d0891"
EVAL_ENV_SHA256 = "6450eb46e5629ade982388a955056f417a244504b0dbea789c715e19fe0dfef5"
SCHEMA = "robodojo-physics-v1"


def numbers(value):
    """Detach engine tensors before JSON serialization; reject invalid readings."""
    for method in ("detach", "cpu", "tolist"):
        if hasattr(value, method):
            value = getattr(value, method)()
    if isinstance(value, (list, tuple)):
        if not value:
            raise ValueError("empty physical array")
        return [numbers(item) for item in value]
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"invalid physical value: {value!r}")
    return float(value)


def _pose(obj):
    position, quaternion = obj.get_world_pose()
    return {"position": numbers(position), "quaternion_wxyz": numbers(quaternion)}


def validate_state(state):
    """Validate the collector's complete schema, including every object reading."""

    def vector(value, size=None):
        if not isinstance(value, list) or not value or any(isinstance(x, (list, tuple)) for x in value):
            raise ValueError("physical vector must be a nonempty flat array")
        numbers(value)
        if size is not None and len(value) != size:
            raise ValueError("physical vector size mismatch")

    if not isinstance(state, dict) or set(state) != {"qpos", "qvel", "robots", "objects"}:
        raise ValueError("incomplete captured state")
    vector(state["qpos"])
    vector(state["qvel"], len(state["qpos"]))
    if not isinstance(state["robots"], dict) or not state["robots"]:
        raise ValueError("missing captured robots")
    qpos, qvel = [], []
    for robot in state["robots"].values():
        if set(robot) != {"joint_names", "root_state_w", "qpos", "qvel"}:
            raise ValueError("incomplete robot state")
        vector(robot["qpos"])
        vector(robot["qvel"], len(robot["qpos"]))
        vector(robot["root_state_w"], 13)
        names = robot["joint_names"]
        if (
            not isinstance(names, list)
            or len(names) != len(robot["qpos"])
            or not all(isinstance(x, str) and x for x in names)
        ):
            raise ValueError("joint identity mismatch")
        qpos.extend(robot["qpos"])
        qvel.extend(robot["qvel"])
    if state["qpos"] != qpos or state["qvel"] != qvel:
        raise ValueError("robot aggregate mismatch")
    if not isinstance(state["objects"], dict) or not state["objects"]:
        raise ValueError("missing captured task objects")
    for item in state["objects"].values():
        kind = item["kind"]
        fields = {"kind", "position", "quaternion_wxyz"}
        if kind in {"rigid", "articulation"}:
            fields |= {"linear_velocity", "angular_velocity"}
        if kind == "articulation":
            fields |= {"qpos", "qvel"}
        elif kind == "garment":
            fields |= {"particle_positions_w", "particle_velocities_w"}
        elif kind not in {"rigid", "geometry"}:
            raise ValueError("unsupported captured object kind")
        if set(item) != fields:
            raise ValueError("incomplete task object state")
        vector(item["position"], 3)
        vector(item["quaternion_wxyz"], 4)
        if kind in {"rigid", "articulation"}:
            vector(item["linear_velocity"], 3)
            vector(item["angular_velocity"], 3)
        if kind == "articulation":
            vector(item["qpos"])
            vector(item["qvel"], len(item["qpos"]))
        if kind == "garment":
            for field in ("particle_positions_w", "particle_velocities_w"):
                if not isinstance(item[field], list) or not item[field]:
                    raise ValueError("missing live cloth particles")
                for particle in item[field]:
                    vector(particle, 3)
            if len(item["particle_positions_w"]) != len(item["particle_velocities_w"]):
                raise ValueError("cloth position/velocity count mismatch")
    return state


def state_structure(value):
    """Retain entity identities and array dimensions, excluding measured numbers."""
    if isinstance(value, dict):
        return {key: state_structure(item) for key, item in value.items()}
    if isinstance(value, list):
        return [state_structure(item) for item in value]
    return value if isinstance(value, str) else None


def capture_state(env, env_idx):
    """All robot joints plus every task object in the official scene managers."""
    state = {"qpos": [], "qvel": [], "robots": {}, "objects": {}}
    seen = set()
    for idx, key in enumerate(env.robot_manager.robot_key):
        # Coupled arms can share one articulation; read its full DOFs once.
        if id(key) in seen:
            continue
        seen.add(id(key))
        data = key.data
        qpos, qvel = numbers(data.joint_pos[env_idx]), numbers(data.joint_vel[env_idx])
        if len(qpos) != len(qvel):
            raise ValueError("robot qpos/qvel size mismatch")
        state["qpos"].extend(qpos)
        state["qvel"].extend(qvel)
        state["robots"][str(idx)] = {
            "joint_names": list(key.joint_names),
            "root_state_w": numbers(data.root_state_w[env_idx]),
            "qpos": qpos,
            "qvel": qvel,
        }
    if not state["qpos"]:
        raise ValueError("no live robot joints")
    manager = env.scene_manager
    groups = (
        ("rigid", "_rigid_and_dynamic_objects"),
        ("articulation", "_articulation_objects"),
        ("garment", "_garment_objects"),
        ("geometry", "_geometry_objects"),
        ("fluid", "_fluid_objects"),
    )
    for kind, attribute in groups:
        for name, obj in sorted(getattr(manager, attribute)[env_idx].items()):
            if kind == "fluid" or type(obj).__name__ == "DynamicObject":
                raise ValueError(f"complete live state API unavailable for {kind}/{name}")
            item = {"kind": kind, **_pose(obj)}
            if kind == "rigid":
                item.update(
                    linear_velocity=numbers(obj.get_linear_velocity()),
                    angular_velocity=numbers(obj.get_angular_velocity()),
                )
            elif kind == "articulation":
                item.update(
                    qpos=numbers(obj.get_joint_positions()),
                    qvel=numbers(obj.get_joint_velocities()),
                    linear_velocity=numbers(obj.get_linear_velocity()),
                    angular_velocity=numbers(obj.get_angular_velocity()),
                )
            elif kind == "garment":
                # PhysX cloth tensor view, rather than the reset USD mesh points.
                item["particle_positions_w"] = numbers(obj._cloth_prim_view.get_world_positions()[0])
                item["particle_velocities_w"] = numbers(obj._cloth_prim_view.get_velocities()[0])
            state["objects"][f"{kind}/{name}"] = item
    if not state["objects"]:
        raise ValueError("no live task objects")
    return validate_state(state)


def instrument_env(env):
    """Wrap official reset / end detection / run_eval without changing its source."""
    initial, final = {}, {}
    original_reset, original_end, original_run = env.reset, env.is_episode_end, env.run_eval

    def reset(*args, **kwargs):
        initial.clear()
        final.clear()
        result = original_reset(*args, **kwargs)
        for idx in env.current_env_seed_map:
            if idx not in env.unstable_envs:
                initial[idx] = capture_state(env, idx)
        return result

    def episode_end(*args, **kwargs):
        before = list(env.end_flag)
        result = original_end(*args, **kwargs)
        for idx in initial:
            if not before[idx] and env.end_flag[idx]:
                final[idx] = capture_state(env, idx)
        return result

    def run_eval(*args, **kwargs):
        old = set(env.eval_result["details"])
        result = original_run(*args, **kwargs)
        by_layout = {int(layout): idx for idx, layout in env.current_env_seed_map.items()}
        for index in set(env.eval_result["details"]) - old:
            detail = env.eval_result["details"][index]
            layout = detail["layout_id"]
            idx = by_layout[layout]
            if idx not in initial or idx not in final:
                raise ValueError(f"missing initial/terminal engine state for layout {layout}")
            payload = {
                "schema": SCHEMA,
                "official_revision": OFFICIAL_REVISION,
                "eval_env_sha256": EVAL_ENV_SHA256,
                "collector_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "capture_token": os.environ["ROBODOJO_CAPTURE_TOKEN"],
                "batch_kind": os.environ["ROBODOJO_CAPTURE_BATCH"],
                "perturbation_seed": int(os.environ["ROBODOJO_CAPTURE_PERTURBATION_SEED"]),
                "task_id": env.task_name,
                "run_id": env.run_id,
                "layout_seed": env.eval_seed,
                "layout_id": layout,
                "env_index": idx,
                "official_detail": detail,
                "initial_state": initial[idx],
                "final_state": final[idx],
                "inventory": state_structure(initial[idx]),
            }
            directory = Path(os.environ["ROBODOJO_CAPTURE_DIR"])
            path = directory / f"{layout}.json"
            temporary = path.with_suffix(".tmp")
            temporary.write_text(json.dumps(payload, allow_nan=False), encoding="utf-8")
            temporary.replace(path)
        return result

    env.reset, env.is_episode_end, env.run_eval = reset, episode_end, run_eval
    return env


class _CaptureLoader(importlib.abc.Loader):
    def __init__(self, loader):
        self.loader = loader

    def create_module(self, spec):
        return self.loader.create_module(spec)

    def exec_module(self, module):
        path = Path(module.__spec__.origin).resolve()
        expected = Path(os.environ["ROBODOJO_CAPTURE_ROOT"], "src/eval_client/eval_env.py").resolve()
        if path != expected or hashlib.sha256(path.read_bytes()).hexdigest() != EVAL_ENV_SHA256:
            raise ImportError("RoboDojo collector refuses unpinned eval_env source")
        self.loader.exec_module(module)
        factory = module.create_eval_env
        module.create_eval_env = lambda *args, **kwargs: instrument_env(factory(*args, **kwargs))


class _CaptureFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname != "src.eval_client.eval_env":
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        if spec is None or spec.loader is None:
            raise ImportError("official RoboDojo eval_env not found")
        spec.loader = _CaptureLoader(spec.loader)
        return spec


def install():
    if os.environ.get("ROBODOJO_CAPTURE_DIR"):
        sys.meta_path.insert(0, _CaptureFinder())
