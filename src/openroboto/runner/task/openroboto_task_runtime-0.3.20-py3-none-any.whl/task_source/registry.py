"""题源与判定器的注册表。

只有这里知道「axis」和「robodojo」这两个名字对应哪个类。上层通过
``get_source`` / ``create_checker`` 拿对象，不直接 import 具体实现。
新增题源 = 在 ``configs/task_sources.json`` 加一条 + 实现一个 ``TaskSource``，
不改准入、评测、结算。

判定器按 ``(source, checker_type)`` 注册。AXIS 的 8 种词表由
``task_source.axis`` 注册；RoboDojo 的官方判据由 ``task_source.robodojo``
注册成 ``RoboDojoOfficialChecker`` 一项。同一份词表同时服务准入和运行期，
不存在「准入认这个类型、评测不认」的分叉。
"""

from __future__ import annotations

import importlib
import json
import os
import pathlib
import threading
from typing import Any, Callable, Mapping

from .base import Checker, TaskSource, TaskSourceError

VALIDATOR_ROOT = pathlib.Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = VALIDATOR_ROOT / "configs" / "task_sources.json"

SourceFactory = Callable[[Mapping[str, Any]], TaskSource]
CheckerFactory = Callable[[Mapping[str, Any]], Checker]

_SOURCE_FACTORIES: dict[str, SourceFactory] = {}
_CHECKER_FACTORIES: dict[tuple[str, str], CheckerFactory] = {}
_INSTANCES: dict[str, TaskSource] = {}
_LOCK = threading.RLock()


def register_source(name: str, factory: SourceFactory) -> None:
    with _LOCK:
        _SOURCE_FACTORIES[name] = factory


def register_checker(source: str, checker_type: str, factory: CheckerFactory) -> None:
    with _LOCK:
        _CHECKER_FACTORIES[(source, checker_type)] = factory


def registered_sources() -> list[str]:
    with _LOCK:
        return sorted(_SOURCE_FACTORIES)


def registered_checkers(source: str) -> list[str]:
    with _LOCK:
        return sorted(t for (s, t) in _CHECKER_FACTORIES if s == source)


def checker_factory(source: str, checker_type: str) -> CheckerFactory:
    try:
        return _CHECKER_FACTORIES[(source, checker_type)]
    except KeyError as exc:
        known = registered_checkers(source)
        raise TaskSourceError(
            f"checker type {checker_type!r} is not registered for source {source!r}; "
            f"registered: {known}"
        ) from exc


def create_checker(source: str, config: Mapping[str, Any]) -> Checker:
    """按声明构造判定器。未知类型直接拒绝，不回落、不猜。"""
    if not isinstance(config, Mapping):
        raise TaskSourceError("checker config must be an object")
    checker_type = config.get("type")
    if not isinstance(checker_type, str) or not checker_type:
        raise TaskSourceError("checker config must declare a string 'type'")
    return checker_factory(source, checker_type)(config)


def load_config(path: str | pathlib.Path | None = None) -> dict[str, Any]:
    path = pathlib.Path(path or os.environ.get("TASK_SOURCE_CONFIG", DEFAULT_CONFIG_PATH)).expanduser()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise TaskSourceError(f"task source config not found: {path}") from exc
    except ValueError as exc:
        raise TaskSourceError(f"task source config is not valid JSON: {path}: {exc}") from exc
    if data.get("schema_version") != 1:
        raise TaskSourceError(f"unsupported task source config schema: {path}")
    if not isinstance(data.get("sources"), dict):
        raise TaskSourceError(f"task source config must contain a 'sources' object: {path}")
    return data


def _load_factory(spec: str) -> Callable[..., Any]:
    if ":" not in spec:
        raise TaskSourceError(f"source factory must look like 'module:Class', got {spec!r}")
    module_name, attr = spec.split(":", 1)
    try:
        module = importlib.import_module(module_name)
    except ImportError as exc:
        raise TaskSourceError(f"cannot import source factory module {module_name!r}: {exc}") from exc
    try:
        return getattr(module, attr)
    except AttributeError as exc:
        raise TaskSourceError(f"{module_name!r} has no attribute {attr!r}") from exc


def load_source_modules(config: Mapping[str, Any]) -> None:
    """Import every configured factory module so checker registrations happen.

    ``sources`` / ``checkers`` 这类只读命令需要它；正常取题源时
    ``get_source`` 会顺带完成同样的 import。
    """
    for entry in (config.get("sources") or {}).values():
        spec = entry.get("factory") if isinstance(entry, Mapping) else None
        if spec:
            _load_factory(str(spec))


def get_source(
    name: str,
    config: Mapping[str, Any] | None = None,
    *,
    root: str | pathlib.Path | None = None,
    fresh: bool = False,
) -> TaskSource:
    """按名字取题源实例。

    ``root`` 是题包搜索根目录（默认取配置里的 ``package_root``，相对
    validator 仓库根解析）。切换题源只改配置里的 ``default_source`` /
    调用方传的名字，不改任何上层代码。
    """
    config = dict(config) if config is not None else load_config()
    sources = config.get("sources") or {}
    entry = sources.get(name)
    if not isinstance(entry, Mapping):
        raise TaskSourceError(f"unknown task source {name!r}; configured: {sorted(sources)}")
    factory_spec = entry.get("factory")
    options = dict(entry.get("options") or {})
    if root is not None:
        options["package_root"] = str(root)
    if "package_root" in options:
        base = VALIDATOR_ROOT
        candidate = pathlib.Path(options["package_root"]).expanduser()
        options["package_root"] = str(candidate if candidate.is_absolute() else base / candidate)

    with _LOCK:
        if not fresh and name in _INSTANCES and root is None:
            return _INSTANCES[name]
        source = _source_from_entry(name, factory_spec, options)
        # 带 root 的实例是一次性视图（准入读提交上来的包）；不要让它污染
        # 按配置缓存的默认实例。
        if root is None:
            _INSTANCES[name] = source
        return source


def _source_from_entry(name: str, factory_spec: Any, options: dict[str, Any]) -> TaskSource:
    if factory_spec:
        factory = _load_factory(str(factory_spec))
        return factory(options)
    with _LOCK:
        factory = _SOURCE_FACTORIES.get(name)
    if factory is None:
        raise TaskSourceError(f"source {name!r} has no factory; add one to the config")
    return factory(options)


def reset_cache() -> None:
    """测试用：清掉已实例化的题源（不动注册表）。"""
    with _LOCK:
        _INSTANCES.clear()


__all__ = [
    "DEFAULT_CONFIG_PATH",
    "VALIDATOR_ROOT",
    "checker_factory",
    "create_checker",
    "get_source",
    "load_config",
    "load_source_modules",
    "register_checker",
    "register_source",
    "registered_checkers",
    "registered_sources",
    "reset_cache",
]
