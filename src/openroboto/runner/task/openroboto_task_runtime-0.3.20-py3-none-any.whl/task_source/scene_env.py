"""Native imported-scene environment, with the unchanged Panda tool clock."""

from __future__ import annotations

import math
import numbers
import threading
import time

import numpy as np

from .base import RuntimeUnavailable, TaskSourceError
from .scene_geometry import SceneResolver
from .scene_runtime import validated_definition
from .tabletop_program import ProgramMonitor

_RENDER_LOCK = threading.RLock()


class SceneDeadlineExceeded(RuntimeUnavailable):
    """An actual runtime wall deadline expired, not a physical task failure."""


class SceneMujocoEnv:
    scene_contract = True

    def __init__(self, imported, state_id, *, event_sink=None, deadline=math.inf):
        import mujoco

        self.mujoco = mujoco
        self.imported = imported
        self.model = imported.model
        self.data = None
        self.state_id = state_id
        self.event_sink = event_sink
        self.deadline = min(
            float(deadline), time.monotonic() + imported.task.execution_contract["budget"]["wall_seconds"]
        )
        if math.isnan(self.deadline):
            raise RuntimeUnavailable("invalid scene runtime deadline")
        self.definition = validated_definition(imported)
        self.observation_contract = self.definition["observation"]
        self.runtime = {"tcp_offset": 0.0}
        self.control_period_s = 0.2
        self.steps_per_control = 100
        self.max_steps = imported.task.execution_contract["budget"]["max_steps"]
        if abs(float(self.model.opt.timestep) - 0.002) > 1e-12 or self.model.nu != 9 or self.model.neq:
            raise RuntimeUnavailable("scene runtime requires exact 2ms Panda physics, nine actuators and no equalities")
        robot = imported.bindings["robot"]
        self.joint_ids = tuple(robot["joint_ids"])
        self.qpos_indices = tuple(robot["qpos_addresses"])
        self.actuator_ids = tuple(robot["actuator_ids"])
        self.resolver = SceneResolver(imported)
        self.program = ProgramMonitor(self.definition, resolver=self.resolver)
        self.control_steps = 0
        self._renderer = None
        self._event_key = None
        self._bodies = dict(imported.bindings["bodies"])
        self._owners = {}
        self.physics_metrics = None
        for name, parts in imported.bindings["geoms"].items():
            self._owners.update({g: name for g in parts.values()})
        for g in imported.bindings["platform_groups"]["robot"]:
            body = int(self.model.geom_bodyid[g])
            self._owners[g] = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_BODY, body)
        for g in imported.bindings["platform_groups"]["table"]:
            self._owners[g] = "table" if g in self.resolver.targets["table"] else "__platform_floor__"

    def _emit(self, kind, value):
        if self.event_sink is not None:
            self.event_sink(kind, value)

    def check_deadline(self):
        if time.monotonic() >= self.deadline:
            raise SceneDeadlineExceeded("scene runtime absolute wall deadline exceeded")

    def reset(self):
        self.check_deadline()
        self._emit("reset_start", {"state_id": self.state_id, "build_digest": self.imported.digest})
        self.program.reset()
        self.data = self.imported.reset(self.state_id)
        self.check_deadline()
        self.control_steps = 0
        self._event_key = None
        self.physics_metrics = {
            "native_steps": 0,
            "minimum_contact_distance_m": 0.0,
            "worst_contact": None,
            "joint_ranges": {},
            "maximum_joint_limit_excursion": {},
        }
        for c in self.data.contact:
            if c.dist < -0.001 and self.model.geom_bodyid[c.geom1] != self.model.geom_bodyid[c.geom2]:
                raise TaskSourceError("scene initial penetration exceeds 1mm; retain this initial state")
        physical = self._physical_state(0)
        self._measure_physics(physical, advanced=False)
        self.program.update(physical, 0)
        initial = self.state()
        self._emit("reset", initial)
        return initial

    def null_action(self):
        positions = self.data.qpos if self.data is not None else self.imported.initial_states[self.state_id]["qpos"]
        return [float(positions[q]) for q in self.qpos_indices]

    def step(self, action):
        self.check_deadline()
        if self.data is None:
            raise TaskSourceError("reset the scene before stepping")
        if self.control_steps >= self.max_steps:
            raise TaskSourceError("scene control-step budget exhausted")
        values = list(action)
        if len(values) != 9 or any(
            not isinstance(v, numbers.Real) or isinstance(v, (bool, np.bool_)) or not math.isfinite(v) for v in values
        ):
            raise TaskSourceError("scene action needs nine finite joint targets")
        for aid, jid, value in zip(self.actuator_ids, self.joint_ids, values):
            if self.model.jnt_limited[jid]:
                value = float(np.clip(value, *self.model.jnt_range[jid]))
            self.data.ctrl[aid] = value
        self._emit("control_start", {"step": self.control_steps, "action": [float(v) for v in values]})
        for _ in range(self.steps_per_control):
            self.check_deadline()
            self.mujoco.mj_step(self.model, self.data)
            self.mujoco.mj_forward(self.model, self.data)
            if (
                not np.all(np.isfinite(self.data.qpos))
                or not np.all(np.isfinite(self.data.qvel))
                or np.any(self.data.warning.number)
            ):
                self._emit(
                    "physics_error", {"tick": self.program.tick + 1, "warnings": self.data.warning.number.tolist()}
                )
                raise RuntimeUnavailable("scene physics produced a warning or nonfinite state; retain failed evidence")
            physical = self._physical_state(self.program.tick + 1)
            self._measure_physics(physical, advanced=True)
            snapshot = self.program.update(physical, self.program.tick + 1)
            if self.event_sink is not None:
                key = (
                    tuple(snapshot["completed"]),
                    str(snapshot["violation"]),
                    snapshot["passed"],
                    tuple((c["geom1"], c["geom2"]) for c in physical["contacts"]),
                )
                if key != self._event_key:
                    self._event_key = key
                    self._emit("physics_event", {**physical, "tabletop_program": snapshot})
        self.control_steps += 1
        final = self.state()
        self._emit("control", final)
        return final

    def _physical_state(self, tick):
        if self.data is None:
            raise TaskSourceError("scene has not been reset")
        mujoco, model, data = self.mujoco, self.model, self.data
        positions, orientations, linear, angular, centers = {}, {}, {}, {}, {}
        for name, bid in self._bodies.items():
            positions[name] = data.xpos[bid].tolist()
            orientations[name] = [*data.xquat[bid, 1:].tolist(), float(data.xquat[bid, 0])]
            centers[name] = data.xipos[bid].tolist()
            velocity = np.zeros(6)
            mujoco.mj_objectVelocity(model, data, mujoco.mjtObj.mjOBJ_XBODY, bid, velocity, 0)
            angular[name], linear[name] = velocity[:3].tolist(), velocity[3:].tolist()
        joints = {
            name: float(data.qpos[q])
            for name, q in zip(self.imported.bindings["robot"]["joint_order"], self.qpos_indices)
        }
        joints.update({
            name: float(data.qpos[model.jnt_qposadr[j]]) for name, j in self.imported.bindings["joints"].items()
        })
        contacts = []
        for index, contact in enumerate(data.contact):
            force = np.zeros(6)
            mujoco.mj_contactForce(model, data, index, force)
            frame = np.asarray(contact.frame).reshape(3, 3)
            g1, g2 = int(contact.geom1), int(contact.geom2)
            contacts.append({
                "id": index,
                "physics_tick": tick,
                "geom1": g1,
                "geom2": g2,
                "a": self._owners[g1],
                "b": self._owners[g2],
                "distance_m": float(contact.dist),
                "point": contact.pos.tolist(),
                "force_on_b": (frame.T @ force[:3]).tolist(),
                "normal_on_b": frame[0].tolist(),
            })
        return {
            "positions": positions,
            "orientations": orientations,
            "centers_of_mass": centers,
            "linear_velocities": linear,
            "angular_velocities": angular,
            "joints": joints,
            "contacts": contacts,
            "qpos": data.qpos.tolist(),
            "qvel": data.qvel.tolist(),
            "ctrl": data.ctrl.tolist(),
            "time": float(data.time),
        }

    def _measure_physics(self, physical, *, advanced):
        """Extrema at every native substep, independent of sparse event logging.

        These diagnostics do not relax or add a success predicate. Physical
        plausibility is reported separately from the task-program boolean.
        """
        metrics = self.physics_metrics
        metrics["native_steps"] += int(advanced)
        for contact in physical["contacts"]:
            if contact["distance_m"] < metrics["minimum_contact_distance_m"]:
                metrics["minimum_contact_distance_m"] = contact["distance_m"]
                metrics["worst_contact"] = dict(contact)
        ids = dict(self.imported.bindings["joints"])
        ids.update(zip(self.imported.bindings["robot"]["joint_order"], self.joint_ids))
        for name, jid in ids.items():
            value = physical["joints"][name]
            span = metrics["joint_ranges"].setdefault(name, [value, value])
            span[0], span[1] = min(span[0], value), max(span[1], value)
            if self.model.jnt_limited[jid]:
                low, high = self.model.jnt_range[jid]
                beyond = max(0.0, float(low) - value, value - float(high))
                metrics["maximum_joint_limit_excursion"][name] = max(
                    beyond, metrics["maximum_joint_limit_excursion"].get(name, 0.0)
                )

    def state(self):
        import copy

        return {
            **self._physical_state(self.program.tick),
            "tabletop_program": self.program.snapshot(),
            "physics_metrics": copy.deepcopy(self.physics_metrics),
        }

    def public_state(self):
        state = self.state()
        return {k: state[k] for k in ("positions", "orientations", "linear_velocities", "angular_velocities", "joints")}

    def object_center(self, name):
        return self.resolver.center(name, self.state())

    def _get_renderer(self):
        if self._renderer is None:
            width, height = self.imported.bindings["camera"]["image_size"]
            try:
                self._renderer = self.mujoco.Renderer(self.model, height=height, width=width)
            except Exception as exc:
                raise RuntimeUnavailable("scene camera renderer is unavailable") from exc
        return self._renderer

    def render_rgb(self):
        self.check_deadline()
        with _RENDER_LOCK:
            renderer = self._get_renderer()
            try:
                renderer.disable_segmentation_rendering()
                renderer.update_scene(self.data, camera=self.imported.bindings["camera"]["name"])
                result = renderer.render().copy()
                self.check_deadline()
                return result
            except SceneDeadlineExceeded:
                raise
            except Exception as exc:
                raise RuntimeUnavailable("scene calibrated camera rendering failed") from exc

    def visibility(
        self,
        names,
        *,
        width=None,
        height=None,
        frame_margin=0.45,
        min_pixels=1.5,
        min_pixel_ratio=0.0,
        min_visible_fraction=0.0,
    ):
        self.check_deadline()
        expected_width, expected_height = self.imported.bindings["camera"]["image_size"]
        if (width is not None and width != expected_width) or (height is not None and height != expected_height):
            raise RuntimeUnavailable("visibility dimensions differ from the frozen scene camera")
        width, height = expected_width, expected_height
        with _RENDER_LOCK:
            renderer = self._get_renderer()
            camera = self.imported.bindings["camera"]["name"]
            saved = self.model.geom_group.copy()
            try:
                renderer.enable_segmentation_rendering()
                renderer.update_scene(self.data, camera=camera)
                segmentation = renderer.render().copy()
                results = {}
                margin = np.zeros((height, width), dtype=bool)
                dx, dy = int(width * (0.5 - frame_margin)), int(height * (0.5 - frame_margin))
                margin[max(0, dy) : min(height, height - dy), max(0, dx) : min(width, width - dx)] = True
                for name in names:
                    self.check_deadline()
                    bid = self._bodies[name]
                    geoms = np.flatnonzero(self.model.geom_bodyid == bid)
                    mask = np.isin(segmentation[:, :, 0], geoms) & (
                        segmentation[:, :, 1] == int(self.mujoco.mjtObj.mjOBJ_GEOM)
                    )
                    pixels = int((mask & margin).sum())
                    self.model.geom_group[:] = 0
                    self.model.geom_group[geoms] = 5
                    option = self.mujoco.MjvOption()
                    option.geomgroup[:] = 0
                    option.geomgroup[5] = 1
                    renderer.update_scene(self.data, camera=camera, scene_option=option)
                    alone = renderer.render()
                    silhouette = int(
                        (np.isin(alone[:, :, 0], geoms) & (alone[:, :, 1] == int(self.mujoco.mjtObj.mjOBJ_GEOM))).sum()
                    )
                    fraction = pixels / silhouette if silhouette else 0.0
                    radius = math.sqrt(pixels / math.pi)
                    ratio = pixels / (width * height)
                    visible = (
                        pixels > 0
                        and radius >= min_pixels
                        and ratio >= min_pixel_ratio
                        and fraction >= min_visible_fraction
                    )
                    results[name] = {
                        "visible": visible,
                        "visible_pixels": pixels,
                        "pixels": radius,
                        "pixel_ratio": ratio,
                        "visible_fraction": fraction,
                        "silhouette_pixels": silhouette,
                        "method": "native_calibrated_segmentation",
                    }
                    self.model.geom_group[:] = saved
                return results
            except SceneDeadlineExceeded:
                raise
            except Exception as exc:
                raise RuntimeUnavailable("scene native visibility rendering failed") from exc
            finally:
                self.model.geom_group[:] = saved
                renderer.disable_segmentation_rendering()

    def close(self):
        if self._renderer is not None:
            self._renderer.close()
            self._renderer = None
        self.data = None
