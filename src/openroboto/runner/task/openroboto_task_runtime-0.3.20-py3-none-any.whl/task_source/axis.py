"""AXIS 题源：``payloads/*.json`` + 8 种 checker + MuJoCo 运行时。

题包结构（与 AXIS 评测程序一致，另加 ``task.json.source = "axis"``）::

    <package>/
      task.json
      benchmark.json
      randomization.json
      payloads/<task_id>-official-00.json ... 19.json
      reference.json                 # 可选；矿工参考解
      scene.xml                      # 或 payload 里内嵌 mjcf_xml

checker 词表**固定 8 种**：出现其他类型直接拒，不回落、不忽略。词表同时服务
准入和评测，两个入口共用 ``create_checker``，不会出现「准入放行、评测不认」。

checker 是纯函数：``evaluate()`` 只读传入的状态，不碰仿真、不看时钟。状态约定：

- ``{"current": <state>, "initial": <state>}``：判定 current，需要初始值相对量
  （``DirectedRotationChecker``）时读 initial。
- 直接传一个 state：current = initial = 该状态（开局检查 / 无相对量的判定）。

``<state>`` 就是 AXIS payload 的 ``initial_state`` 形状（``objects`` / ``robots`` /
``sites``），或者已经规范化过的 ``positions`` / ``orientations`` / ``joints``。
"""

from __future__ import annotations

import math
import pathlib
from typing import Any, Mapping

from .base import (
    CheckResult,
    Checker,
    Env,
    InstanceSpec,
    RuntimeUnavailable,
    Space,
    TaskSource,
    TaskSourceError,
    TaskSpec,
    UnknownTask,
)
from .package import TaskPackage, canonical_json_sha256, load_package, read_json
from .registry import register_checker, register_source

AXIS_CHECKER_TYPES = (
    "CompositeChecker",
    "RelativeCylinderChecker",
    "RelativePositionBoundsChecker",
    "DirectedRotationChecker",
    "GripperOpenChecker",
    "DrawerBBoxChecker",
    "FrameBBoxChecker",
    "SamplePositionDeltaChecker",
)

DEFAULT_JOINT_ORDER = (
    "franka/panda_finger_joint1",
    "franka/panda_finger_joint2",
    "franka/panda_joint1",
    "franka/panda_joint2",
    "franka/panda_joint3",
    "franka/panda_joint4",
    "franka/panda_joint5",
    "franka/panda_joint6",
    "franka/panda_joint7",
)

ACTION_SPACE = Space(
    kind="box",
    shape=(9,),
    dtype="float64",
    meta={
        "semantics": "absolute joint-position targets in observation_joint_order",
        "joint_order": list(DEFAULT_JOINT_ORDER),
    },
)
OBSERVATION_SPACE = Space(
    kind="dict",
    meta={
        "image": {"shape": [180, 320, 3], "dtype": "uint8", "camera": "camera0"},
        "state": {"shape": [9], "dtype": "float32", "joint_order": list(DEFAULT_JOINT_ORDER)},
    },
)

#: 可见性采样网格：在目标物投影圆内做 N×N 点采样。25×25 在 320×180 上
#: 量化误差约 0.16%，对 2–3 px 的小目标仍然稳定。
VISIBILITY_GRID = 25

#: 主相机的「可用画面」：只把中心 2×frame_margin 的区域算作可见。0.45 与
#: 旧实现一致（中心 90%），目标塞在边缘 / 角落时可见面积会明显下降。
DEFAULT_FRAME_MARGIN = 0.45

#: 生产阈值默认值（profile 会覆盖）。取值依据见 docs/admission-worker.md
#: 「可见性阈值」：正常样题（8 道 × 20 实例）的最小值分别留约 20% 余量。
DEFAULT_MIN_PIXELS = 1.5
DEFAULT_MIN_PIXEL_RATIO = 0.00018
DEFAULT_MIN_VISIBLE_FRACTION = 0.6


# ---------------------------------------------------------------------------
# 状态规范化
# ---------------------------------------------------------------------------


def _normalize_state(value: Mapping[str, Any]) -> dict[str, Any]:
    """把 AXIS payload 状态或规范化状态统一成 checker 读取的形状。"""
    if not isinstance(value, Mapping):
        raise TaskSourceError("checker state must be an object")
    if "current" in value and isinstance(value["current"], Mapping):
        current = _normalize_state(value["current"])
        initial = _normalize_state(value.get("initial", value["current"]))
        return {"current": current, "initial": initial}

    if any(key in value for key in ("positions", "orientations", "joints", "site_positions")):
        result = {
            "positions": {str(k): _vec(v, 3) for k, v in (value.get("positions") or {}).items()},
            "orientations": {str(k): _quat(v) for k, v in (value.get("orientations") or {}).items()},
            "joints": {str(k): float(v) for k, v in (value.get("joints") or {}).items()},
            "site_positions": {str(k): _vec(v, 3) for k, v in (value.get("site_positions") or {}).items()},
            "site_orientations": {str(k): _quat(v) for k, v in (value.get("site_orientations") or {}).items()},
        }
        if "tabletop_goal_hold_steps" in value:
            result["tabletop_goal_hold_steps"] = value["tabletop_goal_hold_steps"]
            for key in ("linear_velocities", "angular_velocities"):
                result[key] = {str(k): _vec(v, 3) for k, v in (value.get(key) or {}).items()}
        return result

    positions, orientations, joints = {}, {}, {}
    for name, obj in (value.get("objects") or {}).items():
        if isinstance(obj, Mapping) and "pos" in obj:
            positions[str(name)] = _vec(obj["pos"], 3)
            orientations[str(name)] = _quat(obj.get("rot", [0, 0, 0, 1]))
    sites = value.get("sites") or {}
    site_positions, site_orientations = {}, {}
    for name, site in sites.items():
        if isinstance(site, Mapping) and "pos" in site:
            site_positions[str(name)] = _vec(site["pos"], 3)
            site_orientations[str(name)] = _quat(site.get("rot", [0, 0, 0, 1]))
    for robot in (value.get("robots") or {}).values():
        if isinstance(robot, Mapping):
            joints.update({str(k): float(v) for k, v in (robot.get("dof_pos") or {}).items()})
    return {
        "positions": positions,
        "orientations": orientations,
        "joints": joints,
        "site_positions": site_positions,
        "site_orientations": site_orientations,
    }


def _vec(value: Any, length: int) -> list[float]:
    values = [float(v) for v in value]
    if len(values) != length:
        raise TaskSourceError(f"expected a {length}-vector, got {value!r}")
    return values


def _quat(value: Any) -> list[float]:
    return _vec(value, 4)


def _split_state(state: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    normalized = _normalize_state(state)
    if "current" in normalized:
        return normalized["current"], normalized["initial"]
    return normalized, normalized


def _resolve(name: str, mapping: Mapping[str, Any]) -> Any | None:
    if name in mapping:
        return mapping[name]
    trimmed = name.rstrip("/")
    if trimmed in mapping:
        return mapping[trimmed]
    for suffix in (trimmed + "/", "/" + trimmed):
        for key, value in mapping.items():
            if key.endswith(suffix) or key.endswith(trimmed):
                return value
    return None


def _quat_normalize(quaternion: list[float]) -> list[float]:
    norm = math.sqrt(sum(value * value for value in quaternion))
    return [value / norm for value in quaternion] if norm >= 1e-12 else [0.0, 0.0, 0.0, 1.0]


def _quat_multiply(a: list[float], b: list[float]) -> list[float]:
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return [
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
        aw * bw - ax * bx - ay * by - az * bz,
    ]


def _quat_rotate(quaternion: list[float], vector: list[float]) -> list[float]:
    qx, qy, qz, qw = quaternion
    vx, vy, vz = vector
    tx, ty, tz = 2 * (qy * vz - qz * vy), 2 * (qz * vx - qx * vz), 2 * (qx * vy - qy * vx)
    return [
        vx + qw * tx + qy * tz - qz * ty,
        vy + qw * ty + qz * tx - qx * tz,
        vz + qw * tz + qx * ty - qy * tx,
    ]


# ---------------------------------------------------------------------------
# 8 种 checker
# ---------------------------------------------------------------------------


def evaluate_axis_checker(
    config: Mapping[str, Any],
    current: Mapping[str, Any],
    initial: Mapping[str, Any],
) -> CheckResult:
    """纯函数判定。未知类型抛 ``TaskSourceError``，绝不返回 ``passed=True``。"""
    checker_type = config.get("type")
    if checker_type == "TabletopZoneChecker":
        from .tabletop import zone_condition

        return zone_condition(config, current)
    if checker_type == "CompositeChecker":
        children = [evaluate_axis_checker(child, current, initial) for child in config.get("checkers") or []]
        operator = str(config.get("operator", "AND")).upper()
        values = [child.passed for child in children]
        if operator == "OR":
            passed = any(values)
        elif operator == "NOT":
            passed = len(values) == 1 and not values[0]
        elif operator == "AND":
            passed = bool(values) and all(values)
        else:
            raise TaskSourceError(f"unsupported CompositeChecker operator {operator!r}")
        return CheckResult(
            passed,
            {
                "checker_type": checker_type,
                "operator": operator,
                "passed": passed,
                "sub_results": [dict(child.detail) for child in children],
            },
        )

    if checker_type in {"RelativeCylinderChecker", "RelativePositionBoundsChecker"}:
        object_name = str(config.get("objName", ""))
        reference_name = str(config.get("refName", ""))
        object_position = _resolve(object_name, current["positions"])
        reference_type = config.get("refType", "body")
        if reference_type not in {"body", "object", "site"}:
            raise TaskSourceError(f"unsupported reference type {reference_type!r}")
        reference_position = _resolve(
            reference_name, current["site_positions"] if reference_type == "site" else current["positions"]
        )
        if object_position is None or reference_position is None:
            return CheckResult(False, {"checker_type": checker_type, "passed": False, "reason": "missing positions"})
        delta = [object_position[index] - reference_position[index] for index in range(3)]
        if checker_type == "RelativeCylinderChecker":
            radius = float(config.get("xyRadius", 0.06))
            minimum, maximum = float(config.get("heightMin", 0.0)), float(config.get("heightMax", 0.03))
            distance = math.hypot(delta[0], delta[1])
            passed = distance < radius and minimum < delta[2] < maximum
            return CheckResult(
                passed,
                {
                    "checker_type": checker_type,
                    "passed": passed,
                    "xy_distance": distance,
                    "xy_radius": radius,
                    "dz": delta[2],
                    "height_min": minimum,
                    "height_max": maximum,
                },
            )
        ranges = [config.get("xRange"), config.get("yRange"), config.get("zRange")]
        checks = [bounds[0] < delta[index] < bounds[1] for index, bounds in enumerate(ranges) if bounds is not None]
        return CheckResult(
            bool(checks) and all(checks),
            {"checker_type": checker_type, "passed": bool(checks) and all(checks), "delta": delta, "ranges": ranges},
        )

    if checker_type == "GripperOpenChecker":
        threshold = float(config.get("threshold", 0.2))
        finger_values = {
            name: value
            for name, value in current["joints"].items()
            if "finger" in name.lower() or "gripper" in name.lower()
        }
        passed = any(abs(value) + 1e-4 >= threshold for value in finger_values.values())
        return CheckResult(
            passed,
            {"checker_type": checker_type, "passed": passed, "threshold": threshold, "joint_values": finger_values},
        )

    if checker_type == "DirectedRotationChecker":
        body_name = str(config.get("bodyName", "sample/"))
        current_quaternion = _resolve(body_name, current["orientations"])
        initial_quaternion = _resolve(body_name, initial["orientations"])
        if current_quaternion is None or initial_quaternion is None:
            return CheckResult(False, {"checker_type": checker_type, "passed": False, "reason": "missing orientation"})
        current_q, initial_q = _quat_normalize(current_quaternion), _quat_normalize(initial_quaternion)
        local_up = [float(value) for value in config.get("localUprightAxis", [0.0, 0.0, 1.0])]
        initial_up, current_up = _quat_rotate(initial_q, local_up), _quat_rotate(current_q, local_up)
        up_norms = math.sqrt(sum(value * value for value in initial_up)) * math.sqrt(
            sum(value * value for value in current_up)
        )
        up_dot = max(-1.0, min(1.0, sum(a * b for a, b in zip(initial_up, current_up)) / up_norms))
        tilt = math.degrees(math.acos(up_dot))
        relative = _quat_normalize(
            _quat_multiply(current_q, [-initial_q[0], -initial_q[1], -initial_q[2], initial_q[3]])
        )
        axis_norm = math.sqrt(sum(value * value for value in initial_up)) or 1.0
        axis = [value / axis_norm for value in initial_up]
        scalar = sum(relative[index] * axis[index] for index in range(3))
        angle = ((math.degrees(2.0 * math.atan2(scalar, relative[3])) + 180.0) % 360.0) - 180.0
        target = float(config["targetAngleDeg"])
        error = abs(((angle - target + 180.0) % 360.0) - 180.0)
        tolerance = float(config.get("angleToleranceDeg", 20.0))
        max_tilt = config.get("maxTiltDeg")
        passed = error <= tolerance and (max_tilt is None or tilt <= float(max_tilt))
        return CheckResult(
            passed,
            {
                "checker_type": checker_type,
                "passed": passed,
                "body_name": body_name,
                "twist_angle_deg": angle,
                "target_angle_deg": target,
                "angle_error_deg": error,
                "tilt_angle_deg": tilt,
            },
        )

    if checker_type in {"FrameBBoxChecker", "DrawerBBoxChecker"}:
        object_position = _resolve(str(config["objName"]), current["positions"])
        if checker_type == "FrameBBoxChecker":
            frame_type = config.get("frameType", "body")
            if frame_type not in {"body", "object", "site"}:
                raise TaskSourceError(f"unsupported frame type {frame_type!r}")
            sites = frame_type == "site"
            name = str(config["frameName"])
            origin = _resolve(name, current["site_positions"] if sites else current["positions"])
            quaternion = _resolve(name, current["site_orientations"] if sites else current["orientations"])
            lower, upper = config["lower"], config["upper"]
            tolerance = 0.0
        else:
            name = str(config["cabinetName"])
            origin = _resolve(name, current["positions"])
            quaternion = _resolve(name, current["orientations"])
            prefix = name.rstrip("/") + "/"
            joint = config.get("jointName")
            if joint:
                value = current["joints"].get(joint if "/" in joint else prefix + joint)
            else:
                joints = [v for k, v in current["joints"].items() if k.startswith(prefix)]
                index = int(config.get("jointIndex", 0))
                value = joints[index] if 0 <= index < len(joints) else None
            if origin is None or quaternion is None or value is None:
                return CheckResult(
                    False,
                    {"checker_type": checker_type, "passed": False, "reason": "missing cabinet pose or drawer joint"},
                )
            offset = [float(v) for v in config.get("baseOffset", [0, 0, 0])]
            axis = int(config.get("displacementAxis", 1))
            if axis not in (0, 1, 2):
                raise TaskSourceError("drawer displacementAxis must be 0, 1, or 2")
            offset[axis] += value
            origin = [a + b for a, b in zip(origin, _quat_rotate(_quat_normalize(quaternion), offset))]
            w, x, y, z = config.get("relativeQuat", [1, 0, 0, 0])
            quaternion = _quat_multiply(_quat_normalize(quaternion), _quat_normalize([x, y, z, w]))
            half = config["halfSize"]
            lower, upper = [-v for v in half], half
            tolerance = 1e-6
        if object_position is None or origin is None or quaternion is None:
            return CheckResult(
                False, {"checker_type": checker_type, "passed": False, "reason": "missing object or frame pose"}
            )
        x, y, z, w = _quat_normalize(quaternion)
        local = _quat_rotate([-x, -y, -z, w], [a - b for a, b in zip(object_position, origin)])
        passed = all(lo - tolerance <= value <= hi + tolerance for value, lo, hi in zip(local, lower, upper))
        return CheckResult(
            passed,
            {"checker_type": checker_type, "passed": passed, "local_position": local, "lower": lower, "upper": upper},
        )

    if checker_type == "SamplePositionDeltaChecker":
        name = str(config.get("sampleBodyName", "sample/"))
        position = _resolve(name, current["positions"])
        if position is None:
            return CheckResult(
                False, {"checker_type": checker_type, "passed": False, "reason": "missing object position"}
            )
        origin = config.get("initialPosition")
        if origin is None:
            origin = _resolve(name, initial["positions"])
        if origin is None:
            return CheckResult(
                False, {"checker_type": checker_type, "passed": False, "reason": "missing initial position"}
            )
        delta = [a - b for a, b in zip(position, origin)]
        axes = config.get("axes", ["x", "z"])
        axes = axes.split(",") if isinstance(axes, str) else axes
        checks = []
        for axis in axes:
            axis = axis.strip().lower()
            if axis not in "xyz" or len(axis) != 1:
                raise TaskSourceError(f"invalid position axis {axis!r}")
            value = delta["xyz".index(axis)]
            for bound, compare in (("min", lambda a, b: a >= b), ("max", lambda a, b: a <= b)):
                key = bound + "Delta" + axis.upper()
                if config.get(key) is not None:
                    checks.append(compare(value, float(config[key])))
        if not checks:
            raise TaskSourceError(f"{checker_type} requires at least one position bound")
        return CheckResult(
            all(checks),
            {"checker_type": checker_type, "passed": all(checks), "delta": delta, "checks": checks},
        )

    raise TaskSourceError(f"AXIS checker type {checker_type!r} is not in the 8-type vocabulary {AXIS_CHECKER_TYPES}")


class AxisChecker:
    """把 checker 声明包成统一接口。"""

    def __init__(self, config: Mapping[str, Any]) -> None:
        self.config = dict(config)
        checker_type = self.config.get("type")
        if checker_type not in (*AXIS_CHECKER_TYPES, "TabletopZoneChecker"):
            raise TaskSourceError(f"unknown AXIS checker type {checker_type!r}")
        self.checker_type = str(checker_type)

    def evaluate(self, state: Mapping[str, Any]) -> CheckResult:
        current, initial = _split_state(state)
        return evaluate_axis_checker(self.config, current, initial)

    def describe(self) -> Mapping[str, Any]:
        return {"source": "axis", "checker_type": self.checker_type, "config": self.config}


def _make_checker(config: Mapping[str, Any]) -> AxisChecker:
    return AxisChecker(config)


for _checker_type in AXIS_CHECKER_TYPES:
    register_checker("axis", _checker_type, _make_checker)
register_checker("axis", "TabletopZoneChecker", _make_checker)

# The new program checker consumes physical process evidence from its own env.
from .tabletop_v2 import ProgramChecker

register_checker("axis", "TabletopProgramChecker", ProgramChecker)


def checker_types_in(config: Mapping[str, Any]) -> set[str]:
    """递归收集 checker 配置里的所有 ``type``（含 Composite 的子节点）。"""
    found: set[str] = set()

    def visit(node: Any) -> None:
        if isinstance(node, Mapping):
            if isinstance(node.get("type"), str):
                found.add(node["type"])
                if node["type"] == "TabletopProgramChecker":
                    # The program has its own closed predicate schema; its nodes
                    # are not legacy AXIS checker types.
                    return
            for value in node.values():
                visit(value)
        elif isinstance(node, list):
            for value in node:
                visit(value)

    visit(config)
    return found


# ---------------------------------------------------------------------------
# MuJoCo 环境
# ---------------------------------------------------------------------------


class MujocoAxisEnv:
    """最小 MuJoCo 环境：加载题包场景，应用实例初始状态，按关节目标推进。

    ``mujoco`` 是可选依赖（AXIS 运行时机器上装）。没装时抛
    ``RuntimeUnavailable``，上层按基础设施问题重试，不判题不合格。
    """

    def __init__(self, package: TaskPackage, payload: Mapping[str, Any], runtime: Mapping[str, Any]) -> None:
        try:
            import mujoco  # noqa: F401
        except ImportError as exc:
            raise RuntimeUnavailable(
                "MuJoCo is not installed; install the AXIS runtime (see docs/task-package-format.md)"
            ) from exc
        import mujoco

        self.mujoco = mujoco
        self.payload = dict(payload)
        self.runtime = dict(runtime)
        if package.task.get("execution_profile"):
            from .tabletop import _profile_document

            if mujoco.__version__ != _profile_document()["physics"]["mujoco_version"]:
                raise RuntimeUnavailable("the frozen tabletop profile requires its exact MuJoCo version")
        self._tabletop_checker = (
            (package.task.get("checker") or {}).get("checker") if package.task.get("execution_profile") else None
        )
        self._tabletop_hold = 0
        xml = payload.get("mjcf_xml")
        if xml:
            self.model = mujoco.MjModel.from_xml_string(str(xml))
        else:
            scene = payload.get("scene")
            if not scene:
                raise TaskSourceError("AXIS payload must provide mjcf_xml or scene")
            self.model = mujoco.MjModel.from_xml_path(str(package.path(str(scene))))
        self.data = mujoco.MjData(self.model)
        self.joint_order = list(runtime.get("observation_joint_order", DEFAULT_JOINT_ORDER))
        self.control_period_s = float(runtime.get("control_period_s", 0.2))
        exact = self.control_period_s / float(self.model.opt.timestep)
        self.steps_per_control = int(round(exact))
        if self.steps_per_control < 1 or abs(exact - self.steps_per_control) > 1e-9:
            raise TaskSourceError(
                f"control period {self.control_period_s} is not divisible by timestep {self.model.opt.timestep}"
            )
        self._joint_ids = [self._named(mujoco.mjtObj.mjOBJ_JOINT, name) for name in self.joint_order]
        self._qpos_indices = [int(self.model.jnt_qposadr[joint_id]) for joint_id in self._joint_ids]
        self._actuator_ids = [self._named(mujoco.mjtObj.mjOBJ_ACTUATOR, name) for name in self.joint_order]
        self._initial: dict[str, Any] | None = None
        self._hand_id = self._body_id("hand")
        self._grasp_eqs = self._grasp_equalities(mujoco)
        self._grasp_radius = float(runtime.get("grasp_radius_m", 0.06))
        self._grasp_close_threshold = float(runtime.get("grasp_close_threshold", 0.015))
        self._attached: int | None = None

    def _grasp_equalities(self, mujoco: Any) -> list[tuple[int, int, str]]:
        """样题场景用 ``grasp_<body>`` 的 weld 表示磁吸夹爪。

        真实 AXIS 题包没有这些约束，列表为空、行为不变。约束只在夹爪闭合
        且手贴近物体时激活，不是「任意状态都粘住」。
        """
        found: list[tuple[int, int, str]] = []
        for eq_id in range(self.model.neq):
            name = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_EQUALITY, eq_id) or ""
            if not name.startswith("grasp_") or int(self.model.eq_type[eq_id]) != 1:
                continue
            body_id = int(self.model.eq_obj2id[eq_id])
            body_name = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_BODY, body_id) or name[len("grasp_") :]
            found.append((eq_id, body_id, body_name))
        return found

    def _attach_nearest(self) -> None:
        if self._hand_id < 0 or not self._grasp_eqs:
            return
        hand_position = self.data.xpos[self._hand_id]
        nearest: tuple[float, int, int] | None = None
        for eq_id, body_id, _ in self._grasp_eqs:
            delta = self.data.xpos[body_id] - hand_position
            distance = float(sum(value * value for value in delta) ** 0.5)
            if distance <= self._grasp_radius and (nearest is None or distance < nearest[0]):
                nearest = (distance, eq_id, body_id)
        if nearest is None:
            return
        _, eq_id, body_id = nearest
        self._anchor_equality(eq_id, body_id)
        self.data.eq_active[eq_id] = 1
        self._attached = eq_id

    def _anchor_equality(self, eq_id: int, body_id: int) -> None:
        """把 weld 的相对位姿设成「此刻」的相对位姿，避免激活瞬间弹开。"""
        mujoco = self.mujoco
        import numpy as np

        hand_position = self.data.xpos[self._hand_id]
        hand_quaternion = self.data.xquat[self._hand_id]
        body_position = self.data.xpos[body_id]
        body_quaternion = self.data.xquat[body_id]
        inverse = np.zeros(4)
        mujoco.mju_negQuat(inverse, hand_quaternion)
        relative_position = np.zeros(3)
        mujoco.mju_rotVecQuat(relative_position, body_position - hand_position, inverse)
        relative_quaternion = np.zeros(4)
        mujoco.mju_mulQuat(relative_quaternion, inverse, body_quaternion)
        self.model.eq_data[eq_id, 3:6] = relative_position
        self.model.eq_data[eq_id, 6:10] = relative_quaternion
        self.model.eq_data[eq_id, 10] = 1.0

    @property
    def joint_ids(self) -> tuple[int, ...]:
        """Joint ids in ``observation_joint_order`` (tool harnesses use them)."""

        return tuple(self._joint_ids)

    @property
    def qpos_indices(self) -> tuple[int, ...]:
        return tuple(self._qpos_indices)

    @property
    def actuator_ids(self) -> tuple[int, ...]:
        return tuple(self._actuator_ids)

    def _named(self, object_type: Any, name: str) -> int:
        object_id = self.mujoco.mj_name2id(self.model, object_type, name)
        if object_id < 0:
            short = name.rsplit("/", 1)[-1]
            object_id = self.mujoco.mj_name2id(self.model, object_type, short)
        if object_id < 0:
            raise TaskSourceError(f"scene has no {name!r} (tried short name {short!r})")
        return object_id

    def reset(self) -> Mapping[str, Any]:
        self.mujoco.mj_resetData(self.model, self.data)
        self._tabletop_hold = 0
        if self.model.neq:
            self.data.eq_active[:] = 0
        self._attached = None
        self.apply_state(self.payload.get("initial_state") or {})
        self.mujoco.mj_forward(self.model, self.data)
        self._initial = self._state()
        return self._initial

    def apply_state(self, state: Mapping[str, Any]) -> None:
        """把 AXIS 状态写进仿真（参考解回放 / 测试用）。"""
        normalized = _normalize_state(state)
        if "current" in normalized:
            normalized = normalized["current"]
        for name, position in normalized["positions"].items():
            body_id = self._body_id(name)
            if body_id < 0 or self.model.body_jntadr[body_id] < 0:
                continue
            joint_id = int(self.model.body_jntadr[body_id])
            if self.model.jnt_type[joint_id] != self.mujoco.mjtJoint.mjJNT_FREE:
                continue
            address = int(self.model.jnt_qposadr[joint_id])
            orientation = normalized["orientations"].get(name, [0.0, 0.0, 0.0, 1.0])
            # 题包的 ``rot`` 是 xyzw；MuJoCo 的 qpos 四元数是 wxyz。
            # 不转换会把 identity ``[0,0,0,1]`` 写成 180° 旋转。
            x, y, z, w = orientation
            self.data.qpos[address : address + 3] = position
            self.data.qpos[address + 3 : address + 7] = [w, x, y, z]
        for name, value in normalized["joints"].items():
            joint_id = self._joint_id(name)
            if joint_id >= 0 and self.model.jnt_type[joint_id] != self.mujoco.mjtJoint.mjJNT_FREE:
                self.data.qpos[int(self.model.jnt_qposadr[joint_id])] = value

    def _body_id(self, name: str) -> int:
        for candidate in (name, name.rstrip("/"), name.rsplit("/", 1)[-1]):
            body_id = self.mujoco.mj_name2id(self.model, self.mujoco.mjtObj.mjOBJ_BODY, candidate)
            if body_id >= 0:
                return body_id
        return -1

    def _joint_id(self, name: str) -> int:
        for candidate in (name, name.rsplit("/", 1)[-1]):
            joint_id = self.mujoco.mj_name2id(self.model, self.mujoco.mjtObj.mjOBJ_JOINT, candidate)
            if joint_id >= 0:
                return joint_id
        return -1

    def hold_current_pose(self) -> None:
        for actuator_id, qpos_index in zip(self._actuator_ids, self._qpos_indices):
            self.data.ctrl[actuator_id] = self.data.qpos[qpos_index]

    def step(self, action: Any) -> Mapping[str, Any]:
        values = [float(value) for value in action]
        if len(values) != len(self._actuator_ids):
            raise TaskSourceError(f"action must contain {len(self._actuator_ids)} joint targets")
        if not all(math.isfinite(value) for value in values):
            raise TaskSourceError("action contains non-finite values")
        if self._grasp_eqs:
            finger_target = min(values[0], values[1])
            if finger_target <= self._grasp_close_threshold:
                if self._attached is None:
                    self._attach_nearest()
            elif self._attached is not None:
                self.data.eq_active[self._attached] = 0
                self._attached = None
        for actuator_id, joint_id, value in zip(self._actuator_ids, self._joint_ids, values):
            if bool(self.model.jnt_limited[joint_id]):
                lower, upper = self.model.jnt_range[joint_id]
                value = min(float(upper), max(float(lower), value))
            self.data.ctrl[actuator_id] = value
        self.mujoco.mj_step(self.model, self.data, nstep=self.steps_per_control)
        if self._tabletop_checker:
            from .tabletop import zone_condition

            instant = zone_condition(self._tabletop_checker, self._state(), require_hold=False)
            self._tabletop_hold = self._tabletop_hold + 1 if instant.passed else 0
        return self._state()

    def null_action(self) -> list[float]:
        """全程不动：保持题包声明的初始关节目标。"""
        initial = (self.payload.get("initial_state") or {}).get("robots") or {}
        dof_pos = {}
        if isinstance(initial, Mapping):
            franka = initial.get("franka")
            if isinstance(franka, Mapping):
                dof_pos = franka.get("dof_pos") or {}
        values: list[float] = []
        for name, index in zip(self.joint_order, self._qpos_indices):
            short = name.rsplit("/", 1)[-1]
            value = dof_pos.get(name, dof_pos.get(short))
            values.append(float(value) if value is not None else float(self.model.qpos0[index]))
        return values

    def visibility(
        self,
        names: list[str],
        *,
        width: int = 320,
        height: int = 180,
        frame_margin: float = DEFAULT_FRAME_MARGIN,
        min_pixels: float | None = None,
        min_pixel_ratio: float | None = None,
        min_visible_fraction: float | None = None,
    ) -> Mapping[str, Mapping[str, Any]]:
        """目标物在「主相机」里是否可见。

        不用离屏渲染，结果确定、不依赖 GL 后端，CPU 准入机也能跑：

        1. 把目标 body（含子 body）的包围球投到成像平面，得到中心 ``u, v``
           和投影半径 ``projected_pixels``；
        2. 在投影圆内撒 ``VISIBILITY_GRID`` × ``VISIBILITY_GRID`` 个采样点，
           **两遍** ``mj_ray``：
           - 只放目标 body 的 geom（临时分配到空闲 geomgroup）→ 轮廓采样数；
           - 放全部 geom → 第一次命中是不是目标 body；
        3. 只把落在主相机「可用画面」（中心 ``2*frame_margin``）里的命中算
           可见；``visible_fraction`` = 可见采样 / 轮廓采样，``pixels`` 是
           可见面积的等效半径，``pixel_ratio`` = 可见面积 / 整幅画面。

        出画、遮挡、关灯、目标太小、目标只露一角（塞在画面边缘）都会
        ``visible=False``。阈值来自 profile，默认值见模块常量。
        """
        mujoco = self.mujoco
        width, height = int(width), int(height)
        frame_margin = float(frame_margin)
        min_pixels = DEFAULT_MIN_PIXELS if min_pixels is None else float(min_pixels)
        min_pixel_ratio = DEFAULT_MIN_PIXEL_RATIO if min_pixel_ratio is None else float(min_pixel_ratio)
        min_visible_fraction = (
            DEFAULT_MIN_VISIBLE_FRACTION if min_visible_fraction is None else float(min_visible_fraction)
        )
        camera_id = -1
        for candidate in ("camera0", "main", "head"):
            camera_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_CAMERA, candidate)
            if camera_id >= 0:
                break
        if camera_id < 0 and self.model.ncam:
            camera_id = 0
        if camera_id < 0:
            return {name: {"visible": False, "reason": "scene has no main camera"} for name in names}

        lighting = self._lighting()
        if not lighting["lit"]:
            return {name: {"visible": False, "reason": "no active light", "lighting": lighting} for name in names}

        mujoco.mj_camlight(self.model, self.data)
        camera_position = self.data.cam_xpos[camera_id]
        camera_matrix = self.data.cam_xmat[camera_id].reshape(3, 3)
        fovy = float(self.model.cam_fovy[camera_id]) * math.pi / 180.0
        focal = 0.5 * height / math.tan(fovy / 2.0)
        usable_width = width * frame_margin
        usable_height = height * frame_margin
        results: dict[str, Mapping[str, Any]] = {}
        for name in names:
            body_id = self._body_id(name)
            if body_id < 0:
                results[name] = {"visible": False, "reason": "body not in scene"}
                continue
            center = self.data.xpos[body_id]
            delta = center - camera_position
            in_camera = camera_matrix.T @ delta
            depth = -float(in_camera[2])
            if depth <= 0.0:
                results[name] = {"visible": False, "reason": "behind the camera"}
                continue
            u = focal * float(in_camera[0]) / depth
            v = focal * float(in_camera[1]) / depth
            radius = self._body_radius(body_id)
            projected_pixels = focal * radius / depth
            if abs(u) > usable_width or abs(v) > usable_height:
                results[name] = {
                    "visible": False,
                    "pixels": 0.0,
                    "pixel_ratio": 0.0,
                    "visible_fraction": 0.0,
                    "projected_pixels": round(projected_pixels, 3),
                    "reason": "outside the image",
                }
                continue

            sampled = self._sample_visibility(
                body_id,
                camera_position=camera_position,
                camera_matrix=camera_matrix,
                focal=focal,
                u=u,
                v=v,
                projected_pixels=projected_pixels,
                width=width,
                height=height,
                frame_margin=frame_margin,
            )
            visible_fraction = sampled["visible_fraction"]
            visible_pixels = sampled["visible_pixels"]
            pixel_ratio = sampled["pixel_ratio"]
            reason: str | None = None
            if sampled["clear_samples"] == 0:
                reason = "body not visible to the main camera"
            elif visible_fraction < min_visible_fraction:
                reason = "visible fraction below the pre-registered minimum"
            elif visible_pixels < min_pixels:
                reason = "too few pixels"
            elif min_pixel_ratio > 0.0 and pixel_ratio < min_pixel_ratio:
                reason = "pixel ratio below the pre-registered minimum"
            result: dict[str, Any] = {
                "visible": reason is None,
                "pixels": round(visible_pixels, 3),
                "pixel_ratio": round(pixel_ratio, 6),
                "visible_fraction": round(visible_fraction, 4),
                "projected_pixels": round(projected_pixels, 3),
                "occluded_at_m": sampled["occluded_at_m"],
            }
            if reason is not None:
                result["reason"] = reason
            results[name] = result
        return results

    def _sample_visibility(
        self,
        body_id: int,
        *,
        camera_position: Any,
        camera_matrix: Any,
        focal: float,
        u: float,
        v: float,
        projected_pixels: float,
        width: int,
        height: int,
        frame_margin: float,
    ) -> Mapping[str, Any]:
        """在投影圆内做两遍射线采样。返回可见面积 / 轮廓占比等。"""
        import numpy as np

        model = self.model
        data = self.data
        mujoco = self.mujoco
        body_set = self._body_set(body_id)
        target_geoms = [g for g in range(model.ngeom) if int(model.geom_bodyid[g]) in body_set]
        group = self._free_geom_group(target_geoms)
        saved_groups: dict[int, int] = {}
        if group is not None:
            saved_groups = {g: int(model.geom_group[g]) for g in target_geoms}
            for g in target_geoms:
                model.geom_group[g] = group
            group_filter = np.zeros(6, dtype=np.uint8)
            group_filter[group] = 1

        sample_area = (2.0 * projected_pixels / VISIBILITY_GRID) ** 2
        clear_samples = 0
        visible_samples = 0
        try:
            for row in range(VISIBILITY_GRID):
                dy = 2.0 * (row + 0.5) / VISIBILITY_GRID - 1.0
                for column in range(VISIBILITY_GRID):
                    dx = 2.0 * (column + 0.5) / VISIBILITY_GRID - 1.0
                    if dx * dx + dy * dy > 1.0:
                        continue
                    pixel_x = u + dx * projected_pixels
                    pixel_y = v + dy * projected_pixels
                    direction = camera_matrix @ np.array([pixel_x / focal, pixel_y / focal, -1.0], dtype=float)
                    length = float(np.linalg.norm(direction))
                    if length <= 0.0:
                        continue
                    direction /= length

                    if group is None:
                        # 没有空闲 geomgroup 时退化为「投影圆」分母：仍然
                        # 统计可见命中，但 visible_fraction 会偏低。
                        clear_samples += 1
                    else:
                        geom_id = np.zeros(1, dtype=np.int32)
                        normal = np.zeros(3)
                        hit = float(
                            mujoco.mj_ray(
                                model,
                                data,
                                camera_position,
                                direction,
                                group_filter,
                                True,
                                -1,
                                geom_id,
                                normal,
                            )
                        )
                        if hit >= 0.0:
                            clear_samples += 1

                    if abs(pixel_x) > width * frame_margin or abs(pixel_y) > height * frame_margin:
                        continue
                    geom_id = np.zeros(1, dtype=np.int32)
                    normal = np.zeros(3)
                    hit = float(
                        mujoco.mj_ray(
                            model,
                            data,
                            camera_position,
                            direction,
                            None,
                            True,
                            -1,
                            geom_id,
                            normal,
                        )
                    )
                    if hit >= 0.0 and int(model.geom_bodyid[geom_id[0]]) in body_set:
                        visible_samples += 1
        finally:
            for geom_id, group_value in saved_groups.items():
                model.geom_group[geom_id] = group_value

        visible_area = visible_samples * sample_area
        visible_pixels = math.sqrt(visible_area / math.pi) if visible_area > 0.0 else 0.0
        visible_fraction = visible_samples / clear_samples if clear_samples else 0.0
        pixel_ratio = visible_area / float(width * height)

        # 中心射线的遮挡距离只用于证据展示；可见性由上面的面积采样判定。
        body_center = self.data.xpos[body_id]
        delta = body_center - camera_position
        distance = max(1e-9, float(delta @ delta) ** 0.5)
        direction = delta / distance
        geom_id = np.zeros(1, dtype=np.int32)
        normal = np.zeros(3)
        center_hit = float(
            mujoco.mj_ray(
                model,
                data,
                camera_position,
                direction,
                None,
                True,
                -1,
                geom_id,
                normal,
            )
        )
        occluded_at: float | None = None
        if (
            0.0 <= center_hit < distance - self._body_radius(body_id) - 0.005
            and int(model.geom_bodyid[geom_id[0]]) not in body_set
        ):
            occluded_at = round(center_hit, 4)

        return {
            "visible_fraction": visible_fraction,
            "visible_pixels": visible_pixels,
            "pixel_ratio": pixel_ratio,
            "clear_samples": clear_samples,
            "visible_samples": visible_samples,
            "occluded_at_m": occluded_at,
        }

    def _body_set(self, body_id: int) -> set[int]:
        """目标 body 及其所有子 body（柜子、抽屉这类复合物体）。"""
        bodies = {int(body_id)}
        changed = True
        while changed:
            changed = False
            for candidate in range(int(self.model.nbody)):
                if candidate in bodies:
                    continue
                if int(self.model.body_parentid[candidate]) in bodies:
                    bodies.add(candidate)
                    changed = True
        return bodies

    def _free_geom_group(self, target_geoms: list[int]) -> int | None:
        """找一个不包含其他 geom 的 group，供「只看目标轮廓」的射线使用。"""
        target = set(target_geoms)
        used = {int(self.model.geom_group[geom_id]) for geom_id in range(self.model.ngeom) if geom_id not in target}
        for candidate in (5, 4, 3, 2, 1):
            if candidate not in used:
                return candidate
        return None

    def _lighting(self) -> Mapping[str, Any]:
        """场景有没有可用的光。

        ``nlight == 0`` 时 MuJoCo 用默认头灯，画面不是黑的；声明了灯但全部
        ``active=false`` 或亮度为零时，目标物投影还在，但渲染出来是黑的 ——
        也就是「关灯藏物体」，必须判不可见。
        """
        declared = int(self.model.nlight)
        if declared == 0:
            return {"lit": True, "declared": 0, "active": [], "reason": "default headlight"}
        active: list[int] = []
        for light_id in range(declared):
            if not bool(self.model.light_active[light_id]):
                continue
            diffuse = self.model.light_diffuse[light_id]
            if float(sum(abs(float(value)) for value in diffuse)) <= 1e-9:
                continue
            active.append(light_id)
        return {"lit": bool(active), "declared": declared, "active": active}

    def _body_radius(self, body_id: int) -> float:
        """目标 body（含子 body）包围球半径，以 body 原点为中心。"""
        origin = tuple(float(value) for value in self.data.xpos[body_id])
        bodies = self._body_set(body_id)
        radius = 0.0
        for geom_id in range(self.model.ngeom):
            if int(self.model.geom_bodyid[geom_id]) not in bodies:
                continue
            geom_center = tuple(float(value) for value in self.data.geom_xpos[geom_id])
            offset = math.dist(geom_center, origin)
            radius = max(radius, offset + float(self.model.geom_rbound[geom_id]))
        return radius or 0.01

    def state(self) -> Mapping[str, Any]:
        return self._state()

    def _state(self) -> dict[str, Any]:
        mujoco = self.mujoco
        positions, orientations, joints = {}, {}, {}
        for body_id in range(self.model.nbody):
            name = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_BODY, body_id)
            if not name or name == "world":
                continue
            positions[name] = [float(value) for value in self.data.xpos[body_id]]
            w, x, y, z = [float(value) for value in self.data.xquat[body_id]]
            orientations[name] = [x, y, z, w]
        for joint_id in range(self.model.njnt):
            name = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_JOINT, joint_id)
            if name and self.model.jnt_type[joint_id] != mujoco.mjtJoint.mjJNT_FREE:
                joints[name] = float(self.data.qpos[int(self.model.jnt_qposadr[joint_id])])
        result = {
            "positions": positions,
            "orientations": orientations,
            "joints": joints,
            "site_positions": {},
            "site_orientations": {},
        }
        if self._tabletop_checker:
            linear, angular = {}, {}
            for body_id in range(self.model.nbody):
                name = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_BODY, body_id)
                if not name:
                    continue
                import numpy as np

                velocity = np.zeros(6)
                mujoco.mj_objectVelocity(self.model, self.data, mujoco.mjtObj.mjOBJ_BODY, body_id, velocity, 0)
                angular[name] = [float(v) for v in velocity[:3]]
                linear[name] = [float(v) for v in velocity[3:]]
            result.update(
                linear_velocities=linear, angular_velocities=angular, tabletop_goal_hold_steps=self._tabletop_hold
            )
        return result

    def close(self) -> None:
        self.data = None


# ---------------------------------------------------------------------------
# TaskSource
# ---------------------------------------------------------------------------


class AxisSource(TaskSource):
    source = "axis"

    def __init__(self, options: Mapping[str, Any] | None = None) -> None:
        options = dict(options or {})
        self.expected_execution_profile = options.get("expected_execution_profile")
        self.scene_context = options.get("scene_context")
        self.scene_reference = options.get("scene_reference")
        self.scene_event_sink = options.get("scene_event_sink")
        self.scene_deadline = options.get("scene_deadline", math.inf)
        self.scene_replay_sink = options.get("scene_replay_sink")
        self.package_root = pathlib.Path(options.get("package_root") or "samples/axis").expanduser()
        if not self.package_root.is_absolute():
            from .registry import VALIDATOR_ROOT

            self.package_root = VALIDATOR_ROOT / self.package_root
        self._cache: dict[str, TaskPackage] = {}

    def _packages(self) -> dict[str, TaskPackage]:
        if self._cache:
            return self._cache
        from .package import discover_packages

        packages: dict[str, TaskPackage] = {}
        for directory in discover_packages(self.package_root):
            declared_scene = False
            try:
                document = read_json(directory / "task.json")
                declared_scene = isinstance(document, Mapping) and (
                    document.get("schema_version") == 3
                    or isinstance(document.get("execution_profile"), Mapping)
                    and document["execution_profile"].get("id") == "panda-open-scene-v1"
                )
                if declared_scene:
                    from .scene_runtime import import_context

                    context = self.scene_context if self.scene_context is not None else import_context()
                    package = load_package(directory, scene_context=context)
                else:
                    package = load_package(directory)
            except TaskSourceError:
                if declared_scene:
                    raise
                continue
            if package.source == self.source:
                packages[package.task_id] = package
        self._cache = packages
        return packages

    def list_tasks(self) -> list[str]:
        return sorted(self._packages(), key=lambda value: (len(value), value))

    def load_task(self, task_id: str, instance: int | None = None) -> TaskSpec:
        package = self._packages().get(str(task_id))
        if package is None:
            raise UnknownTask(f"axis task {task_id!r} not found under {self.package_root}")
        from .profile_dispatch import validate_package as validate_tabletop

        profile_summary = validate_tabletop(package, expected_execution_profile=self.expected_execution_profile)
        if hasattr(package, "imported_scene"):
            from .scene_runtime import make_task

            return make_task(package, instance=instance, reference=self.scene_reference)
        checker_config = package.task.get("checker")
        if not isinstance(checker_config, Mapping):
            raise TaskSourceError(f"{package.directory}: task.json must contain a 'checker' object")
        benchmark = self._benchmark(package)
        randomization = self._randomization(package)
        runtime = dict(benchmark.get("runtime") or {})
        runtime.update(package.task.get("runtime") or {})

        variants = randomization.get("variants")
        if not isinstance(variants, list) or not variants:
            raise TaskSourceError(f"{package.directory}: randomization.json has no variants")
        instances: list[InstanceSpec] = []
        for variant in variants:
            number = int(variant["instance"])
            payload_path = str(variant["payload_path"])
            payload = read_json(package.path(payload_path))
            instances.append(
                InstanceSpec(
                    instance=number,
                    initial_state=payload.get("initial_state") or {},
                    payload_path=payload_path,
                    payload_sha256=variant.get("payload_canonical_sha256"),
                    checker_sha256=variant.get("checker_sha256"),
                    initial_state_sha256=variant.get("initial_state_sha256"),
                    seed=variant.get("seed"),
                    metadata={"payload": payload},
                )
            )
        total_instances = len(instances)
        if instance is not None:
            instances = [item for item in instances if item.instance == int(instance)]
            if not instances:
                raise UnknownTask(f"axis task {task_id!r} has no instance {instance}")

        reference = self._reference(package)
        return TaskSpec(
            task_id=str(task_id),
            source=self.source,
            instruction=package.instruction,
            package_dir=str(package.directory),
            action_space=ACTION_SPACE,
            observation_space=OBSERVATION_SPACE,
            checker_config=checker_config,
            instances=tuple(instances),
            reference=reference,
            metadata={
                "title": package.task.get("title"),
                "skill": package.task.get("skill"),
                "instance_count": total_instances,
                "benchmark": benchmark.get("name"),
                "runtime": runtime,
                "benchmark_config": benchmark,
                "randomization": randomization,
                "package": package,
                **(profile_summary or {}),
            },
        )

    def _benchmark(self, package: TaskPackage) -> Mapping[str, Any]:
        path = package.path("benchmark.json")
        if not path.is_file():
            raise TaskSourceError(f"{package.directory}: missing benchmark.json")
        benchmark = read_json(path)
        if not isinstance(benchmark, Mapping):
            raise TaskSourceError(f"{path}: must be an object")
        tasks = [task for task in benchmark.get("tasks") or [] if str(task.get("task_id")) == package.task_id]
        if len(tasks) != 1:
            raise TaskSourceError(f"{path}: must contain exactly one task with task_id={package.task_id}")
        return benchmark

    def _randomization(self, package: TaskPackage) -> Mapping[str, Any]:
        path = package.path("randomization.json")
        if not path.is_file():
            raise TaskSourceError(f"{package.directory}: missing randomization.json")
        randomization = read_json(path)
        if not isinstance(randomization, Mapping):
            raise TaskSourceError(f"{path}: must be an object")
        tasks = [task for task in randomization.get("tasks") or [] if str(task.get("task_id")) == package.task_id]
        if len(tasks) != 1 or not isinstance(tasks[0].get("variants"), list):
            raise TaskSourceError(f"{path}: must contain one task with task_id={package.task_id} and variants")
        return tasks[0]

    def _reference(self, package: TaskPackage) -> Mapping[str, Any] | None:
        relative = package.task.get("reference_solution")
        if not relative:
            return None
        path = package.path(str(relative))
        if not path.is_file():
            raise TaskSourceError(f"{package.directory}: reference_solution {relative!r} not found")
        reference = read_json(path)
        if not isinstance(reference, Mapping) or not isinstance(reference.get("instances"), Mapping):
            raise TaskSourceError(f"{path}: reference must contain an 'instances' object")
        return reference

    def make_env(self, task: TaskSpec, instance: int | None = None) -> Env:
        package = self._package_for(task)
        instance_spec = self._instance_for(task, instance)
        if "imported_scene" in task.metadata:
            from .scene_env import SceneMujocoEnv

            return SceneMujocoEnv(
                task.metadata["imported_scene"],
                instance_spec.metadata["scene_state_id"],
                event_sink=self.scene_event_sink,
                deadline=self.scene_deadline,
            )
        payload = instance_spec.metadata.get("payload") or {}
        from openroboto_protocol.task_profiles import is_v2

        if is_v2(package.task.get("execution_profile")):
            from .tabletop_v2_env import ComposedMujocoAxisEnv

            return ComposedMujocoAxisEnv(package, payload, task.metadata.get("runtime") or {})
        return MujocoAxisEnv(package, payload, task.metadata.get("runtime") or {})

    def checker(self, task: TaskSpec) -> Checker:
        if "imported_scene" in task.metadata:
            from .scene_geometry import SceneResolver
            from .scene_runtime import validated_definition
            from .tabletop_v2 import ProgramChecker

            config = dict(task.checker_config.get("checker", task.checker_config))
            config["definition"] = validated_definition(task.metadata["imported_scene"])
            return ProgramChecker(
                config,
                resolver=SceneResolver(task.metadata["imported_scene"]),
            )
        from .registry import create_checker

        root = task.checker_config.get("checker", task.checker_config)
        return create_checker(self.source, root)

    def replay_step_limit(self, task: TaskSpec) -> int:
        return _axis_step_limit(task)

    def replay_observation_evidence(self, task, env, initial):
        if "imported_scene" not in task.metadata:
            return None
        from agent_harness.runtimes import _AxisArm, scene_tool_observation
        from .scene_observation import validate_observation

        observation = scene_tool_observation(
            env,
            task=task,
            step=0,
            instruction=task.instruction,
            proprioception=_AxisArm(env).proprioception(),
            success=bool(self.checker(task).evaluate({"current": initial, "initial": initial}).passed),
        )
        return validate_observation(task, env, observation)

    def replay(self, task, instance, **options):
        result = super().replay(task, instance, **options)
        if "imported_scene" in task.metadata and self.scene_replay_sink is not None:
            self.scene_replay_sink(instance, options.get("mode", "oracle"), result)
        return result

    def perturb_reference_actions(self, task, instance, actions, noise, *, seed):
        if not task.metadata.get("execution_profile"):
            return super().perturb_reference_actions(task, instance, actions, noise, seed=seed)
        if noise.get("action_transform") != "panda_tcp_fk_ik_v1":
            raise RuntimeUnavailable("Panda admission requires the registered panda_tcp_fk_ik_v1 noise policy")
        from .tabletop_noise import perturb_joint_reference

        if "imported_scene" in task.metadata:
            from .scene_runtime import kinematic_environment

            return perturb_joint_reference(
                kinematic_environment(task, instance, deadline=self.scene_deadline), actions, noise, seed=seed
            )

        env = self.make_env(task, instance)
        try:
            env.reset()
            return perturb_joint_reference(env, actions, noise, seed=seed)
        finally:
            env.close()

    def target_bodies(self, task: TaskSpec) -> list[str]:
        if "imported_scene" in task.metadata:
            return list(task.metadata["imported_scene"].bindings["bodies"])
        if task.metadata.get("execution_profile"):
            package = self._package_for(task)
            definition = package.task["task_definition"]
            from openroboto_protocol.task_profiles import is_v2

            if is_v2(task.metadata["execution_profile"]):
                return [str(obj["id"]) for obj in definition["objects"]] + [
                    f"zone_{z['id']}" for z in definition["zones"]
                ]
            return [str(obj["id"]) for obj in definition["objects"]] + [
                f"target_zone_{i}" for i in range(len(definition["goals"]))
            ]
        return super().target_bodies(task)

    @property
    def action_space(self) -> Space:
        return ACTION_SPACE

    @property
    def observation_space(self) -> Space:
        return OBSERVATION_SPACE

    def _package_for(self, task: TaskSpec) -> TaskPackage:
        package = task.metadata.get("package")
        if isinstance(package, TaskPackage):
            return package
        return load_package(task.package_dir)

    @staticmethod
    def _instance_for(task: TaskSpec, instance: int | None) -> InstanceSpec:
        if instance is None:
            return task.instances[0]
        for item in task.instances:
            if item.instance == int(instance):
                return item
        raise UnknownTask(f"axis task {task.task_id!r} has no instance {instance}")

    def static_checks(self, task: TaskSpec) -> list[tuple[str, bool, Mapping[str, Any]]]:
        return _axis_static_checks(task)

    def runtime_status(self) -> tuple[str, Mapping[str, Any]]:
        try:
            import mujoco
        except ImportError:
            return "unavailable", {
                "requires": "MuJoCo",
                "hint": "install the AXIS runtime on the CPU admission worker (see docs/task-package-format.md)",
            }
        return "ready", {"mujoco": getattr(mujoco, "__version__", "unknown")}


def _axis_step_limit(task: TaskSpec) -> int:
    if "imported_scene" in task.metadata:
        return task.metadata["execution_contract"]["budget"]["max_steps"]
    benchmark = task.metadata.get("benchmark_config") or {}
    protocol = benchmark.get("protocol")
    limit = protocol.get("max_control_steps_per_trial") if isinstance(protocol, Mapping) else None
    # No harness default or int() coercion: this is part of the submitted
    # frozen definition, not a worker's optional operational override.
    if type(limit) is not int or limit <= 0:
        raise TaskSourceError("benchmark.protocol.max_control_steps_per_trial must be a positive integer")
    return limit


def _axis_static_checks(task: TaskSpec) -> list[tuple[str, bool, Mapping[str, Any]]]:
    if "imported_scene" in task.metadata:
        from .scene_runtime import static_checks

        return static_checks(task)
    checks: list[tuple[str, bool, Mapping[str, Any]]] = []
    package = task.metadata.get("package")
    if not isinstance(package, TaskPackage):
        package = load_package(task.package_dir)

    # Validate the budget even when no reference was supplied. Otherwise a
    # missing/invalid frozen limit could fall back to an unrelated run budget.
    budget_errors: list[dict[str, Any]] = []
    try:
        limit = _axis_step_limit(task)
    except TaskSourceError as exc:
        limit = None
        budget_errors.append({"error": str(exc)})
    if limit is not None:
        for item in task.instances:
            reference = task.reference_for(item.instance) or {}
            actions = reference.get("actions")
            if isinstance(actions, list) and len(actions) > limit:
                budget_errors.append({"instance": item.instance, "actions": len(actions), "limit": limit})
    checks.append(("axis.reference_step_budget", not budget_errors, {"limit": limit, "errors": budget_errors}))
    # CLI 和 worker 使用同一份轻量参考轨迹契约，新旧题都不允许错头或超预算。
    if task.reference is not None:
        try:
            from openroboto_protocol.task_contract import reference_contract_issues
        except ImportError:
            # 旧安装保留原有行为；新方案的 load_task 已强制要求新协议。
            reference_issues = []
        else:
            reference_issues = list(
                reference_contract_issues(
                    task.reference,
                    task_id=task.task_id,
                    instance_ids=[item.instance for item in task.instances],
                    step_limit=limit,
                )
            )
        checks.append((
            "axis.reference_contract",
            not reference_issues,
            {"issues": [{"code": i.code, "path": i.path, "message": i.message} for i in reference_issues]},
        ))

    # 1) 旧词表八种；精确验证的新 profile 额外允许其受限目标。
    declared = checker_types_in(task.checker_config)
    allowed_types = set(AXIS_CHECKER_TYPES)
    if task.metadata.get("execution_profile"):
        from openroboto_protocol.task_profiles import checker_types_for_profile

        allowed_types.update(checker_types_for_profile(task.metadata["execution_profile"]))
    unknown = sorted(declared - allowed_types)
    checks.append((
        "axis.checker_vocabulary",
        not unknown and bool(declared),
        {"declared": sorted(declared), "unknown": unknown, "vocabulary": sorted(allowed_types)},
    ))

    # 2) 实例数：题包规范 1..20。
    count = int(task.metadata.get("instance_count") or len(task.instances))
    from openroboto_protocol.task_profiles import is_v2

    max_instances = 64 if is_v2(task.metadata.get("execution_profile")) else 20
    checks.append((
        "axis.instance_count",
        1 <= count <= max_instances,
        {"count": count, "min": 1, "max": max_instances},
    ))

    # 3) payload 的 canonical 哈希 / checker 哈希 / id / 指令一致。
    hash_errors: list[str] = []
    for item in task.instances:
        payload = item.metadata.get("payload") or {}
        actual = canonical_json_sha256(payload)
        if item.payload_sha256 is None or actual != item.payload_sha256:
            declared = str(item.payload_sha256)[:12]
            hash_errors.append(f"instance {item.instance}: payload hash {actual[:12]} != {declared}")
        manifest_checker = canonical_json_sha256(payload.get("checker_config"))
        if item.checker_sha256 is None or manifest_checker != item.checker_sha256:
            hash_errors.append(
                f"instance {item.instance}: checker hash {manifest_checker[:12]} != {str(item.checker_sha256)[:12]}"
            )
        if str(payload.get("id")) != task.task_id:
            hash_errors.append(f"instance {item.instance}: payload id {payload.get('id')!r} != {task.task_id!r}")
        if payload.get("checker_config") != task.checker_config:
            hash_errors.append(f"instance {item.instance}: payload checker_config differs from task.json")
        state_hash = canonical_json_sha256(payload.get("initial_state") or {})
        if item.initial_state_sha256 is not None and state_hash != item.initial_state_sha256:
            hash_errors.append(f"instance {item.instance}: initial state hash differs")
        if not payload.get("mjcf_xml") and not (payload.get("scene") and package.path(str(payload["scene"])).is_file()):
            hash_errors.append(f"instance {item.instance}: no mjcf_xml and no readable scene")
    checks.append(("axis.payload_hashes", not hash_errors, {"errors": hash_errors}))

    # 4) benchmark.json 与 randomization.json 的声明和实际 payload 对账。
    benchmark_task = next(
        (
            item
            for item in (task.metadata.get("benchmark_config") or {}).get("tasks", [])
            if str(item.get("task_id")) == task.task_id
        ),
        {},
    )
    first = task.instances[0].metadata.get("payload") or {}
    manifest_errors = []
    if benchmark_task.get("checker_sha256") != canonical_json_sha256(first.get("checker_config")):
        manifest_errors.append("benchmark.checker_sha256 does not match payload")
    if benchmark_task.get("initial_state_sha256") != canonical_json_sha256(first.get("initial_state") or {}):
        manifest_errors.append("benchmark.initial_state_sha256 does not match payload")
    if str(benchmark_task.get("instruction")) != task.instruction:
        manifest_errors.append("benchmark.instruction does not match task.json")
    checks.append(("axis.manifest_hashes", not manifest_errors, {"errors": manifest_errors}))
    return checks


register_source("axis", AxisSource)


__all__ = [
    "ACTION_SPACE",
    "AXIS_CHECKER_TYPES",
    "AxisChecker",
    "AxisSource",
    "MujocoAxisEnv",
    "OBSERVATION_SPACE",
    "checker_types_in",
    "evaluate_axis_checker",
]
