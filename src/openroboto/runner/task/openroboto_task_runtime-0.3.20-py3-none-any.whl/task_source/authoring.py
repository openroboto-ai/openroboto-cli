"""技术作者的受限桌面制题、参考操作与免费本地自测入口。

本模块不提交、不付费、不连接模型服务。作者脚本只在作者自己显式执行
record-reference 时运行；正式 worker 只读取动作 JSON 并真实回放。
"""

from __future__ import annotations

import argparse
import importlib.util
import inspect
import json
import pathlib
import shutil
import sys
from typing import Any

from .base import TaskSourceError
from .package import package_digest, read_json, write_json
from .tabletop import DATA, _contract, _scene, package_documents, profile_ref, verify_platform_assets


def build_package(
    definition_path: pathlib.Path, output: pathlib.Path, *, task_id: str, title: str, public_summary: Any = None
) -> dict[str, Any]:
    definition = read_json(definition_path)
    if (
        isinstance(definition, dict)
        and isinstance(definition.get("execution_profile"), dict)
        and definition["execution_profile"].get("id") == "panda-tabletop-v2"
    ):
        from .tabletop_v2 import build_package as build_v2

        return build_v2(definition_path, output, task_id=task_id, title=title, public_summary=public_summary)
    if isinstance(definition, dict) and any(
        k in definition for k in ("schema_version", "execution_profile", "task_definition")
    ):
        allowed = {"schema_version", "execution_profile", "task_definition", "public_summary"}
        if (
            type(definition.get("schema_version")) is not int
            or definition["schema_version"] != 1
            or set(definition) - allowed
        ):
            raise TaskSourceError("authoring definition wrapper must be schema 1 with only published contract fields")
        issues = _contract().validate_task_document(
            definition, expected_execution_profile=profile_ref(), require_profile=True
        )
        if issues:
            raise TaskSourceError("; ".join(f"{i.code}: {i.message}" for i in issues))
        if public_summary is None:
            public_summary = definition.get("public_summary")
        definition = definition["task_definition"]
    docs = package_documents(task_id, title, definition, public_summary=public_summary)
    if output.exists():
        raise TaskSourceError(f"output already exists; choose a new package directory: {output}")
    output.mkdir(parents=True)
    try:
        for relative, document in docs.items():
            write_json(output / relative, document, indent=2)
        for relative in verify_platform_assets():
            if relative == "scene.xml":
                continue
            destination = output / "runtime" / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(DATA / relative, destination)
        (output / "runtime" / "scene.xml").write_text(_scene(definition))
        write_json(
            output / "reference.json",
            {
                "schema_version": 1,
                "task_id": task_id,
                "instances": {str(i): {"actions": [], "final_state": {}} for i in range(definition["instance_count"])},
            },
            indent=2,
        )
    except BaseException:
        # 保留失败包供作者检查；不能把部分构建当作可提交任务。
        raise
    return {
        "path": str(output),
        "execution_profile": profile_ref(),
        "package_digest": package_digest(output),
        "reference_ready": False,
        "next": "record-reference with a local solve(runtime, task, instance) script; then self-test",
    }


def record_reference(package: pathlib.Path, script: pathlib.Path) -> dict[str, Any]:
    if read_json(package / "task.json").get("schema_version") == 3:
        raise TaskSourceError("schema3 requires scene-record-reference with a NEW private root and detached manifest")
    from agent_harness.runtimes import AxisToolRuntime
    from .axis import AxisSource

    if not script.is_file():
        raise TaskSourceError(f"reference script not found: {script}")
    try:
        script.resolve().relative_to(package.resolve())
    except ValueError:
        pass
    else:
        raise TaskSourceError("keep the local reference-generation script outside the submitted package")
    module_spec = importlib.util.spec_from_file_location("local_reference_solution", script)
    if module_spec is None or module_spec.loader is None:
        raise TaskSourceError("cannot load the explicit local reference script")
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)
    solve = getattr(module, "solve", None)
    if not callable(solve):
        raise TaskSourceError("reference script must define solve(runtime, task, instance)")
    from .profile_dispatch import package_profile
    from .package import load_package

    source = AxisSource({
        "package_root": str(package),
        "expected_execution_profile": package_profile(load_package(package)),
    })
    source_id = str(read_json(package / "task.json")["task_id"])
    task = source.load_task(source_id)
    limit = source.replay_step_limit(task)
    instances = {}
    for instance in task.instances:
        runtime = AxisToolRuntime(task, instance.instance, source, max_steps=limit)
        # 参考动作生成不需要逐工具渲染；物理和观测状态仍来自真实 env。
        if task.metadata.get("observation_contract") != "vision":
            runtime.render = lambda: None
        actions: list[list[float]] = []
        original_step = runtime.env.step
        tool_actions: list[dict[str, Any]] = []
        call_depth = 0

        def capture_tool(name, method):
            signature = inspect.signature(method)

            def recording_tool(*args, **kwargs):
                nonlocal call_depth
                outer = call_depth == 0
                bound = signature.bind(*args, **kwargs)
                bound.apply_defaults()
                call_depth += 1
                try:
                    result = method(*args, **kwargs)
                finally:
                    call_depth -= 1
                if outer:
                    # JSON 形状与正式 execute_tool 相同，不能保存作者 Python 代码。
                    payload = json.loads(json.dumps(dict(bound.arguments), allow_nan=False))
                    tool_actions.append({"name": name, "args": payload})
                return result

            return recording_tool

        for tool in ("observe", "move_to", "grasp", "release", "step"):
            setattr(runtime, tool, capture_tool(tool, getattr(runtime, tool)))

        def recording_step(action):
            if len(actions) >= limit:
                raise TaskSourceError(f"reference exceeds its {limit}-step budget")
            result = original_step(action)
            actions.append([float(v) for v in action])
            return result

        runtime.env.step = recording_step
        try:
            solve(runtime, task, instance.instance)
            final = dict(runtime.env.state())
            verdict = source.checker(task).evaluate({"current": final, "initial": instance.initial_state})
            if not actions or not verdict.passed:
                raise TaskSourceError(f"reference did not solve instance {instance.instance}: {dict(verdict.detail)}")
            instances[str(instance.instance)] = {"actions": actions, "tool_actions": tool_actions, "final_state": final}
        finally:
            runtime.env.close()
            renderer = getattr(runtime, "_renderer", None)
            if renderer is not None:
                renderer.close()
    # 只有全部实例真实完成后才写新参考解；任何失败不覆盖旧参考解。
    write_json(
        package / "reference.json", {"schema_version": 1, "task_id": source_id, "instances": instances}, indent=2
    )
    return {
        "path": str(package),
        "reference_ready": True,
        "instances": len(instances),
        "steps": {i: len(v["actions"]) for i, v in instances.items()},
        "package_digest": package_digest(package),
    }


def self_test(package: pathlib.Path) -> dict[str, Any]:
    if read_json(package / "task.json").get("schema_version") == 3:
        raise TaskSourceError("schema3 requires scene-self-test with verified private root and detached manifest")
    from .axis import AxisSource
    from .runtime import _noise_for, get_profile

    from .profile_dispatch import package_profile
    from .package import load_package

    selected_profile = package_profile(load_package(package))
    source = AxisSource({"package_root": str(package), "expected_execution_profile": selected_profile})
    task = source.load_task(str(read_json(package / "task.json")["task_id"]))
    static = list(source.static_checks(task))
    if not all(ok for _, ok, _ in static):
        return {
            "accepted": False,
            "phase": "static",
            "checks": [{"name": name, "passed": bool(ok), "detail": detail} for name, ok, detail in static],
        }
    # Use the release's registered policy, not a package-supplied relaxation.
    noise = _noise_for(task, get_profile("axis-cpu")["runtime"]["noise"])
    checks = []
    for instance in task.instances:
        oracle = source.replay(task, instance.instance, mode="oracle")
        repeated = source.replay(task, instance.instance, mode="oracle")
        nop = source.replay(task, instance.instance, mode="nop")
        checker = source.checker(task)
        passes = checker.evaluate({"current": oracle.final_state, "initial": instance.initial_state}).passed
        idle_passes = checker.evaluate({"current": nop.final_state, "initial": instance.initial_state}).passed
        seed = int(instance.seed if instance.seed is not None else instance.instance)
        noise_passes = True
        for trial in range(int(noise.get("trials", 1))):
            perturbed = source.replay(
                task, instance.instance, mode="noise", seed=(seed * 1009 + trial + 1) & 0x7FFFFFFF, noise=noise
            )
            noise_passes &= checker.evaluate({
                "current": perturbed.final_state,
                "initial": perturbed.initial_state,
            }).passed
        checks.append({
            "instance": instance.instance,
            "reference_success": passes,
            "deterministic": oracle.state_digest == repeated.state_digest,
            "nop_success": idle_passes,
            "noise_success": bool(noise_passes),
            "steps": oracle.actions,
        })
    return {
        "accepted": all(
            c["reference_success"] and c["deterministic"] and not c["nop_success"] and c["noise_success"]
            for c in checks
        ),
        "phase": "local-physics",
        "execution_profile": selected_profile,
        "checks": checks,
        "package_digest": package_digest(package),
        "noise_policy": noise,
        "scope": (
            "local reference/nop/repeat/noise using the bundled release policy; "
            "formal admission additionally applies its operator policy, visibility and dedup rules"
        ),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    describe = commands.add_parser("describe")
    describe.add_argument("--include-development", action="store_true")
    initialize = commands.add_parser(
        "initialize-dedup", help="create a new single-authority admission index; never overwrite"
    )
    initialize.add_argument("--index", type=pathlib.Path, required=True)
    build = commands.add_parser("build")
    build.add_argument("--definition", type=pathlib.Path, required=True)
    build.add_argument("--output", type=pathlib.Path, required=True)
    build.add_argument("--task-id", default="authored-tabletop-task")
    build.add_argument("--title", default="Authored tabletop task")
    build.add_argument("--public-summary", type=pathlib.Path)
    record = commands.add_parser("record-reference")
    record.add_argument("package", type=pathlib.Path)
    reference = record.add_mutually_exclusive_group(required=True)
    reference.add_argument("--script", type=pathlib.Path)
    reference.add_argument(
        "--example", action="store_true", help="run the bundled real one-cube pushing example, not a universal solver"
    )
    test = commands.add_parser("self-test")
    test.add_argument("package", type=pathlib.Path)
    test.add_argument("--output", type=pathlib.Path)
    scene_record = commands.add_parser(
        "scene-record-reference", help="record all schema-3 states into a NEW private root"
    )
    scene_record.add_argument("--execution", type=pathlib.Path, required=True)
    scene_record.add_argument("--private", type=pathlib.Path, required=True)
    scene_record.add_argument("--manifest", type=pathlib.Path, required=True)
    scene_record.add_argument("--script", type=pathlib.Path, required=True)
    scene_record.add_argument("--output", type=pathlib.Path, required=True)
    scene_record.add_argument("--timeout-seconds", type=float, default=900.0)
    scene_record.add_argument("--max-reference-steps", type=int)
    scene_test = commands.add_parser("scene-self-test", help="real all-state physics using verified E/P and manifest")
    scene_test.add_argument("--execution", type=pathlib.Path, required=True)
    scene_test.add_argument("--private", type=pathlib.Path, required=True)
    scene_test.add_argument("--manifest", type=pathlib.Path, required=True)
    scene_test.add_argument("--expect-submission-digest", required=True)
    scene_test.add_argument("--output", type=pathlib.Path, required=True)
    scene_test.add_argument("--timeout-seconds", type=float, default=180.0)
    scene_render = commands.add_parser(
        "scene-render-instruction", help="render complete canonical text without changing E/P"
    )
    scene_render.add_argument("--execution", type=pathlib.Path, required=True)
    scene_render.add_argument("--output", type=pathlib.Path)
    scene_render.add_argument("--text-output", type=pathlib.Path)
    args = parser.parse_args(argv)
    try:
        if args.command == "describe":
            from openroboto_protocol.task_profiles import task_profile_catalog

            result = {
                "profiles": task_profile_catalog(include_development=args.include_development),
                "physical_assets_verified": bool(verify_platform_assets()),
            }
            if args.include_development:
                from openroboto_protocol import scene_contract
                from .scene_runtime import RUNTIME_VERSION, registry_document, registry_refs
                from .scene_instruction_runtime import policy_identity as instruction_identity
                from .scene_observation import policy_scope_matches
                from .scene_admission import policy_identity as admission_identity

                result["scene_authoring"] = {
                    "api_version": 1,
                    "runtime_version": RUNTIME_VERSION,
                    "execution_profile": scene_contract.profile_ref(),
                    "environment": registry_refs()["environment"],
                    "registry": registry_document(),
                    "commands": ["scene-record-reference", "scene-self-test", "scene-render-instruction"],
                    "instruction_admission_policy": instruction_identity(),
                    "scene_admission_policy": admission_identity(),
                    "observation_policy_scope_matches_profile": policy_scope_matches(scene_contract.profile_ref()),
                    "status": "development",
                    "physics_support": "only separately validated immutable instance sets",
                    "server_admission": "unregistered",
                    "server_entrypoints": {
                        "prepare_scene_episode": "pure_full_parent_binding_required",
                        "validate_scene_episode_context": "saved_spec_pre_started_gate_not_os_availability",
                        "run_scene_admission": "registered_context_and_verified_private_reference_required",
                        "execute_scene_episode": "prepared_token_and_dedicated_linux_parent_required_unverified",
                    },
                }
        elif args.command == "initialize-dedup":
            import os
            from .fingerprint import INDEX_VERSION

            args.index.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(args.index, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w") as handle:
                json.dump({"schema_version": INDEX_VERSION, "fingerprints": []}, handle)
                handle.write("\n")
            result = {"initialized": str(args.index), "scope": "single authoritative admission host"}
        elif args.command == "build":
            result = build_package(
                args.definition,
                args.output,
                task_id=args.task_id,
                title=args.title,
                public_summary=read_json(args.public_summary) if args.public_summary else None,
            )
        elif args.command == "record-reference":
            if read_json(args.package / "task.json").get("schema_version") == 3:
                raise TaskSourceError(
                    "schema3 requires scene-record-reference with NEW private root and detached manifest"
                )
            script = DATA.parent / "tabletop_reference.py" if args.example else args.script
            if args.example:
                from openroboto_protocol.task_profiles import is_v2

                if is_v2(read_json(args.package / "task.json").get("execution_profile")):
                    script = DATA.parent / "tabletop_v2_reference.py"
            result = record_reference(args.package, script)
        elif args.command == "scene-render-instruction":
            from .scene_instruction_runtime import render_execution

            result = render_execution(args.execution, report_path=args.output, text_path=args.text_output)
        elif args.command == "scene-record-reference":
            from .scene_authoring import record_reference as record_scene

            result = record_scene(
                args.execution,
                script=args.script,
                private_root=args.private,
                manifest_path=args.manifest,
                report_path=args.output,
                timeout_s=args.timeout_seconds,
                max_reference_steps=args.max_reference_steps,
            )
        elif args.command == "scene-self-test":
            from .scene_authoring import self_test as test_scene

            result = test_scene(
                args.execution,
                args.private,
                args.manifest,
                expected_submission_digest=args.expect_submission_digest,
                report_path=args.output,
                timeout_s=args.timeout_seconds,
            )
        else:
            if read_json(args.package / "task.json").get("schema_version") == 3:
                raise TaskSourceError(
                    "schema3 requires scene-self-test with verified private root and detached manifest"
                )
            result = self_test(args.package)
            if args.output:
                if args.output.exists():
                    raise TaskSourceError("self-test output exists; choose a new report path")
                write_json(args.output, result, indent=2)
    except (TaskSourceError, ValueError, OSError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    if args.command.startswith("scene-") and args.command != "scene-render-instruction":
        from .scene_authoring import public_summary

        print(json.dumps(public_summary(result), ensure_ascii=False, sort_keys=True, indent=2))
    else:
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
    return 0 if result.get("ok", True) and result.get("accepted", True) else 1


if __name__ == "__main__":
    raise SystemExit(main())
