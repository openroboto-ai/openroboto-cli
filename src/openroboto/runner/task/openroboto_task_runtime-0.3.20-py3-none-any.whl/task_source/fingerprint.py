"""题目指纹与去重（OPE-111 的接口，OPE-99 里先接上）。

指纹要满足的约束（来自 OPE-111）：

- **改名不换题**：把 ``cube_1`` / ``bowl_1`` 改名、颜色、材质都不是题；
- **整体位移不换题**：同一组物体整体挪 10 cm 还是同一道题；
- **换目标就换题**：判据结构、相对目标、阈值变了就是另一道题；
- **初始状态量化**：实例之间的抖动不该让同一道题躲过去。

实现：

1. ``checker`` 按遍历顺序把 body 名映射成 ``body_0`` / ``body_1``……
   （改名后顺序不变），数值按 3 位小数量化；
2. ``objects`` 用两两距离（排序后）与相对高度（排序后）描述物体集合，
   与绝对坐标无关；
3. 两者 canonical JSON 的 SHA-256 就是指纹。

``DedupIndex`` 是本地账本：同一指纹下链上先提交的算原创；后提交的拒。
「先提交」优先看链上区块 ``commit_block``（队列里的权威排序，见后端
``QueueTask.commit_block``），没有区块时才退回 ``submitted_at``。
「指纹不匹配」只代表不是已知重复，**不是自动通过** —— 其余七项照跑。
"""

from __future__ import annotations

import json
import pathlib
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping

from .base import TaskSpec, canonical_sha256, checker_body_names
from .package import TaskPackage

INDEX_VERSION = 2
DISTANCE_PRECISION = 2  # 1 cm


@dataclass(frozen=True)
class DedupMatch:
    task_id: str
    submitted_at: str | None
    commit_block: int | None = None


def _rounded(value: Any, digits: int = 3) -> Any:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return value
    return round(float(value), digits)


def _canonical_checker(node: Any, roles: Mapping[str, str]) -> Any:
    if isinstance(node, Mapping):
        canonical: dict[str, Any] = {}
        for key in sorted(node, key=str):
            value = node[key]
            if key == "checker" and isinstance(value, Mapping):
                canonical[key] = _canonical_checker(value, roles)
            elif isinstance(value, str) and value in roles:
                canonical[key] = roles[value]
            elif isinstance(value, list):
                canonical[key] = [_canonical_checker(item, roles) for item in value]
            elif isinstance(value, Mapping):
                canonical[key] = _canonical_checker(value, roles)
            else:
                canonical[key] = _rounded(value)
        return canonical
    if isinstance(node, list):
        return [_canonical_checker(item, roles) for item in node]
    if isinstance(node, str) and node in roles:
        return roles[node]
    return _rounded(node)


def _object_geometry(task: TaskSpec) -> list[Any]:
    """物体集合的几何：两两距离 + 相对高度，排序后与名字、绝对坐标无关。

    只看**第一个实例**：同一道题的 20 个实例是同一个摆放模板加不同抖动；
    把全部实例都放进指纹会让「换个种子重交」躲过去，而 OPE-111 明确要求
    这种情况仍命中。
    """
    if not task.instances:
        return []
    item = task.instances[0]
    objects = (item.initial_state or {}).get("objects") or {}
    if not isinstance(objects, Mapping) or not objects:
        return []
    names = sorted(str(name) for name in objects)
    positions = []
    for name in names:
        entry = objects.get(name) or {}
        position = entry.get("pos") if isinstance(entry, Mapping) else None
        if not isinstance(position, (list, tuple)) or len(position) != 3:
            return []
        positions.append([float(value) for value in position])
    distances = []
    for left in range(len(positions)):
        for right in range(left + 1, len(positions)):
            squared = sum((positions[left][axis] - positions[right][axis]) ** 2 for axis in range(3))
            distances.append(round(squared**0.5, DISTANCE_PRECISION))
    lowest = min(position[2] for position in positions)
    heights = sorted(round(position[2] - lowest, DISTANCE_PRECISION) for position in positions)
    return [{"objects": len(names), "distances": sorted(distances), "heights": heights}]


def fingerprint(task: TaskSpec, *, package: TaskPackage | None = None) -> str:
    if task.metadata.get("execution_profile"):
        package = package or task.metadata.get("package")
        if not isinstance(package, TaskPackage):
            raise ValueError("a validated profiled task must retain its immutable package")
        definition = package.task["task_definition"]
        from openroboto_protocol.task_profiles import is_v2

        if is_v2(task.metadata["execution_profile"]):
            from .tabletop_fingerprint import fingerprint as composed_fingerprint

            return composed_fingerprint(definition, task.metadata["execution_profile"])
        objects = definition["objects"]
        anchor = min(tuple(obj["position"]) for obj in objects)
        goals = {goal["object_id"]: goal["target_position"] for goal in definition["goals"]}
        rows = sorted(
            (
                obj["asset_id"],
                tuple(round(v - anchor[i], 2) for i, v in enumerate(obj["position"])),
                tuple(round(v - anchor[i], 2) for i, v in enumerate(goals[obj["id"]])),
            )
            for obj in objects
        )
        return canonical_sha256({"profile": task.metadata["execution_profile"], "placement_relations": rows})
    names = checker_body_names(task.checker_config)
    roles = {name: f"body_{index}" for index, name in enumerate(names)}
    payload = {
        "source": task.source,
        "checker": _canonical_checker(task.checker_config, roles),
        "object_count": len(names),
        "geometry": _object_geometry(task),
    }
    if not names:
        # 没有矿工物体（RoboDojo 官方题）：题的身份就是官方 task 名。
        payload["official_task"] = task.task_id
    return canonical_sha256(payload)


class DedupIndex:
    """本地指纹账本。文件不存在 = 空题库（第一次上线）。"""

    def __init__(self, path: str | pathlib.Path | None, *, strict: bool = False) -> None:
        self.path = pathlib.Path(path).expanduser() if path is not None else None
        self.entries: list[dict[str, Any]] = []
        if self.path is not None and self.path.is_file():
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, Mapping) or not isinstance(data.get("fingerprints"), list):
                raise ValueError(f"dedup index {self.path} has an unsupported shape")
            if strict and (
                data.get("schema_version") != INDEX_VERSION
                or any(
                    not isinstance(entry, Mapping)
                    or not isinstance(entry.get("fingerprint"), str)
                    or len(entry["fingerprint"]) != 64
                    or any(c not in "0123456789abcdef" for c in entry["fingerprint"])
                    or not isinstance(entry.get("task_id"), str)
                    or not entry["task_id"]
                    for entry in data["fingerprints"]
                )
            ):
                raise ValueError(f"dedup index {self.path} contains invalid authoritative entries")
            self.entries = [dict(entry) for entry in data["fingerprints"] if isinstance(entry, Mapping)]
        elif strict:
            raise ValueError("authoritative dedup index is missing; initialize a new index explicitly")

    def find(
        self,
        value: str,
        *,
        submitted_at: str | None = None,
        commit_block: int | None = None,
        task_id: str | None = None,
    ) -> DedupMatch | None:
        """同指纹里**更早**提交的题。没有更早的 = 当前题是原创。

        链上区块优先（``commit_block`` 是后端队列的权威排序）；同一区块内
        再比 ``submitted_at``，仍相同则用 ``task_id`` 做稳定兜底 —— 不同
        worker 对同一批提交会得到同一个结论。
        """
        candidates = [
            entry for entry in self.entries if entry.get("fingerprint") == value and entry.get("task_id") != task_id
        ]
        if not candidates:
            return None
        for entry in sorted(candidates, key=lambda item: _order_key(item)):
            if _is_earlier(entry, submitted_at=submitted_at, commit_block=commit_block, task_id=task_id):
                return DedupMatch(
                    str(entry.get("task_id") or ""),
                    _as_text(entry.get("submitted_at")),
                    _as_block(entry.get("commit_block")),
                )
        return None

    def add(
        self,
        value: str,
        *,
        task_id: str,
        submitted_at: str | None = None,
        commit_block: int | None = None,
    ) -> None:
        block = _as_block(commit_block)
        for entry in self.entries:
            if entry.get("fingerprint") == value and entry.get("task_id") == task_id:
                return
        self.entries.append({
            "fingerprint": value,
            "task_id": task_id,
            "submitted_at": submitted_at,
            "commit_block": block,
        })
        self.save()

    def save(self) -> None:
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(self.path.name + ".tmp")
        temporary.write_text(
            json.dumps(
                {"schema_version": INDEX_VERSION, "fingerprints": self.entries},
                ensure_ascii=False,
                indent=1,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        temporary.replace(self.path)


def _as_block(value: Any) -> int | None:
    """链上区块号；非法 / 缺失返回 ``None``（不猜成 0）。"""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip().isdigit():
        return int(value.strip())
    return None


def _order_key(entry: Mapping[str, Any]) -> tuple[int, datetime, str]:
    block = _as_block(entry.get("commit_block"))
    return (
        block if block is not None else 0,
        _parse_time(entry.get("submitted_at")),
        str(entry.get("task_id") or ""),
    )


def _is_earlier(
    entry: Mapping[str, Any],
    *,
    submitted_at: str | None,
    commit_block: int | None,
    task_id: str | None,
) -> bool:
    """账本里的 ``entry`` 是否早于当前提交。

    先比区块（权威排序），同一区块比时间，再相同就用 ``task_id`` 稳定兜底。
    任何一边缺失可比较的依据时，保守地把**已有题**当更早 —— 宁可把候选
    排在原创后面，也不让同一指纹的两道题都被当成原创。
    """
    entry_block = _as_block(entry.get("commit_block"))
    current_block = _as_block(commit_block)
    entry_id = str(entry.get("task_id") or "")
    current_id = str(task_id or "")
    entry_time = _parse_time(entry.get("submitted_at"))
    current_time = _parse_time(submitted_at) if submitted_at else None

    if entry_block is not None and current_block is not None and entry_block != current_block:
        return entry_block < current_block
    if current_time is None:
        return True
    if entry_time != current_time:
        return entry_time < current_time
    # 同一区块 / 同一秒：用稳定的题号兜底，保证各 worker 结论一致。
    return entry_id < current_id


def _parse_time(value: Any) -> datetime:
    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            # 不带时区的 ISO 串按 UTC 处理，避免 naive/aware 比较抛 TypeError。
            return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    # 时间不可解析时排在最前，避免「未知」被当成更晚。
    return datetime.min.replace(tzinfo=timezone.utc)


def _as_text(value: Any) -> str | None:
    return value if isinstance(value, str) else None


__all__ = ["DedupIndex", "DedupMatch", "fingerprint"]
