"""近重复候选检索与可解释证据（OPE-228）。

指纹（:mod:`task_source.fingerprint`）只回答「是不是同一道题」的精确问题。
本模块在指纹之外产出**候选**与**逐项证据**，供人工/规则审核使用：

- 它不自动把任何题判成抄袭，也不改变准入的八项契约；
- 结论里带 ``policy_version``、每个维度的分数、以及相同/不同的具体项；
- 改名、配色、整体平移不进入相似度；旋转、绝对尺寸、数量、判据阈值、
  物体类型变化各自单独报出，不机械地判重复或原创。

设计约束来自 OPE-228 的验收标准：

======================  ============================================
变化                    本模块的处理
======================  ============================================
改名 / 配色              不进特征（与指纹同一套规范化）
整体平移                 不进特征（两两距离、相对高度）
整体旋转                 报告 ``orientation_changed``，降级为同机制
整体缩放                 报告 ``scale_changed``，不判近重复
物体尺寸变化             报告 ``size_changed``，不判近重复
数量变化                 报告 ``structural_change``，不判近重复
判据阈值微调             报告 ``mechanism_parameter_changed``
物体类型替换             报告 ``asset_types_changed``，降级为同机制
指令文本变化             单独计分，不单独决定分类
======================  ============================================

「同机制」不等于「重复」，「不同指纹」也不等于「原创」—— 这两句话是本
模块存在的理由。
"""

from __future__ import annotations

import argparse
import json
import math
import pathlib
import sys
from collections import Counter
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

from .base import TaskSpec, canonical_sha256, checker_body_names
from .fingerprint import _canonical_checker, fingerprint
from .package import TaskPackage, load_package
from .registry import get_source, load_config

SCHEMA_VERSION = 1
POLICY_VERSION = "nd-v1"

#: 指令分词时去掉的常见虚词。只影响文本相似度，不参与分类门槛。
_STOP_WORDS = frozenset(
    "a an the to of into in on at and or it its is be least than then with for by from around "
    "degrees degree as up down out".split()
)


#: 物体类型名规范化：去掉尾部的 ``_<数字>`` / ``-<数字>``。
def _asset_type(name: str) -> str:
    stem = str(name)
    while True:
        head, separator, tail = stem.rpartition("_")
        if separator and tail.isdigit():
            stem = head
            continue
        head, separator, tail = stem.rpartition("-")
        if separator and tail.isdigit():
            stem = head
            continue
        return stem or str(name)


@dataclass(frozen=True)
class NearDuplicatePolicy:
    """近重复审核策略。版本号进每条结论和索引文件，规则改了必须换版本。"""

    version: str = POLICY_VERSION
    #: 归一化几何相似度下限（1 = 完全一致）。
    near_duplicate_geometry: float = 0.97
    #: 指令文本 Jaccard 下限；没有指令时按 1.0 处理并标注证据缺失。
    near_duplicate_instruction: float = 0.60
    #: 判据谓词多重集的 Jaccard 下限，用于「相关机制」候选。
    related_mechanism_predicate: float = 0.80
    #: 最大两两距离比值偏离 1 超过这个比例，就不判近重复。
    scale_change_ratio: float = 0.10
    #: 物体尺寸变化超过这个比例，就不判近重复。
    size_change_ratio: float = 0.05
    #: 朝向最大夹角（度）超过这个值，就不判近重复。
    rotation_change_degrees: float = 15.0
    #: 默认候选数量。
    candidate_limit: int = 5

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "near_duplicate_geometry": self.near_duplicate_geometry,
            "near_duplicate_instruction": self.near_duplicate_instruction,
            "related_mechanism_predicate": self.related_mechanism_predicate,
            "scale_change_ratio": self.scale_change_ratio,
            "size_change_ratio": self.size_change_ratio,
            "rotation_change_degrees": self.rotation_change_degrees,
            "candidate_limit": self.candidate_limit,
        }

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> NearDuplicatePolicy:
        allowed = set(cls.__dataclass_fields__)
        values = {key: raw[key] for key in allowed if key in raw}
        return cls(**values)

    def digest(self) -> str:
        return canonical_sha256(self.to_dict())


@dataclass(frozen=True)
class Comparison:
    """两道题之间的近重复比较结果。"""

    query_task_id: str
    candidate_task_id: str
    classification: str
    score: float
    components: Mapping[str, Any]
    matched: tuple[str, ...] = ()
    differing: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    reasons: tuple[str, ...] = ()
    policy_version: str = POLICY_VERSION
    policy_digest: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "query_task_id": self.query_task_id,
            "candidate_task_id": self.candidate_task_id,
            "classification": self.classification,
            "score": self.score,
            "components": dict(self.components),
            "matched": list(self.matched),
            "differing": list(self.differing),
            "warnings": list(self.warnings),
            "reasons": list(self.reasons),
            "policy_version": self.policy_version,
            "policy_digest": self.policy_digest,
        }


def _rounded(value: float, digits: int = 4) -> float:
    if not math.isfinite(value):
        return 0.0
    return round(float(value), digits)


def _object_positions(initial_state: Mapping[str, Any]) -> dict[str, list[float]]:
    objects = initial_state.get("objects") if isinstance(initial_state, Mapping) else None
    if not isinstance(objects, Mapping):
        return {}
    positions: dict[str, list[float]] = {}
    for name, entry in objects.items():
        if not isinstance(entry, Mapping):
            continue
        position = entry.get("pos")
        if isinstance(position, (list, tuple)) and len(position) == 3:
            positions[str(name)] = [float(value) for value in position]
    return positions


def _quaternion(entry: Mapping[str, Any]) -> tuple[float, float, float, float] | None:
    raw = entry.get("rot") if isinstance(entry, Mapping) else None
    if not isinstance(raw, (list, tuple)) or len(raw) != 4:
        return None
    try:
        values = tuple(float(value) for value in raw)
    except (TypeError, ValueError):
        return None
    norm = math.sqrt(sum(value * value for value in values))
    if norm <= 0:
        return None
    return tuple(value / norm for value in values)  # type: ignore[return-value]


def _size(entry: Mapping[str, Any]) -> float | None:
    """物体的标量尺寸，用于报「尺寸变化」；题包没声明时返回 None。

    AXIS payload 的 ``size`` / ``scale`` 是可选字段；没有时这一维证据缺失，
    不能据此推断尺寸相同。
    """

    for key in ("size", "scale", "radius"):
        value = entry.get(key) if isinstance(entry, Mapping) else None
        if isinstance(value, (int, float)) and not isinstance(value, bool) and value > 0:
            return float(value)
        if isinstance(value, (list, tuple)) and value:
            try:
                numeric = [float(item) for item in value if isinstance(item, (int, float))]
            except (TypeError, ValueError):
                numeric = []
            if numeric and max(numeric) > 0:
                return float(max(numeric))
    return None


def _role_order(task: TaskSpec, positions: Mapping[str, Sequence[float]]) -> list[str]:
    """对象的稳定角色顺序：先按 checker 出现顺序，其余按名字排序。"""

    declared = checker_body_names(task.checker_config)
    ordered = [name for name in declared if name in positions]
    ordered.extend(sorted(name for name in positions if name not in ordered))
    return ordered


def _geometry_for_instances(task: TaskSpec) -> dict[str, Any]:
    """只用第一个实例：同一道题的多个实例是同一摆放模板加抖动。"""

    if not task.instances:
        return {"distances": [], "heights": [], "max_distance": 0.0, "orientations": [], "sizes": []}
    item = task.instances[0]
    initial = item.initial_state or {}
    positions = _object_positions(initial)
    names = _role_order(task, positions)
    ordered = [positions[name] for name in names]
    objects = initial.get("objects") if isinstance(initial, Mapping) else {}
    objects = objects if isinstance(objects, Mapping) else {}

    distances: list[float] = []
    for left in range(len(ordered)):
        for right in range(left + 1, len(ordered)):
            squared = sum((ordered[left][axis] - ordered[right][axis]) ** 2 for axis in range(3))
            distances.append(round(math.sqrt(squared), 4))
    distances.sort()
    max_distance = max(distances) if distances else 0.0

    heights: list[float] = []
    if ordered:
        lowest = min(position[2] for position in ordered)
        heights = sorted(round(position[2] - lowest, 4) for position in ordered)

    orientations: list[list[float] | None] = []
    sizes: list[float | None] = []
    for name in names:
        entry = objects.get(name) if isinstance(objects.get(name), Mapping) else {}
        quaternion = _quaternion(entry)
        orientations.append(None if quaternion is None else [_rounded(value, 6) for value in quaternion])
        size = _size(entry)
        sizes.append(None if size is None else _rounded(size, 4))

    return {
        "distances": distances,
        "heights": heights,
        "max_distance": _rounded(max_distance, 4),
        "orientations": orientations,
        "sizes": sizes,
    }


def _profiled_features(task: TaskSpec, package: TaskPackage) -> dict[str, Any] | None:
    """受限模板题：用 package.task_definition 的对象 / 目标关系。"""

    definition = package.task.get("task_definition")
    if not isinstance(definition, Mapping):
        return None
    objects = definition.get("objects")
    goals = definition.get("goals")
    if not isinstance(objects, list) or not isinstance(goals, list):
        return None
    positions: dict[str, list[float]] = {}
    asset_types: list[str] = []
    for entry in objects:
        if not isinstance(entry, Mapping):
            continue
        identifier = str(entry.get("id") or "")
        position = entry.get("position")
        asset = str(entry.get("asset_id") or identifier)
        asset_types.append(asset)
        if identifier and isinstance(position, (list, tuple)) and len(position) == 3:
            positions[identifier] = [float(value) for value in position]
    goal_positions = {
        str(goal.get("object_id")): [float(value) for value in goal.get("target_position", [])]
        for goal in goals
        if isinstance(goal, Mapping) and isinstance(goal.get("target_position"), (list, tuple))
    }
    names = sorted(positions)
    ordered = [positions[name] for name in names]
    distances: list[float] = []
    for left in range(len(ordered)):
        for right in range(left + 1, len(ordered)):
            squared = sum((ordered[left][axis] - ordered[right][axis]) ** 2 for axis in range(3))
            distances.append(round(math.sqrt(squared), 4))
    distances.sort()
    goal_distances: list[float] = []
    for name in names:
        goal = goal_positions.get(name)
        if goal is None or len(goal) != 3:
            continue
        squared = sum((positions[name][axis] - goal[axis]) ** 2 for axis in range(3))
        goal_distances.append(round(math.sqrt(squared), 4))
    goal_distances.sort()
    anchor = min(tuple(positions[name]) for name in names) if names else (0.0, 0.0, 0.0)
    placement_relations = sorted(
        (
            str(entry.get("asset_id") or entry.get("id") or ""),
            tuple(round(position - anchor[axis], 3) for axis, position in enumerate(positions[str(entry.get("id"))])),
            tuple(
                round(value - anchor[axis], 3)
                for axis, value in enumerate(goal_positions.get(str(entry.get("id")), ()))
            ),
        )
        for entry in objects
        if isinstance(entry, Mapping) and str(entry.get("id")) in positions
    )
    return {
        "assets": sorted(asset_types),
        "object_count": len(names),
        "distances": distances,
        "heights": [],
        "goal_distances": goal_distances,
        "max_distance": _rounded(max(distances) if distances else 0.0, 4),
        "orientations": [],
        "sizes": [],
        "predicates": ["placement"],
        "mechanism_digest": canonical_sha256({
            "profile": task.metadata["execution_profile"],
            "placement_relations": placement_relations,
        }),
    }


def extract_features(task: TaskSpec, *, package: TaskPackage | None = None) -> dict[str, Any]:
    """从 ``TaskSpec`` 提取可比较、可解释的特征。纯函数，不读文件。"""

    profile = task.metadata.get("execution_profile")
    if profile:
        package = package or task.metadata.get("package")
        if not isinstance(package, TaskPackage):
            raise ValueError("a profiled task must retain its immutable package")
        profiled = _profiled_features(task, package)
        if profiled is not None:
            return {
                "schema_version": SCHEMA_VERSION,
                "task_id": task.task_id,
                "source": task.source,
                "execution_profile": str(profile),
                "instruction": task.instruction,
                "instruction_tokens": _tokens(task.instruction),
                "object_count": profiled["object_count"],
                "assets": profiled["assets"],
                "body_roles": [f"body_{index}" for index in range(profiled["object_count"])],
                "predicates": profiled["predicates"],
                "mechanism_digest": profiled["mechanism_digest"],
                "geometry": {
                    "distances": profiled["distances"],
                    "heights": profiled["heights"],
                    "goal_distances": profiled["goal_distances"],
                    "max_distance": profiled["max_distance"],
                    "orientations": profiled["orientations"],
                    "sizes": profiled["sizes"],
                },
                "fingerprint": fingerprint(task, package=package),
            }

    names = checker_body_names(task.checker_config)
    roles = {name: f"body_{index}" for index, name in enumerate(names)}
    geometry = _geometry_for_instances(task)
    positions = _object_positions(task.instances[0].initial_state) if task.instances else {}
    objects = (task.instances[0].initial_state or {}).get("objects") if task.instances else None
    objects = objects if isinstance(objects, Mapping) else {}
    assets = sorted(_asset_type(name) for name in positions)
    canonical_checker = _canonical_checker(task.checker_config, roles)
    predicates = sorted(_predicate_types(task.checker_config))
    mechanism_digest = canonical_sha256(canonical_checker)
    payload = {
        "schema_version": SCHEMA_VERSION,
        "task_id": task.task_id,
        "source": task.source,
        "execution_profile": None,
        "instruction": task.instruction,
        "instruction_tokens": _tokens(task.instruction),
        "object_count": len(positions),
        "assets": assets,
        "body_roles": [roles.get(name, f"body_{index}") for index, name in enumerate(positions)],
        "predicates": predicates,
        "mechanism_digest": mechanism_digest,
        "geometry": geometry,
        "fingerprint": fingerprint(task),
    }
    if not names:
        # 没有矿工物体（官方题）：身份就是官方 task 名，与 fingerprint 一致。
        payload["official_task"] = task.task_id
    return payload


def _predicate_types(node: Any) -> list[str]:
    found: list[str] = []
    if isinstance(node, Mapping):
        kind = node.get("type")
        if isinstance(kind, str) and kind.endswith("Checker"):
            found.append(kind)
        for value in node.values():
            found.extend(_predicate_types(value))
    elif isinstance(node, (list, tuple)):
        for value in node:
            found.extend(_predicate_types(value))
    return found


def _tokens(instruction: str | None) -> list[str]:
    if not isinstance(instruction, str):
        return []
    words = []
    for raw in instruction.lower().replace("-", " ").split():
        word = "".join(character for character in raw if character.isalnum())
        if len(word) >= 2 and word not in _STOP_WORDS:
            words.append(word)
    return words


def _jaccard(left: Iterable[Any], right: Iterable[Any]) -> float:
    left_set, right_set = set(left), set(right)
    if not left_set and not right_set:
        return 1.0
    if not left_set or not right_set:
        return 0.0
    return len(left_set & right_set) / len(left_set | right_set)


def _multiset_jaccard(left: Sequence[Any], right: Sequence[Any]) -> float:
    left_counter, right_counter = Counter(left), Counter(right)
    if not left_counter and not right_counter:
        return 1.0
    if not left_counter or not right_counter:
        return 0.0
    intersection = sum((left_counter & right_counter).values())
    union = sum((left_counter | right_counter).values())
    return intersection / union if union else 0.0


def _vector_similarity(left: Sequence[float], right: Sequence[float], *, scale: float) -> tuple[float, float]:
    """排序后的标量列表比较，返回 (相似度, 最大绝对差)。

    列表长度不同 = 物体数量不同，由调用方先判结构变化。
    """

    if len(left) != len(right) or not left:
        return (1.0, 0.0) if not left and not right else (0.0, math.inf)
    maximum = max(abs(a - b) for a, b in zip(left, right))
    if scale <= 0:
        return (0.0, maximum)
    delta = maximum / scale
    return (_rounded(max(0.0, 1.0 - delta)), _rounded(maximum))


def _orientation_delta(
    left: Sequence[Sequence[float] | None],
    right: Sequence[Sequence[float] | None],
) -> float:
    """最大四元数夹角（度）；任一维缺失时返回 0 并让调用方标注证据缺失。"""

    if not left or not right or len(left) != len(right):
        return 0.0
    worst = 0.0
    for a, b in zip(left, right):
        if a is None or b is None or len(a) != 4 or len(b) != 4:
            continue
        dot = abs(sum(float(x) * float(y) for x, y in zip(a, b)))
        worst = max(worst, math.degrees(2.0 * math.acos(min(1.0, dot))))
    return _rounded(worst, 2)


def _size_delta(left: Sequence[float | None], right: Sequence[float | None]) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    worst = 0.0
    for a, b in zip(left, right):
        if a is None or b is None or b <= 0:
            continue
        worst = max(worst, abs(float(a) / float(b) - 1.0))
    return _rounded(worst, 4)


def compare(
    query: Mapping[str, Any],
    candidate: Mapping[str, Any],
    *,
    policy: NearDuplicatePolicy | None = None,
    fingerprint_equal: bool | None = None,
) -> Comparison:
    """比较两份 ``extract_features`` 结果，产出可解释结论。"""

    policy = policy or NearDuplicatePolicy()
    query_geometry = query.get("geometry") or {}
    candidate_geometry = candidate.get("geometry") or {}

    geometry_similarity, geometry_delta = _vector_similarity(
        query_geometry.get("distances") or [],
        candidate_geometry.get("distances") or [],
        scale=max(
            float(query_geometry.get("max_distance") or 0.0),
            float(candidate_geometry.get("max_distance") or 0.0),
        ),
    )
    height_similarity, _ = _vector_similarity(
        query_geometry.get("heights") or [],
        candidate_geometry.get("heights") or [],
        scale=max(
            float(query_geometry.get("max_distance") or 0.0),
            float(candidate_geometry.get("max_distance") or 0.0),
        ),
    )
    goal_similarity, _ = _vector_similarity(
        query_geometry.get("goal_distances") or [],
        candidate_geometry.get("goal_distances") or [],
        scale=max(
            float(query_geometry.get("max_distance") or 0.0),
            float(candidate_geometry.get("max_distance") or 0.0),
        ),
    )
    combined_geometry = min(
        value for value in (geometry_similarity, height_similarity, goal_similarity) if value is not None
    )

    query_max = float(query_geometry.get("max_distance") or 0.0)
    candidate_max = float(candidate_geometry.get("max_distance") or 0.0)
    scale_ratio = _rounded(query_max / candidate_max, 4) if candidate_max > 0 and query_max > 0 else 1.0
    orientation_delta = _orientation_delta(
        query_geometry.get("orientations") or [], candidate_geometry.get("orientations") or []
    )
    size_delta = _size_delta(query_geometry.get("sizes") or [], candidate_geometry.get("sizes") or [])

    mechanism_exact = query.get("mechanism_digest") == candidate.get("mechanism_digest")
    predicate_jaccard = _multiset_jaccard(query.get("predicates") or [], candidate.get("predicates") or [])
    asset_jaccard = _multiset_jaccard(query.get("assets") or [], candidate.get("assets") or [])
    instruction_jaccard = _jaccard(query.get("instruction_tokens") or [], candidate.get("instruction_tokens") or [])
    instruction_missing = not (query.get("instruction_tokens") or candidate.get("instruction_tokens"))
    count_match = int(query.get("object_count") or 0) == int(candidate.get("object_count") or 0)
    if fingerprint_equal is None:
        query_fingerprint = query.get("fingerprint")
        candidate_fingerprint = candidate.get("fingerprint")
        fingerprint_match = bool(
            isinstance(query_fingerprint, str)
            and isinstance(candidate_fingerprint, str)
            and query_fingerprint == candidate_fingerprint
        )
    else:
        fingerprint_match = bool(fingerprint_equal)

    components = {
        "fingerprint_equal": fingerprint_match,
        "mechanism_exact": mechanism_exact,
        "predicate_jaccard": _rounded(predicate_jaccard),
        "geometry_similarity": combined_geometry,
        "geometry_max_delta": geometry_delta,
        "asset_jaccard": _rounded(asset_jaccard),
        "instruction_jaccard": _rounded(instruction_jaccard),
        "object_count_match": count_match,
        "scale_ratio": scale_ratio,
        "orientation_max_delta_deg": orientation_delta,
        "size_max_delta_ratio": size_delta,
    }

    matched: list[str] = []
    differing: list[str] = []
    warnings: list[str] = []
    reasons: list[str] = []

    if fingerprint_match:
        matched.append("fingerprint")
    if mechanism_exact:
        matched.append("mechanism")
    elif predicate_jaccard >= policy.related_mechanism_predicate:
        matched.append("predicate_family")
    if combined_geometry >= policy.near_duplicate_geometry:
        matched.append("geometry")
    if asset_jaccard >= 1.0:
        matched.append("asset_types")
    if instruction_jaccard >= policy.near_duplicate_instruction:
        matched.append("instruction")

    if not count_match:
        differing.append("object_count")
    if not mechanism_exact:
        differing.append("mechanism_parameters")
    if asset_jaccard < 1.0:
        differing.append("asset_types")
    if combined_geometry < policy.near_duplicate_geometry:
        differing.append("geometry")
    if instruction_jaccard < policy.near_duplicate_instruction:
        differing.append("instruction")
    if abs(scale_ratio - 1.0) > policy.scale_change_ratio:
        differing.append("scale")
    if orientation_delta > policy.rotation_change_degrees:
        differing.append("orientation")
    if size_delta > policy.size_change_ratio:
        differing.append("object_size")

    if instruction_missing:
        warnings.append("instruction_missing")
    if not (query_geometry.get("orientations") and candidate_geometry.get("orientations")):
        warnings.append("orientation_not_declared")
    if not (query_geometry.get("sizes") and candidate_geometry.get("sizes")):
        warnings.append("object_size_not_declared")
    if not (query_geometry.get("distances") or candidate_geometry.get("distances")):
        warnings.append("geometry_missing")

    if fingerprint_match:
        classification = "identical_fingerprint"
        reasons.append("精确指纹相同：现有 dedup 已足以拒绝，无需依赖近重复分数")
    elif mechanism_exact and not count_match:
        classification = "structural_change"
        reasons.append("判据相同但物体数量不同：这是结构差异，不能按同一道题判重复，也不能据此判原创")
    elif mechanism_exact:
        if orientation_delta > policy.rotation_change_degrees:
            classification = "same_mechanism"
            reasons.append(
                f"判据相同，但物体朝向最大差 {orientation_delta:.1f}°：旋转变化不自动判重复，需审核是否改变了解题难度"
            )
        elif size_delta > policy.size_change_ratio:
            classification = "same_mechanism"
            reasons.append(f"判据相同，但物体尺寸最大变化 {size_delta:.1%}：尺寸变化不自动判重复，需审核可达性与难度")
        elif abs(scale_ratio - 1.0) > policy.scale_change_ratio:
            classification = "same_mechanism"
            reasons.append(f"判据相同，但整体尺度比 {scale_ratio:.2f}：缩放后布局相似，绝对尺寸变化不自动判重复")
        elif (
            combined_geometry >= policy.near_duplicate_geometry
            and instruction_jaccard >= policy.near_duplicate_instruction
            and asset_jaccard >= 1.0
        ):
            classification = "near_duplicate"
            reasons.append("判据结构、对象类型、几何与指令都高度一致：高置信近重复候选，进入人工复核")
        else:
            classification = "same_mechanism"
            reasons.append("判据结构完全相同但其余维度有差异：同机制变体，不自动判重复")
    elif predicate_jaccard >= policy.related_mechanism_predicate and not count_match:
        classification = "structural_change"
        reasons.append("判据谓词家族重叠但物体数量不同：结构变体候选，需审核能力差异")
    elif predicate_jaccard >= policy.related_mechanism_predicate:
        classification = "related_mechanism"
        reasons.append("判据谓词家族部分重叠：相关机制候选，需审核能力差异")
    else:
        classification = "distinct"
        reasons.append("判据谓词与几何都不同：没有近重复证据")

    score = _rounded(
        0.45 * (1.0 if mechanism_exact else predicate_jaccard)
        + 0.35 * combined_geometry
        + 0.10 * asset_jaccard
        + 0.10 * instruction_jaccard
    )

    return Comparison(
        query_task_id=str(query.get("task_id") or ""),
        candidate_task_id=str(candidate.get("task_id") or ""),
        classification=classification,
        score=score,
        components=components,
        matched=tuple(matched),
        differing=tuple(differing),
        warnings=tuple(warnings),
        reasons=tuple(reasons),
        policy_version=policy.version,
        policy_digest=policy.digest(),
    )


class NearDuplicateIndex:
    """特征账本。与指纹账本分开：特征可以重建，指纹账本是准入权威。"""

    def __init__(
        self,
        path: str | pathlib.Path | None,
        *,
        policy: NearDuplicatePolicy | None = None,
        strict: bool = False,
    ) -> None:
        self.path = pathlib.Path(path).expanduser() if path is not None else None
        self.policy = policy or NearDuplicatePolicy()
        self.entries: list[dict[str, Any]] = []
        if self.path is not None and self.path.is_file():
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, Mapping) or not isinstance(data.get("features"), list):
                raise ValueError(f"near-duplicate index {self.path} has an unsupported shape")
            if strict and data.get("policy_version") != self.policy.version:
                raise ValueError(
                    f"near-duplicate index {self.path} was built with policy "
                    f"{data.get('policy_version')!r}, not {self.policy.version!r}"
                )
            self.entries = [dict(entry) for entry in data["features"] if isinstance(entry, Mapping)]
        elif strict:
            raise ValueError("authoritative near-duplicate index is missing")

    def add(self, features: Mapping[str, Any]) -> None:
        task_id = str(features.get("task_id") or "")
        if not task_id:
            raise ValueError("features must carry a task_id")
        self.entries = [entry for entry in self.entries if entry.get("task_id") != task_id]
        self.entries.append(dict(features))
        self.save()

    def candidates(
        self,
        query: Mapping[str, Any],
        *,
        limit: int | None = None,
        minimum_score: float = 0.0,
    ) -> list[Comparison]:
        results = [
            compare(query, entry, policy=self.policy)
            for entry in self.entries
            if entry.get("task_id") != query.get("task_id")
        ]
        results = [item for item in results if item.score >= minimum_score]
        results.sort(key=lambda item: (-item.score, item.candidate_task_id))
        return results[: (limit if limit is not None else self.policy.candidate_limit)]

    def save(self) -> None:
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(self.path.name + ".tmp")
        temporary.write_text(
            json.dumps(
                {
                    "schema_version": SCHEMA_VERSION,
                    "policy_version": self.policy.version,
                    "policy_digest": self.policy.digest(),
                    "features": self.entries,
                },
                ensure_ascii=False,
                indent=1,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        temporary.replace(self.path)


def audit(
    features: Sequence[Mapping[str, Any]],
    *,
    policy: NearDuplicatePolicy | None = None,
    include_distinct: bool = False,
) -> dict[str, Any]:
    """对一组题做两两比较，返回完整报告（含分类计数与逐对证据）。"""

    policy = policy or NearDuplicatePolicy()
    pairs: list[dict[str, Any]] = []
    counts: Counter[str] = Counter()
    for left in range(len(features)):
        for right in range(left + 1, len(features)):
            comparison = compare(features[left], features[right], policy=policy)
            counts[comparison.classification] += 1
            if include_distinct or comparison.classification != "distinct":
                pairs.append(comparison.to_dict())
    pairs.sort(key=lambda item: -float(item["score"]))
    return {
        "schema_version": SCHEMA_VERSION,
        "policy_version": policy.version,
        "policy_digest": policy.digest(),
        "policy": policy.to_dict(),
        "task_count": len(features),
        "pair_count": len(features) * (len(features) - 1) // 2,
        "classification_counts": dict(sorted(counts.items())),
        "pairs": pairs,
        "notes": [
            "classification 是候选分级，不是抄袭结论；自动拒绝仍需人工/规则确认",
            "不同指纹不等于原创，同机制不等于重复；warnings 列出的维度是证据盲区",
        ],
    }


def _load_task_dir(directory: str | pathlib.Path) -> TaskSpec:
    path = pathlib.Path(directory).expanduser().resolve()
    package = load_package(path)
    source = get_source(package.source, load_config(), root=path)
    return source.load_task(package.task_id)


def _cmd_audit(args: argparse.Namespace) -> int:
    policy = _load_policy(args.policy)
    features = []
    for directory in args.package:
        task = _load_task_dir(directory)
        features.append(extract_features(task))
    report = audit(features, policy=policy, include_distinct=args.include_distinct)
    _emit(report, args.output)
    return 0


def _cmd_compare(args: argparse.Namespace) -> int:
    policy = _load_policy(args.policy)
    left = extract_features(_load_task_dir(args.a))
    right = extract_features(_load_task_dir(args.b))
    report = compare(left, right, policy=policy).to_dict()
    _emit(report, args.output)
    return 0


def _cmd_index(args: argparse.Namespace) -> int:
    policy = _load_policy(args.policy)
    index = NearDuplicateIndex(args.index, policy=policy, strict=args.strict)
    feature = extract_features(_load_task_dir(args.package))
    index.add(feature)
    _emit({"task_id": feature["task_id"], "index": str(index.path), "entries": len(index.entries)}, args.output)
    return 0


def _load_policy(path: str | None) -> NearDuplicatePolicy:
    if not path:
        return NearDuplicatePolicy()
    raw = json.loads(pathlib.Path(path).expanduser().read_text(encoding="utf-8"))
    if not isinstance(raw, Mapping):
        raise ValueError("policy file must contain a JSON object")
    thresholds = raw.get("thresholds") if isinstance(raw.get("thresholds"), Mapping) else raw
    values = dict(thresholds)
    if isinstance(raw.get("policy_version"), str):
        values["version"] = raw["policy_version"]
    return NearDuplicatePolicy.from_mapping(values)


def _emit(payload: Mapping[str, Any], output: str | None) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output:
        path = pathlib.Path(output).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    else:
        sys.stdout.write(text)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="近重复候选检索与可解释证据（OPE-228）")
    parser.add_argument("--policy", default=None, help="策略 JSON（默认用内置 nd-v1）")
    parser.add_argument("--output", default=None, help="写入文件而不是 stdout")
    subparsers = parser.add_subparsers(dest="command", required=True)

    audit_parser = subparsers.add_parser("audit", help="对一组题包两两比较")
    audit_parser.add_argument("--package", action="append", required=True, help="题包目录，可重复")
    audit_parser.add_argument("--include-distinct", action="store_true", help="报告里也保留 distinct 对")
    audit_parser.set_defaults(func=_cmd_audit)

    compare_parser = subparsers.add_parser("compare", help="比较两个题包")
    compare_parser.add_argument("--a", required=True)
    compare_parser.add_argument("--b", required=True)
    compare_parser.set_defaults(func=_cmd_compare)

    index_parser = subparsers.add_parser("index", help="把题包特征追加进特征账本")
    index_parser.add_argument("--index", required=True)
    index_parser.add_argument("--package", required=True)
    index_parser.add_argument("--strict", action="store_true", help="账本策略版本不符时拒绝")
    index_parser.set_defaults(func=_cmd_index)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


__all__ = [
    "Comparison",
    "NearDuplicateIndex",
    "NearDuplicatePolicy",
    "POLICY_VERSION",
    "SCHEMA_VERSION",
    "audit",
    "compare",
    "extract_features",
    "main",
]


if __name__ == "__main__":
    raise SystemExit(main())
