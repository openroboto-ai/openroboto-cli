"""R12 historical original-report identity. Never grants execution permission."""

from __future__ import annotations

import copy
import hashlib
import math
import re
from dataclasses import fields
from types import SimpleNamespace

from task_source.panel_state import read
from task_source.scene_views.identity import encoded

DOMAIN = "openroboto:scene-report-ack-binding:v1"
EXPECTED = {"frozen_binding_digest", "report_sha256", "report_bytes_len", "report_digest", "manifest_hash", "signature"}
OUTCOME = {
    "status",
    "category",
    "discrimination",
    "hardness",
    "hardness_proof_hash",
    "disposition",
    "settleable",
    "needs_recheck",
    "zero_d_streak",
    "policy_version",
    "evidence_ok",
}


def require(condition, code="SCENE_REPORT_ACK_INVALID"):
    if not condition:
        raise ValueError(code)


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def stable_projection(work, report, *, worker_id, node_id):
    task, manifest = work["task"], report["manifest"]
    require(task["package_layout"] == "scene")
    require(manifest["node_id"] == node_id and manifest["run_id"] == work["run_id"])
    projection = {
        "domain": DOMAIN,
        "owner": {"run_id": work["run_id"], "worker_id": worker_id, "node_id": node_id},
        "task": {
            key: task[key]
            for key in (
                "task_id",
                "competition_id",
                "source",
                "package_layout",
                "package_digest",
                "submission_digest",
                "execution_profile",
                "package_url",
                "scene_registration",
            )
        },
        "config": {
            **{key: work[key] for key in ("config_version", "config_digest", "registry_digest", "trials_per_member")},
            "settlement_panel": work["config"]["settlement_panel"],
            "config_json": work["config"],
        },
        "run": {
            **{
                key: manifest[key]
                for key in ("panel", "roles", "members", "key_id", "algorithm", "node_id", "settlement")
            },
            "trials_per_member": work["trials_per_member"],
        },
    }
    projection["task"]["receipt_authority"] = {
        key: task["receipt_authority"][key] for key in ("trust", "receipt_digest")
    }
    return copy.deepcopy(projection)


def expected_identity(work, raw, *, worker_id, node_id):
    """Call only AFTER original bytes/manifest/episodes have been verified."""
    from task_source.scene_views.identity import decode

    report = decode(raw)
    members = [
        {
            "member": m["member"],
            "member_kind": m["member_kind"],
            "trials": [
                {
                    **{key: t[key] for key in ("trial", "success", "steps", "model_calls", "wall_ms", "child_root")},
                    # R12's original bytes may omit the DTO's nullable default.
                    # The old report digest nevertheless projects error=null.
                    "error": t.get("error"),
                }
                for t in m["trials"]
            ],
        }
        for m in report["members"]
    ]
    domain = {
        key: report[key]
        for key in (
            "task_id",
            "run_id",
            "package_digest",
            "config_version",
            "config_digest",
            "panel",
            "task_source",
            "roles",
        )
    }
    domain["members"] = members
    manifest = report["manifest"]
    return {
        "frozen_binding_digest": digest(stable_projection(work, report, worker_id=worker_id, node_id=node_id)),
        "report_sha256": hashlib.sha256(raw).hexdigest(),
        "report_bytes_len": len(raw),
        "report_digest": digest(domain),
        "manifest_hash": digest({key: value for key, value in manifest.items() if key != "signature"}),
        "signature": manifest["signature"],
    }


def validate_expected(value):
    require(isinstance(value, dict) and set(value) == EXPECTED)
    require(type(value["report_bytes_len"]) is int and value["report_bytes_len"] > 0)
    for key in EXPECTED - {"report_bytes_len"}:
        require(
            isinstance(value[key], str)
            and re.fullmatch(r"[0-9a-f]{128}" if key == "signature" else r"[0-9a-f]{64}", value[key])
        )


def validate_ack(value, work, expected, *, worker_id, node_id):
    require(
        isinstance(value, dict)
        and set(value)
        == {
            "accepted",
            "completed",
            "evidence_ok",
            "run_id",
            "task_id",
            "worker_id",
            "node_id",
            "matched_identity",
            "original_outcome",
            "replayed",
            "changed",
            "execution_authorized",
        }
    )
    require(all(value[key] is True for key in ("accepted", "completed", "evidence_ok", "replayed")))
    require(value["changed"] is False and value["execution_authorized"] is False)
    require(
        (value["run_id"], value["task_id"], value["worker_id"], value["node_id"])
        == (work["run_id"], work["task"]["task_id"], worker_id, node_id)
    )
    validate_expected(value["matched_identity"])
    require(value["matched_identity"] == expected)
    outcome = value["original_outcome"]
    require(
        isinstance(outcome, dict)
        and set(outcome) <= OUTCOME
        and isinstance(outcome.get("status"), str)
        and outcome.get("evidence_ok") is True
    )
    for key in ("settleable", "needs_recheck"):
        require(type(outcome.get(key)) is bool)
    require(type(outcome.get("zero_d_streak")) is int and outcome["zero_d_streak"] >= 0)
    for key in ("discrimination", "hardness"):
        require(outcome.get(key) is None or (type(outcome[key]) in (int, float) and math.isfinite(outcome[key])))
    for key, limit in (("category", 64), ("disposition", 200), ("policy_version", 200)):
        require(outcome.get(key) is None or (isinstance(outcome[key], str) and len(outcome[key]) <= limit))
    require(
        outcome.get("hardness_proof_hash") is None
        or (
            isinstance(outcome["hardness_proof_hash"], str)
            and re.fullmatch(r"[0-9a-f]{64}", outcome["hardness_proof_hash"])
        )
    )
    return value


def historical_inputs(worker, state, directory):
    """Original frozen inputs, independent of CURRENT runtime/key expiry/host.

    Missing old public key or model-host snapshot is a hard dependency. Never
    choose verification keys from the report/ACK and never load a private key.
    """
    from benchmark_worker.reference_panel.config import MemberSpec

    work = state["work"]
    original = state.get("scene_report_signer")
    if original is None:
        # Compatibility for already-written reports: only independently
        # operator-configured public key data, even if its live TTL is over.
        doc = worker.scene.registration.document if worker.scene is not None else worker.scene_report_registration
        require(isinstance(doc, dict), "SCENE_REPORT_ORIGINAL_KEY_REQUIRED")
        original = {key: doc[key] for key in ("node_id", "key_id", "public_key_hex")}
    require(
        isinstance(original, dict) and set(original) == {"node_id", "key_id", "public_key_hex"},
        "SCENE_REPORT_ORIGINAL_KEY_REQUIRED",
    )
    require(
        original["node_id"] == worker.client.node_id and re.fullmatch(r"[0-9a-f]{64}", original["public_key_hex"]),
        "SCENE_REPORT_ORIGINAL_KEY_REQUIRED",
    )
    cfg = work["config"]
    panel_name = cfg["settlement_panel"]
    panel = cfg["panels"][panel_name]
    known = {f.name for f in fields(MemberSpec)} - {"raw"}
    members = [MemberSpec(**{key: value for key, value in row.items() if key in known}) for row in panel["members"]]
    require(
        members
        and len({m.id for m in members}) == len(members)
        and all(
            re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", m.id) and m.kind == "agent" and m.harness == "headless"
            for m in members
        ),
        "SCENE_REPORT_CONFIG_INVALID",
    )
    config = SimpleNamespace(
        execution_contract=cfg["execution_contract"],
        settlement_panel=panel_name,
        version=work["config_version"],
        digest=work["config_digest"],
        settlement=SimpleNamespace(members=members, roles=panel["roles"]),
    )
    return config, read(directory / "model-host.json"), SimpleNamespace(**original)


def report_with_ack(worker, state, directory, *, ack_only=False):
    """Historical ACK first; only NOT_COMPLETED may enter live R11 retry."""
    from task_source.panel_client import PanelAPIError
    from task_source.panel_state import complete_reported_work, write

    try:
        worker._verify_scene_report(state, directory, historical=True)
        expected = expected_identity(
            state["work"],
            (directory / "report.json").read_bytes(),
            worker_id=worker.client.worker_id,
            node_id=worker.client.node_id,
        )
        if state.get("scene_report_ack_expected") is not None:
            require(state["scene_report_ack_expected"] == expected, "REPORT_ORIGINAL_CHANGED")
        state["scene_report_ack_expected"] = expected
        worker._state(state)  # Durable independent expected BEFORE HTTP.
        try:
            ack = worker.client.report_ack(state["work"], expected)
        except PanelAPIError as exc:
            if exc.status != 409 or exc.code != "ACK_NOT_COMPLETED":
                raise
            state["scene_report_not_completed"] = copy.deepcopy(expected)
            worker._state(state)  # Current authenticated negative ACK, not execution permission.
        else:
            validate_ack(ack, state["work"], expected, worker_id=worker.client.worker_id, node_id=worker.client.node_id)
            write(directory / "report-response.json", ack)
            return "completed" if complete_reported_work(worker.root, state["work"], state["binding"]) else "held"
        if ack_only:
            return "not_completed"  # No live context, renewal or R8 authority is inferred from this response.
        # No historical permission was granted. The old live context/deadline
        # gates remain mandatory and an expired run needs explicit R8.
        if worker.scene is None:
            require(callable(worker.scene_adapter_loader), "SCENE_REPORT_LIVE_CONTEXT_REQUIRED")
            try:
                scene = worker.scene_adapter_loader()
                require(
                    scene.transport._base == worker.client.base_url.rstrip("/")
                    and scene.transport._identity.node_id == worker.client.node_id,
                    "SCENE_TRANSPORT_SCOPE_MISMATCH",
                )
                worker.scene = scene
            except Exception:
                raise ValueError("SCENE_REPORT_LIVE_CONTEXT_REQUIRED") from None
        worker._scene_context(state)
        worker._verify_scene_report(state, directory)
        response = (
            worker.client.report_archive(state["work"], directory / "report.json", directory / "transfers/report.json")
            if hasattr(worker.client, "report_archive")
            else worker.client.report(state["work"], read(directory / "report.json"))
        )
        require(response.get("evidence_ok") is True, "REPORT_EVIDENCE_REJECTED")
        write(directory / "report-response.json", response)
        return "completed" if complete_reported_work(worker.root, state["work"], state["binding"]) else "held"
    except PanelAPIError as exc:
        if exc.status in (None, 429) or exc.status >= 500:
            return "retry"
        code = exc.code
    except Exception as exc:
        from task_source.scene_transport import SceneTransportError

        code = (
            exc.code.upper()
            if isinstance(exc, SceneTransportError)
            else str(exc)
            if isinstance(exc, ValueError)
            else "SCENE_REPORT_ORIGINAL_UNAVAILABLE"
        )
    if not re.fullmatch(r"[A-Z][A-Z0-9_:-]{0,79}", code):
        code = "SCENE_REPORT_ACK_REJECTED"
    state.update(phase="held", error_code=code)
    worker._state(state)  # Never progress/renew using historical credentials.
    return "held"
