"""Private, atomic worker checkpoints. Existing paid attempts are never overwritten."""

from __future__ import annotations
import contextlib
import fcntl
import json
import os
import pathlib
import secrets
from collections.abc import Mapping


def read(path: pathlib.Path):
    return json.loads(path.read_text())


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write(path: pathlib.Path, value: Mapping, *, exclusive=False):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    text = json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)
    if exclusive:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        sync_directory(path.parent)
        return
    temp = path.with_name("." + path.name + "." + secrets.token_hex(8))
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
        sync_directory(path.parent)
    finally:
        if temp.exists():
            temp.unlink()


def complete_reported_work(root: pathlib.Path, work: Mapping, binding: Mapping):
    """Confirm only the acknowledged run while the caller owns worker.lock."""
    path = root / "state.json"
    state = read(path)
    if state.get("work") != work or state.get("binding") != binding:
        return False
    state["phase"] = "completed"
    state.pop("error_code", None)
    write(path, state)
    return True


@contextlib.contextmanager
def single_owner(root: pathlib.Path):
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    root.chmod(0o700)
    with (root / "worker.lock").open("a") as f:
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("another A worker owns this state directory") from None
        try:
            yield
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)
