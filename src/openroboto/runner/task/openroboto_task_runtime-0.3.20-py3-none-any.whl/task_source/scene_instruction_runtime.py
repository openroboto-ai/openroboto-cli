"""Trusted installation binding for the single pure scene instruction renderer.

No author source, private material or native model is an input to generation.
This text gate grants no physical, deduplication or server admission result.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from openroboto_protocol.tabletop_assets import canonical_digest

from .base import RuntimeUnavailable, TaskSourceError

_MANIFEST = Path(__file__).parent / "data/scene_instruction_runtime_v1.json"


class SceneInstructionError(TaskSourceError):
    def __init__(self, finding):
        self.finding = finding
        self.code = finding["code"]
        self.capability = "failed" if self.code.startswith("reject_") or "mismatch" in self.code else "unsupported"
        super().__init__(self.code)


def installation_binding():
    from . import scene_instruction

    manifest = json.loads(_MANIFEST.read_bytes())
    source = Path(scene_instruction.__file__).read_bytes()
    actual = hashlib.sha256(source).hexdigest()
    policy = scene_instruction.policy_document()
    if (
        manifest["renderer_module"] != "task_source.scene_instruction"
        or actual != manifest["renderer_implementation_digest"]
        or policy != manifest["policy"]
        or canonical_digest(policy) != manifest["policy_digest"]
    ):
        raise RuntimeUnavailable("scene_instruction_installation_mismatch")
    return source, {
        "version": policy["policy_version"],
        "digest": manifest["policy_digest"],
        "renderer_version": policy["renderer"],
        "renderer_implementation_digest": actual,
        "installation_manifest_digest": canonical_digest(manifest),
        "configuration": policy,
    }


def policy_identity():
    return installation_binding()[1]


def render(raw_task):
    from .scene_instruction import render_instruction

    source, _ = installation_binding()
    return render_instruction(raw_task, renderer_source=source)


def check(raw_task, *, delivered_instruction=None):
    from .scene_instruction import check_instruction

    source, _ = installation_binding()
    return check_instruction(raw_task, renderer_source=source, delivered_instruction=delivered_instruction)


def require(raw_task, *, delivered_instruction=None):
    result = check(raw_task, delivered_instruction=delivered_instruction)
    if not result.accepted or (delivered_instruction is not None and not result.delivery_checked):
        raise SceneInstructionError(result.to_dict())
    return result.to_dict()


def require_task(task, *, delivered_instruction=None):
    # The original raw E-resident text is checked; no normalization or rewrite.
    return require(task.metadata["package"].task, delivered_instruction=delivered_instruction)


def require_messages(raw_task, messages):
    """Check both strings in the actual P03 initial model-message projection."""
    try:
        if messages[1]["role"] != "user" or messages[2]["role"] != "user":
            raise ValueError("expected goal and observation messages")
        if not isinstance(messages[1]["content"], str):
            raise TypeError("delivered goal must be a string")
        goal = require(raw_task, delivered_instruction=messages[1]["content"])
        observation = json.loads(messages[2]["content"])
        if not isinstance(observation["instruction"], str):
            raise TypeError("delivered observation instruction must be a string")
        require(raw_task, delivered_instruction=observation["instruction"])
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        raise TaskSourceError("scene_instruction_model_messages_invalid") from exc
    return goal


def render_execution(execution_root, *, report_path=None, text_path=None):
    """Pure CLI bridge. Write optional NEW outputs outside E; never migrate E/P.

    The caller first authors a new schema3 E with current exact refs. Only its
    public task is read. The render result is not a package/import validation.
    """
    from openroboto_protocol import scene_contract
    from .scene_runtime import RUNTIME_VERSION, registry_refs

    execution = Path(execution_root).resolve()
    outputs = [Path(p).absolute() for p in (report_path, text_path) if p is not None]
    resolved = [p.resolve() for p in outputs]
    if any(p == execution or p.is_relative_to(execution) or execution.is_relative_to(p) for p in resolved):
        raise TaskSourceError("instruction_output_layout_invalid")
    if any(
        a == b or a.is_relative_to(b) or b.is_relative_to(a) for i, a in enumerate(resolved) for b in resolved[i + 1 :]
    ):
        raise TaskSourceError("instruction_output_layout_invalid")
    if any(p.exists() or p.is_symlink() for p in outputs):
        raise TaskSourceError("instruction_output_exists")
    task_bytes = (execution / "task.json").read_bytes()
    raw = json.loads(task_bytes)
    finding = render(raw)
    refs = registry_refs()
    result = {
        "schema_version": 1,
        "command": "scene-render-instruction",
        "ok": finding.accepted,
        "capability": "instruction_render" if finding.accepted else "unsupported",
        "instruction": finding.to_dict(),
        "runtime_version": RUNTIME_VERSION,
        "execution_profile": scene_contract.profile_ref(),
        "installed_environment": refs["environment"],
        "input_environment": raw.get("environment") if isinstance(raw, dict) else None,
        "environment_matches_installation": isinstance(raw, dict) and raw.get("environment") == refs["environment"],
        "input_task_sha256": hashlib.sha256(task_bytes).hexdigest(),
        "package_validated": False,
        "private_reference_created": False,
        "server_admission": "not_run",
        "business_model_calls": 0,
    }
    # Text export contains exactly the rendered Unicode bytes, no extra newline.
    for target, payload in (
        (report_path, json.dumps(result, sort_keys=True, ensure_ascii=False, indent=2).encode() + b"\n"),
        (text_path, finding.text.encode("utf-8") if finding.text is not None else None),
    ):
        if target is not None and payload is not None:
            path = Path(target)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as stream:
                stream.write(payload)
    return result
