"""Only registered messages cross into a model. Runtime remains worker-owned."""

from __future__ import annotations

import base64
import contextlib
import hashlib
import io
import math
import struct
import zlib

from agent_harness.manifest import agent_binding
from agent_harness.prompts import system_prompt
from agent_harness.tools import execute_tool, tool_manifest
from task_source.tabletop import JOINT_ORDER
from task_source.tool_reference import _tool_action

from .identity import SceneViewError, decode, encoded


def _number(v):
    if type(v) not in (int, float) or not math.isfinite(v):
        raise SceneViewError("observation_invalid")
    return v


def _vector(v, size):
    if not isinstance(v, (list, tuple)) or len(v) != size:
        raise SceneViewError("observation_invalid")
    return [_number(n) for n in v]


def _image(raw, camera):
    """No paths, URLs or PNG text/metadata chunks in the model channel."""
    if not isinstance(raw, dict) or raw.get("mime_type") != "image/png":
        raise SceneViewError("image_invalid")
    data = base64.b64decode(raw["data_base64"], validate=True)
    if len(data) > 8_000_000 or not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise SceneViewError("image_invalid")
    offset, kinds, compressed = 8, [], bytearray()
    while offset < len(data):
        size = struct.unpack(">I", data[offset : offset + 4])[0]
        chunk = data[offset + 4 : offset + 8]
        payload = data[offset + 8 : offset + 8 + size]
        crc = data[offset + 8 + size : offset + 12 + size]
        if (
            chunk not in {b"IHDR", b"IDAT", b"IEND"}
            or len(crc) != 4
            or crc != struct.pack(">I", zlib.crc32(chunk + payload) & 0xFFFFFFFF)
        ):
            raise SceneViewError("image_invalid")
        if chunk == b"IHDR" and (size != 13 or struct.unpack(">II", payload[:8]) != tuple(camera["image_size"])):
            raise SceneViewError("image_dimensions_mismatch")
        if chunk == b"IHDR" and payload[8:] != bytes([8, 2, 0, 0, 0]):
            raise SceneViewError("image_invalid")
        if chunk == b"IDAT":
            compressed.extend(payload)
        if chunk == b"IEND" and size != 0:
            raise SceneViewError("image_invalid")
        kinds.append(chunk)
        offset += size + 12
    if (
        kinds[:1] != [b"IHDR"]
        or kinds[-1:] != [b"IEND"]
        or kinds.count(b"IHDR") != 1
        or b"IDAT" not in kinds
        or any(k != b"IDAT" for k in kinds[1:-1])
    ):
        raise SceneViewError("image_invalid")
    expected_size = camera["image_size"][1] * (1 + camera["image_size"][0] * 3)
    decompressor = zlib.decompressobj()
    pixels = decompressor.decompress(compressed, expected_size + 1)
    if len(pixels) != expected_size or not decompressor.eof or decompressor.unconsumed_tail or decompressor.unused_data:
        raise SceneViewError("image_invalid")
    digest = hashlib.sha256(data).hexdigest()
    if raw.get("sha256") != digest:
        raise SceneViewError("image_digest_mismatch")
    return {
        "mime_type": "image/png",
        "data_base64": base64.b64encode(data).decode(),
        "sha256": digest,
        "bytes": str(len(data)),
    }


class ModelBoundary:
    """Projection + dispatch, NOT a substitute for process or harness budgets.

    Only operator-verified ExecutionView instances belong here. The existing
    harness retains metering/deadline/terminal semantics. Internal errors are
    fatal: do not continue a possibly corrupted runtime after `runtime_error`.
    """

    def __init__(self, view, *, audit=None):
        if view.contract["agent"] != agent_binding():
            raise SceneViewError("registered_agent_mismatch")
        self._view = view
        self._audit = audit or (lambda event: None)
        self._fatal = False
        self._task = view.task
        self._contract = view.contract
        scene = self._task["scene"]
        self._bodies = {o[k] for o in self._task["task_definition"]["objects"] for k in ("id", "body")}
        self._bodies.update(g["body"] for g in scene["platform_groups"])
        self._bodies.update(g["id"] for g in scene["platform_groups"])
        self._joints = {j[k] for j in scene["joints"] for k in ("id", "name")} | set(JOINT_ORDER)

    @property
    def tools(self):
        return decode(encoded(tool_manifest()))

    def observation(self, raw):
        try:
            step = raw["step"]
            if type(step) is not int or step < 0 or type(raw["success"]) is not bool:
                raise SceneViewError("observation_invalid")
            result = {"step": step, "instruction": self._task["instruction"], "success": raw["success"]}
            # Never take instruction, mode, sensors, tools or errors from raw.
            proprio = raw.get("proprioception", {})
            result["proprioception"] = {
                k: (_vector(proprio[k], 3) if k == "tcp" else _number(proprio[k]))
                for k in ("tcp", "gripper")
                if k in proprio
            }
            if self._contract["observation_contract"] == "vision" and raw.get("image") is None:
                raise SceneViewError("image_unavailable")
            result["image"] = (
                _image(raw["image"], self._task["scene"]["camera"]) if raw.get("image") is not None else None
            )
            if self._contract["observation_contract"] == "state":
                result["objects"] = {
                    name: {k: _vector(entry[k], 3) for k in ("pos", "center") if k in entry}
                    for name, entry in raw.get("objects", {}).items()
                    if name in self._bodies
                }
                state = raw.get("state", {})
                visible = {}
                for key, size in (
                    ("positions", 3),
                    ("orientations", 4),
                    ("linear_velocities", 3),
                    ("angular_velocities", 3),
                    ("centers_of_mass", 3),
                ):
                    if key in state:
                        visible[key] = {
                            name: _vector(value, size) for name, value in state[key].items() if name in self._bodies
                        }
                if "joints" in state:
                    visible["joints"] = {
                        name: _number(value) for name, value in state["joints"].items() if name in self._joints
                    }
                result["state"] = visible
            # A round-trip excludes custom objects and snapshots mutable input.
            return decode(encoded(result))
        except SceneViewError:
            raise
        except Exception as exc:
            raise SceneViewError("observation_invalid") from exc

    def initial_messages(self, raw_observation):
        return [
            {"role": "system", "content": system_prompt()},
            {"role": "user", "content": self._task["instruction"]},
            {"role": "user", "content": encoded(self.observation(raw_observation)).decode()},
        ]

    def dispatch(self, runtime, request):
        """Strict known tools; no model-chosen getattr/path/env/URL operations."""
        if self._fatal:
            return {"ok": False, "error": "runtime_error", "fatal": True}
        try:
            name, args = _tool_action(request)
            if name == "step" and len(args["action"]) != 9:
                raise ValueError("Panda action dimension")
        except Exception:
            return {"ok": False, "error": "invalid_tool_request", "fatal": False}
        log = io.StringIO()
        try:
            # These streams are audit-only; they are not a tool response.
            with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
                outcome = execute_tool(runtime, name, args)
            self._audit({"tool": name, "detail": outcome.detail, "output": log.getvalue()})
            return {"ok": True, "observation": self.observation(outcome.observation)}
        except Exception as exc:
            self._fatal = True
            try:
                self._audit({
                    "tool": name,
                    "exception_type": type(exc).__name__,
                    "error": str(exc),
                    "output": log.getvalue(),
                })
            except Exception:
                pass
            return {"ok": False, "error": "runtime_error", "fatal": True}
