"""Fixed installed scene worker. Never import native code at module import."""

from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import socket
import struct
import time

from .episode import authenticated_frame, require, verify_frame
from .identity import decode, encoded


def validate_image_identity(binding, image):
    from agent_harness.manifest import agent_binding, harness_code_digest

    require(
        image.get("schema_version") == 1
        and image["runtime"] == binding["runtime"]
        and image["agent"] == binding["execution_contract"]["agent"]
        and image["harness_code_digest"] == harness_code_digest(),
        "episode_image_identity",
    )
    # Public deployment label comes from the measured image manifest, never
    # from E or an inherited arbitrary environment. Prompt/tools still recompute.
    os.environ["AGENT_HARNESS_COMMIT"] = image["agent"]["harness_commit"]
    require(agent_binding() == image["agent"], "registered_agent_mismatch")


def _read(sock, count):
    result = bytearray()
    while len(result) < count:
        chunk = sock.recv(count - len(result))
        require(chunk, "episode_ipc_eof")
        result.extend(chunk)
    return bytes(result)


def _receive(sock, maximum):
    size = struct.unpack("!I", _read(sock, 4))[0]
    require(0 < size <= maximum, "episode_frame_limit")
    return decode(_read(sock, size))


def _send(sock, payload, maximum):
    data = encoded(payload)
    require(len(data) <= maximum, "episode_frame_limit")
    sock.sendall(struct.pack("!I", len(data)) + data)


def serve(sock):
    # Parent is the only IPC peer; no network/provider/registration-file lookup.
    init = _receive(sock, 1_000_000)
    key, nonce, binding = bytes.fromhex(init["key"]), init["nonce"], init["binding"]
    require(len(key) == 32 and len(nonce) == 64, "episode_ipc_auth")
    deadline, maximum = init["deadline"], init["frame_bytes"]
    require(type(deadline) in (int, float) and time.monotonic() < deadline, "episode_deadline")
    sock.settimeout(max(0.001, deadline - time.monotonic()))
    sequence, runtime, reset_done = 0, None, False
    audit = []
    try:
        from agent_harness.manifest import agent_binding
        from agent_harness.runtimes import AxisToolRuntime
        from agent_harness.sandbox import install_syscall_guard
        from openroboto_protocol.tabletop_assets import canonical_digest
        from task_source.execution_contract import verify_execution_runtime
        from .boundary import ModelBoundary
        from .identity import verify_execution_view
        from .receipt import ReceiptTrust

        # Must precede E/import/native work; parent independently checks /proc seccomp/UID/ns.
        require(install_syscall_guard(), "episode_seccomp_missing", status="resource_unavailable")
        validate_image_identity(binding, decode(Path("/scene-runtime-identity.json").read_bytes()))
        trust = ReceiptTrust(**{k: v for k, v in init["trust"].items() if k != "algorithm"})
        view = verify_execution_view(
            "/execution",
            init["manifest"],
            init["receipt"],
            expected_submission_digest=binding["submission_digest"],
            trust=trust,
        )
        require(
            all(
                binding[k] == view.manifest[k]
                for k in ("submission_digest", "execution_package_digest", "private_package_digest")
            ),
            "episode_startup_identity",
        )
        require(
            binding["identity"] == view.identity
            and binding["execution_contract"] == view.contract
            and binding["execution_contract_digest"] == canonical_digest(view.contract)
            and binding["receipt_digest"] == hashlib.sha256(encoded(init["receipt"])).hexdigest(),
            "episode_startup_identity",
        )
        index = binding["instance"]
        state = view.task["scene"]["initial_states"][index]
        require(
            state["id"] == binding["initial_state_id"] and canonical_digest(state) == binding["initial_state_digest"],
            "episode_initial_state",
        )
        require(
            view.contract["agent"] == agent_binding() and view.contract["observation_contract"] == "state",
            "episode_lane_unsupported",
        )
        boundary = ModelBoundary(view, audit=audit.append)
        while True:
            require(time.monotonic() < deadline, "episode_deadline")
            request = verify_frame(key, "parent", sequence, _receive(sock, maximum))
            op = request.get("op")
            if op == "startup" and runtime is None and sequence == 0:
                # Existing P02 source/control path, never a second physical scheduler.
                from task_source.scene_authoring import _source, _task

                source = _source("/execution", deadline=deadline)
                task = _task(source)
                runtime = AxisToolRuntime(task, index, source, max_steps=view.contract["budget"]["max_steps"])
                require(runtime.env.deadline == deadline, "episode_native_deadline")
                require(runtime.env.state_id == state["id"], "episode_native_initial_state")
                effective = verify_execution_runtime(view.contract, runtime)
                reply = {
                    "ok": True,
                    "execution_runtime": effective,
                    "identity": {
                        "binding_digest": hashlib.sha256(encoded(binding)).hexdigest(),
                        "nonce": nonce,
                        "deadline": deadline,
                        "agent": agent_binding(),
                        "runtime": binding["runtime"],
                        "initial_state_id": runtime.env.state_id,
                        "initial_state_digest": canonical_digest(state),
                    },
                }
            elif op == "reset" and runtime is not None and not reset_done:
                reset_done = True
                runtime.env.check_deadline()
                reply = {"ok": True, "observation": boundary.observation(runtime.reset())}
            elif op == "tool" and runtime is not None and reset_done:
                runtime.env.check_deadline()
                reply = boundary.dispatch(runtime, request["request"])
            else:
                reply = {"ok": False, "error": "runtime_error", "fatal": True}
            require(time.monotonic() < deadline, "episode_deadline")
            # Diagnostics have a separate private envelope field, never a tool observation.
            reply["private_audit"] = list(audit)
            audit.clear()
            _send(sock, authenticated_frame(key, "worker", sequence, reply), maximum)
            sequence += 1
            if reply.get("fatal"):
                return 1
    except Exception as exc:
        # No traceback, submitted strings or environment in the public reply.
        try:
            _send(
                sock,
                authenticated_frame(key, "worker", sequence, {"ok": False, "error": "runtime_error", "fatal": True}),
                maximum,
            )
        except Exception:
            pass
        print(type(exc).__name__, file=__import__("sys").stderr)
        return 1
    finally:
        # Parent independently kills/reaps the group even if close/native blocks.
        if runtime is not None:
            runtime.close()
        sock.close()


def main():
    parser = argparse.ArgumentParser()
    # bubblewrap cannot pass an inherited descriptor into the sandbox, so the
    # parent mounts a private unix socket and the worker connects to it.
    parser.add_argument("--path", required=True)
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(parser.parse_args().path)
    return serve(sock)


if __name__ == "__main__":
    raise SystemExit(main())
