"""Private schema-1 material IO; recording/replay/success decisions stay in P02.

No executable scripts, simulator imports, reference search under E or grading.
An accepted payload is validated material, not proof of physical truth.
"""

from __future__ import annotations

import math
import os
import unicodedata
from collections.abc import Mapping
from pathlib import Path, PurePosixPath

from openroboto_protocol.scene_contract import SubmissionIdentity, profile_catalog
from openroboto_protocol.task_contract import reference_contract_issues
from openroboto_protocol.tabletop_assets import canonical_digest

from task_source.tool_reference import _tool_action
from task_source.scene_import.resources import MAX_FILES, MAX_PACKAGE_BYTES, relative_path

from .identity import (
    AdmissionView,
    SceneViewError,
    _execution_metadata,
    decode,
    digest_contents,
    encoded,
    read_root,
    verify_admission_view,
)

_ROW_INPUT = frozenset({"state_id", "actions", "tool_actions", "final_state", "success"})
_ROW_DIGESTS = frozenset({"initial_state_digest", "actions_digest", "tool_actions_digest", "final_state_digest"})
_RESERVED_EVIDENCE = frozenset({
    "reference.json",
    "reference-attempt.json",
    "reference-binding.json",
    "failure.json",
    "submission.json",
    "receipt.json",
    "manifest.json",
    "report.json",
})


def _evidence_path(name):
    try:
        if not isinstance(name, str):
            raise ValueError()
        relative_path(name, "evidence")
        path = PurePosixPath(name)
        if len(path.parts) > 16 or path.suffix != ".json" or any(".secrets" in part.casefold() for part in path.parts):
            raise ValueError()
    except Exception as exc:
        raise SceneViewError("evidence_path_invalid") from exc
    if any(part.casefold() in _RESERVED_EVIDENCE for part in path.parts):
        raise SceneViewError("evidence_path_reserved")
    return path


def _parse_evidence(content):
    if type(content) is not bytes:
        raise SceneViewError("evidence_bytes_required")
    try:
        value = decode(content)
        if not isinstance(value, (dict, list)):
            raise ValueError()
        canonical = encoded(value)
    except Exception as exc:
        raise SceneViewError("evidence_json_invalid") from exc
    if content != canonical and content != canonical + b"\n":
        raise SceneViewError("evidence_json_noncanonical")
    return value


def _evidence_payloads(files, remaining):
    if files is None:
        return {}
    if not isinstance(files, Mapping):
        raise SceneViewError("evidence_files_invalid")
    if len(files) + 4 > MAX_FILES:
        raise SceneViewError("evidence_resource_limit")
    contents, aliases, directories, directory_aliases, total = {}, set(), set(), set(), 0
    for name, content in files.items():
        path = _evidence_path(name)
        alias = unicodedata.normalize("NFC", name).casefold()
        if alias in aliases:
            raise SceneViewError("evidence_path_conflict")
        aliases.add(alias)
        parents = {str(p) for p in path.parents if str(p) != "."}
        directories.update(parents)
        directory_aliases.update(unicodedata.normalize("NFC", p).casefold() for p in parents)
        if type(content) is not bytes:
            raise SceneViewError("evidence_bytes_required")
        total += len(content)
        if total > remaining:
            raise SceneViewError("package_resource_limit")
        _parse_evidence(content)
        contents[name] = content  # Preserve the actual supplied canonical bytes.
    if aliases & directory_aliases:
        raise SceneViewError("evidence_path_conflict")
    if len(aliases) + len(directories) + 4 > MAX_FILES:
        raise SceneViewError("evidence_resource_limit")
    return contents


def load_private_evidence(view: AdmissionView, *, evidence_file: str):
    """Parse one explicitly named canonical JSON evidence object/array in P.

    This is not a typed reference and does not add to binding.reference_files.
    Its original bytes are available from view.private_contents[evidence_file].
    Authenticity of view/P and physical proof provenance remain caller duties.
    """
    if type(view) is not AdmissionView:
        raise SceneViewError("admission_view_required")
    _evidence_path(evidence_file)
    if evidence_file not in view.private_contents:
        raise SceneViewError("evidence_missing")
    content = view.private_contents[evidence_file]
    if len(content) > MAX_PACKAGE_BYTES:
        raise SceneViewError("package_resource_limit")
    return _parse_evidence(content)


def _validate_tool_actions(actions, *, max_api_calls):
    """One tool/dimension rule for typed P and admitted replay proof rows."""
    if not isinstance(actions, list) or not actions or len(actions) > max_api_calls:
        raise SceneViewError("reference_tool_budget")
    for action in actions:
        try:
            name, args = _tool_action(action)
            if name == "step" and len(args["action"]) != 9:
                raise ValueError()
        except (ValueError, TypeError, KeyError):
            raise SceneViewError("reference_tool_invalid") from None


def _validate_rows(payload, task, contract, *, complete):
    if not isinstance(payload, dict) or set(payload) != {"schema_version", "task_id", "instances"}:
        raise SceneViewError("reference_payload_invalid")
    if type(payload["schema_version"]) is not int or payload["schema_version"] != 1:
        raise SceneViewError("reference_schema_invalid")
    if payload["task_id"] != task["task_id"]:
        raise SceneViewError("reference_task_mismatch")
    rows = payload["instances"]
    states = task["scene"]["initial_states"]
    if not isinstance(rows, dict) or set(rows) != {str(i) for i in range(len(states))}:
        raise SceneViewError("reference_instance_coverage")
    budget = contract["budget"]
    for i, state in enumerate(states):
        row = rows[str(i)]
        if not isinstance(row, dict) or set(row) != (_ROW_INPUT | _ROW_DIGESTS if complete else _ROW_INPUT):
            raise SceneViewError("reference_row_invalid")
        if row["state_id"] != state["id"]:
            raise SceneViewError("reference_state_mismatch")
        if row["success"] is not True:
            raise SceneViewError("reference_instance_failed")
        actions = row["actions"]
        if not isinstance(actions, list) or not actions:
            raise SceneViewError("reference_actions_missing")
        if len(actions) > budget["max_steps"]:
            raise SceneViewError("reference_step_budget")
        for action in actions:
            if not isinstance(action, list) or len(action) != 9:
                raise SceneViewError("reference_action_dimension")
            if any(type(v) not in (int, float) or not math.isfinite(v) for v in action):
                raise SceneViewError("reference_action_invalid")
        tools = row["tool_actions"]
        _validate_tool_actions(tools, max_api_calls=budget["max_api_calls"])
        if not isinstance(row["final_state"], dict) or not row["final_state"]:
            raise SceneViewError("reference_final_state_missing")
        expected = {
            "initial_state_digest": canonical_digest(state),
            "actions_digest": canonical_digest(actions),
            "tool_actions_digest": canonical_digest(tools),
            "final_state_digest": canonical_digest(row["final_state"]),
        }
        if complete and any(row[k] != v for k, v in expected.items()):
            raise SceneViewError("reference_content_drift")
        row.update(expected)
    issues = reference_contract_issues(
        payload, task_id=task["task_id"], instance_ids=list(range(len(states))), step_limit=budget["max_steps"]
    )
    if issues:
        raise SceneViewError(issues[0].code)
    return payload


def load_private_reference(view: AdmissionView, *, reference_file: str = "reference.json") -> dict:
    """Read only bound P bytes after verify_admission_view, never search E.

    Returns a detached JSON copy compatible with TaskSpec.reference_for(i).
    P00's generic schema-only fixtures remain valid view fixtures; this explicit
    typed loader rejects them as incomplete recordings rather than inventing one.
    """
    try:
        if type(view) is not AdmissionView:
            raise SceneViewError("admission_view_required")
        if reference_file not in view.binding["reference_files"]:
            raise SceneViewError("reference_not_bound")
        if reference_file not in view.private_contents:
            raise SceneViewError("reference_missing")
        payload = decode(view.private_contents[reference_file])
        return _validate_rows(payload, view.execution.task, view.execution.contract, complete=True)
    except SceneViewError:
        raise
    except Exception as exc:
        raise SceneViewError("reference_payload_invalid") from exc


def _exclusive_write(path, content):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())


def _exclusive_evidence_write(root, name, content):
    """O_NOFOLLOW on every parent and O_EXCL on the leaf; no symlink traversal."""
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        parts = PurePosixPath(name).parts
        for part in parts[:-1]:
            try:
                os.mkdir(part, mode=0o700, dir_fd=fd)
            except FileExistsError:
                pass
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        leaf = os.open(parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
        with os.fdopen(leaf, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
    finally:
        os.close(fd)


def _output_paths(execution_root, private_root, manifest_path):
    execution = Path(execution_root).resolve()
    private_input, manifest_input = Path(private_root).absolute(), Path(manifest_path).absolute()
    if private_input.exists() or private_input.is_symlink() or manifest_input.exists() or manifest_input.is_symlink():
        raise SceneViewError("output_exists")
    private, manifest = private_input.resolve(), manifest_input.resolve()
    if (
        private.is_relative_to(execution)
        or execution.is_relative_to(private)
        or manifest.is_relative_to(execution)
        or execution.is_relative_to(manifest)
        or manifest.is_relative_to(private)
        or private.is_relative_to(manifest)
    ):
        raise SceneViewError("output_layout_invalid")
    return private, manifest


def write_private_reference(
    execution_root,
    *,
    expected_execution_digest: str,
    instances: Mapping[int, Mapping],
    private_root,
    manifest_path,
    evidence_files: Mapping[str, bytes] | None = None,
) -> AdmissionView:
    """Finalize a NEW P and detached manifest without writing any byte under E.

    P02 supplies actual all-state recordings and success flags. `instances` has
    exact integer 0..N-1 keys and input rows with state_id/actions/tool_actions/
    final_state/success. Actual execution provenance remains P02's obligation.
    The raw JSON attempt is retained even on validation failure; no binding or
    manifest is published then. Non-JSON/oversize/path preflight failures leave
    outputs untouched; the caller retains its original recording diagnostics.
    Never overwrite a previous attempt, success, binding, receipt or manifest.
    Optional canonical JSON evidence bytes are written before P is finalized,
    counted in P's digest/size, but never named as typed reference_files. No
    proof schema/truth is inferred; P02 supplies the actual tool-reference proof.
    """
    created = None
    try:
        contents = read_root(execution_root)
        execution_digest = digest_contents(contents)
        if execution_digest != expected_execution_digest:
            raise SceneViewError("execution_drift")
        try:
            parsed_task, contract, _ = _execution_metadata(contents)
        except SceneViewError:
            raise
        except Exception as exc:
            raise SceneViewError("execution_material_invalid") from exc
        task = decode(contents["task.json"])
        private, manifest_path = _output_paths(execution_root, private_root, manifest_path)
        if not isinstance(instances, Mapping) or any(type(i) is not int for i in instances):
            raise SceneViewError("reference_instance_coverage")
        raw = {"schema_version": 1, "task_id": task["task_id"], "instances": {str(i): r for i, r in instances.items()}}
        try:
            attempt = encoded(raw) + b"\n"
        except (TypeError, ValueError, OverflowError) as exc:
            raise SceneViewError("reference_json_invalid") from exc
        maximum = profile_catalog()["resources"][parsed_task.task_definition.resource_profile]["max_package_bytes"]
        execution_size = sum(map(len, contents.values()))
        private_limit = min(MAX_PACKAGE_BYTES, maximum - execution_size)
        if len(attempt) > private_limit:
            raise SceneViewError("package_resource_limit")
        extras = _evidence_payloads(evidence_files, private_limit - len(attempt))
        evidence_size = sum(map(len, extras.values()))
        private.mkdir(parents=True, mode=0o700, exist_ok=False)
        created = private
        _exclusive_write(private / "reference-attempt.json", attempt)
        for name, content in extras.items():
            _exclusive_evidence_write(private, name, content)
        payload = _validate_rows(decode(attempt), task, contract, complete=False)
        reference = encoded(payload) + b"\n"
        binding = (
            encoded({
                "schema_version": 1,
                "execution_package_digest": execution_digest,
                "execution_contract_digest": canonical_digest(contract),
                "reference_schema_version": 1,
                "reference_files": ["reference.json"],
            })
            + b"\n"
        )
        if len(attempt) + len(reference) + len(binding) + evidence_size > private_limit:
            raise SceneViewError("package_resource_limit")
        _exclusive_write(private / "reference.json", reference)
        _exclusive_write(private / "reference-binding.json", binding)
        identity = SubmissionIdentity(execution_digest, digest_contents(read_root(private)))
        manifest = {
            "schema_version": 1,
            "execution_package_digest": execution_digest,
            "private_package_digest": identity.private_package_digest,
            "submission_digest": identity.digest,
        }
        # Recheck actual E/P before publishing: concurrent E drift never earns a
        # detached manifest. The output contains the recorded raw attempt too.
        view = verify_admission_view(execution_root, private, manifest, expected_submission_digest=identity.digest)
        load_private_reference(view)
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        _exclusive_write(manifest_path, encoded(manifest) + b"\n")
        return view
    except Exception as exc:
        if isinstance(exc, SceneViewError):
            error = exc
        elif isinstance(exc, FileExistsError):
            error = SceneViewError("output_exists")
        elif isinstance(exc, OSError):
            error = SceneViewError("write_io_error")
        else:
            error = SceneViewError("reference_payload_invalid")
        if created is not None:
            try:
                _exclusive_write(created / "failure.json", encoded(error.to_dict()) + b"\n")
            except OSError:
                pass
        if error is exc:
            raise
        raise error from exc
