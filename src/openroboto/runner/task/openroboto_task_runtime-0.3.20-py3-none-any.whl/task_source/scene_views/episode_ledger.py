"""Parent-only local A originals and R12 reconciliation; no execution authority.

Prepare BEFORE the resume HTTP request, using authenticated/frozen specs and a
quiescent, independently inventoried local journal. A response is never a source
for expected files, modes, policies, keys, calls or reservations. This module
does not launch, refund, settle, rotate, recover trials, or verify BackendGateway
DB roots: that namespace retains its separate server-original verifier.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import pathlib
import re
import stat
from dataclasses import dataclass, field

from .identity import SceneViewError, decode, encoded

NAMESPACE = "local-a-subscription-v1"
_SEAL = object()
_MAX_ORIGINAL = 16 * 1024 * 1024
_MAX_TOTAL = 64 * 1024 * 1024
_MAX_ROWS = 8192
_SERVER_LEDGERS = ("calls", "budget_reservations", "subscription_reservations")


class LocalLedgerHeld(SceneViewError):
    def __init__(self, code):
        super().__init__(code, status="held")


def _need(condition, code):
    if not condition:
        raise LocalLedgerHeld(code)


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _hash(value):
    return _sha(encoded(value))


def _hex(value, length=64):
    return type(value) is str and re.fullmatch("[0-9a-f]{" + str(length) + "}", value) is not None


def _json(raw):
    _need(type(raw) is bytes and len(raw) <= _MAX_ORIGINAL, "local_original_missing_or_oversize")
    try:
        return decode(raw)
    except (ValueError, TypeError, UnicodeError, RecursionError) as exc:
        raise LocalLedgerHeld("local_original_json_invalid") from exc


def _rows(raw):
    _need(type(raw) is bytes and len(raw) <= _MAX_ORIGINAL, "local_original_missing_or_oversize")
    _need(not raw or raw.endswith(b"\n"), "local_original_truncated")
    lines = raw.splitlines()
    _need(len(lines) <= _MAX_ROWS, "local_original_row_limit")
    values = [_json(line) for line in lines]
    _need(all(type(value) is dict for value in values), "local_original_row_invalid")
    return values


class PrivateCallRecorder:
    """Bounded, exclusive original CallRecorder, only in the trusted parent.

    Its file is never mounted in the model/native roots. The caller supplies a
    trusted evidence path under the supervised parent, not a ZIP/model path.
    The original record format is unchanged; snapshot bytes/hash enter the
    executor's signed cleanup event. Failures retain the partial original.
    """

    def __init__(self, path, *, clock, max_bytes, audit, charge=None, private_roots=(), forbidden_roots=()):
        from agent_eval.records import CallRecorder

        self.path = pathlib.Path(path)
        self.clock, self.max_bytes, self.audit, self.charge = clock, max_bytes, audit, charge
        self.size, self.count, self.digest = 0, 0, hashlib.sha256()
        self.native_context = None
        clock.remaining()
        _need(self.path.is_absolute() and self.path.parent.resolve() == self.path.parent, "local_recorder_path")
        if private_roots:
            _need(
                any(self.path.is_relative_to(pathlib.Path(value).resolve()) for value in private_roots),
                "local_recorder_not_private",
            )
        for value in forbidden_roots:
            root = pathlib.Path(value).resolve()
            _need(not self.path.is_relative_to(root), "local_recorder_path")
        _need(type(max_bytes) is int and 0 < max_bytes <= _MAX_ORIGINAL, "local_recorder_limit")
        fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            info = os.fstat(fd)
            self.inode = (info.st_dev, info.st_ino)
        finally:
            os.close(fd)
        self.writer = CallRecorder(self.path)

    def write(self, record):
        self.clock.remaining()
        if self.native_context is not None:
            record = {**record, "native_context": decode(self.native_context)}
        data = (json.dumps(record, ensure_ascii=False, separators=(",", ":"), default=str) + "\n").encode()
        _need(self.size + len(data) <= self.max_bytes, "local_recorder_limit")
        info = self.path.lstat()
        _need(
            stat.S_ISREG(info.st_mode)
            and stat.S_IMODE(info.st_mode) == 0o600
            and info.st_nlink == 1
            and (info.st_dev, info.st_ino) == self.inode
            and info.st_size == self.size,
            "local_recorder_changed",
        )
        self.audit([{"a_gateway_call": record}])
        if self.charge is not None:
            self.charge(len(data))  # Count the second persistent copy too.
        self.writer.write(record)
        self.size += len(data)
        self.count += 1
        self.digest.update(data)
        self.clock.remaining()

    def bind_native_context(self, context):
        _need(self.native_context is None, "local_native_context_pending")
        raw = encoded(context)
        _need(self.size + len(raw) < self.max_bytes, "local_recorder_limit")
        self.native_context = raw

    def clear_native_context(self):
        self.native_context = None

    def snapshot(self):
        # No reread, quota/network call or new credential after failure.
        return {"sha256": self.digest.hexdigest(), "bytes": self.size, "count": self.count}


@dataclass(frozen=True)
class LocalAEpisodeOriginal:
    spec_bytes: bytes = field(repr=False)
    started_bytes: bytes = field(repr=False)
    events_bytes: bytes = field(repr=False)
    root_bytes: bytes = field(repr=False)
    calls_bytes: bytes = field(repr=False)


@dataclass(frozen=True)
class LocalARecoveryJournal:
    _document: bytes = field(repr=False)
    _seal: object = field(repr=False, compare=False)

    @property
    def document(self):
        return decode(self._document)

    def reconcile(self, portable):
        """R12 parser first validates its own checkpoint/transport contract.

        A match is bookkeeping only, never permission to rerun a paid trial or
        rotate/restore a lease. Preserve this expectation and the server receipt
        atomically in the parent's pending recovery transaction.
        """
        _need(self._seal is _SEAL, "local_journal_untrusted")
        expected = self.document
        _need(
            type(portable) is dict
            and set(portable)
            == {
                "schema_version",
                "run_id",
                "binding_digest",
                "recovery_generation",
                "reconciliation_required",
                *_SERVER_LEDGERS,
            },
            "local_portable_shape",
        )
        _need(
            portable["schema_version"] == "scene-recovery-checkpoint-v1"
            and portable["reconciliation_required"] is True
            and type(portable["recovery_generation"]) is int
            and all(portable[key] == expected[key] for key in ("run_id", "binding_digest", "recovery_generation")),
            "local_portable_binding",
        )
        for name in _SERVER_LEDGERS:
            ledger = portable[name]
            _need(type(ledger) is dict and set(ledger) == {"count", "digest", "rows"}, "local_server_ledger_shape")
            _need(
                type(ledger["count"]) is int
                and ledger["count"] == 0
                and ledger["rows"] == []
                and ledger["digest"] == _hash([]),
                "local_unexpected_server_ledger",
            )
        return {
            "status": "matched",
            "execution_authorized": False,
            "rerun_authorized": False,
            "ledger_namespace": NAMESPACE,
            "gateway_mode": "a_subscription",
            "local_journal_digest": _sha(self._document),
            "portable_digest": _hash(portable),
            "local_calls": expected["local_calls"],
            "local_wire_reservations": expected["local_wire_reservations"],
        }


def _subscription_rows(raw, policy):
    from agent_eval.subscription_gateway import FORMAT

    rows = _rows(raw)
    _need(rows and rows[0].get("type") == "policy", "local_subscription_missing")
    previous, entries, snapshots = None, {}, {}
    for index, row in enumerate(rows):
        _need(
            row.get("format") == FORMAT
            and type(row.get("seq")) is int
            and row["seq"] == index
            and row.get("prev_sha256") == previous
            and row.get("sha256") == _hash({key: value for key, value in row.items() if key != "sha256"}),
            "local_subscription_chain",
        )
        previous = row["sha256"]
        if index == 0:
            _need(
                row.get("policy") == policy.frozen() and row.get("policy_sha256") == policy.sha256,
                "local_subscription_policy",
            )
        else:
            rid = row.get("reservation_id")
            _need(_hex(rid, 32), "local_reservation_id")
            if row.get("type") == "reserve":
                _need(
                    rid not in entries and row.get("state") == "reserved" and row.get("usage_sha256") is None,
                    "local_subscription_transition",
                )
                entries[rid] = dict(row)
            elif row.get("type") == "settle":
                _need(rid in entries and entries[rid].get("usage_sha256") is None, "local_subscription_transition")
                entries[rid].update(row)
            else:
                raise LocalLedgerHeld("local_subscription_transition")
        snapshots[previous] = {key: dict(value) for key, value in entries.items()}
    _need(len(entries) <= policy.max_calls, "local_subscription_cap")
    for entry in entries.values():
        usage = entry.get("usage")
        _need(
            entry.get("state") == "settled"
            and entry.get("usage_status") == "recorded"
            and type(usage) is dict
            and all(type(usage.get(k)) is int and usage[k] >= 0 for k in ("input_tokens", "output_tokens"))
            and entry.get("usage_sha256") == _hash(usage),
            "local_subscription_unsettled",
        )
        _quota(entry.get("quota"), entry.get("quota_sha256"), policy)
    return entries, snapshots, previous


def _quota(quota, digest, policy):
    from .episode_authority import wire_epoch

    _need(
        type(quota) is dict and set(quota) == {"checked_at", "data"} and _hash(quota) == digest, "local_quota_invalid"
    )
    wire_epoch(quota["checked_at"])
    rows = quota["data"]
    _need(type(rows) is list and rows, "local_quota_invalid")
    for row in rows:
        _need(
            type(row) is dict
            and (row.get("provider"), row.get("kind"), row.get("plan"))
            == (policy.subscription_provider, policy.subscription_kind, policy.subscription_plan),
            "local_quota_invalid",
        )
        windows = row.get("windows")
        _need(type(windows) is list and windows, "local_quota_invalid")
        for window in windows:
            _need(type(window) is dict and window.get("name") == policy.quota_window, "local_quota_invalid")
            remaining = window.get("remaining")
            _need(
                type(remaining) in (int, float)
                and math.isfinite(remaining)
                and policy.min_remaining < remaining <= 100,
                "local_quota_floor",
            )


def _wire_payload(spec, messages, tools):
    # The actual A adapter's conversion, not a new renderer/recorder protocol.
    from agent_eval.spec import from_evaluation_spec
    from agent_eval.providers.openai_compat import _convert_messages, _convert_tools

    model = from_evaluation_spec(spec.raw)
    payload = {"model": model.model, "messages": _convert_messages(messages), "stream": model.stream}
    if model.max_tokens:
        payload[model.max_tokens_param] = model.max_tokens
    converted = _convert_tools(tools)
    if converted:
        payload["tools"] = converted
    if model.stream:
        payload["stream_options"] = {"include_usage": True}
    if model.effort and model.effort_param:
        payload[model.effort_param] = model.effort
    payload.update(model.extra_body)
    return payload


def _episode(original, spec, trust, identity, gateway_config, native_policy=None, native_evidence=None):
    from agent_evidence import verify_chain, verify_root
    from agent_harness.headless import _model_evidence, _panel_binding_fields
    from agent_eval.gateway import _provider_meta, _target_identity, BudgetLedger, GatewayPolicy
    from agent_eval.spec import from_evaluation_spec
    from agent_eval.providers.openai_compat import chat_completions_url
    from agent_harness.loop import tool_manifest_for_model
    from .episode_authority import wire_epoch

    _need(_json(original.spec_bytes) == spec.raw, "local_spec_mismatch")
    marker = _json(original.started_bytes)
    _need(
        type(marker) is dict
        and set(marker) in (
            {"spec_sha256", "started_at"},
            {"spec_sha256", "started_at", "launcher_request_digest"},
        )
        and marker["spec_sha256"] == _sha(original.spec_bytes)
        # The trusted P08 parent binds this digest to its complete original
        # request and signed CLOSED. Keep marker bytes intact for inventory.
        and ("launcher_request_digest" not in marker or _hex(marker["launcher_request_digest"])),
        "local_started_mismatch",
    )
    wire_epoch(marker["started_at"])
    events, root, calls = _rows(original.events_bytes), _json(original.root_bytes), _rows(original.calls_bytes)
    _need(type(root) is dict and bool(events), "local_episode_incomplete")
    _need(
        verify_root(root, trust).ok
        and verify_chain(
            events,
            expected_root=root.get("root"),
            party="executor",
            job_id=spec.job_id,
            attempt_id=spec.attempt_id,
            episode=spec.episode,
            job_nonce=spec.job_nonce,
            require_payload=True,
        ).ok,
        "local_episode_signature_or_chain",
    )
    _need(
        all(
            root.get(k) == v
            for k, v in {
                "run_id": spec.run_id,
                "job_id": spec.job_id,
                "attempt_id": spec.attempt_id,
                "episode": spec.episode,
                "job_nonce": spec.job_nonce,
                "job_digest": spec.job_digest,
                "party": "executor",
                "event_count": len(events),
                "first_seq": 0,
                "last_seq": len(events) - 1,
            }.items()
        )
        and all(event.get("run_id") == spec.run_id for event in events),
        "local_episode_scope",
    )
    types = [event["type"] for event in events]
    _need(
        types[0] == "run_start"
        and types[-1] == "run_end"
        and types.count("run_start") == 1
        and types.count("run_end") == 1
        and types.count("scene_episode_cleanup") == 1
        and "error" not in types,
        "local_episode_incomplete",
    )
    start, terminal = events[0]["payload"], events[-1]["payload"]
    expected = {
        "harness": spec.harness_name,
        "source": spec.source,
        "task_id": spec.task_id,
        "instance": spec.instance,
        "mode": spec.mode,
        "sensors": list(spec.sensors),
        "permissions": spec.permissions_payload(),
        "model": _model_evidence(spec),
        "agent": spec.raw["agent"],
        "max_turns": spec.max_turns,
        "max_steps": spec.max_steps,
        "wall_seconds": spec.wall_seconds,
        **_panel_binding_fields(spec),
        "execution_contract": spec.panel_binding["execution_contract"],
        "execution_contract_digest": spec.panel_binding["execution_contract_digest"],
    }
    _need(all(start.get(k) == v for k, v in expected.items()), "local_episode_spec_binding")
    _need(terminal.get("status") == "ok" and type(terminal.get("success")) is bool, "local_episode_unresolved")
    cleanup = next(event["payload"] for event in events if event["type"] == "scene_episode_cleanup")
    gateway = cleanup.get("a_gateway", {})
    _need(
        cleanup.get("terminal") is None and type(gateway) is dict and gateway.get("identity") == identity,
        "local_gateway_identity",
    )
    local = gateway.get("local_ledger", {})
    _need(
        type(local) is dict
        and local.get("namespace") == NAMESPACE
        and local.get("calls")
        == {
            "sha256": _sha(original.calls_bytes),
            "bytes": len(original.calls_bytes),
            "count": len(calls),
        },
        "local_calls_signed_original",
    )
    model_events = [e["payload"] for e in events if e["type"] == "model_call"]
    _need(len(calls) == len(model_events) <= spec.max_turns, "local_calls_coverage")
    matched, seen = [], set()
    target = from_evaluation_spec(spec.raw)
    endpoint = chat_completions_url(target.resolved_endpoint())
    designated = _target_identity(target, endpoint)
    budget = BudgetLedger(GatewayPolicy.from_config(gateway_config, max_api_calls=spec.max_turns).budget)
    for payload, call in zip(model_events, calls):
        cid = call.get("call_id")
        _need(_hex(cid, 32) and cid not in seen and call.get("status") == "ok", "local_call_unresolved")
        seen.add(cid)
        _need(
            all(
                call.get(k) == v
                for k, v in {
                    "provider": target.provider,
                    "model": target.model,
                    "api_format": target.resolved_api_format(),
                    "endpoint": endpoint,
                    "effort": target.effort,
                    "max_tokens": target.max_tokens,
                }.items()
            ),
            "local_call_model",
        )
        _need(call.get("run_id") == spec.run_id and call.get("attempt_id") == spec.attempt_id, "local_call_scope")
        _need(
            call.get("gateway", {}).get("mode") == "enforce"
            and call["gateway"].get("decision") == "allow"
            and call["gateway"].get("violations") == [],
            "local_call_gateway",
        )
        _need(
            call["gateway"].get("designated") == designated and call["gateway"].get("requested") == designated,
            "local_call_model",
        )
        before = budget.snapshot()
        _need(not budget.violations(target), "local_call_budget")
        budget.commit(call.get("usage"))
        _need(call["gateway"].get("budget") == {"before": before, "after": budget.snapshot()}, "local_call_budget")
        meta = _provider_meta(call, call.get("provider_extra"))
        meta["gateway"] = {"decision": "allow", "violations": []}
        _need(
            payload.get("provider_meta") == meta and payload.get("usage") == call.get("usage"),
            "local_call_event_mismatch",
        )
        messages, tools = payload.get("input_messages"), payload.get("input_tools")
        _need(
            type(messages) is list
            and tools == tool_manifest_for_model()
            and _hash(messages) == payload.get("messages_sha256") == call.get("messages_sha256")
            and _hash(tools) == payload.get("tools_sha256") == call.get("tools_sha256"),
            "local_call_input",
        )
        retry = call.get("provider_extra", {}).get("retry", {})
        _need(
            retry.get("attempts") == 1 and retry.get("retries") == 0 and retry.get("failed_attempts") == 0,
            "local_wire_attempts_unresolved",
        )
        wire = _wire_payload(spec, messages, tools)
        if native_policy is not None:
            from .episode_native import native_context_projection

            context = call.get("native_context")
            _need(type(context) is dict and set(context) == {"checked_at", "projection"}, "local_native_context")
            at = context["checked_at"]
            _need(type(at) in (int, float) and math.isfinite(at)
                  and native_evidence["observed_at"] <= at < native_evidence["valid_until"], "local_native_context")
            _need(context["projection"] == native_context_projection(native_policy, messages, tools),
                  "local_native_context")
        matched.append({"call_id": cid, "payload_sha256": _hash(wire), "usage": call["usage"]})
    _need(gateway.get("budget") == budget.snapshot(), "local_call_budget")
    return local, gateway.get("subscription_route"), matched


def prepare_local_a_journal(
    *,
    factories,
    expected_specs,
    episode_bindings,
    originals,
    subscription_ledgers,
    inventory,
    executor_trust,
    run_id,
    binding_digest,
    recovery_generation,
    quiescent,
):
    """Freeze verified ORIGINAL local evidence before making any resume request.

    ``expected_specs`` is the complete original-started inventory, independently
    validated by the authenticated P08 parent against work/config/member/trial.
    ``factories``/``subscription_ledgers`` are keyed by the same started members;
    each ledger contains its ENTIRE run history (no filtering/reinitializing).
    ``inventory`` is the parent's own pre-HTTP SHA256 map: ``<stem>/<field>``
    for the five LocalAEpisodeOriginal fields, plus ``subscription/<member>``.
    Pending starts, missing originals, unknown usage, API/USD or Backend mode
    remain held. Passing does not authorize any execution/recovery operation.
    """
    try:
        return _prepare_local_a_journal(
            factories=factories,
            expected_specs=expected_specs,
            episode_bindings=episode_bindings,
            originals=originals,
            subscription_ledgers=subscription_ledgers,
            inventory=inventory,
            executor_trust=executor_trust,
            run_id=run_id,
            binding_digest=binding_digest,
            recovery_generation=recovery_generation,
            quiescent=quiescent,
        )
    except LocalLedgerHeld:
        raise
    except (ValueError, TypeError, KeyError, AttributeError, IndexError, RecursionError) as exc:
        raise LocalLedgerHeld("local_original_invalid") from exc


def _prepare_local_a_journal(
    *,
    factories,
    expected_specs,
    episode_bindings,
    originals,
    subscription_ledgers,
    inventory,
    executor_trust,
    run_id,
    binding_digest,
    recovery_generation,
    quiescent,
):
    from agent_harness.spec import HarnessSpec, parse_spec
    from agent_evidence.signing import TrustStore
    from agent_eval.subscription_gateway import _episode_key, session_for_episode
    from .episode import EpisodeBinding
    from .episode_gateway import SceneAGatewayFactory

    _need(quiescent is True and type(executor_trust) is TrustStore, "local_journal_not_quiescent_or_trusted")
    _need(
        type(run_id) is str
        and run_id
        and _hex(binding_digest)
        and type(recovery_generation) is int
        and recovery_generation >= 1,
        "local_journal_binding",
    )
    _need(
        type(expected_specs) is dict
        and expected_specs
        and type(originals) is dict
        and type(episode_bindings) is dict
        and expected_specs.keys() == originals.keys() == episode_bindings.keys(),
        "local_started_coverage",
    )
    _need(
        len(expected_specs) <= 512
        and type(factories) is dict
        and type(subscription_ledgers) is dict
        and type(inventory) is dict,
        "local_journal_shape",
    )
    actual, total, members = {}, 0, set()
    for stem, spec in expected_specs.items():
        _need(
            type(spec) is HarnessSpec
            and parse_spec(decode(encoded(spec.raw))) == spec
            and spec.run_id == run_id
            and spec.panel_binding.get("kind") == "agent"
            and spec.panel_binding.get("trial") == spec.episode,
            "local_spec_not_frozen",
        )
        member = spec.panel_binding["member"]
        _need(
            stem == f"{member}-{spec.episode}" and spec.panel_binding.get("run_id") == run_id, "local_spec_not_frozen"
        )
        members.add(member)
        binding = episode_bindings[stem]
        _need(
            type(binding) is EpisodeBinding
            and binding.document["run_id"] == run_id
            and binding.document["member_id"] == member
            and binding.document["trial"] == spec.episode
            and binding.document["instance"] == spec.instance
            and binding.document["task_id"] == spec.task_id
            and binding.document["attempt_id"] == spec.attempt_id
            and binding.document["execution_contract"] == spec.panel_binding["execution_contract"],
            "local_episode_binding",
        )
        original = originals[stem]
        _need(type(original) is LocalAEpisodeOriginal, "local_original_missing_or_oversize")
        for key in original.__dataclass_fields__:
            raw = getattr(original, key)
            _need(type(raw) is bytes and len(raw) <= _MAX_ORIGINAL, "local_original_missing_or_oversize")
            total += len(raw)
            actual[stem + "/" + key] = _sha(raw)
    _need(factories.keys() == subscription_ledgers.keys() == members, "local_member_coverage")
    for member, raw in subscription_ledgers.items():
        _need(type(raw) is bytes and len(raw) <= _MAX_ORIGINAL, "local_subscription_missing")
        total += len(raw)
        actual["subscription/" + member] = _sha(raw)
    _need(total <= _MAX_TOTAL and inventory == actual, "local_inventory_mismatch")
    summaries, all_calls, all_reservations = {}, set(), set()
    for member in sorted(members):
        factory = factories[member]
        _need(
            type(factory) is SceneAGatewayFactory
            and factory.identity["ledger_namespace"] == NAMESPACE
            and factory.identity["gateway_mode"] == "a_subscription",
            "local_ledger_namespace_unsupported",
        )
        specs = {stem: spec for stem, spec in expected_specs.items() if spec.panel_binding["member"] == member}
        policy = factory.subscription_policy(next(iter(specs.values())))
        entries, snapshots, root = _subscription_rows(subscription_ledgers[member], policy)
        consumed, episodes = set(), []
        for stem, spec in specs.items():
            _need(factory.subscription_policy(spec) == policy, "local_subscription_policy")
            binding = episode_bindings[stem]
            _need(
                factory.config_digest == binding.document["config_digest"] == spec.panel_binding["config_digest"]
                and spec.raw["task"].get("execution_profile") == binding.view.identity["execution_profile"],
                "local_gateway_config",
            )
            key = _episode_key(spec, policy)
            identity = {
                **factory.identity,
                "binding_digest": episode_bindings[stem].digest,
                "permissions_digest": _hash(spec.panel_binding["execution_contract"]["permissions"]),
                "tools_digest": spec.raw["agent"]["tools_digest"],
                **{k: decode(factory.provider_policy_bytes)[k] for k in ("active_config_digest", "input_projection")},
                "provider_service": decode(factory.provider_policy_bytes)["service"],
            }
            provider_policy = decode(factory.provider_policy_bytes)
            native_evidence = None
            if provider_policy["schema_version"] == 2:
                from agent_eval.spec import from_evaluation_spec
                from .episode_native import load_native_registration

                native_evidence = decode(load_native_registration(
                    provider_policy, decode(factory.native_registration_bytes), from_evaluation_spec(spec.raw)))
            local, route, calls = _episode(
                originals[stem], spec, executor_trust, identity, decode(factory.host_bytes).get("gateway", {}),
                provider_policy if native_evidence is not None else None, native_evidence,
            )
            snapshot = local.get("subscription")
            _need(type(snapshot) is dict and snapshot.get("root_sha256") in snapshots, "local_subscription_root")
            prefix = snapshots[snapshot["root_sha256"]]
            episode_entries = [entry for entry in entries.values() if entry["episode_key"] == key]
            _need(len(episode_entries) == len(calls) <= policy.per_episode_calls, "local_reservation_coverage")
            _need(
                snapshot
                == {
                    "format": "magpie-subscription-attempts/v1",
                    "run_id": run_id,
                    "policy_sha256": policy.sha256,
                    "root_sha256": snapshot["root_sha256"],
                    "calls": len(prefix),
                    "episode_calls": len(calls),
                    "max_calls": policy.max_calls,
                    "per_episode_calls": policy.per_episode_calls,
                    "billing_kind": policy.subscription_kind,
                    "spent_usd": None,
                }
                and all(
                    entry["reservation_id"] in prefix and prefix[entry["reservation_id"]] == entry
                    for entry in episode_entries
                ),
                "local_subscription_snapshot",
            )
            session = session_for_episode(spec, policy)
            _need(
                type(route) is dict and route.get("session") == session and type(route.get("route")) is dict,
                "local_subscription_session",
            )
            wire_route = route["route"]
            _need(
                all(
                    wire_route.get(k) == v
                    for k, v in {
                        "asked": policy.codex_model,
                        "model": policy.codex_model,
                        "asked_effort": policy.codex_effort,
                        "effort": policy.codex_effort,
                        "done": True,
                        "status": 200,
                    }.items()
                ),
                "local_subscription_route",
            )
            _need(
                route.get("sha256") == _hash({"session": session, "route": wire_route})
                and type(wire_route.get("tries")) is list
                and wire_route["tries"]
                and all(
                    type(attempt) is dict
                    and attempt.get("model") == policy.codex_model
                    and attempt.get("effort") == policy.codex_effort
                    for attempt in wire_route["tries"]
                ),
                "local_subscription_route",
            )
            for call, entry in zip(calls, episode_entries):
                rid = entry["reservation_id"]
                _need(call["call_id"] not in all_calls and rid not in all_reservations, "local_duplicate_call")
                _need(
                    entry["payload_sha256"] == call["payload_sha256"]
                    and entry["usage"] == call["usage"]
                    and (entry["provider"], entry["model"], entry["api_format"], entry["reasoning_effort"])
                    == (policy.codex_provider, policy.codex_model, policy.codex_api_format, policy.codex_effort)
                    and entry.get("billing_kind") == policy.subscription_kind
                    and entry.get("reserved_usd") is None
                    and entry.get("settled_usd") is None,
                    "local_call_reservation_mismatch",
                )
                all_calls.add(call["call_id"])
                call["reservation_id"] = rid
                all_reservations.add(rid)
                consumed.add(rid)
            episodes.append({"stem": stem, "session": session, "calls": calls, "snapshot": snapshot})
        _need(consumed == entries.keys(), "local_extra_reservations")
        summaries[member] = {
            "factory": factory.identity,
            "local_root_sha256": root,
            "policy_sha256": policy.sha256,
            "episodes": episodes,
        }
    return LocalARecoveryJournal(
        encoded({
            "schema_version": "scene-local-a-journal-v1",
            "gateway_mode": "a_subscription",
            "ledger_namespace": NAMESPACE,
            "run_id": run_id,
            "binding_digest": binding_digest,
            "recovery_generation": recovery_generation,
            "inventory": actual,
            "executor_trust_digest": _hash(executor_trust.to_dict()),
            "members": summaries,
            "local_calls": len(all_calls),
            "local_wire_reservations": len(all_reservations),
        }),
        _SEAL,
    )
