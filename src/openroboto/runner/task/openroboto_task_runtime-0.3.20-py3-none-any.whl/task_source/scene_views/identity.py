"""Worker-only immutable E/P snapshots. No model access or physical verdicts."""

from __future__ import annotations

import hashlib
import json
import pathlib
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import PurePosixPath
from types import MappingProxyType
from typing import Mapping

from openroboto_protocol.package_digest import digest_of_files
from openroboto_protocol.scene_contract import parse_execution_contract, profile_catalog
from openroboto_protocol.scene_schema import (
    PrivateReferenceBinding,
    SceneTask,
    SubmissionManifest,
    dependency_issues,
    submission_issues,
)
from openroboto_protocol.tabletop_assets import canonical_digest

from task_source.scene_import.resources import snapshot


class SceneViewError(ValueError):
    """Stable internal code; never interpolate submitted paths or raw errors."""

    def __init__(self, code, *, status=None):
        self.code = code
        self.status = status or (
            "resource_unavailable" if code.startswith(("sandbox_", "output_", "write_")) else "invalid_package"
        )
        super().__init__(code)

    def to_dict(self):
        return {"status": self.status, "code": self.code}


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


def decode(value):
    # Duplicate keys must not create parser-dependent identities.
    def pairs(items):
        out = {}
        for k, v in items:
            if k in out:
                raise SceneViewError("json_duplicate_key")
            out[k] = v
        return out

    return json.loads(value, object_pairs_hook=pairs, parse_constant=lambda _: _invalid_json())


def _invalid_json():
    raise SceneViewError("json_nonfinite")


def digest_contents(contents, *, clock=None):
    # The public package rule sorts Path parts, not strings. No exclusions.
    def files():
        for path in sorted(contents, key=PurePosixPath):
            data = memoryview(contents[path])
            digest = hashlib.sha256()
            for offset in range(0, len(data), 65536):
                if clock is not None:
                    clock.remaining()
                digest.update(data[offset : offset + 65536])
            if clock is not None:
                clock.remaining()
            yield path, digest.hexdigest()

    return digest_of_files(files())


def read_root(root):
    try:
        return MappingProxyType(snapshot(root))
    except Exception as exc:
        raise SceneViewError("materialization_invalid") from exc


@dataclass(frozen=True)
class ExecutionView:
    """Trusted native runtime input; never a model/adapter/filesystem-tool mount."""

    contents: Mapping[str, bytes]
    manifest_bytes: bytes
    task_bytes: bytes
    contract_bytes: bytes
    identity_bytes: bytes

    @property
    def manifest(self):
        return decode(self.manifest_bytes)

    @property
    def task(self):
        return decode(self.task_bytes)

    @property
    def contract(self):
        return decode(self.contract_bytes)

    @property
    def identity(self):
        return decode(self.identity_bytes)


@dataclass(frozen=True)
class AdmissionView:
    execution: ExecutionView
    private_contents: Mapping[str, bytes]
    binding_bytes: bytes

    @property
    def binding(self):
        return decode(self.binding_bytes)


def _execution(contents, submission, expected_submission_digest, *, clock=None):
    if clock is not None:
        clock.remaining()
    manifest = SubmissionManifest.model_validate(submission)
    if manifest.submission_digest != expected_submission_digest:
        raise SceneViewError("submission_identity_mismatch")
    if digest_contents(contents, clock=clock) != manifest.execution_package_digest:
        raise SceneViewError("execution_drift")
    if clock is not None:
        clock.remaining()
    _, contract, identity = _execution_metadata(contents)
    if clock is not None:
        clock.remaining()
    return ExecutionView(
        contents, encoded(manifest.model_dump()), contents["task.json"], encoded(contract), encoded(identity)
    )


def _execution_metadata(contents):
    """One validation path for pre-reference authoring and registered views."""
    task = SceneTask.model_validate(decode(contents["task.json"]))
    maximum = profile_catalog()["resources"][task.task_definition.resource_profile]["max_package_bytes"]
    if sum(map(len, contents.values())) > maximum:
        raise SceneViewError("package_resource_limit")
    issues = dependency_issues(task, contents)
    if issues:
        raise SceneViewError(issues[0].code)
    contract = parse_execution_contract(task.execution_contract)
    identity = {
        "task_definition_id": task.task_id,
        "execution_profile": task.execution_profile.model_dump(),
        "environment": task.environment.model_dump(),
        "robot": task.robot.artifact.model_dump(),
        "control_mapping": task.robot.control_mapping.model_dump(),
        "resource_profile": task.task_definition.resource_profile,
        "observation_contract": task.task_definition.observation,
        "assets_digest": canonical_digest([a.model_dump(mode="json") for a in task.scene.assets]),
        "instances": len(task.scene.initial_states),
    }
    return task, contract, identity


def verify_admission_view(execution_root, private_root, submission, *, expected_submission_digest):
    """Compare with an operator-selected registration before loading any runtime.

    Both roots use P01's bounded openat/O_NOFOLLOW reader. Use the returned
    bytes for compilation/replay; reopening mutable input paths is not verified.
    The reference format is P00's schema, not a second action/record format.
    """
    try:
        view = _execution(read_root(execution_root), submission, expected_submission_digest)
        private = read_root(private_root)
        maximum = profile_catalog()["resources"][view.identity["resource_profile"]]["max_package_bytes"]
        if sum(map(len, view.contents.values())) + sum(map(len, private.values())) > maximum:
            raise SceneViewError("package_resource_limit")
        binding = PrivateReferenceBinding.model_validate(decode(private["reference-binding.json"]))
        issues = submission_issues(
            SubmissionManifest.model_validate(view.manifest),
            binding,
            execution_package_digest=digest_contents(view.contents),
            private_package_digest=digest_contents(private),
            execution_contract=view.contract,
        )
        if issues:
            raise SceneViewError(issues[0].code)
        for name in binding.reference_files:
            raw = decode(private[name])
            if not isinstance(raw, dict) or type(raw.get("schema_version")) is not int or raw["schema_version"] != 1:
                raise SceneViewError("reference_schema_invalid")
        return AdmissionView(view, private, encoded(binding.model_dump()))
    except SceneViewError:
        raise
    except Exception as exc:
        raise SceneViewError("submission_material_invalid") from exc


def verify_execution_view(execution_root, submission, receipt, *, expected_submission_digest, trust):
    """Independently verify E and its detached authenticated P identity, without P."""
    from .receipt import verify_scene_receipt

    try:
        view = _execution(read_root(execution_root), submission, expected_submission_digest)
        verify_scene_receipt(view, receipt, trust=trust)
        if receipt["result"]["admission"] != "admitted":
            raise SceneViewError("execution_not_admitted")
        return view
    except SceneViewError:
        raise
    except Exception as exc:
        raise SceneViewError("execution_material_invalid") from exc


@contextmanager
def materialize_execution(view):
    """Bridge P01's directory entrypoint to already-verified immutable bytes.

    Keep the context open while a consumer needs the package directory. All
    files are read-only; do not place the private root or any output here. The
    caller selects SceneImportContext from trusted configuration as before.
    """
    if type(view) is not ExecutionView:
        raise SceneViewError("execution_view_required")
    with tempfile.TemporaryDirectory(prefix="openroboto-verified-execution-") as tmp:
        root = pathlib.Path(tmp)
        for name, content in view.contents.items():
            # Defense against incorrectly constructed, non-verified views.
            from task_source.scene_import.resources import relative_path

            path = root / relative_path(name, name)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
            path.chmod(0o400)
        yield root
