"""Owned A-lane gateway factory. No B job token/target or arbitrary chat hook.

Constructed only by the authenticated parent from independently pinned host,
model and config snapshots. The capability creates the existing ModelGateway /
subscription adapter and keeps their original ledgers, quota and route gates.
Import/construction is offline; only chat/finish may perform network work.
"""

from __future__ import annotations

import dataclasses
import hashlib
import pathlib
import time
from dataclasses import dataclass, field

from openroboto_protocol.tabletop_assets import canonical_digest

from .identity import decode, encoded
from .episode import EpisodeError, require

FACTORY_ID = "scene-a-gateway"
FACTORY_VERSION = "5"
_SEAL = object()
_SOURCES = (
    "task_source/scene_views/episode_gateway.py",
    "agent_eval/call_scope.py",
    "task_source/scene_views/episode.py",
    "task_source/scene_views/episode_linux.py",
    "task_source/scene_views/episode_scope.py",
    "task_source/scene_views/episode_watchdog.py",
    "task_source/scene_views/episode_worker.py",
    "task_source/scene_views/episode_authority.py",
    "task_source/scene_views/identity.py",
    "task_source/scene_views/episode_provider.py",
    "task_source/scene_views/episode_native.py",
    "task_source/scene_episode_launcher.py",
    "task_source/scene_views/episode_ledger.py",
    "task_source/scene_views/boundary.py",
    "task_source/scene_views/receipt.py",
    "task_source/scene_views/reference.py",
    "agent_harness/manifest.py",
    "agent_harness/loop.py",
    "agent_harness/headless.py",
    "agent_harness/tools.py",
    "agent_harness/modes.py",
    "agent_harness/prompts.py",
    "task_source/panel_episode.py",
    "agent_eval/gateway.py",
    "agent_eval/records.py",
    "agent_eval/spec.py",
    "agent_eval/subscription_gateway.py",
    "agent_eval/inline_image_guard.py",
    "agent_eval/providers/__init__.py",
    "agent_eval/providers/base.py",
    "agent_eval/providers/openai_compat.py",
    "agent_eval/providers/anthropic.py",
    "agent_eval/run_budget.py",
    "agent_evidence/canonical.py",
    "agent_evidence/__init__.py",
    "agent_evidence/result.py",
    "agent_evidence/events.py",
    "agent_evidence/verify.py",
    "agent_evidence/signing.py",
    "agent_evidence/ed25519.py",
)


def gateway_factory_identity():
    """Build/registration helper, not an independent trust decision."""
    root = pathlib.Path(__file__).resolve().parents[2]
    return {
        "id": FACTORY_ID,
        "version": FACTORY_VERSION,
        "digest": canonical_digest({name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in _SOURCES}),
    }


@dataclass(frozen=True)
class SceneAGatewayFactory:
    host_bytes: bytes = field(repr=False)
    model_bytes: bytes = field(repr=False)
    config_digest: str
    implementation_digest: str
    lease_file: str = field(repr=False)
    ledger_directory: str = field(repr=False)
    provider_policy_bytes: bytes = field(repr=False)
    _seal: object = field(repr=False, compare=False)
    native_registration_bytes: bytes = field(default=b"", repr=False)

    @classmethod
    def from_registered_config(
        cls,
        host,
        *,
        expected_host_digest,
        frozen_model,
        expected_model_digest,
        config_digest,
        expected_factory_digest,
        lease_file,
        ledger_directory,
        provider_policy=None,
        expected_provider_policy_digest=None,
        native_registration=None,
    ):
        """Expected pins come from operator registry + authenticated work config.

        host is the real A panel host config (mode/subscription/session_prefix),
        frozen_model is that config's selected member model. Never select pins
        from the downloaded task, its receipt, or this helper's computed digest.
        """
        import re

        require(type(host) is dict and type(frozen_model) is dict, "episode_a_gateway_config")
        for value in (expected_host_digest, expected_model_digest, config_digest, expected_factory_digest):
            require(type(value) is str and re.fullmatch("[0-9a-f]{64}", value), "episode_a_gateway_pin")
        require(
            canonical_digest(host) == expected_host_digest and canonical_digest(frozen_model) == expected_model_digest,
            "episode_a_gateway_pin",
        )
        require(
            gateway_factory_identity()["digest"] == expected_factory_digest,
            "episode_gateway_implementation",
            status="resource_unavailable",
        )
        require(host.get("mode") in {"api", "subscription"}, "episode_a_gateway_mode", status="resource_unavailable")
        # Credentials are resolved in the trusted parent, never frozen into an
        # EvaluationSpec, model input or the child image. No arbitrary wire overrides.
        require(
            not frozen_model.get("api_key")
            and not frozen_model.get("record_path")
            and not frozen_model.get("headers")
            and not frozen_model.get("extra_body"),
            "episode_a_gateway_model",
        )
        gateway = host.get("gateway", {})
        require(
            type(gateway) is dict and gateway.get("mode", "enforce") == "enforce",
            "episode_a_gateway_enforce",
            status="resource_unavailable",
        )
        from agent_eval.spec import from_evaluation_spec
        from agent_eval.gateway import GatewayPolicy
        from agent_eval.errors import ProviderConfigError

        try:
            target = from_evaluation_spec({"model": frozen_model})
            GatewayPolicy.from_config(gateway)
            api_format = target.resolved_api_format()
        except ProviderConfigError as exc:
            raise EpisodeError("episode_a_gateway_config") from exc
        require(
            target.provider != "pi" and api_format in {"openai", "anthropic"},
            "episode_gateway_unsupported",
            status="resource_unavailable",
        )
        from .episode_provider import registered_provider_policy

        provider_policy_bytes = registered_provider_policy(
            provider_policy, expected_digest=expected_provider_policy_digest, target=target,
            native_registration=native_registration,
        )
        if provider_policy["schema_version"] == 2:
            require(host["mode"] == "subscription" and api_format == "openai", "episode_native_transport",
                    status="resource_unavailable")
        if host["mode"] == "subscription":
            config = host.get("subscription")
            require(
                type(config) is dict
                and {"max_calls_per_member", "max_calls_per_episode", "min_remaining"} <= config.keys()
                and type(host.get("session_prefix")) is str,
                "episode_a_gateway_config",
                status="resource_unavailable",
            )
        for value in (lease_file, ledger_directory):
            require(pathlib.Path(value).is_absolute(), "episode_a_gateway_path")
        return cls(
            encoded(host),
            encoded(frozen_model),
            config_digest,
            expected_factory_digest,
            str(lease_file),
            str(ledger_directory),
            provider_policy_bytes,
            _SEAL,
            encoded(native_registration) if provider_policy["schema_version"] == 2 else b"",
        )

    @property
    def identity(self):
        # This choice is made by the independently pinned host, NEVER by a
        # provider reply, a portable checkpoint, or a server-shaped example.
        mode = decode(self.host_bytes)["mode"]
        return {
            "id": FACTORY_ID,
            "version": FACTORY_VERSION,
            "digest": self.implementation_digest,
            "host_digest": hashlib.sha256(self.host_bytes).hexdigest(),
            "model_digest": hashlib.sha256(self.model_bytes).hexdigest(),
            "config_digest": self.config_digest,
            "provider_policy_digest": hashlib.sha256(self.provider_policy_bytes).hexdigest(),
            "gateway_mode": "a_" + mode,
            "ledger_namespace": "local-a-" + mode + "-v1",
        }

    def subscription_policy(self, spec):
        """The original persistent A policy, shared by execution and recovery.

        ``spec`` must already be checked against authenticated work/config by
        the parent. A ledger header is never an authority for selecting it.
        """
        from agent_eval.subscription_gateway import MixedModelPolicy

        require(
            self._seal is _SEAL
            and self.implementation_digest == gateway_factory_identity()["digest"]
            and encoded(spec.model) == self.model_bytes,
            "episode_gateway_assignment",
        )
        host = decode(self.host_bytes)
        require(host["mode"] == "subscription", "episode_local_ledger_unsupported", status="resource_unavailable")
        member = spec.panel_binding["member"]
        require(__import__("re").fullmatch("[A-Za-z0-9_.-]{1,100}", member), "episode_gateway_member")
        config = host["subscription"]
        return MixedModelPolicy(
            run_id=spec.run_id,
            ledger_path=pathlib.Path(self.ledger_directory) / (member + ".jsonl"),
            max_calls=config["max_calls_per_member"],
            per_episode_calls=config["max_calls_per_episode"],
            min_remaining=config["min_remaining"],
            session_prefix=host["session_prefix"],
            quota_timeout_s=config.get("quota_timeout_s", 8),
            codex_model=spec.model["model"],
            codex_effort=spec.model["effort"],
            codex_endpoint=spec.model["endpoint"],
        )

    def open(self, *, binding, spec, policy, clock, recorder):
        require(
            self._seal is _SEAL
            and self.implementation_digest == policy.gateway_factory_digest == gateway_factory_identity()["digest"],
            "episode_gateway_implementation",
            status="resource_unavailable",
        )
        require(
            self.config_digest == policy.config_digest and encoded(spec.model) == self.model_bytes,
            "episode_gateway_assignment",
        )
        require(
            spec.panel_binding.get("kind") == "agent"
            and spec.panel_binding.get("run_id") == spec.run_id
            and type(spec.panel_binding.get("panel")) is str
            and spec.panel_binding["panel"],
            "episode_gateway_assignment",
        )
        from agent_eval.call_scope import CallScope
        from task_source.panel_episode import LeaseCheckedGateway
        from task_source.panel_state import read
        from .episode_authority import wire_epoch

        def lease_check():
            lease = read(pathlib.Path(self.lease_file))
            require(
                lease.get("allowed") is True and wire_epoch(lease["expires_at"]) > __import__("time").time(),
                "episode_lease_cancelled",
                status="timeout",
            )

        provider = decode(self.provider_policy_bytes)
        if provider["schema_version"] == 2:
            from agent_eval.spec import from_evaluation_spec
            from .episode_native import load_native_registration

            load_native_registration(provider, decode(self.native_registration_bytes),
                                     from_evaluation_spec(spec.raw), now=time.time())
        body_limit = min(policy.frame_bytes, provider["body_limit_bytes"])
        scope = CallScope(clock, max_bytes=body_limit, lease_check=lease_check, max_request_bytes=body_limit)
        host = decode(self.host_bytes)
        raw = {**spec.raw, "gateway": host.get("gateway", {"mode": "enforce"})}
        subscription = None
        with scope.activate():
            if host["mode"] == "subscription":
                from agent_eval.subscription_gateway import make_model_gateway

                subscription = self.subscription_policy(spec)
                base = make_model_gateway(
                    dataclasses.replace(spec, raw=raw), policy=subscription, deepseek_budget=None, recorder=recorder
                )
            else:
                from agent_eval.gateway import ModelGateway

                base = ModelGateway.from_evaluation_spec(raw, recorder=recorder)
            require(base.policy.mode == "enforce", "episode_a_gateway_enforce")
            gateway = LeaseCheckedGateway(base, pathlib.Path(self.lease_file))
        return SceneAGatewayCapability(
            _SEAL,
            gateway,
            scope,
            subscription,
            spec,
            {
                **self.identity,
                "binding_digest": binding.digest,
                "permissions_digest": canonical_digest(binding.view.contract["permissions"]),
                "tools_digest": binding.view.contract["agent"]["tools_digest"],
                "provider_service": provider["service"],
                "active_config_digest": provider["active_config_digest"],
                "input_projection": provider["input_projection"],
            },
            view=binding.view,
            recorder=recorder,
            native_policy=provider if provider["schema_version"] == 2 else None,
            native_registration=decode(self.native_registration_bytes) if self.native_registration_bytes else None,
        )


class SceneAGatewayCapability:
    def __init__(self, seal, gateway, scope, subscription, spec, identity, *, view, recorder=None,
                 native_policy=None, native_registration=None):
        require(seal is _SEAL, "episode_gateway_unsupported", status="resource_unavailable")
        self._gateway, self.scope, self.subscription, self.spec = gateway, scope, subscription, spec
        self._identity_bytes, self.route = encoded(identity), None
        self.recorder = recorder
        self.native_policy, self.native_registration = native_policy, native_registration
        from .episode_provider import PublicTranscript

        self.transcript = PublicTranscript(view, spec)

    @property
    def identity(self):
        return decode(self._identity_bytes)

    def initial_observation(self, observation):
        self.transcript.initial(observation)

    def tool_observation(self, call_id, observation):
        self.transcript.tool(call_id, observation)

    def chat(self, *args, **kwargs):
        self.scope.bytes = 0  # per logical call; retries and quota share this bound
        with self.scope.activate():
            messages = args[0] if args else kwargs.get("messages")
            tools = args[1] if len(args) > 1 else kwargs.get("tools")
            self.transcript.validate(messages, tools)
            if self.native_policy is not None:
                from agent_eval.spec import from_evaluation_spec
                from .episode_ledger import PrivateCallRecorder
                from .episode_native import load_native_registration, native_context_projection

                require(type(self.recorder) is PrivateCallRecorder, "episode_native_recorder",
                        status="resource_unavailable")
                checked_at = time.time()
                load_native_registration(self.native_policy, self.native_registration,
                                         from_evaluation_spec(self.spec.raw), now=checked_at)
                self.recorder.bind_native_context({
                    "checked_at": checked_at,
                    "projection": native_context_projection(self.native_policy, messages, tools),
                })
            try:
                result = self._gateway.chat(*args, **kwargs)
            finally:
                if self.native_policy is not None:
                    self.recorder.clear_native_context()
            self.scope.check()
            self.transcript.reply(result)
            return result

    def finish(self):
        self.scope.bytes = 0
        if self.native_policy is not None:
            from agent_eval.spec import from_evaluation_spec
            from .episode_native import load_native_registration

            load_native_registration(self.native_policy, self.native_registration,
                                     from_evaluation_spec(self.spec.raw), now=time.time())
        with self.scope.activate():
            if self.subscription is not None:
                from agent_eval.subscription_gateway import confirm_session_route, session_for_episode

                self.route = confirm_session_route(self.subscription, session_for_episode(self.spec, self.subscription))
            self.scope.assert_drained()
            local = None
            if self.subscription is not None:
                # Original local UUID/hashchain journal. No server call ID,
                # gateway signature root or DB reservation is manufactured.
                snapshot = self._gateway.adapter.subscription_ledger.snapshot()
                local = {key: value for key, value in snapshot.items() if key != "entries"}
        from .episode_ledger import PrivateCallRecorder

        calls = self.recorder.snapshot() if type(self.recorder) is PrivateCallRecorder else None
        return {
            "identity": self.identity,
            "subscription_route": self.route,
            "budget": self._gateway.ledger.snapshot(),
            "local_ledger": {"namespace": self.identity["ledger_namespace"], "subscription": local, "calls": calls},
        }

    def failure_evidence(self):
        # No activate/check/metadata I/O after cancellation. Unknown usage is
        # NOT refunded; the original persistent subscription ledger is retained.
        self.assert_drained()
        return {
            "identity": self.identity,
            "subscription_route": self.route,
            "route_confirmation": "not_requested_after_failure",
            "budget": self._gateway.ledger.snapshot(),
            "public_transcript_digest": self.transcript.digest(),
        }

    def assert_drained(self):
        try:
            self.scope.assert_drained()
        except Exception as exc:
            raise EpisodeError("episode_gateway_not_drained") from exc
