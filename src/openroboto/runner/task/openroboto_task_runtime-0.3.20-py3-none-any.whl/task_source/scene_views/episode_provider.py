"""Registered provider policy and the owned public headless transcript.

The installed-source pin is NOT active configuration evidence. A caller must
obtain the policy/expected digest from independent authenticated registration;
missing middleware/config evidence closes this lane. No service is inspected
or configured here. Tests use explicitly artificial registration snapshots.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
import re

from openroboto_protocol.tabletop_assets import canonical_digest

from .episode import require
from .identity import encoded

MAGPIE_SOURCE = {
    "id": "magpie",
    "version": "0.1.2953",
    "source_revision": "b61c71448c4fbbce97a664efb1b72e70633dc454",
    "vcs_modified": False,
    "binary_sha256": "6f1b00b8a2b07bf7e4d8df934b8e1448baa4757a66703f601b2cad466f91cc3b",
}


# Same fixed release/source, verified official Linux amd64 terminal-only build.
# https://github.com/yetone/magpie-releases/releases/tag/v0.1.2953
_MAGPIE_SOURCES = (
    MAGPIE_SOURCE,
    {**MAGPIE_SOURCE, "binary_sha256": "d08daa0619f256641b732a2010ab30845663269d77630668519499625b6da658"},
)

TERZA_SERVICE = {"id": "terza", "api": "openai-compatible-v1", "base_url": "https://terza.si/v1"}


def public_input_policy_identity():
    root = Path(__file__).resolve().parents[2]
    names = (
        "task_source/scene_views/boundary.py",
        "agent_harness/loop.py",
        "agent_harness/tools.py",
        "agent_harness/modes.py",
        "agent_harness/prompts.py",
    )
    return {
        "id": "owned-headless-public-v1",
        "digest": canonical_digest({name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in names}),
    }


def registered_provider_policy(document, *, expected_digest, target, native_registration=None):
    unavailable = {"status": "resource_unavailable"}
    fields = {
        "schema_version",
        "service",
        "active_config_digest",
        "endpoint",
        "transport",
        "tools_digest",
        "input_projection",
        "function_tools",
        "native_tools",
        "tool_transform",
        "message_transform",
        "middleware",
        "body_limit_bytes",
    }
    if type(document) is dict and document.get("schema_version") == 2:
        fields.add("native_adapter")
    require(type(document) is dict and set(document) == fields, "episode_provider_policy_missing", **unavailable)
    require(
        type(expected_digest) is str
        and re.fullmatch("[0-9a-f]{64}", expected_digest)
        and canonical_digest(document) == expected_digest,
        "episode_provider_policy_pin",
        **unavailable,
    )
    from agent_harness.tools import tools_digest

    magpie = (
        any(encoded(document["service"]) == encoded(source) for source in _MAGPIE_SOURCES)
        and document["transport"] == "codex-account-http-context"
    )
    terza = (
        document["schema_version"] == 1
        and document["service"] == TERZA_SERVICE
        and document["transport"] == "openai-chat-completions"
        and document["endpoint"] == TERZA_SERVICE["base_url"]
        and target.resolved_api_format() == "openai"
    )
    require(
        document["schema_version"] in (1, 2)
        and type(document["schema_version"]) is int
        and (magpie or terza),
        "episode_provider_source_unsupported",
        **unavailable,
    )
    require(
        type(document["active_config_digest"]) is str
        and re.fullmatch("[0-9a-f]{64}", document["active_config_digest"]),
        "episode_provider_active_config_missing",
        **unavailable,
    )
    require(
        document["endpoint"] == target.resolved_endpoint()
        and document["tools_digest"] == tools_digest()
        and document["input_projection"] == public_input_policy_identity(),
        "episode_provider_contract_mismatch",
        **unavailable,
    )
    require(
        document["function_tools"] == "declared-only"
        and document["native_tools"] == []
        and document["middleware"] == []
        and document["tool_transform"] == "identity",
        "episode_provider_transform_unsupported",
        **unavailable,
    )
    if document["schema_version"] == 1:
        require(document["message_transform"] == "identity", "episode_provider_transform_unsupported", **unavailable)
    else:
        from .episode_native import NATIVE_POLICY, load_native_registration

        require(document["message_transform"] == NATIVE_POLICY, "episode_provider_transform_unsupported", **unavailable)
        load_native_registration(document, native_registration, target)
    require(
        type(document["body_limit_bytes"]) is int and 0 < document["body_limit_bytes"] <= 8_000_000,
        "episode_provider_body_limit",
        **unavailable,
    )
    return encoded(document)


class PublicTranscript:
    """Only messages reconstructed from this owned episode may reach provider.

    Uses real headless constructors; public task/registered observations, prior
    provider replies and correlated projected tool results are its only inputs.
    This is an application gate, not evidence about a remote middleware config.
    """

    def __init__(self, view, spec):
        from .boundary import ModelBoundary
        from agent_harness.loop import tool_manifest_for_model

        self.boundary, self.spec = ModelBoundary(view), spec
        self.sensors, self.tools_bytes = tuple(spec.sensors), encoded(tool_manifest_for_model())
        self.instruction = view.task["instruction"]
        self.messages = None
        self.pending, self.results, self.turn = [], [], 0

    def visible(self, observation):
        from agent_harness.tools import filter_observation

        return filter_observation(self.boundary.observation(observation), self.sensors)

    def initial(self, observation):
        from agent_harness.loop import model_messages

        require(self.messages is None, "episode_public_input_reset")
        self.messages = model_messages(self.visible(observation), self.instruction)

    def tool(self, call_id, observation):
        require(self.pending and self.pending[0] == call_id, "episode_public_tool_correlation")
        self.pending.pop(0)
        self.results.append((call_id, self.visible(observation)))

    def validate(self, messages, tools):
        from agent_harness.loop import tool_result_messages

        require(self.messages is not None and not self.pending, "episode_public_input_unbound")
        require(encoded(tools) == self.tools_bytes, "episode_gateway_tools_mismatch")
        if self.results:
            self.messages.extend(tool_result_messages(self.results))
            self.results = []
        require(encoded(messages) == encoded(self.messages), "episode_public_input_mismatch")

    def reply(self, reply):
        from agent_harness.loop import assistant_message

        calls = reply.get("tool_calls") or []
        require(type(calls) is list and all(type(call) is dict for call in calls), "episode_gateway_response_invalid")
        self.turn += 1
        identifiers = [str(call.get("id") or f"call-{self.turn}-{index}") for index, call in enumerate(calls)]
        require(len(set(identifiers)) == len(identifiers), "episode_gateway_response_invalid")
        self.messages.append(
            assistant_message(reply.get("content") or "", calls, reasoning_content=reply.get("reasoning_content"))
        )
        self.pending = identifiers

    def digest(self):
        return canonical_digest(self.messages)
