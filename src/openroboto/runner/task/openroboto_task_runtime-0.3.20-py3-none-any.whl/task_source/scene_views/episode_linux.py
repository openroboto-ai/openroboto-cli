"""Linux-only episode enforcement. Importing this module performs no OS probe.

No injected capability flags, cgroup paths from submissions, or portable/demo
fallback. Host execution must be independently authorized and validated.
"""

from __future__ import annotations

import hashlib
import os
import pathlib
from pathlib import PurePosixPath
import select
import shutil
import socket
import stat
import struct
import subprocess
import sys
import tempfile
import threading
import time

from .episode import EpisodeError, require
from .identity import decode, encoded
from .episode_watchdog import MEMORY_LIMIT_SAMPLED, resource_violation, scope_stats


_NATIVE_ENV_POLICY_VERSION = "scene-linux-osmesa-env/1"
_NATIVE_ENVIRONMENT = (
    ("MUJOCO_GL", "osmesa"),
    ("PYOPENGL_PLATFORM", "osmesa"),
    ("OMP_NUM_THREADS", "1"),
    ("OPENBLAS_NUM_THREADS", "1"),
    ("MKL_NUM_THREADS", "1"),
    ("VECLIB_MAXIMUM_THREADS", "1"),
    ("NUMEXPR_NUM_THREADS", "1"),
)
# Fixed before Python/native imports; actual Mesa driver limits need image validation.

# bubblewrap has no --preserve-fds (only --sync-fd, which does not pass the fd
# into the sandbox), so the parent listens on a private unix socket and mounts
# its directory read-only into the sandbox instead of inheriting a descriptor.
# The mount point must be creatable after the read-only root bind, so it lives
# under the sandbox's own tmpfs instead of a top-level path.
SANDBOX_IPC_DIRECTORY = "/tmp/ipc"
SANDBOX_IPC_SOCKET = SANDBOX_IPC_DIRECTORY + "/s"


def measured_tree_digest(files_digest):
    from openroboto_protocol.package_digest import digest_of_files

    return digest_of_files((name, files_digest[name]) for name in sorted(files_digest, key=PurePosixPath))


def _file(path, limit=1_000_000):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        data = bytearray()
        while len(data) <= limit:
            chunk = os.read(fd, min(65536, limit + 1 - len(data)))
            if not chunk:
                return bytes(data)
            data.extend(chunk)
        raise EpisodeError("episode_host_file_limit")
    finally:
        os.close(fd)


def _write(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        os.write(fd, str(data).encode())
    finally:
        os.close(fd)


def _numbers(data):
    return {line.split()[0]: int(line.split()[1]) for line in data.decode().splitlines()}


def _overlap(left, right):
    return left.is_relative_to(right) or right.is_relative_to(left)


def bwrap_arguments(policy, execution, ipc_directory):
    """Pure argv planner, no mounts or execution performed here."""
    return [
        "--unshare-all",
        "--die-with-parent",
        "--new-session",
        "--cap-drop",
        "ALL",
        "--clearenv",
        "--ro-bind",
        policy.rootfs,
        "/",
        "--proc",
        "/proc",
        "--dev",
        "/dev",
        "--tmpfs",
        "/tmp",
        "--ro-bind",
        str(execution),
        "/execution",
        "--ro-bind",
        str(ipc_directory),
        SANDBOX_IPC_DIRECTORY,
        "--chdir",
        "/tmp",
        "--setenv",
        "HOME",
        "/tmp",
        "--setenv",
        "TMPDIR",
        "/tmp",
        "--setenv",
        "LANG",
        "C.UTF-8",
        "--setenv",
        "PATH",
        "/nonexistent",
        "--setenv",
        "SCENE_IPC_SOCKET",
        SANDBOX_IPC_SOCKET,
        *(item for name, value in _NATIVE_ENVIRONMENT for item in ("--setenv", name, value)),
        policy.python,
        "-I",
        "-B",
        "-m",
        "task_source.scene_views.episode_worker",
        "--path",
        SANDBOX_IPC_SOCKET,
    ]


class LinuxEpisodeBackend:
    def __init__(self, binding, policy, clock, evidence_directory, *, parent_scope=None):
        self.binding, self.policy, self.clock = binding, policy, clock
        self.evidence = pathlib.Path(evidence_directory)
        self.process = self.sock = self.group = self.workspace = self.watchdog = self.listener = None
        self.stop = threading.Event()
        self.lock = threading.RLock()
        self.reason = None
        self.output = 0
        self.logs = {"stdout": bytearray(), "stderr": bytearray()}
        self.diagnostics = {}
        self.parent_cpu = clock.parent_cpu_started
        self.parent_scope = parent_scope
        self.last_stats = {}
        self.reaped = False
        self.enrolled = False
        self.launch_deadline = None
        self.startup_evidence = None

    def preflight(self):
        p = self.policy
        require(
            sys.platform == "linux" and os.geteuid() == 0 and hasattr(socket, "SCM_CREDENTIALS"),
            "episode_linux_unavailable",
            status="resource_unavailable",
        )
        require(self.parent_scope is not None, "episode_parent_scope_unavailable", status="resource_unavailable")
        self.parent_scope.check_resources()
        for executable, digest in ((p.bwrap, p.bwrap_sha256), (p.setpriv, p.setpriv_sha256)):
            binary = pathlib.Path(executable)
            require(binary.resolve() == binary, "episode_launcher_untrusted", status="resource_unavailable")
            for directory in binary.parents:
                directory_stat = directory.lstat()
                require(
                    directory_stat.st_uid == 0 and not directory_stat.st_mode & 0o022,
                    "episode_launcher_parent_untrusted",
                    status="resource_unavailable",
                )
            st = os.stat(executable, follow_symlinks=False)
            require(
                stat.S_ISREG(st.st_mode) and st.st_uid == 0 and not st.st_mode & 0o022,
                "episode_launcher_untrusted",
                status="resource_unavailable",
            )
            require(
                hashlib.sha256(_file(executable, 32_000_000)).hexdigest() == digest,
                "episode_launcher_digest",
                status="resource_unavailable",
            )
        root = pathlib.Path(p.rootfs)
        require(root.is_absolute() and root.resolve() == root and root != pathlib.Path("/"), "episode_rootfs_path")
        for directory in (root, *root.parents):
            directory_stat = directory.lstat()
            require(
                stat.S_ISDIR(directory_stat.st_mode)
                and directory_stat.st_uid == 0
                and not directory_stat.st_mode & 0o022,
                "episode_rootfs_parent_untrusted",
            )
        for protected in p.protected_roots:
            require(not _overlap(root, pathlib.Path(protected).resolve()), "episode_rootfs_overlaps_private")
        require(not _overlap(root, self.evidence.resolve()), "episode_evidence_overlap")
        files_digest, size = {}, 0
        for directory, directories, files in os.walk(root, followlinks=False):
            for name in [*directories, *files]:
                self.clock.remaining()
                path = pathlib.Path(directory) / name
                st = path.lstat()
                require(
                    ".secrets" not in name.lower()
                    and not stat.S_ISLNK(st.st_mode)
                    and st.st_uid == 0
                    and not st.st_mode & 0o022,
                    "episode_rootfs_untrusted",
                )
                require(stat.S_ISDIR(st.st_mode) or stat.S_ISREG(st.st_mode), "episode_rootfs_special_file")
                if stat.S_ISREG(st.st_mode):
                    require(len(files_digest) < p.max_rootfs_files, "episode_rootfs_limit")
                    size += st.st_size
                    require(size <= p.max_rootfs_bytes, "episode_rootfs_limit")
                    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
                    try:
                        h = hashlib.sha256()
                        for chunk in iter(lambda: os.read(fd, 65536), b""):
                            self.clock.remaining()
                            h.update(chunk)
                    finally:
                        os.close(fd)
                    files_digest[path.relative_to(root).as_posix()] = h.hexdigest()
        require(files_digest and measured_tree_digest(files_digest) == p.rootfs_digest, "episode_rootfs_digest")
        image = decode(_file(root / "scene-runtime-identity.json"))
        require(
            image["runtime"] == dict(p.runtime) and image["agent"] == self.binding.view.contract["agent"],
            "episode_image_identity",
        )
        require((root / p.python.lstrip("/")).is_file(), "episode_interpreter_missing")
        parent = pathlib.Path(p.cgroup_parent)
        mounts = [line.split(" - ") for line in _file("/proc/self/mountinfo").decode().splitlines()]
        require(
            any(
                after.startswith("cgroup2 ") and parent.is_relative_to(pathlib.Path(before.split()[4]))
                for before, after in mounts
            ),
            "episode_cgroup_v2_missing",
            status="resource_unavailable",
        )
        require(
            int(_file("/proc/sys/user/max_user_namespaces")) > 0,
            "episode_user_namespace_unavailable",
            status="resource_unavailable",
        )
        require(
            parent.resolve() == parent and parent.is_dir() and parent != pathlib.Path("/sys/fs/cgroup"),
            "episode_cgroup_delegation",
            status="resource_unavailable",
        )
        controllers = set(_file(parent / "cgroup.subtree_control").decode().split())
        require(
            {"cpu", "memory", "pids"} <= controllers and _file(parent / "cgroup.type").strip() == b"domain",
            "episode_cgroup_delegation",
            status="resource_unavailable",
        )
        # Real write/create failures are also fail-closed; a configured path is not a capability certificate.
        self.clock.remaining()

    def _charge(self, count):
        with self.lock:
            self.output += count
            if self.output > self.policy.output_bytes:
                self.abort("episode_output_limit")
                raise EpisodeError("episode_output_limit")

    def _stats(self):
        # The aggregate domain, including the parent/provider/transcript heaps,
        # is pre-enrolled and kernel limited; a child leaf alone is insufficient.
        try:
            previous = self.last_stats or getattr(self.parent_scope, "last_stats", None)
            if self.policy.memory_evidence_mode == MEMORY_LIMIT_SAMPLED:
                require(previous, "episode_memory_evidence_unfrozen", status="resource_unavailable")
            return scope_stats(
                self.policy.accounting_scope,
                memory_evidence_mode=self.policy.memory_evidence_mode,
                previous=previous,
            )
        except (OSError, ValueError, KeyError) as exc:
            raise EpisodeError("episode_stats_unavailable") from exc

    def _validate_stats(self, stats):
        reason = resource_violation(
            stats,
            cpu_budget_s=self.policy.cpu_budget_s,
            memory_bytes=self.policy.memory_bytes,
            pids=self.policy.pids,
            memory_evidence_mode=self.policy.memory_evidence_mode,
            cpu_quota_us=self.policy.cpu_quota_us,
        )
        if time.process_time() - self.parent_cpu >= self.policy.cpu_budget_s:
            reason = "episode_cpu_limit"
        if reason:
            raise EpisodeError(reason)

    def _monitor_once(self):
        self.clock.remaining()
        if self.launch_deadline is not None and not self.enrolled and time.monotonic() >= self.launch_deadline:
            raise EpisodeError("episode_enrollment_timeout")
        self.last_stats = self._stats()
        self._validate_stats(self.last_stats)
        if self.parent_scope is not None:
            self.parent_scope.check_resources()

    def _watch(self):
        while not self.stop.wait(0.01):
            try:
                self._monitor_once()
                if self.process:
                    streams = [s for s in (self.process.stdout, self.process.stderr) if s and not s.closed]
                    for stream in select.select(streams, [], [], 0)[0]:
                        chunk = os.read(stream.fileno(), min(65536, self.policy.frame_bytes))
                        self._charge(len(chunk))
                        self.logs["stdout" if stream is self.process.stdout else "stderr"].extend(chunk)
            except Exception as exc:
                self.abort(getattr(exc, "code", "episode_supervisor_failure"))
                return

    def start(self, init):
        try:
            self.preflight()
            # The external parent watchdog is already active. This additional
            # output/resource monitor starts BEFORE workspace materialization.
            self._monitor_once()
            self.watchdog = threading.Thread(target=self._watch, name="scene-episode-watchdog", daemon=True)
            self.watchdog.start()
            # Audit is parent-only, never mounted; do not follow existing output/symlink paths.
            require(not self.evidence.exists() and not self.evidence.is_symlink(), "episode_evidence_exists")
            self.evidence.mkdir(mode=0o700, parents=False)
            self.workspace = pathlib.Path(tempfile.mkdtemp(prefix="scene-episode-"))
            os.chown(self.workspace, 0, self.policy.gid)
            self.workspace.chmod(0o750)
            execution = self.workspace / "execution"
            execution.mkdir(mode=0o750)
            self._materialize(execution)
            group = pathlib.Path(self.policy.cgroup_parent) / ("scene-" + os.urandom(16).hex())
            group.mkdir(mode=0o700)
            self.group = group
            for name, value in {
                "cpu.max": f"{self.policy.cpu_quota_us} 100000",
                "memory.max": self.policy.memory_bytes,
                "memory.swap.max": 0,
                "memory.oom.group": 1,
                "pids.max": self.policy.pids,
            }.items():
                _write(self.group / name, value)
            # Force all mandatory kernel/delegation facilities before a child can execute.
            killfd = os.open(self.group / "cgroup.kill", os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            os.close(killfd)
            self._monitor_once()
            ipc_directory = self.workspace / "ipc"
            ipc_directory.mkdir(mode=0o750)
            os.chown(ipc_directory, 0, self.policy.gid)
            ipc_path = ipc_directory / "s"
            listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            listener.bind(str(ipc_path))
            os.chmod(ipc_path, 0o660)
            os.chown(ipc_path, 0, self.policy.gid)
            listener.listen(1)
            self.listener = listener
            ready_r, ready_w = os.pipe()
            go_r, go_w = os.pipe()
            cgfd = os.open(self.group / "cgroup.procs", os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            command = [
                self.policy.setpriv,
                "--reuid",
                str(self.policy.uid),
                "--regid",
                str(self.policy.gid),
                "--clear-groups",
                "--no-new-privs",
                self.policy.bwrap,
                *bwrap_arguments(self.policy, execution, ipc_directory),
            ]
            # Fixed trusted enrollment shim: no E imports, commands or runtime
            # before cgroup membership + parent barrier. Reserve launch CPU above.
            shim = (
                "import os,resource\n"
                f"resource.setrlimit(resource.RLIMIT_AS,({self.policy.memory_bytes},{self.policy.memory_bytes}))\n"
                f"os.write({cgfd},str(os.getpid()).encode());os.close({cgfd})\n"
                f"os.write({ready_w},b'1');os.close({ready_w})\n"
                f"assert os.read({go_r},1)==b'g';os.close({go_r})\n"
                f"os.execv({self.policy.setpriv!r},{command!r})\n"
            )
            try:
                self.launch_deadline = min(self.clock.deadline, time.monotonic() + self.policy.launch_seconds)
                self.process = subprocess.Popen(
                    [sys.executable, "-I", "-S", "-B", "-c", shim],
                    env={"LANG": "C.UTF-8", "PATH": "/nonexistent"},
                    cwd="/",
                    close_fds=True,
                    pass_fds=(ready_w, go_r, cgfd),
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    start_new_session=True,
                )
                launch_end = self.launch_deadline
                if not select.select([ready_r], [], [], max(0, launch_end - time.monotonic()))[0]:
                    raise EpisodeError("episode_enrollment_timeout")
                require(
                    os.read(ready_r, 1) == b"1" and self.process.pid in self._members(), "episode_enrollment_failed"
                )
                self.clock.remaining()
                require(not self.reason, "episode_launch_cancelled", status="resource_unavailable")
                self.enrolled = True
                os.write(go_w, b"g")
            finally:
                for fd in (ready_r, ready_w, go_r, go_w, cgfd):
                    os.close(fd)
            # The sandboxed worker connects to the mounted socket once it is
            # past the enrollment barrier; reject a launch that never arrives.
            accept_deadline = min(self.clock.deadline, time.monotonic() + self.policy.launch_seconds)
            if not select.select([self.listener], [], [], max(0, accept_deadline - time.monotonic()))[0]:
                raise EpisodeError("episode_ipc_unavailable", status="resource_unavailable")
            self.sock, _ = self.listener.accept()
            self.listener.close()
            self.listener = None
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
            self.sock.setblocking(False)
            self._send(encoded(init))
        except BaseException as exc:
            self.abort(getattr(exc, "code", "episode_launch_unavailable"))
            self.close()
            raise EpisodeError(getattr(exc, "code", "episode_launch_unavailable")) from exc

    def _materialize(self, execution):
        from task_source.scene_import.resources import relative_path

        for name, data in self.binding.view.contents.items():
            self._check()
            path = execution / relative_path(name, name)
            path.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            try:
                pending = memoryview(data)
                while pending:
                    self._check()
                    count = os.write(fd, pending[:65536])
                    require(count > 0, "episode_materialize_write")
                    self._check()
                    pending = pending[count:]
            finally:
                os.close(fd)
        for directory, _, files in os.walk(execution):
            self._check()
            os.chown(directory, 0, self.policy.gid)
            os.chmod(directory, 0o550)
            for name in files:
                self._check()
                os.chown(pathlib.Path(directory) / name, 0, self.policy.gid)
                os.chmod(pathlib.Path(directory) / name, 0o440)
        self._check()

    def _members(self):
        return {int(p) for p in _file(self.group / "cgroup.procs").split()}

    def _check(self):
        self.clock.remaining()
        if self.reason:
            raise EpisodeError(self.reason)

    def _send(self, raw):
        require(len(raw) <= self.policy.frame_bytes, "episode_frame_limit")
        data = memoryview(struct.pack("!I", len(raw)) + raw)
        self._charge(len(data))
        while data:
            self._check()
            if select.select([], [self.sock], [], min(0.02, self.clock.remaining()))[1]:
                count = self.sock.send(data)
                require(count > 0, "episode_ipc_eof")
                data = data[count:]

    def _receive(self, count):
        data = bytearray()
        peer = None
        while len(data) < count:
            self._check()
            if not select.select([self.sock], [], [], min(0.02, self.clock.remaining()))[0]:
                continue
            chunk, ancillary, flags, _ = self.sock.recvmsg(count - len(data), socket.CMSG_SPACE(12))
            require(chunk and not flags & socket.MSG_CTRUNC, "episode_ipc_eof")
            credentials = [
                struct.unpack("3i", value)
                for level, kind, value in ancillary
                if level == socket.SOL_SOCKET and kind == socket.SCM_CREDENTIALS
            ]
            require(len(credentials) == 1, "episode_peer_credentials")
            pid, uid, gid = credentials[0]
            require(
                uid == self.policy.uid and gid == self.policy.gid and pid in self._members(), "episode_peer_identity"
            )
            require(not hasattr(self, "peer_pid") or self.peer_pid == pid, "episode_peer_changed")
            if peer is not None:
                require(peer == pid, "episode_peer_changed")
            peer = pid
            self.peer_pid = pid
            self._charge(len(chunk))
            data.extend(chunk)
        return bytes(data)

    def exchange(self, frame):
        self._send(encoded(frame))
        size = struct.unpack("!I", self._receive(4))[0]
        require(0 < size <= self.policy.frame_bytes, "episode_frame_limit")
        reply = decode(self._receive(size))
        if not hasattr(self, "peer_verified"):
            status = _file(f"/proc/{self.peer_pid}/status").decode()
            require("NoNewPrivs:\t1" in status and "CapEff:\t0000000000000000" in status, "episode_peer_privileges")
            namespaces = {}
            for namespace in ("mnt", "net", "pid", "user"):
                namespaces[namespace] = os.readlink(f"/proc/{self.peer_pid}/ns/{namespace}")
                require(
                    namespaces[namespace] != os.readlink(f"/proc/self/ns/{namespace}"),
                    "episode_namespace_missing",
                )
            require("Seccomp:\t2" in status, "episode_seccomp_missing")
            mounts = _file(f"/proc/{self.peer_pid}/mountinfo").decode()
            mounted = {line.split()[4]: line.split()[5].split(",") for line in mounts.splitlines()}
            require(
                "ro" in mounted.get("/", []) and "ro" in mounted.get("/execution", []), "episode_mount_not_readonly"
            )
            self.startup_evidence = {
                "mechanism": "linux-cgroup-v2-bwrap",
                "host_pid": self.peer_pid,
                "host_uid": self.policy.uid,
                "host_gid": self.policy.gid,
                "namespaces": namespaces,
                "uid_map": _file(f"/proc/{self.peer_pid}/uid_map").decode(),
                "gid_map": _file(f"/proc/{self.peer_pid}/gid_map").decode(),
                "mountinfo": mounts,
                "status": {
                    line.split(":", 1)[0]: line.split(":", 1)[1].strip()
                    for line in status.splitlines()
                    if line.split(":", 1)[0] in {"Uid", "Gid", "NSpid", "CapEff", "NoNewPrivs", "Seccomp"}
                },
                "cgroup": str(self.group),
                "rootfs_digest": self.policy.rootfs_digest,
                "parent_scope": self.parent_scope.startup_evidence,
            }
            self.peer_verified = True
        return reply

    def record_private(self, value):
        data = encoded(value) + b"\n"
        self._charge(len(data))
        self.logs.setdefault("audit", bytearray()).extend(data)

    def abort(self, reason):
        with self.lock:
            self.reason = self.reason or reason
            if reason != "episode_finished":
                self.clock.cancelled.set()
            if self.group:
                try:
                    _write(self.group / "cgroup.kill", 1)
                except OSError:
                    self.reason = "episode_kill_failed"
            if self.process and self.process.poll() is None:
                # Enrollment cannot fork before membership. Kill a stalled
                # shim too; descendants are independently covered by cgroup.kill.
                self.process.kill()

    def close(self):
        try:
            self._close()
        except EpisodeError:
            raise
        except Exception as exc:
            raise EpisodeError("episode_cleanup_unavailable") from exc

    def _close(self):
        if self.reaped:
            return
        # Always kill the group even if the leader exited. No tool/model grace.
        end = time.monotonic() + self.policy.cleanup_seconds
        previous_reason = self.reason
        self.stop.set()
        if self.group:
            self.abort(self.reason or "episode_finished")
        if self.process:
            try:
                self.process.wait(timeout=max(0.001, end - time.monotonic()))
            except subprocess.TimeoutExpired as exc:
                self.process.kill()
                raise EpisodeError("episode_reap_timeout") from exc
        if self.watchdog:
            self.watchdog.join(timeout=max(0, end - time.monotonic()))
            require(not self.watchdog.is_alive(), "episode_watchdog_reap", status="resource_unavailable")
        if self.listener:
            self.listener.close()
            self.listener = None
        if self.sock:
            self.sock.close()
        if self.process:
            for stream in (self.process.stdout, self.process.stderr):
                # Final finite drain after the entire tree has died.
                for chunk in iter(lambda: stream.read(65536), b""):
                    require(time.monotonic() < end, "episode_cleanup_deadline", status="resource_unavailable")
                    self._charge(len(chunk))
                    self.logs["stdout" if stream is self.process.stdout else "stderr"].extend(chunk)
                stream.close()
        if self.group:
            # Teardown must not depend on an optional/stat feature which may
            # itself have caused the fail-closed startup (e.g. memory.peak).
            # The kernel drops an empty cgroup on its own once the last member
            # leaves, so a vanished fileset is already torn down, not a failure.
            try:
                while _numbers(_file(self.group / "cgroup.events"))["populated"]:
                    if time.monotonic() >= end:
                        raise EpisodeError("episode_tree_not_empty")
                    time.sleep(0.005)
            except FileNotFoundError:
                pass
            try:
                self.last_stats = self._stats()
                self._validate_stats(self.last_stats)
            except EpisodeError as exc:
                self.reason = exc.code
            except (OSError, ValueError, KeyError):
                self.last_stats = {"populated": 0, "stats_unavailable": True}
                self.reason = "episode_stats_unavailable"
            try:
                self.group.rmdir()
            except FileNotFoundError:
                pass
        self.diagnostics = {
            "mechanism": "linux-cgroup-v2-bwrap",
            "empty": True,
            "leader_reaped": True,
            "stats": self.last_stats,
            "output_bytes": self.output,
            "policy_digest": self.policy.digest,
            "reason": self.reason if self.reason != "episode_finished" else previous_reason,
            "resource_scope": self.policy.accounting_scope,
            "private_output_sha256": {name: hashlib.sha256(data).hexdigest() for name, data in self.logs.items()},
        }
        if self.evidence.exists():
            for name, data in (
                ("cleanup.json", encoded(self.diagnostics)),
                ("stdout.bin", bytes(self.logs["stdout"])),
                ("stderr.bin", bytes(self.logs["stderr"])),
                ("private-audit.jsonl", bytes(self.logs.get("audit", b""))),
            ):
                fd = os.open(self.evidence / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
                try:
                    pending = memoryview(data)
                    while pending:
                        require(time.monotonic() < end, "episode_cleanup_deadline", status="resource_unavailable")
                        count = os.write(fd, pending)
                        require(count > 0, "episode_audit_write_failed", status="resource_unavailable")
                        pending = pending[count:]
                finally:
                    os.close(fd)
        if self.workspace:
            shutil.rmtree(self.workspace)
        self.reaped = True
        final_reason = self.reason if self.reason != "episode_finished" else previous_reason
        if final_reason:
            raise EpisodeError(
                final_reason,
                status=(
                    "agent_budget_exhausted"
                    if final_reason == "episode_tool_budget"
                    else "timeout"
                    if "deadline" in final_reason or "cancelled" in final_reason
                    else "resource_unavailable"
                ),
            )
