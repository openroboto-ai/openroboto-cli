"""Independent, credential-free parent-scope watchdog (stdlib only).

Executed as an absolute installed file with -I -B; no scene/private imports.
All paths/limits come from the trusted parent. Pure helpers are shared with the
in-process monitor and final resource validation. Importing performs no probe.
"""

from __future__ import annotations

import json
import hashlib
import os
from pathlib import Path
import resource
import re
import select
import sys
import time

WATCHDOG_PROTOCOL = 2
READY = b"R2"
MEMORY_PEAK_REQUIRED = "kernel-peak-required/1"
MEMORY_LIMIT_SAMPLED = "kernel-limit-sampled/1"
MEMORY_EVIDENCE_MODES = (MEMORY_PEAK_REQUIRED, MEMORY_LIMIT_SAMPLED)


def finish_command(config):
    token = config.get("finish_token")
    if config.get("protocol") != WATCHDOG_PROTOCOL or type(token) is not str or not re.fullmatch("[0-9a-f]{64}", token):
        raise ValueError("watchdog finish transaction unavailable")
    return b"D2:" + token.encode("ascii")


def finish_receipt(config, pid):
    """Fixed-size confirmation binds this startup config/nonce and child PID.

    This private pipe transaction is not a server signature or a credential.
    The independent parent computes its own expectation before startup.
    """
    finish_command(config)
    if type(pid) is not int or pid <= 0:
        raise ValueError("watchdog PID unavailable")
    data = json.dumps(
        {"config": config, "watchdog_pid": pid},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode()
    return b"F2:" + hashlib.sha256(data).digest()


def resource_violation(
    stats, *, cpu_budget_s, memory_bytes, pids, memory_evidence_mode=MEMORY_PEAK_REQUIRED, cpu_quota_us=100000
):
    """No absent/boolean/negative kernel counters may be interpreted as zero."""
    if type(stats) is not dict or memory_evidence_mode not in MEMORY_EVIDENCE_MODES:
        return "episode_stats_unavailable"
    numbers = ("cpu_usec", "memory_current", "pids", "populated", "rss_bytes")
    if memory_evidence_mode == MEMORY_PEAK_REQUIRED:
        numbers += ("memory_peak",)
    if any(type(stats.get(key)) is not int or stats[key] < 0 for key in numbers):
        return "episode_stats_unavailable"
    for key, fields in (("memory_events", ("oom", "oom_kill", "max")), ("pids_events", ("max",))):
        events = stats.get(key)
        if type(events) is not dict or any(type(events.get(field)) is not int or events[field] < 0 for field in fields):
            return "episode_stats_unavailable"
    if memory_evidence_mode == MEMORY_LIMIT_SAMPLED or "memory_evidence_mode" in stats:
        peak = stats.get("memory_peak")
        status = "unsupported" if peak is None else "measured"
        if (
            "memory_peak" not in stats
            or (peak is not None and (type(peak) is not int or peak < 0))
            or stats.get("memory_evidence_mode") != memory_evidence_mode
            or stats.get("memory_peak_status") != status
        ):
            return "episode_stats_unavailable"
        for sample, current in (("memory_current_sample_max", "memory_current"), ("rss_sample_max", "rss_bytes")):
            if type(stats.get(sample)) is not int or stats[sample] < stats[current]:
                return "episode_stats_unavailable"
        for key, fields in (
            ("cpu_stat", ("usage_usec", "user_usec", "system_usec")),
            ("memory_events", ("low", "high", "max", "oom", "oom_kill")),
            ("pids_events", ("max",)),
        ):
            counters = stats.get(key)
            if (
                type(counters) is not dict
                or not set(fields) <= counters.keys()
                or any(type(value) is not int or value < 0 for value in counters.values())
            ):
                return "episode_stats_unavailable"
        if stats["cpu_stat"]["usage_usec"] != stats["cpu_usec"]:
            return "episode_stats_unavailable"
        limits = stats.get("resource_limits")
        names = {"memory_max", "memory_swap_max", "memory_oom_group", "pids_max", "cpu_quota_us", "cpu_period_us"}
        if (
            type(limits) is not dict
            or set(limits) != names
            or any(type(v) is not int or v < 0 for v in limits.values())
        ):
            return "episode_stats_unavailable"
        if (
            not 0 < limits["memory_max"] <= memory_bytes
            or limits["memory_swap_max"] != 0
            or limits["memory_oom_group"] != 1
            or not 0 < limits["pids_max"] <= pids
            or limits["cpu_quota_us"] <= 0
            or limits["cpu_period_us"] <= 0
            or limits["cpu_quota_us"] * 100000 > cpu_quota_us * limits["cpu_period_us"]
        ):
            return "episode_parent_hard_limit"
    if stats["cpu_usec"] / 1_000_000 >= cpu_budget_s:
        return "episode_cpu_limit"
    memory = [stats["memory_current"], stats["rss_bytes"]]
    if stats["memory_peak"] is not None:
        memory.append(stats["memory_peak"])
    if memory_evidence_mode == MEMORY_LIMIT_SAMPLED:
        memory.extend((stats["memory_current_sample_max"], stats["rss_sample_max"]))
    if max(memory) > memory_bytes or any(stats["memory_events"][key] for key in ("oom", "oom_kill", "max")):
        return "episode_memory_limit"
    if stats["pids"] > pids or stats["pids_events"]["max"]:
        return "episode_pid_limit"
    return None


def _read(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        result = os.read(fd, 65537)
        if len(result) > 65536:
            raise ValueError("kernel counter limit")
        return result
    finally:
        os.close(fd)


def _numbers(path):
    rows = [line.split() for line in _read(path).decode().splitlines()]
    if any(len(row) != 2 for row in rows) or len({row[0] for row in rows}) != len(rows):
        raise ValueError("invalid kernel counters")
    return {key: int(value) for key, value in rows}


def _walk_failure(error):
    raise error


def scope_stats(scope, *, memory_evidence_mode=MEMORY_PEAK_REQUIRED, previous=None):
    """Aggregate counters include the trusted parent and every descendant.

    memory.current/peak are kernel aggregate accounting (including buffers).
    RSS additionally sums each live process; shared pages can count twice.
    """
    scope = Path(scope)
    if memory_evidence_mode not in MEMORY_EVIDENCE_MODES:
        raise ValueError("unsupported memory evidence mode")
    rss, seen = 0, set()
    for directory, _, _ in os.walk(scope, onerror=_walk_failure):
        for value in _read(Path(directory) / "cgroup.procs").split():
            pid = int(value)
            if pid in seen:
                continue
            seen.add(pid)
            try:
                pages = int(_read(f"/proc/{pid}/statm").split()[1])
                if pages < 0:
                    raise ValueError("invalid process RSS")
                rss += pages * os.sysconf("SC_PAGE_SIZE")
            except FileNotFoundError:
                pass
    try:
        peak = int(_read(scope / "memory.peak"))
    except FileNotFoundError:
        if memory_evidence_mode != MEMORY_LIMIT_SAMPLED:
            raise
        peak = None
    cpu = _numbers(scope / "cpu.stat")
    stats = {
        "cpu_usec": cpu["usage_usec"],
        "memory_current": int(_read(scope / "memory.current")),
        "memory_peak": peak,
        "pids": int(_read(scope / "pids.current")),
        "populated": _numbers(scope / "cgroup.events")["populated"],
        "memory_events": _numbers(scope / "memory.events"),
        "pids_events": _numbers(scope / "pids.events"),
        "rss_bytes": rss,
    }
    quota, period = _read(scope / "cpu.max").split()
    stats.update(
        memory_evidence_mode=memory_evidence_mode,
        memory_peak_status="unsupported" if peak is None else "measured",
        memory_current_sample_max=stats["memory_current"],
        rss_sample_max=rss,
        cpu_stat=cpu,
        resource_limits={
            "memory_max": int(_read(scope / "memory.max")),
            "memory_swap_max": int(_read(scope / "memory.swap.max")),
            "memory_oom_group": int(_read(scope / "memory.oom.group")),
            "pids_max": int(_read(scope / "pids.max")),
            "cpu_quota_us": int(quota),
            "cpu_period_us": int(period),
        },
    )
    if previous is not None:
        for key in ("memory_evidence_mode", "memory_peak_status", "resource_limits"):
            if stats[key] != previous[key]:
                raise ValueError("resource capability or hard limit changed")
        for key in ("cpu_stat", "memory_events", "pids_events"):
            if stats[key].keys() != previous[key].keys() or any(
                stats[key][name] < value for name, value in previous[key].items()
            ):
                raise ValueError("resource counters regressed")
        if peak is not None and peak < previous["memory_peak"]:
            raise ValueError("memory peak regressed")
        stats["memory_current_sample_max"] = max(stats["memory_current"], previous["memory_current_sample_max"])
        stats["rss_sample_max"] = max(rss, previous["rss_sample_max"])
    return stats


def main(argv=None):
    # Private pipes and frozen scope/limits; no config file, keys, environment or E/P.
    config = json.loads((argv or sys.argv[1:])[0])
    command = finish_command(config)
    measurement = dict(config.get("memory_evidence", {}))
    measurement.setdefault("memory_evidence_mode", MEMORY_PEAK_REQUIRED)
    resource.setrlimit(resource.RLIMIT_AS, (128 * 1024**2, 128 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
    with open(config["watchdog_group"] + "/cgroup.procs", "w") as handle:
        handle.write(str(os.getpid()))
    try:
        ready_sent = os.write(config["ready_fd"], READY) == len(READY)
        while ready_sent:
            try:
                stats = scope_stats(config["scope"], **measurement)
                reason = resource_violation(stats, **config["limits"])
                measurement["previous"] = stats
                if time.monotonic() >= config["deadline"] or os.getppid() != config["parent_pid"] or reason:
                    break
                ready = select.select([config["control_fd"]], [], [], 0.01)[0]
                if ready:
                    # EOF, old/partial messages and foreign transactions never
                    # disarm. Read is fixed-size; the owned write fits PIPE_BUF.
                    if os.read(config["control_fd"], len(command) + 1) == command:
                        final = scope_stats(config["scope"], **measurement)
                        empty = _numbers(Path(config["kill_scope"]) / "native/cgroup.events")["populated"] == 0
                        if (
                            time.monotonic() < config["deadline"]
                            and os.getppid() == config["parent_pid"]
                            and empty
                            and not resource_violation(final, **config["limits"])
                        ):
                            receipt = finish_receipt(config, os.getpid())
                            if os.write(config["ready_fd"], receipt) == len(receipt):
                                return 0
                    break
            except Exception:
                break  # Missing counter / kernel permission is a terminal failure.
        with open(config["kill_scope"] + "/cgroup.kill", "w") as handle:
            handle.write("1")
        return 1
    finally:
        os.close(config["ready_fd"])
        os.close(config["control_fd"])


if __name__ == "__main__":
    raise SystemExit(main())
