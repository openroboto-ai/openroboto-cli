"""Parent + native resource domain. No migration of a long-lived worker.

The control plane must launch one dedicated parent per episode, already in
accounting/episode/parent. The independent watchdog is in accounting/watchdogs:
outside the killable episode tree, INSIDE the same hard accounting ancestor.
No host probe is performed by importing this module.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
import select
import stat
import subprocess
import sys
import time

from .episode import EpisodeError, require
from .identity import encoded
from .episode_watchdog import (
    _read,
    resource_violation,
    scope_stats,
    WATCHDOG_PROTOCOL,
    READY,
    finish_command,
    finish_receipt,
    MEMORY_LIMIT_SAMPLED,
    MEMORY_PEAK_REQUIRED,
)


def episode_scope_name(*, episode, submission_digest, config_digest):
    return (
        "scene-"
        + hashlib.sha256(
            encoded({"episode": episode, "submission_digest": submission_digest, "config_digest": config_digest})
        ).hexdigest()
    )


class EpisodeParentScope:
    def __init__(self, policy, clock, *, parent_cpu_started):
        self.policy, self.clock, self.parent_cpu_started = policy, clock, parent_cpu_started
        self.scope = Path(policy.accounting_scope)
        self.kill_scope = Path(policy.parent_scope)
        self.process = self.control = self.group = None
        self.last_stats = {}
        self.startup_evidence = None
        self.closed = False
        self.armed = False
        self.terminating = False
        self.receipt_fd = None
        self.finish_config = self.finish_expected = self.finish_evidence = None
        self.finish_confirmed = self.reaped = False
        self.cleanup_error = None

    def _watchdog_limits(self):
        limits = {
            "cpu_budget_s": self.policy.cpu_budget_s,
            "memory_bytes": self.policy.memory_bytes,
            "pids": self.policy.pids,
        }
        if self.policy.memory_evidence_mode == MEMORY_LIMIT_SAMPLED:
            limits.update(memory_evidence_mode=self.policy.memory_evidence_mode, cpu_quota_us=self.policy.cpu_quota_us)
        return limits

    def check_resources(self, *, check_watchdog=True):
        # Entry baseline, never a late backend-construction baseline. Aggregate
        # cgroup CPU also includes bootstrap before the Python public entry.
        if time.process_time() - self.parent_cpu_started >= self.policy.cpu_budget_s:
            raise EpisodeError("episode_cpu_limit")
        try:
            stats = scope_stats(
                self.scope,
                memory_evidence_mode=self.policy.memory_evidence_mode,
                previous=self.last_stats or None,
            )
        except (OSError, ValueError, KeyError) as exc:
            raise EpisodeError("episode_stats_unavailable") from exc
        require(
            not self.last_stats
            or (
                stats["cpu_usec"] >= self.last_stats["cpu_usec"]
                and (
                    stats["memory_peak"] is None
                    and self.last_stats["memory_peak"] is None
                    or stats["memory_peak"] is not None
                    and self.last_stats["memory_peak"] is not None
                    and stats["memory_peak"] >= self.last_stats["memory_peak"]
                )
            ),
            "episode_stats_regressed",
            status="resource_unavailable",
        )
        self.last_stats = stats
        reason = resource_violation(
            self.last_stats,
            cpu_budget_s=self.policy.cpu_budget_s,
            memory_bytes=self.policy.memory_bytes,
            pids=self.policy.pids,
            memory_evidence_mode=self.policy.memory_evidence_mode,
            cpu_quota_us=self.policy.cpu_quota_us,
        )
        if reason:
            raise EpisodeError(reason)
        if check_watchdog and self.process is not None:
            require(self.process.poll() is None, "episode_parent_watchdog_lost", status="resource_unavailable")

    def preflight(self):
        p, scope = self.policy, self.scope
        require(
            sys.platform == "linux" and os.geteuid() == 0,
            "episode_parent_scope_unavailable",
            status="resource_unavailable",
        )
        require(
            scope.is_relative_to(Path("/sys/fs/cgroup"))
            and scope != Path("/sys/fs/cgroup")
            and scope.resolve() == scope,
            "episode_parent_scope_unavailable",
            status="resource_unavailable",
        )
        native, watchdog_parent, kill_scope = Path(p.cgroup_parent), Path(p.watchdog_parent), self.kill_scope
        require(
            kill_scope == scope / "episode"
            and native == kill_scope / "native"
            and watchdog_parent == scope / "watchdogs",
            "episode_parent_scope_layout",
            status="resource_unavailable",
        )
        for path in (scope, kill_scope, native, watchdog_parent):
            require(path.resolve() == path, "episode_parent_scope_untrusted", status="resource_unavailable")
            for directory in (path, *path.parents):
                info = directory.lstat()
                require(
                    stat.S_ISDIR(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022,
                    "episode_parent_scope_untrusted",
                    status="resource_unavailable",
                )
        mounts = _read("/proc/self/mountinfo").decode().splitlines()
        require(
            any(
                line.split(" - ")[1].startswith("cgroup2 ") and line.split()[3:5] == ["/", "/sys/fs/cgroup"]
                for line in mounts
            ),
            "episode_cgroup_v2_missing",
            status="resource_unavailable",
        )
        membership = _read("/proc/self/cgroup").decode().splitlines()
        require(
            membership == ["0::/" + str((kill_scope / "parent").relative_to("/sys/fs/cgroup"))],
            "episode_parent_not_enrolled",
            status="resource_unavailable",
        )
        require(
            {entry.name for entry in scope.iterdir() if entry.is_dir()} == {"episode", "watchdogs"}
            and {entry.name for entry in kill_scope.iterdir() if entry.is_dir()} == {"parent", "native"}
            and set(_read(kill_scope / "parent/cgroup.procs").split()) == {str(os.getpid()).encode()}
            and not _read(scope / "cgroup.procs").strip()
            and not _read(kill_scope / "cgroup.procs").strip()
            and not _read(watchdog_parent / "cgroup.procs").strip()
            and not any(entry.is_dir() for entry in watchdog_parent.iterdir())
            and not _read(native / "cgroup.procs").strip()
            and not any(entry.is_dir() for entry in native.iterdir()),
            "episode_parent_not_exclusive",
            status="resource_unavailable",
        )
        require(
            _read(scope / "cgroup.type").strip() == b"domain"
            and {"cpu", "memory", "pids"} <= set(_read(scope / "cgroup.subtree_control").decode().split()),
            "episode_cgroup_delegation",
            status="resource_unavailable",
        )
        for parent in (kill_scope, native, watchdog_parent):
            require(
                {"cpu", "memory", "pids"} <= set(_read(parent / "cgroup.subtree_control").decode().split()),
                "episode_cgroup_delegation",
                status="resource_unavailable",
            )
        # The standalone supervisor is loaded from the installed, measured
        # package, with a root-controlled interpreter and source ancestry.
        for executable in (Path(sys.executable).resolve(), Path(__file__).with_name("episode_watchdog.py")):
            info = executable.lstat()
            require(
                stat.S_ISREG(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022,
                "episode_supervisor_untrusted",
                status="resource_unavailable",
            )
            for directory in executable.parents:
                info = directory.lstat()
                require(
                    stat.S_ISDIR(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022,
                    "episode_supervisor_untrusted",
                    status="resource_unavailable",
                )
        for name, ceiling in (("memory.max", p.memory_bytes), ("pids.max", p.pids)):
            value = _read(scope / name).strip()
            require(
                value.isdigit() and 0 < int(value) <= ceiling,
                "episode_parent_hard_limit",
                status="resource_unavailable",
            )
        quota, period = _read(scope / "cpu.max").split()
        require(
            quota.isdigit()
            and period.isdigit()
            and int(period) > 0
            and 0 < int(quota) / int(period) <= p.cpu_quota_us / 100000
            and _read(scope / "memory.swap.max").strip() == b"0"
            and _read(scope / "memory.oom.group").strip() == b"1",
            "episode_parent_hard_limit",
            status="resource_unavailable",
        )
        self.verify_kill_targets()
        self.clock.remaining()
        self.check_resources()

    def verify_kill_targets(self):
        try:
            for group in (self.scope, self.kill_scope):
                require(
                    _read(group / "cgroup.type").strip() == b"domain",
                    "episode_kill_domain_unavailable",
                    status="resource_unavailable",
                )
                fd = os.open(group / "cgroup.kill", os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
                os.close(fd)
        except OSError as exc:
            raise EpisodeError("episode_kill_capability_unavailable") from exc

    def start(self):
        try:
            self.preflight()
            group = Path(self.policy.watchdog_parent) / ("watch-" + os.urandom(16).hex())
            group.mkdir(mode=0o700)
            self.group = group
            # Watchdog's own small, separate kernel domain; it cannot escape a
            # hung parent by inheriting the scope which it is supposed to kill.
            for name, value in {
                "pids.max": 1,
                "memory.max": 128 * 1024**2,
                "memory.swap.max": 0,
                "cpu.max": "10000 100000",
            }.items():
                (group / name).write_text(str(value))
            control_r, self.control = os.pipe()
            ready_r, ready_w = os.pipe()
            self.receipt_fd = ready_r
            config = {
                "protocol": WATCHDOG_PROTOCOL,
                "finish_token": os.urandom(32).hex(),
                "scope": str(self.scope),
                "kill_scope": str(self.kill_scope),
                "watchdog_group": str(group),
                "deadline": self.clock.deadline,
                "parent_pid": os.getpid(),
                "control_fd": control_r,
                "ready_fd": ready_w,
                "limits": self._watchdog_limits(),
            }
            config["memory_evidence"] = {
                "memory_evidence_mode": self.policy.memory_evidence_mode,
                "previous": self.last_stats,
            }
            self.finish_config = config
            try:
                self.process = subprocess.Popen(
                    [
                        sys.executable,
                        "-I",
                        "-B",
                        str(Path(__file__).with_name("episode_watchdog.py")),
                        encoded(config).decode(),
                    ],
                    env={"LANG": "C.UTF-8", "PATH": "/nonexistent"},
                    cwd="/",
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    close_fds=True,
                    pass_fds=(control_r, ready_w),
                    start_new_session=True,
                )
                self.finish_expected = finish_receipt(config, self.process.pid)
                require(
                    select.select([ready_r], [], [], min(self.policy.launch_seconds, self.clock.remaining()))[0]
                    and os.read(ready_r, len(READY)) == READY,
                    "episode_parent_watchdog_startup",
                    status="resource_unavailable",
                )
                self.armed = True
                require(
                    set(_read(group / "cgroup.procs").split()) == {str(self.process.pid).encode()},
                    "episode_parent_watchdog_enrollment",
                    status="resource_unavailable",
                )
            finally:
                for fd in (control_r, ready_w):
                    os.close(fd)
            self.clock.remaining()
            self.check_resources()
            self.startup_evidence = {
                "mechanism": "dedicated-parent-cgroup-v2-independent-watchdog",
                "memory_evidence_mode": self.policy.memory_evidence_mode,
                "watchdog_protocol": WATCHDOG_PROTOCOL,
                "scope": str(self.scope),
                "kill_scope": str(self.kill_scope),
                "native_parent": self.policy.cgroup_parent,
                "parent_host_pid": os.getpid(),
                "parent_host_uid": os.geteuid(),
                "watchdog_host_pid": self.process.pid,
                "watchdog_cgroup": str(self.group),
                "watchdog_code_sha256": hashlib.sha256(
                    Path(__file__).with_name("episode_watchdog.py").read_bytes()
                ).hexdigest(),
                "deadline": self.clock.deadline,
                "initial_stats": self.last_stats,
            }
        except BaseException as exc:
            primary = exc if isinstance(exc, EpisodeError) else EpisodeError("episode_parent_scope_unavailable")
            try:
                self.close(validate=False)
            except EpisodeError as cleanup:
                primary.cleanup_error = cleanup.to_dict()
            raise primary from exc

    def close(self, *, validate=True, check_clock=True):
        if self.cleanup_error is not None:
            raise self.cleanup_error
        try:
            self._close(validate=validate, check_clock=check_clock)
        except EpisodeError as exc:
            self.cleanup_error, self.closed = exc, False
            raise
        except Exception as exc:
            self.cleanup_error = EpisodeError("episode_parent_scope_cleanup_unavailable")
            self.closed = False
            raise self.cleanup_error from exc

    def _reap_watchdog(self, end):
        try:
            code = self.process.wait(timeout=max(0.001, end - time.monotonic()))
        except Exception as exc:
            # Cleanup remains bounded on timeout AND other wait failures. A
            # forced kill/reap cannot turn the failed transaction into success.
            try:
                if self.process.poll() is None:
                    self.process.kill()
                code = self.process.wait(timeout=max(0.001, end - time.monotonic()))
                polled = self.process.poll()
                self.reaped = type(code) is int and type(polled) is int and polled == code
            except Exception:
                pass
            raise EpisodeError("episode_parent_watchdog_reap") from exc
        polled = self.process.poll()
        self.reaped = type(code) is int and type(polled) is int and polled == code
        require(
            self.reaped and code == 0 and type(self.process.returncode) is int and self.process.returncode == 0,
            "episode_parent_watchdog_exit",
            status="resource_unavailable",
        )

    def _close(self, *, validate=True, check_clock=True):
        if self.closed:
            return
        require(not self.terminating, "episode_parent_scope_terminated", status="resource_unavailable")
        error = None
        try:
            if validate:
                self.check_resources()  # final aggregate check before a result can escape
                if check_clock:
                    self.clock.remaining()
        except BaseException as exc:
            error = exc
        finally:
            end = time.monotonic() + self.policy.cleanup_seconds
            if self.armed:
                # Never disarm over surviving native descendants, even when the
                # leader already exited or cleanup itself failed. cgroup.kill
                # includes this dedicated parent; a successful return is impossible.
                try:
                    from .episode_watchdog import _numbers

                    empty = _numbers(Path(self.policy.cgroup_parent) / "cgroup.events")["populated"] == 0
                except (OSError, ValueError, KeyError):
                    empty = False
                if not empty:
                    self.terminate()
            sent = False
            try:
                if self.process is not None or validate:
                    require(
                        self.armed
                        and self.process is not None
                        and self.process.poll() is None
                        and type(self.control) is int
                        and self.control >= 0
                        and type(self.receipt_fd) is int
                        and self.receipt_fd >= 0
                        and self.group is not None
                        and type(self.finish_config) is dict
                        and str(self.group) == self.finish_config.get("watchdog_group")
                        and str(self.scope) == self.finish_config.get("scope")
                        and str(self.kill_scope) == self.finish_config.get("kill_scope")
                        and self.clock.deadline == self.finish_config.get("deadline")
                        and self.finish_config.get("parent_pid") == os.getpid()
                        and self.finish_config.get("limits") == self._watchdog_limits()
                        and self.finish_config.get("memory_evidence", {}).get(
                            "memory_evidence_mode", MEMORY_PEAK_REQUIRED
                        )
                        == self.policy.memory_evidence_mode
                        and type(self.finish_expected) is bytes
                        and self.finish_expected == finish_receipt(self.finish_config, self.process.pid),
                        "episode_parent_watchdog_transaction",
                        status="resource_unavailable",
                    )
                    command = finish_command(self.finish_config)
                    require(
                        os.write(self.control, command) == len(command),
                        "episode_parent_watchdog_disarm",
                        status="resource_unavailable",
                    )
                    sent = True
            except Exception as exc:
                error = error or (
                    exc if isinstance(exc, EpisodeError) else EpisodeError("episode_parent_watchdog_disarm")
                )
            finally:
                if self.control is not None:
                    try:
                        os.close(self.control)
                    except OSError:
                        error = error or EpisodeError("episode_parent_watchdog_disarm")
                    self.control = None
            if self.process is not None:
                try:
                    self._reap_watchdog(end)
                    require(
                        sent
                        and select.select([self.receipt_fd], [], [], max(0.001, end - time.monotonic()))[0]
                        == [self.receipt_fd],
                        "episode_parent_watchdog_finish",
                        status="resource_unavailable",
                    )
                    receipt = os.read(self.receipt_fd, len(self.finish_expected) + 1)
                    require(
                        receipt == self.finish_expected, "episode_parent_watchdog_finish", status="resource_unavailable"
                    )
                    self.finish_confirmed = True
                except Exception as exc:
                    error = error or (
                        exc if isinstance(exc, EpisodeError) else EpisodeError("episode_parent_watchdog_finish")
                    )
            if self.receipt_fd is not None:
                try:
                    os.close(self.receipt_fd)
                except OSError:
                    error = error or EpisodeError("episode_parent_watchdog_finish")
                self.receipt_fd = None
            if self.group is not None:
                try:
                    from .episode_watchdog import _numbers

                    require(
                        (self.process is None or self.reaped)
                        and _numbers(self.group / "cgroup.events")["populated"] == 0,
                        "episode_parent_watchdog_not_empty",
                        status="resource_unavailable",
                    )
                    self.group.rmdir()
                except Exception as exc:
                    error = error or (
                        exc if isinstance(exc, EpisodeError) else EpisodeError("episode_parent_watchdog_not_empty")
                    )
            if validate:
                # Teardown itself consumes CPU/wall. Do not let a final done/
                # reap interval turn the last successful sample into a result.
                try:
                    self.check_resources(check_watchdog=False)
                    if check_clock:
                        self.clock.remaining()
                except BaseException as exc:
                    error = error or exc
            if time.monotonic() >= end:
                error = error or EpisodeError("episode_parent_watchdog_reap")
        if error:
            raise error
        if self.finish_confirmed:
            self.finish_evidence = {
                "protocol": WATCHDOG_PROTOCOL,
                "exit_code": 0,
                "watchdog_pid": self.process.pid,
                "config_digest": hashlib.sha256(encoded(self.finish_config)).hexdigest(),
                "receipt_sha256": hashlib.sha256(self.finish_expected).hexdigest(),
                "final_stats": self.last_stats,
            }
        self.closed = True

    def terminate(self):
        # This is an enforced failure, never a graceful stop or a result. The
        # separate watchdog stays armed if the kernel kill itself is denied.
        self.terminating = True
        try:
            (self.kill_scope / "cgroup.kill").write_text("1")
        finally:
            raise EpisodeError("episode_parent_scope_terminated")
