"""Pure adapter for backend R11 FrozenSceneTask wire; never a trust selector.

The authenticated parent supplies the unmodified wire and separately selected
ReceiptTrust. There is no expected-from-ZIP/receipt/authority convenience path.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
import hashlib
import math

from .identity import SceneViewError, decode, encoded
from .receipt import ReceiptTrust


def _require(condition, code):
    from .episode import require

    require(condition, code)


def wire_epoch(value):
    """Backend assignment datetime is an ISO timestamp with an explicit zone."""
    _require(type(value) is str and len(value) <= 64, "episode_lease_wire")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        _require(parsed.tzinfo is not None, "episode_lease_wire")
        epoch = parsed.timestamp()
    except (ValueError, OverflowError) as exc:
        from .episode import EpisodeError

        raise EpisodeError("episode_lease_wire", status="invalid_package") from exc
    _require(math.isfinite(epoch) and epoch > 0, "episode_lease_wire")
    return epoch


@dataclass(frozen=True)
class ReceiptAuthorityBinding:
    wire_bytes: bytes
    trust: ReceiptTrust = field(repr=False)
    valid_until: float

    @property
    def document(self):
        return decode(self.wire_bytes)


def authority_from_wire(document, *, expected_trust, receipt, lease_expires_at, now):
    """Compare nested wire trust with independent expected_trust; do not create it.

    This matches backend@0db0514 ReceiptAuthority exactly, including retired=False.
    receipt bytes are canonical detached receipt bytes, not an authority source.
    """
    _require(type(expected_trust) is ReceiptTrust, "episode_independent_trust_required")
    _require(
        type(document) is dict and set(document) == {"trust", "receipt_digest", "valid_until", "retired"},
        "episode_receipt_authority_wire",
    )
    _require(
        type(document["trust"]) is dict and encoded(document["trust"]) == encoded(expected_trust.document),
        "episode_receipt_authority",
    )
    expiry = document["valid_until"]
    _require(
        type(expiry) in (int, float)
        and math.isfinite(expiry)
        and now < expiry <= lease_expires_at
        and document["retired"] is False,
        "episode_receipt_identity",
    )
    _require(document["receipt_digest"] == hashlib.sha256(encoded(receipt)).hexdigest(), "episode_receipt_identity")
    return ReceiptAuthorityBinding(encoded(document), expected_trust, float(expiry))


def detached_receipt_bytes(raw, *, receipt, limit):
    """Same authenticated download bytes, never reconstructed from E.

    Backend receipt_digest is canonical-JSON identity. Keep the separate raw
    byte SHA so whitespace/original bytes are not silently lost by a dict API.
    Authentication/source selection remains the credential-owning parent duty.
    """
    from .episode import require, EpisodeError

    require(type(raw) is bytes, "episode_authenticated_receipt_missing", status="resource_unavailable")
    require(0 < len(raw) <= limit, "episode_receipt_bytes_limit")
    try:
        _require(encoded(decode(raw)) == encoded(receipt), "episode_receipt_bytes_mismatch")
    except (SceneViewError, ValueError, TypeError) as exc:
        if isinstance(exc, EpisodeError):
            raise
        raise EpisodeError("episode_receipt_bytes_invalid", status="invalid_package") from exc
    return hashlib.sha256(raw).hexdigest()
