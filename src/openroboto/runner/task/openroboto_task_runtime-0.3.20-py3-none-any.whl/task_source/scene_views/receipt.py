"""P04-compatible detached receipt, with explicit operator-owned key trust.

Matching hashes/signatures attest content and key possession, not physical
truth. A local diagnostic key never becomes a server key by signing a receipt.
"""

from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass

from openroboto_protocol.scene_contract import parse_execution_contract
from openroboto_protocol.scene_schema import SceneAdmissionResult
from openroboto_protocol.tabletop_assets import canonical_digest

from agent_evidence.ed25519 import public_key_hex, sign, verify
from task_source.manifest import CHECK_NAMES

from .identity import SceneViewError, decode, encoded
from .reference import _validate_tool_actions, load_private_reference

RECEIPT_FIELDS = frozenset({
    "schema_version",
    "signature",
    "key_id",
    "algorithm",
    "submission_digest",
    "execution_package_digest",
    "private_package_digest",
    "execution_contract_digest",
    "identity",
    "node_id",
    "runtime",
    "policy_version",
    "raw_evidence_digest",
    "signature_root",
    "result",
})


@dataclass(frozen=True, init=False)
class ReceiptTrust:
    """From authenticated worker configuration, never a downloaded receipt.

    provenance is a report label only. Registration/revocation/lease checks and
    worker runtime authenticity remain server/caller obligations.
    """

    _bytes: bytes

    def __init__(self, *, node_id, key_id, public_key_hex, runtime, policy_version, provenance):
        if provenance not in {"local_diagnostic", "server_registered"}:
            raise SceneViewError("trust_provenance_invalid")
        if not all(isinstance(v, str) and v for v in (node_id, key_id, policy_version)):
            raise SceneViewError("trust_identity_invalid")
        try:
            if len(bytes.fromhex(public_key_hex)) != 32 or not isinstance(runtime, dict) or not runtime:
                raise ValueError()
        except (ValueError, TypeError):
            raise SceneViewError("trust_identity_invalid") from None
        object.__setattr__(
            self,
            "_bytes",
            encoded({
                "node_id": node_id,
                "key_id": key_id,
                "algorithm": "ed25519",
                "public_key_hex": public_key_hex,
                "runtime": runtime,
                "policy_version": policy_version,
                "provenance": provenance,
            }),
        )

    @property
    def document(self):
        return decode(self._bytes)


def reference_identity(view):
    """Private raw-verdict metadata; not a new public/P00 schema.

    Numeric proof instances map in frozen task order to each complete initial
    state. No deleting failures, swapping states or regenerating references.
    """
    e = view.execution
    return {
        **e.manifest,
        "execution_contract_digest": canonical_digest(e.contract),
        "reference_binding_digest": canonical_digest(view.binding),
        "reference_files": {
            p: hashlib.sha256(view.private_contents[p]).hexdigest() for p in view.binding["reference_files"]
        },
        "initial_states": [
            {"instance": i, "id": s["id"], "digest": canonical_digest(s)}
            for i, s in enumerate(e.task["scene"]["initial_states"])
        ],
    }


def _validate_proof(view, verdict, config_digest):
    """Validate existing tool-reference raw proof; physical replay is P02's job."""
    # A joint/root hash alone does not establish that the proof actually replayed
    # those private references. Require complete typed P before any admission.
    private_reference = load_private_reference(view)
    checks = verdict.get("checks", [])
    solvable = [r for r in checks if isinstance(r, dict) and r.get("name") == "runtime.solvable"]
    if len(solvable) != 1 or solvable[0].get("ok") is not True:
        raise SceneViewError("reference_proof_missing")
    detail = solvable[0]["detail"]
    if isinstance(detail, str):
        detail = decode(detail)
    total = view.execution.identity["instances"]
    if type(detail.get("total")) is not int or detail["total"] != total or detail.get("passed") != total:
        raise SceneViewError("reference_coverage_mismatch")
    proof = detail["tool_reference_proof"]
    e, contract = view.execution, view.execution.contract
    if (
        type(proof.get("version")) is not int
        or proof["version"] != 1
        or proof.get("verified") is not True
        or proof.get("task_id") != e.identity["task_definition_id"]
        or proof.get("package_digest") != e.manifest["execution_package_digest"]
        or proof.get("config_digest") != config_digest
        or not config_digest
        or parse_execution_contract(proof.get("execution_contract")) != contract
        or proof.get("contract_digest") != canonical_digest(contract)
        or proof.get("execution_runtime")
        != {"name": "AxisToolRuntime", "control_period_s": contract["timing"]["control_step_seconds"]}
        or verdict.get("scene_reference_binding") != reference_identity(view)
    ):
        raise SceneViewError("reference_identity_mismatch")
    required, rows = proof.get("required_instances"), proof.get("instances")
    if (
        not isinstance(required, list)
        or any(type(i) is not int for i in required)
        or required != list(range(total))
        or not isinstance(rows, list)
        or len(rows) != total
        or any(type(r.get("instance")) is not int for r in rows)
        or [r["instance"] for r in rows] != list(range(total))
    ):
        raise SceneViewError("reference_coverage_mismatch")
    budget = contract["budget"]
    for row in rows:
        actions, steps, wall = row.get("tool_actions"), row.get("steps"), row.get("wall_s")
        if (
            row.get("success") is not True
            or row.get("error")
            or type(steps) is not int
            or not 0 < steps <= budget["max_steps"]
            or type(wall) not in (int, float)
            or not math.isfinite(wall)
            or not 0 <= wall <= budget["wall_seconds"]
            or not isinstance(actions, list)
            or not 0 < len(actions) <= budget["max_api_calls"]
            or not isinstance(row.get("final_state"), dict)
            or row.get("tool_actions_digest") != canonical_digest(actions)
            or row.get("final_state_digest") != canonical_digest(row["final_state"])
        ):
            raise SceneViewError("reference_evidence_invalid")
        _validate_tool_actions(actions, max_api_calls=budget["max_api_calls"])
        recorded = private_reference["instances"][str(row["instance"])]
        if (
            encoded(actions) != encoded(recorded["tool_actions"])
            or row["tool_actions_digest"] != recorded["tool_actions_digest"]
            or encoded(row["final_state"]) != encoded(recorded["final_state"])
            or row["final_state_digest"] != recorded["final_state_digest"]
            or steps != len(recorded["actions"])
        ):
            raise SceneViewError("reference_proof_mismatch")
    encoded(proof)


def _trust_fields(trust):
    if type(trust) is not ReceiptTrust:
        raise SceneViewError("receipt_trust_required")
    d = trust.document
    key = {k: d[k] for k in ("node_id", "key_id", "algorithm", "public_key_hex")}
    return {
        "node_id": d["node_id"],
        "key_id": d["key_id"],
        "algorithm": "ed25519",
        "runtime": d["runtime"],
        "policy_version": d["policy_version"],
        "signature_root": canonical_digest(key),
    }


def _expected(view, trust):
    return {
        "schema_version": 1,
        **{k: v for k, v in view.manifest.items() if k != "schema_version"},
        "execution_contract_digest": canonical_digest(view.contract),
        "identity": view.identity,
        **_trust_fields(trust),
    }


def sign_scene_receipt(view, *, checks, verdict, result, trust, seed, config_digest=None):
    """Sign P04's existing shape, only after binding full raw checks/verdict.

    Returned receipt stays OUTSIDE E/P. The caller puts it in the outer signed
    admission verdict. Neither result nor a local key grants reward eligibility.
    """
    try:
        if public_key_hex(seed) != trust.document["public_key_hex"]:
            raise SceneViewError("receipt_signer_mismatch")
        if "scene_receipt" in verdict:
            raise SceneViewError("receipt_self_reference")
        parsed = SceneAdmissionResult.model_validate(result)
        if sorted(c.get("name", "") for c in checks) != sorted(CHECK_NAMES):
            raise SceneViewError("admission_checks_incomplete")
        if parsed.admission == "admitted":
            if verdict.get("passed") is not True or any(c.get("ok") is not True for c in checks):
                raise SceneViewError("admission_checks_failed")
            _validate_proof(view, verdict, config_digest)
        root = canonical_digest({"checks": checks, "verdict": verdict})
        if parsed.evidence_digest != root:
            raise SceneViewError("raw_evidence_mismatch")
        raw = {
            **_expected(view.execution, trust),
            "raw_evidence_digest": root,
            "result": parsed.model_dump(mode="json"),
        }
        raw["signature"] = sign(seed, encoded(raw)).hex()
        verify_scene_receipt(view.execution, raw, trust=trust, checks=checks, verdict=verdict)
        return raw
    except SceneViewError:
        raise
    except Exception as exc:
        raise SceneViewError("receipt_evidence_invalid") from exc


def verify_scene_receipt(view, receipt, *, trust, checks=None, verdict=None):
    """Detached verification can authenticate P's digest without receiving P.

    Pass raw checks AND raw verdict to independently verify the evidence root;
    otherwise only the signature/identities are verified, not raw availability.
    """
    try:
        raw = decode(encoded(receipt))
        if set(raw) != RECEIPT_FIELDS or any(raw.get(k) != v for k, v in _expected(view, trust).items()):
            raise SceneViewError("receipt_identity_mismatch")
        signature = bytes.fromhex(raw.pop("signature"))
        if not verify(bytes.fromhex(trust.document["public_key_hex"]), encoded(raw), signature):
            raise SceneViewError("receipt_signature_invalid")
        parsed = SceneAdmissionResult.model_validate(raw["result"])
        if (
            parsed.submission_digest != view.manifest["submission_digest"]
            or parsed.reward_status != "not_evaluated"
            or parsed.evidence_digest != raw["raw_evidence_digest"]
            or not isinstance(raw["raw_evidence_digest"], str)
            or len(raw["raw_evidence_digest"]) != 64
            or set(raw["raw_evidence_digest"]) <= {"0"}
        ):
            raise SceneViewError("receipt_result_mismatch")
        if (checks is None) != (verdict is None):
            raise SceneViewError("raw_evidence_incomplete")
        if checks is not None and raw["raw_evidence_digest"] != canonical_digest({
            "checks": checks,
            "verdict": verdict,
        }):
            raise SceneViewError("raw_evidence_mismatch")
        return {
            "signature_verified": True,
            "raw_evidence_verified": checks is not None,
            "provenance": trust.document["provenance"],
        }
    except SceneViewError:
        raise
    except Exception as exc:
        raise SceneViewError("receipt_invalid") from exc
