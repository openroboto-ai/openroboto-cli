"""Kernel-enforced model/probe process with no raw package mounts.

macOS: Seatbelt deny-default file/network/process policy. Linux: bubblewrap
empty root + pid/user/network namespaces. No Python-audit-hook fallback. This
is a local runner, not a server capability or a generic simulator launcher.
"""

from __future__ import annotations

import json
import os
import pathlib
import selectors
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass

from .identity import SceneViewError, encoded


@dataclass(frozen=True)
class ProcessResult:
    returncode: int
    stdout: bytes
    stderr: bytes
    timed_out: bool
    mechanism: str
    policy: str
    environment: dict
    cwd: str
    host_uid: int
    ipc: tuple = ()
    # stdout/stderr/policy are operator diagnostics, never model tool replies.


def _overlaps(a, b):
    return a.is_relative_to(b) or b.is_relative_to(a)


def _runtime_paths(forbidden_roots):
    executable = pathlib.Path(sys.executable).resolve()
    prefix = pathlib.Path(sys.base_prefix).resolve()
    roots = [pathlib.Path(p).resolve() for p in forbidden_roots]
    allowed = [prefix]
    if sys.platform == "darwin":
        allowed += [
            pathlib.Path(p) for p in ("/System/Library", "/System/Volumes/Preboot", "/System/Cryptexes", "/usr/lib")
        ]
    elif sys.platform.startswith("linux"):
        allowed += [pathlib.Path(p) for p in ("/usr", "/lib", "/lib64") if pathlib.Path(p).exists()]
    if prefix == pathlib.Path("/") or any(_overlaps(a, r) for a in allowed for r in roots):
        raise SceneViewError("sandbox_runtime_overlaps_material")
    return str(executable), sorted(set(map(str, allowed)))


def _exchange(process, initial, *, timeout_s, max_bytes, handler, max_requests):
    """Bounded, nonblocking stdio; no dispatch/response may start after expiry.

    Synchronous handlers must enforce their own (P02 runtime) deadline inside
    physical/tool work. This loop stops subsequent dispatches, including ones
    batched in the same stdout chunk; it cannot interrupt an active callback.
    """
    stdout, stderr, records = bytearray(), bytearray(), []
    pending = bytearray(initial + (b"\n" if handler else b""))
    line = bytearray()
    timed_out = False
    fatal_channel = False
    deadline = time.monotonic() + timeout_s

    def expired_result():
        return bytes(stdout), bytes(stderr), tuple(records), True

    with selectors.DefaultSelector() as selector:
        for stream in (process.stdin, process.stdout, process.stderr):
            os.set_blocking(stream.fileno(), False)
        selector.register(process.stdin, selectors.EVENT_WRITE, "stdin")
        selector.register(process.stdout, selectors.EVENT_READ, "stdout")
        selector.register(process.stderr, selectors.EVENT_READ, "stderr")
        while selector.get_map():
            if time.monotonic() >= deadline:
                timed_out = True
                break
            if process.poll() is not None and process.stdin in [k.fileobj for k in selector.get_map().values()]:
                selector.unregister(process.stdin)
                process.stdin.close()
            for key, _ in selector.select(max(0, min(0.05, deadline - time.monotonic()))):
                # Readiness may arrive at/after expiry. In particular, queued
                # replies cannot be flushed just because stdin is writable.
                if time.monotonic() >= deadline:
                    return expired_result()
                if key.data == "stdin":
                    try:
                        count = os.write(process.stdin.fileno(), pending[:65536])
                        del pending[:count]
                    except BrokenPipeError:
                        pending.clear()
                    if not pending:
                        selector.unregister(process.stdin)
                        if handler is None:
                            process.stdin.close()
                    continue
                chunk = os.read(key.fd, min(65536, max_bytes + 1))
                if not chunk:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                target = stdout if key.data == "stdout" else stderr
                target.extend(chunk)
                if len(stdout) + len(stderr) > max_bytes:
                    raise SceneViewError("sandbox_output_limit")
                if handler and key.data == "stdout":
                    line.extend(chunk)
                    while b"\n" in line:
                        if time.monotonic() >= deadline:
                            return expired_result()
                        request_line, _, remaining = line.partition(b"\n")
                        line[:] = remaining
                        if len(records) >= max_requests:
                            raise SceneViewError("sandbox_request_limit")
                        try:
                            from .identity import decode

                            request = decode(request_line)
                            # Parsing can consume the last remaining time; a
                            # batch-level/outer-loop check is insufficient.
                            if time.monotonic() >= deadline:
                                return expired_result()
                            reply = (
                                {"ok": False, "error": "runtime_error", "fatal": True}
                                if fatal_channel
                                else handler(request)
                            )
                            reply_bytes = encoded(reply)
                        except Exception:
                            # Never send traceback/submitted text into the child.
                            request = {"invalid": True}
                            reply = {"ok": False, "error": "runtime_error", "fatal": True}
                            reply_bytes = encoded(reply)
                        fatal_channel = fatal_channel or reply.get("fatal") is True
                        if len(reply_bytes) > max_bytes:
                            raise SceneViewError("sandbox_response_limit")
                        records.append({"request": request, "reply": reply})
                        # An in-flight handler can finish late. Retain its
                        # completion for audit, but neither send that reply
                        # nor execute the rest of the chunk after the deadline.
                        if time.monotonic() >= deadline:
                            return expired_result()
                        pending.extend(reply_bytes + b"\n")
                        if len(pending) > max_bytes:
                            raise SceneViewError("sandbox_response_limit")
                        if process.stdin.closed:
                            raise SceneViewError("sandbox_channel_closed")
                        if process.stdin not in [k.fileobj for k in selector.get_map().values()]:
                            selector.register(process.stdin, selectors.EVENT_WRITE, "stdin")
    return bytes(stdout), bytes(stderr), tuple(records), timed_out


def run_isolated_python(
    code,
    *,
    input_messages,
    forbidden_roots,
    timeout_s=10,
    cpu_seconds=5,
    max_output_bytes=1_000_000,
    request_handler=None,
    max_requests=64,
):
    """Run an offline model-side program. Never pass credentials/package bytes.

    `forbidden_roots` are operator-selected E/P/evidence/repository roots and
    cannot overlap the interpreter/system read mounts. Environment is built
    from scratch, close_fds=True, stdin/stdout/stderr only. The caller may use
    the same JSON-line channel for a model adapter; provider gateway and
    simulator stay outside. No arbitrary mounts/env additions are accepted.
    With request_handler, stdin starts with one JSON line; each stdout JSON
    request line receives one JSON reply. Pass ModelBoundary.dispatch bound to
    the trusted runtime. Handler calls must use P02's existing absolute runtime
    deadline/cancellation checks inside each physical step. Set timeout_s no
    larger than its remaining wall allowance. The IPC guard refuses new calls
    after expiry; it does not cancel an already-running synchronous handler.
    """
    if not forbidden_roots:
        raise SceneViewError("sandbox_material_roots_required")
    if type(max_requests) is not int or not 0 < max_requests <= 1024:
        raise SceneViewError("sandbox_limits_invalid")
    if (
        not 0 < timeout_s <= 60
        or type(timeout_s) not in (int, float)
        or type(cpu_seconds) is not int
        or not 0 < cpu_seconds <= 30
        or not 0 < max_output_bytes <= 8_000_000
        or type(max_output_bytes) is not int
    ):
        raise SceneViewError("sandbox_limits_invalid")
    initial = encoded(input_messages)
    if len(initial) > max_output_bytes:
        raise SceneViewError("sandbox_input_limit")
    executable, allowed = _runtime_paths(forbidden_roots)
    if sys.platform == "darwin":
        launcher = "/usr/bin/sandbox-exec"
        if not pathlib.Path(launcher).is_file():
            raise SceneViewError("sandbox_unavailable")
        mechanism = "macos-seatbelt-deny-default"
    elif sys.platform.startswith("linux") and shutil.which("bwrap"):
        launcher = shutil.which("bwrap")
        mechanism = "linux-bubblewrap-namespaces"
    else:
        raise SceneViewError("sandbox_unavailable")
    with tempfile.TemporaryDirectory(prefix="openroboto-model-view-") as directory:
        workspace = str(pathlib.Path(directory).resolve())
        env = {"HOME": workspace, "TMPDIR": workspace, "LANG": "C.UTF-8", "PATH": "/nonexistent"}
        if mechanism.startswith("macos"):
            rules = " ".join("(subpath " + json.dumps(p) + ")" for p in allowed)
            # dyld/Framework Python open their canonical root/parent directories.
            # Literal ancestors grant no descendant contents (unlike subpath).
            ancestors = {str(p) for a in allowed for p in pathlib.Path(a).parents}
            rules += " " + " ".join("(literal " + json.dumps(p) + ")" for p in sorted(ancestors))
            policy = (
                "(version 1)(deny default)"
                "(allow process-exec (subpath " + json.dumps(sys.base_prefix) + "))"
                "(allow sysctl-read)"
                "(allow file-read* " + rules + " (subpath " + json.dumps(workspace) + ")"
                ' (literal "/dev/null") (literal "/dev/random") (literal "/dev/urandom"))'
                "(allow file-write* (subpath " + json.dumps(workspace) + ') (literal "/dev/null"))'
                '(deny file-read* (regex #".*[.]secrets.*"))'
                + "".join(
                    "(deny file-read* (subpath " + json.dumps(str(pathlib.Path(p).resolve())) + "))"
                    for p in forbidden_roots
                )
            )
            command = [launcher, "-p", policy]
            child_cwd = workspace
        else:
            command = [
                launcher,
                "--unshare-all",
                "--die-with-parent",
                "--new-session",
                "--cap-drop",
                "ALL",
                "--clearenv",
            ]
            for p in allowed:
                command += ["--ro-bind", p, p]
            command += [
                "--proc",
                "/proc",
                "--dev",
                "/dev",
                "--tmpfs",
                "/tmp",
                "--bind",
                workspace,
                "/work",
                "--chdir",
                "/work",
            ]
            env.update(HOME="/work", TMPDIR="/work")
            for k, v in env.items():
                command += ["--setenv", k, v]
            child_cwd = "/work"
            policy = json.dumps(command)
        # Hard limits are installed BEFORE the program; it cannot raise them.
        wrapped = (
            "import resource\n"
            f"resource.setrlimit(resource.RLIMIT_CPU, ({cpu_seconds}, {cpu_seconds}))\n"
            f"resource.setrlimit(resource.RLIMIT_FSIZE, ({max_output_bytes}, {max_output_bytes}))\n"
            "resource.setrlimit(resource.RLIMIT_NOFILE, (32, 32))\n" + code
        )
        command += [executable, "-I", "-S", "-B", "-c", wrapped]
        process = subprocess.Popen(
            command,
            cwd=workspace,
            env=env,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            close_fds=True,
            start_new_session=True,
        )
        try:
            stdout, stderr, ipc, timed_out = _exchange(
                process,
                initial,
                timeout_s=timeout_s,
                max_bytes=max_output_bytes,
                handler=request_handler,
                max_requests=max_requests,
            )
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            for stream in (process.stdin, process.stdout, process.stderr):
                if not stream.closed:
                    stream.close()
        return ProcessResult(
            process.returncode, stdout, stderr, timed_out, mechanism, policy, env, child_cwd, os.getuid(), ipc
        )
