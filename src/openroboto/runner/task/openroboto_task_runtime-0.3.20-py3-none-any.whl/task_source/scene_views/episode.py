"""Owned formal scene episode: authenticated state lane, never an offline probe.

The public entry has no runtime/backend injection. Linux enforcement lives in
episode_linux; software tests exercise the state machine with private fakes.
"""

from __future__ import annotations

import hashlib
import hmac
import math
import secrets
import threading
import time
from dataclasses import dataclass, field
from functools import wraps
from types import MappingProxyType

from openroboto_protocol.tabletop_assets import canonical_digest

from .identity import ExecutionView, SceneViewError, _execution, decode, encoded
from .receipt import ReceiptTrust, verify_scene_receipt
from .episode_watchdog import MEMORY_EVIDENCE_MODES, MEMORY_PEAK_REQUIRED


class EpisodeError(SceneViewError):
    fatal = True

    def __init__(self, code, *, status="resource_unavailable"):
        super().__init__(code, status=status)

    def to_dict(self):
        return {
            **super().to_dict(),
            **({"cleanup_error": self.cleanup_error} if hasattr(self, "cleanup_error") else {}),
            **({"cleanup_errors": self.cleanup_errors} if hasattr(self, "cleanup_errors") else {}),
        }


def require(condition, code, *, status="invalid_package"):
    if not condition:
        raise EpisodeError(code, status=status)


def positive(value, name, *, integer=False):
    require(type(value) is int if integer else type(value) in (int, float), "episode_policy_" + name)
    require(math.isfinite(value) and value > 0, "episode_policy_" + name)
    return value


def exact(document, fields, name):
    require(type(document) is dict and set(document) == set(fields), "episode_" + name)
    return document


def runtime_image_identity(runtime):
    """Pure build helper; write this outside E/P into the sealed image BEFORE
    computing rootfs_digest. runtime is the wheel/artifact ref, not rootfs hash.
    No self-reference or claim that this image was installed/validated.
    """
    from agent_harness.manifest import agent_binding, harness_code_digest

    return {
        "schema_version": 1,
        "runtime": dict(runtime),
        "agent": agent_binding(),
        "harness_code_digest": harness_code_digest(),
    }


@dataclass(frozen=True)
class EpisodePolicy:
    """Operator-owned immutable snapshot; paths never come from E/model requests.

    rootfs is a sealed, symlink-free minimal installed runtime, not a checkout
    or host prefix. Its complete measured tree digest is required by Linux.
    config_digest pins the operator config containing this policy, not E's data.
    """

    config_digest: str
    runtime: dict
    policy_version: str
    rootfs: str
    rootfs_digest: str
    python: str
    bwrap: str
    bwrap_sha256: str
    setpriv: str
    setpriv_sha256: str
    cgroup_parent: str
    accounting_scope: str
    parent_scope: str
    watchdog_parent: str
    gateway_factory_digest: str
    uid: int
    gid: int
    cpu_quota_us: int
    cpu_budget_s: float
    memory_bytes: int
    pids: int
    output_bytes: int
    frame_bytes: int
    launch_seconds: float
    cleanup_seconds: float
    max_rootfs_bytes: int
    max_rootfs_files: int
    protected_roots: tuple[str, ...]
    memory_evidence_mode: str = MEMORY_PEAK_REQUIRED

    def __post_init__(self):
        import re

        for value in (
            self.config_digest,
            self.rootfs_digest,
            self.bwrap_sha256,
            self.setpriv_sha256,
            self.gateway_factory_digest,
        ):
            require(type(value) is str and re.fullmatch("[0-9a-f]{64}", value), "episode_policy_digest")
        exact(self.runtime, ("id", "version", "digest"), "policy_runtime")
        for key in ("id", "version", "digest"):
            require(type(self.runtime[key]) is str and self.runtime[key], "episode_policy_runtime")
        require(re.fullmatch("[0-9a-f]{64}", self.runtime["digest"]), "episode_policy_runtime")
        require(type(self.policy_version) is str and self.policy_version, "episode_policy_version")
        require(
            type(self.memory_evidence_mode) is str and self.memory_evidence_mode in MEMORY_EVIDENCE_MODES,
            "episode_memory_evidence_mode",
        )
        for name in (
            "uid",
            "gid",
            "cpu_quota_us",
            "memory_bytes",
            "pids",
            "output_bytes",
            "frame_bytes",
            "max_rootfs_bytes",
            "max_rootfs_files",
        ):
            positive(getattr(self, name), name, integer=True)
        for name in ("cpu_budget_s", "launch_seconds", "cleanup_seconds"):
            positive(getattr(self, name), name)
        require(self.cpu_quota_us <= 100_000 and self.frame_bytes <= self.output_bytes, "episode_policy_limits")
        # Transcript buffers coexist with E, Python/provider/native heaps. The
        # aggregate cgroup is the hard bound; this is an additional buffer cap.
        require(self.output_bytes * 4 <= self.memory_bytes, "episode_policy_output_memory")
        require(self.launch_seconds <= 10 and self.cleanup_seconds <= 10, "episode_policy_limits")
        require(type(self.protected_roots) is tuple and self.protected_roots, "episode_policy_protected_roots")
        for value in (
            self.rootfs,
            self.python,
            self.bwrap,
            self.setpriv,
            self.cgroup_parent,
            self.accounting_scope,
            self.parent_scope,
            self.watchdog_parent,
            *self.protected_roots,
        ):
            require(type(value) is str and value.startswith("/") and "\x00" not in value, "episode_policy_path")
        object.__setattr__(self, "runtime", MappingProxyType(dict(self.runtime)))

    @classmethod
    def from_registered_config(cls, document):
        try:
            values = dict(document)
            values["protected_roots"] = tuple(values["protected_roots"])
            return cls(**values)
        except (EpisodeError, TypeError, ValueError, KeyError) as exc:
            raise EpisodeError("episode_policy_unavailable") from exc

    @property
    def digest(self):
        values = {**vars(self), "runtime": dict(self.runtime)}
        if self.memory_evidence_mode == MEMORY_PEAK_REQUIRED:
            values.pop("memory_evidence_mode")
        return canonical_digest(values)


@dataclass(frozen=True)
class EpisodeBinding:
    view: ExecutionView = field(repr=False)
    document_bytes: bytes
    receipt_bytes: bytes = field(repr=False)
    trust: ReceiptTrust = field(repr=False)

    @property
    def document(self):
        return decode(self.document_bytes)

    @property
    def digest(self):
        return hashlib.sha256(self.document_bytes).hexdigest()

    @classmethod
    def create(cls, view, *, frozen_task, receipt, trust, episode, policy, clock=None):
        """frozen_task is the full authenticated backend FrozenSceneTask.

        Caller must obtain it from P08's authenticated claim/context, not ZIP.
        We compare both its outer task and inner scene_registration identities.
        No authenticated=True flag, task-ref lookup or receipt-derived key trust.
        """
        require(type(view) is ExecutionView and type(trust) is ReceiptTrust, "episode_view_required")
        require(type(policy) is EpisodePolicy, "episode_policy_required")
        require(all(type(k) is str and type(v) is bytes for k, v in view.contents.items()), "episode_view_inconsistent")
        snapshot = _execution(
            MappingProxyType(dict(view.contents)), view.manifest, view.manifest["submission_digest"], clock=clock
        )
        require(snapshot == view, "episode_view_inconsistent")
        require(trust.document["provenance"] == "server_registered", "episode_receipt_source")
        verify_scene_receipt(snapshot, receipt, trust=trust)
        require(receipt["result"]["admission"] == "admitted", "episode_not_admitted")
        exact(
            episode,
            ("run_id", "attempt_id", "member_id", "worker_id", "node_id", "trial", "instance"),
            "episode_fields",
        )
        for key in ("run_id", "attempt_id", "member_id", "worker_id", "node_id"):
            require(type(episode[key]) is str and 0 < len(episode[key]) <= 200, "episode_identity")
        for key in ("trial", "instance"):
            require(type(episode[key]) is int and episode[key] >= 0, "episode_index")
        try:
            from .episode_authority import authority_from_wire, wire_epoch

            exact(
                frozen_task,
                (
                    "task_id",
                    "competition_id",
                    "source",
                    "package_layout",
                    "package_digest",
                    "submission_digest",
                    "execution_profile",
                    "package_url",
                    "scene_registration",
                    "receipt_authority",
                    "assignment",
                ),
                "frozen_task_wire",
            )
            row = frozen_task["scene_registration"]
            assignment = frozen_task["assignment"]
            exact(
                row,
                (
                    "task_id",
                    "package_repo",
                    "package_commit",
                    "attempt",
                    "execution_package_digest",
                    "private_package_digest",
                    "submission_digest",
                    "execution_contract_digest",
                    "execution_contract",
                    "identity",
                ),
                "scene_registration_wire",
            )
            exact(
                assignment, ("run_id", "worker_id", "node_id", "config_digest", "lease_expires_at"), "assignment_wire"
            )
            manifest, contract = snapshot.manifest, snapshot.contract
            require(frozen_task["package_layout"] == "scene" and frozen_task["source"] == "axis", "episode_task_lane")
            require(frozen_task["task_id"] == row["task_id"], "episode_task_identity")
            for outer, inner in (
                ("package_digest", "execution_package_digest"),
                ("submission_digest", "submission_digest"),
            ):
                require(frozen_task[outer] == row[inner] == manifest[inner], "episode_task_identity")
            require(row["private_package_digest"] == manifest["private_package_digest"], "episode_private_identity")
            require(encoded(row["identity"]) == snapshot.identity_bytes, "episode_scene_identity")
            require(frozen_task["execution_profile"] == row["identity"]["execution_profile"], "episode_profile")
            require(
                encoded(row["execution_contract"]) == snapshot.contract_bytes
                and row["execution_contract_digest"] == canonical_digest(contract),
                "episode_contract_identity",
            )
            for key in ("package_repo", "package_commit"):
                require(type(row[key]) is str and row[key], "episode_package_source")
            import re

            require(
                re.fullmatch("[0-9a-f]{40}", row["package_commit"])
                and type(row["attempt"]) is int
                and row["attempt"] > 0,
                "episode_package_source",
            )
            require(
                type(frozen_task["competition_id"]) is int and frozen_task["competition_id"] > 0, "episode_competition"
            )
            require(type(frozen_task["package_url"]) is str and frozen_task["package_url"], "episode_package_source")
            require(
                all(assignment[key] == episode[key] for key in ("run_id", "worker_id", "node_id"))
                and assignment["config_digest"] == policy.config_digest,
                "episode_assignment",
            )
            expiry = wire_epoch(assignment["lease_expires_at"])
            receipt_hash = hashlib.sha256(encoded(receipt)).hexdigest()
            authority = authority_from_wire(
                frozen_task["receipt_authority"],
                expected_trust=trust,
                receipt=receipt,
                lease_expires_at=expiry,
                now=time.time(),
            )
            require(
                dict(policy.runtime) == trust.document["runtime"]
                and policy.policy_version == trust.document["policy_version"],
                "episode_registered_runtime",
            )
            require(
                contract["harness"] == {"name": "headless"}
                and contract["permissions"]["mode"] == "privileged"
                and contract["observation_contract"] == "state",
                "episode_lane_unsupported",
                status="resource_unavailable",
            )
            states = snapshot.task["scene"]["initial_states"]
            index = episode["instance"]
            require(index < len(states), "episode_initial_state")
            require(index == episode["trial"] % len(states), "episode_trial_initial_state")
            document = {
                **episode,
                **manifest,
                "task_id": row["task_id"],
                "competition_id": frozen_task["competition_id"],
                "package_repo": row["package_repo"],
                "package_commit": row["package_commit"],
                "identity": snapshot.identity,
                "execution_contract": contract,
                "execution_contract_digest": canonical_digest(contract),
                "receipt_digest": receipt_hash,
                "config_digest": policy.config_digest,
                "runtime": dict(policy.runtime),
                "policy_version": policy.policy_version,
                "isolation_policy_digest": policy.digest,
                "initial_state_id": states[index]["id"],
                "initial_state_digest": canonical_digest(states[index]),
                "lease_expires_at": min(expiry, authority.valid_until),
                "frozen_task_digest": canonical_digest(frozen_task),
                "receipt_authority_digest": canonical_digest(authority.document),
            }
        except (KeyError, TypeError, IndexError) as exc:
            raise EpisodeError("episode_authenticated_metadata_missing", status="invalid_package") from exc
        return cls(snapshot, encoded(document), encoded(receipt), trust)


class EpisodeClock:
    def __init__(
        self,
        wall,
        expiry,
        *,
        cancellation=None,
        started=None,
        parent_cpu_started=None,
        monotonic=time.monotonic,
        epoch=time.time,
    ):
        self.now = monotonic
        now = monotonic()
        self.deadline = min((now if started is None else started) + wall, now + expiry - epoch())
        self.cancelled = threading.Event()
        self.lease_cancelled = cancellation
        self.parent_cpu_started = time.process_time() if parent_cpu_started is None else parent_cpu_started

    def remaining(self):
        if self.lease_cancelled is not None and self.lease_cancelled.is_set():
            raise EpisodeError("episode_lease_cancelled", status="timeout")
        if self.cancelled.is_set():
            raise EpisodeError("episode_cancelled", status="timeout")
        value = self.deadline - self.now()
        if value <= 0:
            raise EpisodeError("episode_deadline", status="timeout")
        return value


def authenticated_frame(key, direction, sequence, payload):
    body = {"direction": direction, "sequence": sequence, "payload": payload}
    return {**body, "mac": hmac.new(key, encoded(body), hashlib.sha256).hexdigest()}


def verify_frame(key, direction, sequence, frame):
    exact(frame, ("direction", "sequence", "payload", "mac"), "ipc_envelope")
    expected = authenticated_frame(key, direction, sequence, frame["payload"])
    require(
        type(frame["sequence"]) is int
        and frame["direction"] == direction
        and frame["sequence"] == sequence
        and type(frame["mac"]) is str
        and hmac.compare_digest(expected["mac"], frame["mac"]),
        "episode_ipc_auth",
    )
    return frame["payload"]


def _terminal_operation(operation):
    @wraps(operation)
    def run(self, *args, **kwargs):
        try:
            if self.terminal is not None:
                raise self.terminal
            return operation(self, *args, **kwargs)
        except SceneViewError as exc:
            error = exc if type(exc) is EpisodeError else EpisodeError(exc.code, status=exc.status)
            self.remember_failure(error)
            if error.code == "episode_cancelled":
                raise self.terminal from exc
            raise error

    return run


class _Episode:
    """Private owned lifecycle. Fake backends are used only by software tests."""

    def __init__(self, binding, policy, clock, backend):
        self.binding, self.policy, self.clock, self.backend = binding, policy, clock, backend
        self.nonce, self.key = secrets.token_hex(32), secrets.token_bytes(32)
        self.sequence, self.tools, self.steps = 0, 0, 0
        self.ready, self.closed, self.reset_done = False, False, False
        self._lock = threading.Lock()
        self.startup = None
        self.terminal = None
        self.abort_reason = None
        self._cleanup_failures = []
        self._cleanup_primary = None

    def remember_failure(self, error):
        if self.terminal is None:
            # Cancellation is a consequence of the native supervisor's first
            # terminal event; retain that event rather than its generic flag.
            reason = getattr(self.backend, "reason", None)
            if error.code == "episode_cancelled" and reason:
                status = (
                    "agent_budget_exhausted"
                    if reason == "episode_tool_budget"
                    else "timeout"
                    if "deadline" in reason or "cancelled" in reason
                    else "resource_unavailable"
                )
                error = EpisodeError(reason, status=status)
            self.terminal = error

    def cleanup_error(self, error):
        if self.terminal is None:
            self.remember_failure(error)
            self._cleanup_primary = error
            return error
        if error is self._cleanup_primary and not self._cleanup_failures:
            return error
        # Keep detached snapshots in occurrence order. Repropagating our own
        # primary wrapper (or the same exception) is not another cleanup event;
        # two distinct exceptions with the same code are still distinct causes.
        if error is not self._cleanup_primary and getattr(error, "_cleanup_owner", None) is not self and not any(
            original is error for original, _ in self._cleanup_failures
        ):
            self._cleanup_failures.append((error, encoded(error.to_dict())))
        primary = EpisodeError(self.terminal.code, status=self.terminal.status)
        primary.cleanup_error = decode(self._cleanup_failures[-1][1])
        if len(self._cleanup_failures) > 1:
            primary.cleanup_errors = [decode(raw) for _, raw in self._cleanup_failures]
        primary._cleanup_owner = self
        return primary

    @_terminal_operation
    def start(self):
        self.clock.remaining()
        init = {
            "binding": self.binding.document,
            "nonce": self.nonce,
            "deadline": self.clock.deadline,
            "frame_bytes": self.policy.frame_bytes,
            "key": self.key.hex(),
            "manifest": self.binding.view.manifest,
            "receipt": decode(self.binding.receipt_bytes),
            "trust": self.binding.trust.document,
        }
        self.backend.start(init)
        startup = self._rpc({"op": "startup"})
        require(startup.get("ok") is True, "episode_worker_unavailable", status="resource_unavailable")
        expected = {
            "binding_digest": self.binding.digest,
            "nonce": self.nonce,
            "deadline": self.clock.deadline,
            "agent": self.binding.view.contract["agent"],
            "runtime": dict(self.policy.runtime),
            "initial_state_id": self.binding.document["initial_state_id"],
            "initial_state_digest": self.binding.document["initial_state_digest"],
        }
        require(startup.get("identity") == expected, "episode_startup_identity")
        actual = startup.get("execution_runtime")
        require(
            type(actual) is dict
            and actual.get("name") == "AxisToolRuntime"
            and actual.get("control_period_s") == self.binding.view.contract["timing"]["control_step_seconds"],
            "episode_native_contract",
        )
        self.startup = startup
        require(
            type(self.backend.startup_evidence) is dict and self.backend.startup_evidence,
            "episode_os_startup_evidence_missing",
            status="resource_unavailable",
        )
        self.startup["isolation"] = self.backend.startup_evidence
        self.ready = True

    @_terminal_operation
    def _rpc(self, payload):
        self.clock.remaining()
        if self.closed:
            raise EpisodeError("episode_closed")
        sequence = self.sequence
        self.sequence += 1
        frame = self.backend.exchange(authenticated_frame(self.key, "parent", sequence, payload))
        self.clock.remaining()
        result = verify_frame(self.key, "worker", sequence, frame)
        private = result.pop("private_audit", [])
        self.backend.record_private(private)
        return result

    @_terminal_operation
    def call(self, request):
        with self._lock:
            self.clock.remaining()
            require(self.ready and not self.closed, "episode_not_ready")
            if self.tools >= self.binding.view.contract["budget"]["max_api_calls"]:
                self.abort_reason = "episode_tool_budget"
                self.clock.cancelled.set()
                self.backend.abort("episode_tool_budget")
                raise EpisodeError("episode_tool_budget", status="agent_budget_exhausted")
            # Charge every attempt before validation/dispatch, including observe and a batch's invalid call.
            self.tools += 1
            from task_source.tool_reference import _tool_action

            try:
                name, args = _tool_action(request)
                require(name != "step" or len(args["action"]) == 9, "episode_invalid_tool")
            except Exception as exc:
                raise EpisodeError("episode_invalid_tool", status="invalid_tool_request") from exc
            reply = self._rpc({"op": "tool", "request": {"name": name, "args": args}})
            if reply.get("ok") is not True:
                self.abort_reason = "episode_runtime_error"
                self.backend.abort("episode_runtime_error")
                raise EpisodeError("runtime_error")
            observation = reply["observation"]
            from .boundary import ModelBoundary

            projected = ModelBoundary(self.binding.view).observation(observation)
            step = projected["step"]
            require(self.steps <= step <= self.binding.view.contract["budget"]["max_steps"], "episode_step_counter")
            self.steps = step
            self.clock.remaining()
            return projected

    @_terminal_operation
    def reset(self):
        with self._lock:
            self.clock.remaining()
            require(self.ready and not self.reset_done and not self.closed, "episode_reset_forbidden")
            self.reset_done = True
            reply = self._rpc({"op": "reset"})
            require(reply.get("ok") is True, "episode_reset_failed", status="resource_unavailable")
            from .boundary import ModelBoundary

            observation = ModelBoundary(self.binding.view).observation(reply["observation"])
            require(observation["step"] == 0, "episode_reset_step")
            return observation

    def close(self):
        if not self.closed:
            self.closed = True
            try:
                self.backend.close()
            except EpisodeError as exc:
                # Linux close may report the already recorded abort AFTER a
                # complete successful kill/reap/audit. That is not a second
                # cleanup failure. A different reason or incomplete tree still
                # rejects returning/signing, retaining primary plus secondary.
                diagnostics = self.backend.diagnostics
                if (
                    self.terminal is not None
                    and exc.code == self.abort_reason
                    and getattr(self.backend, "reaped", False)
                    and diagnostics.get("empty") is True
                    and diagnostics.get("leader_reaped") is True
                ):
                    return
                raise self.cleanup_error(exc) from exc


class _SceneRuntime:
    """Owned headless ToolRuntime protocol; not a caller-injected runtime."""

    source = "axis"

    def __init__(self, session):
        self.session = session
        self.instruction = session.binding.view.task["instruction"]
        self.last = None

    def reset(self):
        try:
            self.last = self.session.reset()
            self.session.gateway.initial_observation(self.last)
            return self.last
        except EpisodeError as exc:
            self.session.remember_failure(exc)
            raise

    def call(self, call_id, name, args):
        from agent_harness.tools import ToolOutcome

        try:
            self.last = self.session.call({"name": name, "args": args})
            self.session.gateway.tool_observation(call_id, self.last)
        except EpisodeError as exc:
            self.session.remember_failure(exc)
            raise
        return ToolOutcome(self.last, self.last["success"], {}, self.last["step"])

    def success(self):
        if self.session.terminal is not None:
            return False, {}
        try:
            self.session.clock.remaining()
        except EpisodeError as exc:
            self.session.remember_failure(exc)
            return False, {}
        return bool(self.last and self.last["success"]), {}

    def close(self):
        self.session.close()

    def contract_evidence(self, spec):
        require(
            type(self) is _SceneRuntime and self.session.ready and not self.session.closed,
            "episode_runtime_unavailable",
            status="resource_unavailable",
        )
        self.session.clock.remaining()
        contract = self.session.binding.view.contract
        require(spec.panel_binding["execution_contract"] == contract, "episode_spec_contract")
        return {
            "execution_contract": contract,
            "execution_contract_digest": canonical_digest(contract),
            "execution_runtime": self.session.startup["execution_runtime"],
            "scene_episode_startup": self.session.startup,
            "scene_episode_binding": self.session.binding.document,
        }

    def finish_episode(self):
        # _finish calls this before run_end/signing, including all failure paths.
        try:
            if self.session.terminal is None:
                self.session.clock.remaining()
                gateway = self.session.gateway.finish()
            else:
                # A cancellation cannot trigger quota/route/model I/O. The
                # persistent attempt ledger remains consumed, including unknown usage.
                gateway = self.session.gateway.failure_evidence()
        except Exception as exc:
            error = (
                exc
                if isinstance(exc, EpisodeError)
                else EpisodeError(str(getattr(exc, "code", "") or "episode_gateway_error"))
            )
            self.session.remember_failure(error)
            raise error from exc
        finally:
            self.session.close()
        scope = self.session.backend.parent_scope
        try:
            scope.check_resources()
        except EpisodeError as exc:
            raise self.session.cleanup_error(exc) from exc
        return {
            **self.session.backend.diagnostics,
            "a_gateway": gateway,
            "parent_scope_stats": scope.last_stats,
            "terminal": self.session.terminal.to_dict() if self.session.terminal else None,
        }


def validate_scene_episode(
    view,
    *,
    frozen_task,
    receipt,
    trust,
    episode,
    policy,
    spec,
    gateway_factory,
    receipt_bytes=None,
    clock=None,
):
    """Pure caller gate; no native, provider, cgroup or sandbox launch.

    Does not certify Linux availability. frozen_task must be the complete,
    original authenticated backend wire, separate from normalized P08 work.
    """
    from agent_harness.spec import HarnessSpec, SpecError, parse_spec
    from agent_harness.assurance import profile
    from agent_harness.manifest import agent_binding
    from .episode_gateway import SceneAGatewayFactory, gateway_factory_identity, _SEAL

    require(
        type(gateway_factory) is SceneAGatewayFactory and gateway_factory._seal is _SEAL,
        "episode_gateway_unsupported",
        status="resource_unavailable",
    )
    require(type(policy) is EpisodePolicy, "episode_policy_unavailable", status="resource_unavailable")
    require(type(spec) is HarnessSpec, "episode_frozen_spec_required")
    require(
        spec.harness_name == "headless"
        and spec.assurance.isolated
        and spec.mode == "privileged"
        and not spec.runtime_override,
        "episode_harness_unsupported",
        status="resource_unavailable",
    )
    require(
        spec.assurance == profile("isolated") and not spec.harness_options and not spec.task_package_root,
        "episode_harness_unsupported",
        status="resource_unavailable",
    )
    try:
        parsed = parse_spec(decode(encoded(spec.raw)))
    except SpecError as exc:
        raise EpisodeError("episode_frozen_spec_changed", status="invalid_package") from exc
    if not (spec.raw.get("binding", {}).get("nonce") or spec.raw.get("job_nonce")):
        # The existing A parser generates this legacy evidence nonce when no
        # backend B job nonce exists. P03 authenticates its own per-start nonce.
        from dataclasses import replace

        parsed = replace(parsed, job_nonce=spec.job_nonce)
    require(spec == parsed, "episode_frozen_spec_changed")
    from .episode_authority import detached_receipt_bytes

    receipt_raw_digest = detached_receipt_bytes(receipt_bytes, receipt=receipt, limit=policy.frame_bytes)
    require(
        gateway_factory.config_digest == policy.config_digest
        and gateway_factory.implementation_digest
        == policy.gateway_factory_digest
        == gateway_factory_identity()["digest"]
        and encoded(spec.model) == gateway_factory.model_bytes,
        "episode_gateway_assignment",
    )
    binding = EpisodeBinding.create(
        view, frozen_task=frozen_task, receipt=receipt, trust=trust, episode=episode, policy=policy, clock=clock
    )
    from dataclasses import replace

    binding = replace(
        binding,
        document_bytes=encoded({**binding.document, "receipt_raw_digest": receipt_raw_digest}),
        receipt_bytes=receipt_bytes,
    )
    contract = binding.view.contract
    require(contract["agent"] == agent_binding(), "registered_agent_mismatch")
    require(
        (spec.run_id, spec.attempt_id, spec.instance)
        == (episode["run_id"], episode["attempt_id"], episode["instance"]),
        "episode_spec_assignment",
    )
    require(
        spec.source == "axis" and spec.task_version_digest == view.manifest["execution_package_digest"],
        "episode_spec_package",
    )
    require(
        spec.max_turns == contract["budget"]["max_api_calls"]
        and spec.max_steps == contract["budget"]["max_steps"]
        and spec.wall_seconds == contract["budget"]["wall_seconds"]
        and set(spec.sensors) == set(contract["permissions"]["allowed_sensors"]),
        "episode_spec_permissions",
    )
    require(
        spec.panel_binding and spec.panel_binding.get("execution_contract_digest") == canonical_digest(contract),
        "episode_spec_contract",
    )
    require(
        spec.panel_binding.get("kind") == "agent"
        and spec.panel_binding.get("run_id") == episode["run_id"]
        and type(spec.panel_binding.get("panel")) is str
        and spec.panel_binding["panel"]
        and spec.episode == episode["trial"]
        and spec.panel_binding.get("member") == episode["member_id"]
        and spec.panel_binding.get("trial") == episode["trial"]
        and spec.panel_binding.get("config_digest") == policy.config_digest,
        "episode_spec_assignment",
    )
    require(
        # Harness timing also contains the resolved on_action marker; its
        # control period is stored separately. Compare effective fields, while
        # the raw signed timing block must still equal the frozen contract.
        spec.timing["clock_mode"] == contract["timing"]["clock_mode"]
        and spec.timing["s"] == contract["timing"]["s"]
        and spec.timing["environment_advance"] == "on_action"
        and spec.control_step_seconds == contract["timing"]["control_step_seconds"]
        and spec.agent == contract["agent"]
        and spec.instruction == view.task["instruction"],
        "episode_spec_permissions",
    )
    for key in ("budget", "permissions", "timing"):
        require(spec.raw.get(key) == contract[key], "episode_spec_permissions")
    require(
        spec.task_id == str(binding.document["task_id"])
        and spec.task_package_repo == binding.document["package_repo"]
        and spec.task_package_commit == binding.document["package_commit"],
        "episode_spec_package",
    )
    return binding


def run_scene_episode(
    view,
    *,
    frozen_task,
    receipt,
    trust,
    episode,
    policy,
    spec,
    gateway_factory,
    evidence_directory,
    signer=None,
    frame_collector=None,
    cancellation=None,
    receipt_bytes=None,
):
    """Owned A episode, dedicated pre-enrolled Linux parent, strict state lane.

    No B job wrapper, user callback, runtime/OS injection or demo fallback.
    The same deadline starts BEFORE expensive identity verification and lasts
    through gateway startup, reset/render/provider/IPC/native and final checks.
    """
    started, parent_cpu_started = time.monotonic(), time.process_time()
    from agent_harness.spec import HarnessSpec
    from .episode_authority import wire_epoch
    from .episode_gateway import SceneAGatewayFactory
    from .episode_linux import LinuxEpisodeBackend
    from .episode_scope import EpisodeParentScope, episode_scope_name

    require(type(gateway_factory) is SceneAGatewayFactory, "episode_gateway_unsupported", status="resource_unavailable")
    require(
        type(policy) is EpisodePolicy and type(spec) is HarnessSpec,
        "episode_policy_unavailable",
        status="resource_unavailable",
    )
    require(
        type(spec.evidence_path) is str and __import__("pathlib").Path(spec.evidence_path).is_absolute(),
        "episode_call_records_path_missing", status="resource_unavailable",
    )
    require(cancellation is None or type(cancellation) is threading.Event, "episode_cancellation_invalid")
    require(type(receipt_bytes) is bytes, "episode_authenticated_receipt_missing", status="resource_unavailable")
    try:
        expiry = min(
            wire_epoch(frozen_task["assignment"]["lease_expires_at"]),
            positive(frozen_task["receipt_authority"]["valid_until"], "receipt_valid_until"),
        )
    except (KeyError, TypeError) as exc:
        raise EpisodeError("episode_authenticated_metadata_missing", status="invalid_package") from exc
    clock = EpisodeClock(
        spec.wall_seconds, expiry, cancellation=cancellation, started=started, parent_cpu_started=parent_cpu_started
    )
    clock.remaining()
    resources = EpisodeParentScope(policy, clock, parent_cpu_started=parent_cpu_started)
    backend = session = gateway = result = None
    try:
        # The operator must provide a dedicated pre-enrolled parent. Fail before
        # binding/materializing if aggregate kernel enforcement is absent.
        resources.start()
        clock.remaining()
        from agent_harness.headless import HeadlessHarness

        binding = validate_scene_episode(
            view,
            frozen_task=frozen_task,
            receipt=receipt,
            trust=trust,
            episode=episode,
            policy=policy,
            spec=spec,
            gateway_factory=gateway_factory,
            receipt_bytes=receipt_bytes,
            clock=clock,
        )
        require(
            __import__("pathlib").Path(policy.accounting_scope).name
            == episode_scope_name(
                episode=episode,
                submission_digest=binding.view.manifest["submission_digest"],
                config_digest=policy.config_digest,
            ),
            "episode_parent_scope_identity",
            status="resource_unavailable",
        )
        clock.remaining()
        resources.check_resources()
        backend = LinuxEpisodeBackend(binding, policy, clock, evidence_directory, parent_scope=resources)

        from .episode_ledger import PrivateCallRecorder

        recorder = PrivateCallRecorder(
            spec.evidence_path + ".calls.jsonl", clock=clock,
            max_bytes=min(policy.output_bytes, 16 * 1024 * 1024), audit=backend.record_private,
            charge=backend._charge, private_roots=policy.protected_roots,
            forbidden_roots=tuple(root for root in (policy.rootfs, spec.task_package_root) if root),
        )
        gateway = gateway_factory.open(binding=binding, spec=spec, policy=policy, clock=clock, recorder=recorder)
        session = _Episode(binding, policy, clock, backend)
        session.gateway = gateway
        session.start()
        runtime = _SceneRuntime(session)

        def deadline_chat(messages, tools, model_spec, **kwargs):
            # Existing A gateway and ledger; no B job token or provider fallback.
            try:
                clock.remaining()
                backend.record_private([{"model_input": {"messages": messages, "tools": tools}}])
                value = gateway.chat(messages, tools, model_spec, **kwargs)
                clock.remaining()
                backend.record_private([{"model_output": value}])
                return value
            except Exception as exc:
                error = (
                    exc
                    if isinstance(exc, EpisodeError)
                    else EpisodeError(str(getattr(exc, "code", "") or "episode_gateway_error"))
                )
                session.remember_failure(error)
                raise

        result = HeadlessHarness().run(
            # The original event chain is completed by the real harness. Its
            # executor signature is deferred until the owned OS cleanup and
            # final resource transaction have succeeded; no event is replayed.
            spec, runtime, chat_fn=deadline_chat, signer=None, frame_collector=frame_collector
        )
        result.extra = {
            **dict(result.extra),
            "scene_episode": {
                "binding": binding.document,
                "tools": session.tools,
                "steps": session.steps,
                "deadline": clock.deadline,
                "policy_digest": policy.digest,
                "a_gateway": gateway.identity,
                "terminal": session.terminal.to_dict() if session.terminal else None,
            },
        }
    finally:
        try:
            if session is not None:
                session.close()
        finally:
            try:
                if gateway is not None:
                    try:
                        gateway.assert_drained()
                    except BaseException:
                        resources.terminate()
            finally:
                # A failed watchdog/native cleanup cannot leave an executor
                # signature for a run which has not passed its final gates.
                import sys

                try:
                    resources.close(
                        check_clock=sys.exc_info()[0] is None and (session is None or session.terminal is None)
                    )
                except EpisodeError as exc:
                    if session is not None:
                        raise session.cleanup_error(exc) from exc
                    raise
    try:
        require(
            result is not None and getattr(resources, "closed", False)
            and getattr(resources, "finish_confirmed", False),
            "episode_parent_scope_cleanup_unavailable", status="resource_unavailable",
        )
        resources.check_resources(check_watchdog=False)
        if session.terminal is None:
            clock.remaining()
        # Reuse the one OPE-126 signer and the actual RunResult.events snapshot
        # produced above. RunResult supplies .events directly: no reconstructed
        # stream, new nonce, second harness, or reference replay.
        from agent_harness.loop import sign_run_evidence

        sign_run_evidence(result, result, spec, signer)
        resources.check_resources(check_watchdog=False)
        if session.terminal is None:
            clock.remaining()
    except EpisodeError as exc:
        raise session.cleanup_error(exc) from exc
    except Exception as exc:
        raise session.cleanup_error(EpisodeError("episode_signature_unavailable")) from exc
    return result
