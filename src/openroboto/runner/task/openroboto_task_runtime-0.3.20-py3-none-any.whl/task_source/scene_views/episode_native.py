"""Root-registered Codex account context. Projection is source-derived.

The operator owns the signed deployment observation and its independent trust
pin. This module verifies that original and computes a logical context. It
does not inspect a service or attest what an upstream model received.
"""

from __future__ import annotations

import hashlib
import json
import math
import re

from .episode import require
from .identity import decode, encoded

NATIVE_POLICY = "codex-account-native-instructions/1"
NATIVE_DOMAIN = "openroboto:codex-account-deployment:v1"
_SOURCE_KINDS = ("saved", "models_cache", "bundled", "default_prompt")
_COMPILED_BLOBS = {
    "bundled": "61eace426474c08bf144114fceae964eeefdb844",
    "default_prompt": "907ff8b877026871b088f01f4366cea36e1f02cd",
}
_CONTROLS = {"settings", "plugins", "plugin_tools", "plugin_policy", "providers", "sync", "access"}
_MAX_BYTES = 8_000_000


def _need(condition, code="episode_native_registration"):
    require(condition, code, status="resource_unavailable")


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _hex(value, length=64):
    return type(value) is str and re.fullmatch("[0-9a-f]{" + str(length) + "}", value) is not None


def _text(value):
    return type(value) is str and 0 < len(value.encode("utf-8")) <= _MAX_BYTES


def _source_bytes(source):
    raw = source["text"].encode("utf-8")
    _need(len(raw) == source["bytes"] and _sha(raw) == source["sha256"], "episode_native_source")
    return raw


def _json(text):
    def pairs(values):
        _need(len(values) == len(dict(values)), "episode_native_source")
        return dict(values)

    return json.loads(text, object_pairs_hook=pairs)


def select_native_instructions(sources, model):
    """Exact key, models-cache slug, bundled longest-prefix, default prompt."""
    rows = {row["kind"]: row for row in sources}
    saved = rows["saved"]
    if saved["state"] == "present":
        values = _json(saved["text"])
        _need(type(values) is dict and all(type(k) is str and type(v) is str for k, v in values.items()),
              "episode_native_source")
        if model in values:
            return {"kind": "saved", "key": model, "text": values[model]}
    cache = rows["models_cache"]
    if cache["state"] == "present":
        values = _json(cache["text"])
        _need(type(values) is dict and type(values.get("models")) is list, "episode_native_source")
        prompts = {}
        for row in values["models"]:
            _need(type(row) is dict and type(row.get("slug", "")) is str, "episode_native_source")
            messages = row.get("model_messages") or {}
            _need(type(messages) is dict, "episode_native_source")
            text = messages.get("instructions_template") or row.get("base_instructions", "")
            _need(type(text) is str, "episode_native_source")
            if text:
                prompts[row.get("slug", "")] = text
        if model in prompts:
            return {"kind": "models_cache", "key": model, "text": prompts[model]}
    bundled = rows["bundled"]
    _source_bytes(bundled)
    raw = bundled["text"].encode("utf-8")
    _need(hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
          == _COMPILED_BLOBS["bundled"], "episode_native_compiled_source")
    values = _json(bundled["text"])["instructions"]
    _need(type(values) is dict and all(type(k) is str and type(v) is str for k, v in values.items()),
          "episode_native_source")
    slug = model.rsplit("/", 1)[-1].lower()
    matches = [key for key in values if key and slug.startswith(key)]
    if matches:
        key = max(matches, key=len)
        return {"kind": "bundled", "key": key, "text": values[key]}
    default = rows["default_prompt"]
    raw = _source_bytes(default)
    _need(hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
          == _COMPILED_BLOBS["default_prompt"], "episode_native_compiled_source")
    return {"kind": "default_prompt", "key": "", "text": default["text"]}


def validate_native_evidence(policy, raw, registration, target, *, now=None):
    """Verify an independently pinned root observation, including its signature."""
    from agent_evidence.ed25519 import verify

    _need(type(raw) is bytes and len(raw) <= _MAX_BYTES and type(registration) is dict)
    _need(set(registration) == {"path", "sha256", "key_id", "public_key_hex"})
    _need(_hex(registration["sha256"]) and _sha(raw) == registration["sha256"], "episode_native_original")
    evidence = decode(raw)
    _need(type(evidence) is dict and set(evidence) == {
        "domain", "key_id", "signature", "service", "endpoint", "model", "effort",
        "instance", "config_digest", "control_files", "composition", "sources", "instructions", "observed_at", "valid_until",
    })
    _need(evidence["domain"] == NATIVE_DOMAIN and _text(registration["key_id"])
          and evidence["key_id"] == registration["key_id"]
          and _hex(registration["public_key_hex"]) and _hex(evidence["signature"], 128))
    body = {key: value for key, value in evidence.items() if key != "signature"}
    _need(verify(bytes.fromhex(registration["public_key_hex"]), encoded(body),
                 bytes.fromhex(evidence["signature"])), "episode_native_signature")
    _need(encoded(evidence["service"]) == encoded(policy["service"]) and evidence["endpoint"] == target.resolved_endpoint()
          and evidence["model"] == target.model and evidence["effort"] == target.effort,
          "episode_native_model")
    _need(all(type(value) in (int, float) and math.isfinite(value)
              for value in (evidence["observed_at"], evidence["valid_until"]))
          and evidence["observed_at"] < evidence["valid_until"], "episode_native_expired")
    if now is not None:
        _need(type(now) in (int, float) and math.isfinite(now)
              and evidence["observed_at"] <= now < evidence["valid_until"], "episode_native_expired")
    instance = evidence["instance"]
    _need(type(instance) is dict and set(instance) == {"id", "pid", "start", "uid", "argv_sha256", "binary_sha256"}
          and _text(instance["id"]) and _text(instance["start"])
          and type(instance["pid"]) is int and instance["pid"] > 0
          and type(instance["uid"]) is int and instance["uid"] > 0
          and _hex(instance["argv_sha256"]) and instance["binary_sha256"] == policy["service"]["binary_sha256"])
    controls = evidence["control_files"]
    _need(type(controls) is dict and set(controls) == _CONTROLS, "episode_native_controls")
    for row in controls.values():
        _need(type(row) is dict and set(row) == {"path", "sha256", "bytes", "owner_uid", "writable", "replaceable"}
              and _text(row["path"]) and row["path"].startswith("/") and _hex(row["sha256"])
              and type(row["bytes"]) is int and 0 <= row["bytes"] <= _MAX_BYTES
              and type(row["owner_uid"]) is int and row["owner_uid"] == 0
              and row["writable"] is False and row["replaceable"] is False, "episode_native_controls")
    _need(evidence["config_digest"] == policy["active_config_digest"]
          == _sha(encoded(controls)), "episode_native_controls")
    _need(encoded(evidence["composition"]) == encoded({
        "kind": "operator-config-observation/1", "instance_digest": _sha(encoded(instance)),
        "controls_digest": evidence["config_digest"], "read_errors": [], "middleware": [], "native_tools": [],
        "in_use": {name: 0 for name in ("middleware", "redact", "tools", "groups", "routing", "search",
                                      "rotation", "warmups", "library")},
        "no_loop_guard": True, "dynamic_sync": False,
    }), "episode_native_composition")
    sources = evidence["sources"]
    _need(type(sources) is list and [row.get("kind") for row in sources if type(row) is dict]
          == list(_SOURCE_KINDS), "episode_native_sources")
    for source in sources:
        _need(set(source) == {"kind", "path", "state", "text", "sha256", "bytes", "protected", "git_blob_sha1"}
              and _text(source["path"]) and source["protected"] is True
              and source["state"] in {"present", "absent", "compiled"}
              and type(source["text"]) is str and type(source["bytes"]) is int, "episode_native_sources")
        _need(source["state"] == "compiled" if source["kind"] in _COMPILED_BLOBS
              else source["state"] in {"present", "absent"}, "episode_native_sources")
        if source["kind"] in _COMPILED_BLOBS:
            _need(source["git_blob_sha1"] == _COMPILED_BLOBS[source["kind"]],
                  "episode_native_compiled_source")
        else:
            _need(source["git_blob_sha1"] is None and source["path"].startswith("/"), "episode_native_sources")
        if source["state"] == "absent":
            _need(source["text"] == "" and source["bytes"] == 0 and source["sha256"] is None,
                  "episode_native_sources")
        elif source["state"] == "present" or source["text"]:
            source_raw = _source_bytes(source)
            if source["state"] == "compiled":
                _need(hashlib.sha1(b"blob " + str(len(source_raw)).encode() + b"\0" + source_raw).hexdigest()
                      == _COMPILED_BLOBS[source["kind"]], "episode_native_compiled_source")
        else:
            _need(source["sha256"] is None and source["bytes"] == 0,
                  "episode_native_compiled_source")
    adapter = policy["native_adapter"]
    _need(type(adapter) is dict and set(adapter) == {
        "id", "model", "effort", "upstream_model", "registration_sha256", "instance_digest",
        "sources_digest", "instructions", "role_map", "projection_kind",
    }, "episode_native_adapter")
    _need(adapter["id"] == NATIVE_POLICY and adapter["projection_kind"] == "source-derived-logical-context/1"
          and adapter["model"] == target.model and adapter["effort"] == target.effort
          and _text(adapter["effort"])
          and type(adapter["upstream_model"]) is str and target.model == "codex/" + adapter["upstream_model"]
          and adapter["role_map"] == {"system": "developer"}
          and adapter["registration_sha256"] == registration["sha256"]
          and adapter["instance_digest"] == _sha(encoded(instance))
          and adapter["sources_digest"] == _sha(encoded(sources)), "episode_native_adapter")
    selected = select_native_instructions(sources, adapter["upstream_model"])
    text = selected["text"]
    expected = {**selected, "sha256": _sha(text.encode("utf-8")), "bytes": len(text.encode("utf-8"))}
    _need(_text(text) and encoded(evidence["instructions"]) == encoded(adapter["instructions"]) == encoded(expected),
          "episode_native_instructions")
    return evidence


def load_native_registration(policy, registration, target, *, now=None):
    """The registry path/trust pin is supplied by the authenticated parent."""
    from task_source.scene_episode_launcher import trusted_file

    _need(type(registration) is dict and type(registration.get("path")) is str)
    try:
        raw = trusted_file(registration["path"], limit=_MAX_BYTES)
        validate_native_evidence(policy, raw, registration, target, now=now)
    except Exception as exc:
        from .episode import EpisodeError

        if isinstance(exc, EpisodeError):
            raise
        require(False, "episode_native_registration", status="resource_unavailable")
    return raw


def native_context_projection(policy, messages, tools):
    """Full logical context, with protocol-envelope and delivery claims excluded."""
    from agent_eval.providers.openai_compat import _convert_messages, _convert_tools

    _need(policy["schema_version"] == 2, "episode_native_adapter")
    client = decode(encoded({"messages": messages, "tools": tools}))
    from agent_harness.loop import tool_manifest_for_model

    _need(encoded(tools) == encoded(tool_manifest_for_model()), "episode_native_context_unsupported")
    def supported(value):
        if type(value) is list:
            return all(supported(item) for item in value)
        if type(value) is dict:
            return value.get("type") not in ("web_search_call", "additional_tools", "compaction_trigger",
                                              "compaction", "encrypted_content", "local_shell_call") and all(
                supported(item) for item in value.values())
        return True
    _need(supported(client), "episode_native_context_unsupported")
    converted = _convert_messages(client["messages"])
    native = policy["native_adapter"]["instructions"]["text"]
    for message in converted:
        _need(message.get("role") in {"system", "developer", "user", "assistant", "tool"},
              "episode_native_context_unsupported")
        if message["role"] == "system":
            own = message.get("content")
            _need(type(own) is str and own.strip().split("\n", 1)[0] != native.strip().split("\n", 1)[0],
                  "episode_native_context_unsupported")
            message["role"] = "developer"
    return {
        "kind": "source-derived-logical-context/1",
        "provider_policy_digest": _sha(encoded(policy)),
        "registration_sha256": policy["native_adapter"]["registration_sha256"],
        "client": client,
        "effective": {"instructions": native,
                      "messages": converted, "tools": _convert_tools(client["tools"])},
    }
