"""Schema-3 reference normalization for scene-nd-v2; never a task/package rewrite.

Only declared identifiers and their typed reference fields are mapped. Property
keys, predicate operators, enums, units, coordinates and ordinary strings retain
exact values. Native names and asset-local part names have separate namespaces.
"""

from copy import deepcopy


def canonical_scene(task):
    definition, scene = task["task_definition"], task["scene"]
    object_ids = {o["id"] for o in definition["objects"]}
    order = []

    def referenced(p):
        for field in ("object_id", "object_ids", "support_id", "other_id"):
            values = p.get(field, [])
            for value in values if isinstance(values, list) else [values]:
                if value in object_ids and value not in order:
                    order.append(value)
        for child in p.get("children", []):
            referenced(child)
        if "child" in p:
            referenced(p["child"])

    for stage in definition["stages"]:
        referenced(stage["goal"])
        for p in stage["invariants"]:
            referenced(p)
    for p in definition["invariants"]:
        referenced(p)
    order.extend(o["id"] for o in definition["objects"] if o["id"] not in order)
    objects = {name: f"object_{i}" for i, name in enumerate(order)}
    by_id = {o["id"]: o for o in definition["objects"]}
    bodies = {by_id[name]["body"]: f"body_{i}" for i, name in enumerate(order)}
    frames = {f["id"]: f"frame_{i}" for i, f in enumerate(scene["frames"])}
    joints = {j["id"]: f"joint_{i}" for i, j in enumerate(scene["joints"])}
    native_joints = {j["name"]: f"joint_name_{i}" for i, j in enumerate(scene["joints"])}
    for name in order:
        native = by_id[name]["free_joint_name"]
        if native is not None:
            native_joints.setdefault(native, f"free_joint_{objects[name]}")
    asset_order = list(dict.fromkeys(by_id[name]["asset"]["id"] for name in order))
    asset_order.extend(a["id"] for a in scene["assets"] if a["id"] not in asset_order)
    assets = {name: f"asset_{i}" for i, name in enumerate(asset_order)}
    parts = {a["id"]: {p["id"]: f"part_{i}" for i, p in enumerate(a["collision"]["parts"])} for a in scene["assets"]}
    geoms = {}
    for name in order:
        obj = by_id[name]
        for part, native in obj["collision_geoms"].items():
            geoms[native] = f"geom_{objects[name]}_{parts[obj['asset']['id']][part]}"
    targets = {t["id"]: f"contact_target_{i}" for i, t in enumerate(scene["contact_targets"])}
    zones = {z["id"]: f"zone_{i}" for i, z in enumerate(definition["zones"])}
    stages = {s["id"]: f"stage_{i}" for i, s in enumerate(definition["stages"])}

    def entity(name):
        # Table/robot are fixed platform groups, not user identifiers.
        return objects.get(name, targets.get(name, name))

    def predicate(p):
        result = deepcopy(p)
        if "object_id" in p:
            result["object_id"] = objects[p["object_id"]]
        if "object_ids" in p:
            result["object_ids"] = [objects[n] for n in p["object_ids"]]
        for field in ("support_id", "other_id"):
            if field in p:
                result[field] = entity(p[field])
        if "zone_id" in p:
            result["zone_id"] = zones[p["zone_id"]]
        if "zone_ids" in p:
            result["zone_ids"] = [zones[n] for n in p["zone_ids"]]
        if "children" in p:
            result["children"] = [predicate(child) for child in p["children"]]
        if "child" in p:
            result["child"] = predicate(p["child"])
        return result

    result = deepcopy(task)
    d, s = result["task_definition"], result["scene"]
    for original, obj in zip(definition["objects"], d["objects"]):
        obj["id"] = objects[original["id"]]
        obj["body"] = bodies[original["body"]]
        obj["body_frame"] = frames[original["body_frame"]]
        obj["asset"]["id"] = assets[original["asset"]["id"]]
        obj["free_joint_name"] = native_joints.get(original["free_joint_name"])
        obj["collision_geoms"] = {
            parts[original["asset"]["id"]][part]: geoms[name] for part, name in original["collision_geoms"].items()
        }
    for original, asset in zip(scene["assets"], s["assets"]):
        asset["id"] = assets[original["id"]]
        for p in asset["collision"]["parts"]:
            p["id"] = parts[original["id"]][p["id"]]
        asset["physics"]["contacts"] = {
            parts[original["id"]][key]: value for key, value in asset["physics"]["contacts"].items()
        }
    for f in s["frames"]:
        f["id"] = frames[f["id"]]
        f["parent"] = frames.get(f["parent"], f["parent"])
    for j in s["joints"]:
        j["id"] = joints[j["id"]]
        j["name"] = native_joints[j["name"]]
        j["body_id"] = objects[j["body_id"]]
        j["parent_body"] = "world" if j["parent_body"] == "world" else bodies.get(j["parent_body"], j["parent_body"])
    for target in s["contact_targets"]:
        target["id"] = targets[target["id"]]
        target["entity_id"] = entity(target["entity_id"])
        target["geom_names"] = [geoms.get(n, n) for n in target["geom_names"]]
    s["camera"]["frame"] = frames.get(s["camera"]["frame"], s["camera"]["frame"])
    for i, state in enumerate(s["initial_states"]):
        state["id"] = f"state_{i}"
        for obj in state["objects"]:
            obj["object_id"] = objects[obj["object_id"]]
        for j in state["joints"]:
            j["joint_id"] = joints[j["joint_id"]]
    for zone in d["zones"]:
        zone["id"] = zones[zone["id"]]
        for ref in zone["accepts"]:
            ref["id"] = assets[ref["id"]]
    for stage in d["stages"]:
        stage["id"] = stages[stage["id"]]
        stage["requires"] = [stages[n] for n in stage["requires"]]
        stage["goal"] = predicate(stage["goal"])
        stage["invariants"] = [predicate(p) for p in stage["invariants"]]
    d["invariants"] = [predicate(p) for p in d["invariants"]]
    return result
