"""Explicit scene credential rotation, never an episode or budget reset.

Only a trusted parent runtime may provide RecoveryJournal from ORIGINAL local
append-only records. Independent local binding/files/trials/ledger expectations
must exist before HTTP, never reconstructed from the recovery response. No Operator credential or
reference/physics/model code belongs in this module.
"""

from __future__ import annotations

import copy
import hashlib
import logging
import os
import re
import secrets
import stat
from dataclasses import dataclass, field
from pathlib import PurePosixPath

from task_source.panel_client import PanelAPIError, contains_recovery_material
from task_source.panel_state import read
from task_source.scene_adapter import bind_scene_context, epoch, frozen_context, normalize_scene_work
from task_source.scene_dispatch import is_scene_task
from task_source.scene_views.identity import decode, encoded

HEX = re.compile(r"[0-9a-f]{64}\Z")
REQUEST_FIELDS = {"worker_id", "node_id", "recovery_token", "lease_token", "next_recovery_token", "nonce"}
LEGACY_CHECKPOINT_FIELDS = {
    "binding_digest",
    "progress",
    "artifacts",
    "report_digest",
    "calls",
    "budget_reservations",
    "subscription_reservations",
}
CHECKPOINT_FIELDS = LEGACY_CHECKPOINT_FIELDS | {"portable"}


class SceneRecoveryError(ValueError):
    """A safe structured code; never include credential or journal contents."""


def require(condition, code):
    if not condition:
        raise SceneRecoveryError(code)


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def token(value, minimum=32):
    return isinstance(value, str) and minimum <= len(value) <= 200


def validate_request(work, body, *, worker_id, node_id):
    require(isinstance(body, dict) and set(body) == REQUEST_FIELDS, "SCENE_RECOVERY_REQUEST_INVALID")
    require(body["worker_id"] == worker_id and body["node_id"] == node_id, "SCENE_RECOVERY_OWNER_MISMATCH")
    values = [body[key] for key in ("recovery_token", "lease_token", "next_recovery_token", "nonce")]
    require(
        all(token(value, 20 if index == 1 else 32) for index, value in enumerate(values)),
        "SCENE_RECOVERY_CREDENTIAL_INVALID",
    )
    require(len(set(values)) == 4 and work["lease_token"] not in values, "SCENE_RECOVERY_CREDENTIAL_REUSED")


def stable_work(work):
    result = copy.deepcopy(normalize_scene_work(work))
    result.pop("_scene_frozen_task", None)  # Duplicate original metadata, bound separately before new execution.
    for key in ("lease_token", "lease_expires_at", "status"):
        result.pop(key, None)
    result["task"]["assignment"].pop("lease_expires_at")
    result["task"]["receipt_authority"].pop("valid_until")
    return result


def checkpoint(value):
    require(
        isinstance(value, dict) and set(value) in (LEGACY_CHECKPOINT_FIELDS, CHECKPOINT_FIELDS),
        "SCENE_RECOVERY_CHECKPOINT_INVALID",
    )
    if "portable" in value:
        from task_source.scene_checkpoint import parse_portable

        parse_portable(value["portable"])
    require(
        isinstance(value["binding_digest"], str) and HEX.fullmatch(value["binding_digest"]),
        "SCENE_RECOVERY_CHECKPOINT_INVALID",
    )
    report = value["report_digest"]
    require(report is None or (isinstance(report, str) and HEX.fullmatch(report)), "SCENE_RECOVERY_CHECKPOINT_INVALID")
    progress = value["progress"]
    require(
        isinstance(progress, dict)
        and set(progress)
        == {"completed_trials", "total_trials", "current_member", "current_trial", "last_status", "error_code"},
        "SCENE_RECOVERY_PROGRESS_INVALID",
    )
    done, total = progress["completed_trials"], progress["total_trials"]
    require(type(done) is int and type(total) is int and 0 <= done <= total, "SCENE_RECOVERY_PROGRESS_INVALID")
    require(
        all(
            progress[key] is None or isinstance(progress[key], str)
            for key in ("current_member", "last_status", "error_code")
        )
        and (
            progress["current_trial"] is None
            or (type(progress["current_trial"]) is int and progress["current_trial"] >= 0)
        ),
        "SCENE_RECOVERY_PROGRESS_INVALID",
    )
    for key in ("calls", "budget_reservations", "subscription_reservations"):
        row = value[key]
        require(
            isinstance(row, dict)
            and set(row) == {"count", "digest"}
            and type(row["count"]) is int
            and row["count"] >= 0
            and isinstance(row["digest"], str)
            and HEX.fullmatch(row["digest"]),
            "SCENE_RECOVERY_CHECKPOINT_INVALID",
        )
        if "portable" in value:
            require(row["count"] == value["portable"][key]["count"], "SCENE_RECOVERY_CHECKPOINT_INVALID")
    artifacts = value["artifacts"]
    require(isinstance(artifacts, list) and len(artifacts) <= 4096, "SCENE_RECOVERY_CHECKPOINT_INVALID")
    seen = set()
    for row in artifacts:
        require(
            isinstance(row, dict)
            and set(row) == {"artifact_id", "kind", "member", "trial", "sha256", "bytes_len", "status"},
            "SCENE_RECOVERY_CHECKPOINT_INVALID",
        )
        require(
            all(isinstance(row[key], str) and row[key] for key in ("artifact_id", "kind", "status"))
            and row["artifact_id"] not in seen
            and type(row["bytes_len"]) is int
            and row["bytes_len"] > 0
            and isinstance(row["sha256"], str)
            and HEX.fullmatch(row["sha256"])
            and (row["member"] is None or isinstance(row["member"], str))
            and (row["trial"] is None or (type(row["trial"]) is int and row["trial"] >= 0)),
            "SCENE_RECOVERY_CHECKPOINT_INVALID",
        )
        seen.add(row["artifact_id"])
    return value


@dataclass(frozen=True)
class RecoveryJournal:
    """Parent-only verified original journal, not a server-supplied snapshot.

    The provider verifies original hash-chains, run/config/N/call sequences,
    price/quota receipts, settled reservations and process-tree quiescence.
    Portable semantic rows replace an impossible local SQL-text mirror.
    Missing original records must never be opened as empty ledgers.
    """

    _bytes: bytes = field(repr=False)
    _local_a: object = field(default=None, repr=False, compare=False)
    _remote: object = field(default=None, repr=False, compare=False)

    @classmethod
    def create(cls, *, work, expected_checkpoint, checkpoint_digest, files, unresolved_calls, quiescent):
        """Historical R8 format only; active preflight requires create_portable."""
        checkpoint(expected_checkpoint)
        require(
            isinstance(checkpoint_digest, str)
            and HEX.fullmatch(checkpoint_digest)
            and checkpoint_digest == digest(expected_checkpoint),
            "SCENE_RECOVERY_CHECKPOINT_INVALID",
        )
        return cls(
            encoded({
                "local_binding_digest": digest(stable_work(work)),
                "checkpoint": expected_checkpoint,
                "checkpoint_digest": checkpoint_digest,
                "files": files,
                "unresolved_calls": unresolved_calls,
                "quiescent": quiescent,
            })
        )

    @property
    def document(self):
        return decode(self._bytes)

    @classmethod
    def create_portable(
        cls,
        *,
        work,
        checkpoint_state,
        rows,
        gateway_trust,
        files,
        unresolved_calls,
        quiescent,
        server_binding_digest=None,
    ):
        """Independent ORIGINAL rows/receipts, frozen before scene-resume HTTP.

        The parent verifies specs, chains, frozen prices/quota and receipts.
        SQL string hashes are deliberately not reproduced. A previously known
        server binding is compared; a first authenticated binding is recorded
        only as a server commitment, never as the local work identity.
        """
        from task_source.scene_checkpoint import verify_local_rows

        require(
            isinstance(checkpoint_state, dict) and set(checkpoint_state) == {"progress", "artifacts", "report_digest"},
            "SCENE_RECOVERY_JOURNAL_INVALID",
        )
        verify_local_rows(work, rows, gateway_trust)
        require(
            server_binding_digest is None
            or (isinstance(server_binding_digest, str) and HEX.fullmatch(server_binding_digest)),
            "SCENE_RECOVERY_JOURNAL_INVALID",
        )
        return cls(
            encoded({
                "schema_version": "scene-local-recovery-journal-v2",
                "local_binding_digest": digest(stable_work(work)),
                "checkpoint_state": checkpoint_state,
                "rows": rows,
                "gateway_trust": gateway_trust,
                "server_binding_digest": server_binding_digest,
                "files": files,
                "unresolved_calls": unresolved_calls,
                "quiescent": quiescent,
            })
        )

    @classmethod
    def create_local_a(cls, *, work, checkpoint_state, local_a, files, quiescent):
        """Wrap P03's sealed, ORIGINAL local-A journal before resume HTTP.

        Namespace/factory choice is made by the independent parent. Empty DB
        rows cannot stand in for an absent local ledger or grant new execution.
        """
        from task_source.scene_views.episode_ledger import LocalARecoveryJournal
        from task_source.scene_checkpoint import VERSION, expected_ledgers, LEDGERS

        require(type(local_a) is LocalARecoveryJournal, "SCENE_RECOVERY_LOCAL_A_JOURNAL_REQUIRED")
        doc = local_a.document
        require(doc["run_id"] == work["run_id"] and quiescent is True, "SCENE_RECOVERY_JOURNAL_INVALID")
        # Check the P03 seal before HTTP, using ONLY its independent frozen
        # expectation. Never reconstruct a sealed journal from persisted JSON.
        local_a.reconcile({
            "schema_version": VERSION,
            "run_id": doc["run_id"],
            "binding_digest": doc["binding_digest"],
            "recovery_generation": doc["recovery_generation"],
            "reconciliation_required": True,
            **expected_ledgers({name: [] for name in LEDGERS}),
        })
        require(
            isinstance(checkpoint_state, dict) and set(checkpoint_state) == {"progress", "artifacts", "report_digest"},
            "SCENE_RECOVERY_JOURNAL_INVALID",
        )
        return cls(
            encoded({
                "schema_version": "scene-local-recovery-journal-v3",
                "local_binding_digest": digest(stable_work(work)),
                "checkpoint_state": checkpoint_state,
                "server_binding_digest": doc["binding_digest"],
                "local_a": doc,
                "files": files,
                "unresolved_calls": False,
                "quiescent": True,
            }),
            local_a,
        )


def directory(worker, state):
    return worker.root / "runs" / hashlib.sha256(state["work"]["run_id"].encode()).hexdigest()[:24]


def scope(worker, state):
    work = state.get("work", {})
    require(
        worker.task_kind == "scene" and worker.scene is not None and is_scene_task(work.get("task", {})),
        "SCENE_RECOVERY_WORK_REQUIRED",
    )
    require(
        state["binding"]
        == {
            "backend": worker.client.base_url,
            "worker_id": worker.client.worker_id,
            "node_id": worker.client.node_id,
            "competition_id": work["task"]["competition_id"],
        },
        "SCENE_RECOVERY_OWNER_MISMATCH",
    )
    require(
        not contains_recovery_material(
            work, [state.get("scene_recovery_token")] if state.get("scene_recovery_token") else []
        ),
        "SCENE_RECOVERY_MATERIAL_EXPOSED",
    )
    return work


def verify_files(root, files):
    require(
        root.is_dir() and not root.is_symlink() and isinstance(files, dict) and 0 < len(files) <= 4096,
        "SCENE_RECOVERY_JOURNAL_REQUIRED",
    )
    total = 0
    for name, expected in files.items():
        require(
            isinstance(name, str) and isinstance(expected, str) and HEX.fullmatch(expected),
            "SCENE_RECOVERY_JOURNAL_INVALID",
        )
        relative = PurePosixPath(name)
        require(
            not relative.is_absolute()
            and relative.parts
            and all(p not in {"", ".", ".."} for p in relative.parts)
            and relative.as_posix() == name
            and "\\" not in name,
            "SCENE_RECOVERY_JOURNAL_INVALID",
        )
        path = root
        for part in relative.parts:
            path = path / part
            require(not path.is_symlink(), "SCENE_RECOVERY_JOURNAL_INVALID")
        require(path.is_file(), "SCENE_RECOVERY_JOURNAL_REQUIRED")
        hashed = hashlib.sha256()
        with path.open("rb") as stream:
            while chunk := stream.read(65536):
                total += len(chunk)
                require(total <= 64_000_000, "SCENE_RECOVERY_JOURNAL_LIMIT")
                hashed.update(chunk)
        require(hashed.hexdigest() == expected, "SCENE_RECOVERY_JOURNAL_CHANGED")


def preflight(worker, state, *, with_parent=False, unstarted=False):
    from task_source.panel_worker import validate_host, validate_work
    from task_source.scene_adapter import scene_runtime

    work = scope(worker, state)
    config = validate_work(work)
    host = read(worker.model_config)
    validate_host(host, config)
    root = directory(worker, state)
    require(root.is_dir() and not root.is_symlink(), "SCENE_RECOVERY_JOURNAL_REQUIRED")
    runtime = worker.scene.evaluation_runtime or scene_runtime()
    provider = getattr(worker, "scene_recovery_reader", None) or runtime
    reader = getattr(provider, "scene_recovery_journal", None)
    require(callable(reader), "SCENE_RECOVERY_JOURNAL_UNAVAILABLE")
    from task_source.scene_unstarted_recovery import JOURNAL_VERSION

    pending_version = state.get("scene_recovery_pending", {}).get("journal", {}).get("schema_version")
    if unstarted or pending_version == JOURNAL_VERSION:
        from task_source.scene_recovery_bootstrap import RegisteredRecoveryReader

        require(type(provider) is RegisteredRecoveryReader, "SCENE_RECOVERY_UNSTARTED_PARENT_REQUIRED")
        value = provider.scene_unstarted_recovery_journal(work, directory=root)
    else:
        value = reader(work, directory=root)
    require(type(value) is RecoveryJournal and len(value._bytes) <= 4_000_000, "SCENE_RECOVERY_JOURNAL_INVALID")
    doc = value.document
    local_a = doc.get("schema_version") == "scene-local-recovery-journal-v3"
    zero_start = doc.get("schema_version") == JOURNAL_VERSION
    ledger_fields = {"unstarted"} if zero_start else {"local_a"} if local_a else {"rows", "gateway_trust"}
    require(
        doc.get("schema_version")
        in {"scene-local-recovery-journal-v2", "scene-local-recovery-journal-v3", JOURNAL_VERSION}
        and set(doc)
        == {
            "schema_version",
            "local_binding_digest",
            "checkpoint_state",
            *ledger_fields,
            "server_binding_digest",
            "files",
            "unresolved_calls",
            "quiescent",
        },
        "SCENE_RECOVERY_PORTABLE_JOURNAL_REQUIRED",
    )
    require(doc["local_binding_digest"] == digest(stable_work(work)), "SCENE_RECOVERY_JOURNAL_INVALID")
    require(doc["unresolved_calls"] is False and doc["quiescent"] is True, "SCENE_RECOVERY_UNRESOLVED_CALLS")
    from task_source.scene_checkpoint import verify_local_rows, verify_event_bindings

    if zero_start:
        from task_source.scene_recovery_bootstrap import ParentRecoveryJournal
        from task_source.scene_unstarted_recovery import verify_zero_checkpoint

        require(
            type(value._remote) is ParentRecoveryJournal and value._local_a is None,
            "SCENE_RECOVERY_UNSTARTED_PARENT_REQUIRED",
        )
        value._remote.verify(doc)
        require(
            type(state["scene_recovery_generation"]) is int and state["scene_recovery_generation"] == 0,
            "SCENE_RECOVERY_UNSTARTED_GENERATION_INVALID",
        )
        verify_zero_checkpoint(
            doc["unstarted"]["expected_checkpoint"],
            work=work,
            binding_digest=doc["server_binding_digest"],
            generation=1,
        )
    elif local_a:
        from task_source.scene_local_recovery import verify_local_parent

        verify_local_parent(
            value, work, root, host=host, config=config, generation=state["scene_recovery_generation"] + 1
        )
    else:
        require(value._local_a is None and value._remote is None, "SCENE_RECOVERY_JOURNAL_INVALID")
        verify_local_rows(work, doc["rows"], doc["gateway_trust"])
    checkpoint({
        "binding_digest": "0" * 64,
        **doc["checkpoint_state"],
        **{
            key: {"count": 0, "digest": digest([])}
            for key in ("calls", "budget_reservations", "subscription_reservations")
        },
    })
    verify_files(root, doc["files"])
    total = work["trials_per_member"] * len(config.settlement.members)
    require(
        doc["checkpoint_state"]["progress"]["total_trials"] == state["progress"]["total_trials"] == total,
        "SCENE_RECOVERY_N_CHANGED",
    )
    completed = worker._completed_count(work, root, config, host)
    require(
        doc["checkpoint_state"]["progress"]["completed_trials"] <= completed <= total
        and state["progress"]["completed_trials"] <= completed,
        "SCENE_RECOVERY_EVIDENCE_MISSING",
    )
    allowed = {
        f"{member.id}-{trial}" for member in config.settlement.members for trial in range(work["trials_per_member"])
    }
    results = {path.stem for path in (root / "results").glob("*.json")}
    started = {path.stem for path in (root / "started").glob("*.json")}
    require(started <= results and results <= allowed, "SCENE_RECOVERY_PARTIAL_TRIAL")
    if not local_a and not zero_start:
        # Backend namespace only. Actual A has provider_meta.call_id at the
        # top level and no signed Backend gateway root in provider_meta.
        verify_event_bindings(work, root, doc["rows"], doc["files"])
    report = root / "report.json"
    if report.exists() or state.get("scene_report_sha256") or doc["checkpoint_state"]["report_digest"] is not None:
        worker._verify_scene_report(state, root, historical=True)
        from task_source.scene_report_ack import expected_identity

        require(
            state.get("scene_report_not_completed")
            == expected_identity(
                work, report.read_bytes(), worker_id=worker.client.worker_id, node_id=worker.client.node_id
            ),
            "SCENE_RECOVERY_REPORT_ACK_REQUIRED",
        )
    return (doc, completed, value) if with_parent else (doc, completed)


def held(worker, state, code):
    state = copy.deepcopy(state)
    code = code if re.fullmatch(r"[A-Z][A-Z0-9_:-]{0,79}", code) else "SCENE_RECOVERY_FAILED"
    state.update(
        phase="held",
        error_code=code,
        error_category="infra" if "JOURNAL" in code or code.endswith("UNAVAILABLE") else "authorization",
    )
    worker._state(state)  # Never send ordinary progress using an expired L or R.
    return "held"


def mint(excluded):
    for _ in range(8):
        value = secrets.token_urlsafe(32)
        if value not in excluded:
            return value
    raise SceneRecoveryError("SCENE_RECOVERY_CREDENTIAL_REUSED")


def adopt_initial_token(worker, state, path):
    """Import a control-plane R already registered by a separate Operator.

    This never calls scene-recovery-authorize or loads an Operator key, and
    cannot replace an existing/unknown-generation recovery credential.
    """
    require(
        "scene_recovery_token" not in state
        and "scene_recovery_generation" not in state
        and not state.get("scene_recovery_pending"),
        "SCENE_RECOVERY_CREDENTIAL_EXISTS",
    )
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        metadata = os.fstat(stream.fileno())
        require(
            stat.S_ISREG(metadata.st_mode)
            and stat.S_IMODE(metadata.st_mode) in (0o400, 0o600)
            and metadata.st_uid == os.getuid(),
            "SCENE_RECOVERY_CREDENTIAL_FILE_INVALID",
        )
        raw = stream.read(4097)
    require(len(raw) <= 4096, "SCENE_RECOVERY_CREDENTIAL_FILE_INVALID")
    value = decode(raw)
    require(
        isinstance(value, dict)
        and set(value) == {"run_id", "worker_id", "node_id", "recovery_token"}
        and value["run_id"] == state["work"]["run_id"]
        and value["worker_id"] == worker.client.worker_id
        and value["node_id"] == worker.client.node_id
        and token(value["recovery_token"])
        and value["recovery_token"] != state["work"]["lease_token"],
        "SCENE_RECOVERY_CREDENTIAL_FILE_INVALID",
    )
    state.update(scene_recovery_token=value["recovery_token"], scene_recovery_generation=0)
    worker._state(state)


def prepare_scene_resume(worker, *, credential_file=None, unstarted=False):
    try:
        state = read(worker.root / "state.json")
    except (OSError, ValueError):
        logging.getLogger(__name__).error("SCENE_RECOVERY_STATE_REQUIRED")
        return "held"
    try:
        work = scope(worker, state)
        require(work.get("status") != "completed" and state["phase"] != "completed", "SCENE_RECOVERY_COMPLETED")
        require(epoch(work["lease_expires_at"]) <= worker.scene.transport._clock(), "SCENE_RECOVERY_NOT_EXPIRED")
        lease_file = directory(worker, state) / "lease.json"
        if lease_file.exists():
            require(
                epoch(read(lease_file)["expires_at"]) <= worker.scene.transport._clock(), "SCENE_RECOVERY_NOT_EXPIRED"
            )
        if credential_file is not None:
            adopt_initial_token(worker, state, credential_file)
        if state.get("scene_recovery_pending"):
            state["phase"] = "scene_resuming"
            worker._state(state)
            return "resuming"
        recovery = state.get("scene_recovery_token")
        require(token(recovery) and recovery != work["lease_token"], "SCENE_RECOVERY_CREDENTIAL_REQUIRED")
        generation = state.get("scene_recovery_generation")
        require(type(generation) is int and generation >= 0, "SCENE_RECOVERY_JOURNAL_REQUIRED")
        journal, completed, prepared = preflight(worker, state, with_parent=True, unstarted=unstarted)
        used = {work["lease_token"], recovery}
        values = []
        for _ in range(3):
            value = mint(used)
            values.append(value)
            used.add(value)
        body = {
            "worker_id": worker.client.worker_id,
            "node_id": worker.client.node_id,
            "recovery_token": recovery,
            "lease_token": values[0],
            "next_recovery_token": values[1],
            "nonce": values[2],
        }
        validate_request(work, body, worker_id=worker.client.worker_id, node_id=worker.client.node_id)
        state["scene_recovery_pending"] = {
            "request": body,
            "request_digest": digest(body),
            "base_generation": generation,
            "journal": journal,
            "local_completed_trials": completed,
        }
        if prepared._remote is not None:
            state["scene_recovery_pending"]["parent_preflight_proof"] = prepared._remote.proof
        state["phase"] = "scene_resuming"
        worker._state(state)  # Entire pending body is fsync/atomic BEFORE HTTP.
        return "resuming"
    except SceneRecoveryError as exc:
        return held(worker, state, str(exc))
    except ValueError as exc:
        return held(worker, state, str(exc))
    except Exception:
        return held(worker, state, "SCENE_RECOVERY_JOURNAL_UNAVAILABLE")


def finish_scene_resume(worker, state):
    """Continue only an already explicitly authorized durable transaction."""
    committed = False
    try:
        work = scope(worker, state)
        item = state["scene_recovery_pending"]
        body = item["request"]
        validate_request(work, body, worker_id=worker.client.worker_id, node_id=worker.client.node_id)
        require(
            body["recovery_token"] == state["scene_recovery_token"]
            and digest(body) == item["request_digest"]
            and type(item["base_generation"]) is int
            and type(state["scene_recovery_generation"]) is int
            and item["base_generation"] == state["scene_recovery_generation"],
            "SCENE_RECOVERY_PENDING_CHANGED",
        )
        journal, completed, parent = preflight(worker, state, with_parent=True)
        require(
            journal == item["journal"] and completed == item["local_completed_trials"], "SCENE_RECOVERY_JOURNAL_CHANGED"
        )
        response = worker.client.scene_resume(work, body)
        require(
            isinstance(response, dict)
            and set(response) == {"work", "recovery_generation", "checkpoint", "checkpoint_digest"},
            "SCENE_RECOVERY_REPLY_INVALID",
        )
        require(
            type(response["recovery_generation"]) is int
            and response["recovery_generation"] == item["base_generation"] + 1,
            "SCENE_RECOVERY_GENERATION_INVALID",
        )
        checkpoint(response["checkpoint"])
        require(response["checkpoint_digest"] == digest(response["checkpoint"]), "SCENE_RECOVERY_CHECKPOINT_MISMATCH")
        require("portable" in response["checkpoint"], "SCENE_RECOVERY_PORTABLE_REQUIRED")
        from task_source.scene_checkpoint import reconcile

        receipt = {
            "checkpoint": copy.deepcopy(response["checkpoint"]),
            "checkpoint_digest": response["checkpoint_digest"],
            "recovery_generation": response["recovery_generation"],
            # Keep HTTP-before independent expectations after pending is removed.
            "expected_journal": copy.deepcopy(item["journal"]),
            **(
                {"parent_preflight_proof": copy.deepcopy(item["parent_preflight_proof"])}
                if "parent_preflight_proof" in item
                else {}
            ),
            "reconciliation": {"matched": False, "execution_authorized": False, "rerun_authorized": False},
        }
        state = copy.deepcopy(state)
        state["scene_recovery_pending"]["server_receipt"] = receipt
        worker._state(state)  # Server fact durably saved BEFORE reconciliation.
        receipt["reconciliation"] = reconcile(
            journal,
            response["checkpoint"],
            run_id=work["run_id"],
            generation=response["recovery_generation"],
            local_a=parent._local_a,
            remote=parent._remote,
        )
        state["scene_recovery_pending"]["server_receipt"] = receipt
        worker._state(state)
        new_work = normalize_scene_work(response["work"])
        require(
            new_work["lease_token"] == body["lease_token"]
            and new_work["status"] == "running"
            and stable_work(new_work) == stable_work(work),
            "SCENE_RECOVERY_WORK_CHANGED",
        )
        metadata = frozen_context(new_work, new_work["task"])
        bind_scene_context(work, metadata)
        worker.scene.evaluation_context(new_work, metadata)
        verify_files(directory(worker, state), journal["files"])
        require(preflight(worker, state) == (journal, completed), "SCENE_RECOVERY_JOURNAL_CHANGED")
        state = copy.deepcopy(state)
        state.update(
            work=new_work,
            scene_recovery_token=body["next_recovery_token"],
            scene_recovery_generation=response["recovery_generation"],
            scene_recovery_receipt=receipt,
            scene_recovery_last={
                "request_digest": item["request_digest"],
                "checkpoint_digest": response["checkpoint_digest"],
                "generation": response["recovery_generation"],
            },
        )
        state.pop("scene_recovery_pending")
        state.pop("error_code", None)
        state.pop("error_category", None)
        state["progress"] = {**state["progress"], "completed_trials": completed}
        state["phase"] = "reporting" if (directory(worker, state) / "report.json").exists() else "claimed"
        worker._state(state)  # One atomic L/R switch; old pending secrets removed.
        committed = True
        worker._scene_context(state)  # New L must pass current read-only trust again.
        if worker.scene_recovery_reader is not None:
            from task_source.scene_commitment import ensure_commitment

            ensure_commitment(worker, state, directory(worker, state))
        return "resumed"
    except PanelAPIError as exc:
        if committed:
            return held(worker, state, "SCENE_RECOVERY_REFRESH_UNAVAILABLE")
        if exc.status in (None, 429) or exc.status >= 500:
            state.update(error_code="SCENE_RECOVERY_RESPONSE_PENDING", error_category="infra")
            worker._state(state)
            return "retry"
        return held(worker, state, "SCENE_RECOVERY_REJECTED")
    except SceneRecoveryError as exc:
        return held(worker, state, str(exc))
    except ValueError as exc:
        return held(worker, state, str(exc))
    except Exception:
        if committed:
            return held(worker, state, "SCENE_RECOVERY_REFRESH_UNAVAILABLE")
        return held(worker, state, "SCENE_RECOVERY_JOURNAL_UNAVAILABLE")
