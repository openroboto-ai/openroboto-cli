"""Authenticated A leases; credentials remain in private control-plane state."""

from __future__ import annotations
import json
import math
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Mapping


class PanelAPIError(RuntimeError):
    def __init__(self, status: int | None, code: str):
        super().__init__(f"A evaluation API: {code} (HTTP {status})")
        self.status, self.code = status, code


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def _no_store(headers):
    values = [
        value for key, value in (headers.items() if headers is not None else ()) if key.lower() == "cache-control"
    ]
    return any("no-store" in {part.strip().lower() for part in value.split(",")} for value in values)


def contains_recovery_material(value, protected=()):
    """Recovery credentials are control-plane only, never execution metadata."""
    if isinstance(value, Mapping):
        return any(
            key in {"scene_recovery_token", "recovery_token", "next_recovery_token"}
            or (isinstance(key, str) and any(secret and secret in key for secret in protected))
            or contains_recovery_material(item, protected)
            for key, item in value.items()
        )
    if isinstance(value, list):
        return any(contains_recovery_material(item, protected) for item in value)
    return isinstance(value, str) and any(secret and secret in value for secret in protected)


class PanelClient:
    def __init__(
        self,
        base_url: str,
        key: str,
        worker_id: str,
        node_id: str,
        *,
        timeout_s: float = 60,
        report_timeout_s: float = 600,
    ):
        parsed = urllib.parse.urlsplit(base_url)
        if (
            parsed.scheme not in ("http", "https")
            or not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
        ):
            raise ValueError("backend URL must be credential-free HTTP(S)")
        if not key or not worker_id or not node_id:
            raise ValueError("worker credentials and IDs required")
        if any(not math.isfinite(value) or value <= 0 for value in (timeout_s, report_timeout_s)):
            raise ValueError("API timeouts must be positive finite seconds")
        self.base_url = base_url.rstrip("/")
        self._key = key
        self.worker_id = worker_id
        self.node_id = node_id
        self.timeout_s = timeout_s
        self.report_timeout_s = report_timeout_s

    def request(
        self,
        path: str,
        body: Mapping,
        *,
        timeout_s: float | None = None,
        envelope_only: bool = False,
        require_no_store: bool = False,
        capture_response: bool = False,
    ):
        req = urllib.request.Request(
            self.base_url + path,
            data=json.dumps(body, ensure_ascii=False, allow_nan=False).encode(),
            method="POST",
            headers={
                "X-API-Key": self._key,
                "Content-Type": "application/json",
                "Accept": "application/vnd.openroboto.envelope+json" + ("" if envelope_only else ", application/json"),
                **({"Cache-Control": "no-store"} if require_no_store else {}),
            },
        )
        try:
            with urllib.request.build_opener(_NoRedirect()).open(
                req,
                timeout=self.timeout_s if timeout_s is None else timeout_s,
            ) as response:
                if require_no_store and not _no_store(getattr(response, "headers", None)):
                    raise PanelAPIError(409, "SCENE_ACK_CACHE_POLICY_INVALID")
                if capture_response:
                    raw = response.read(65537)
                    if len(raw) > 65536:
                        raise PanelAPIError(409, "SCENE_COMMITMENT_RESPONSE_LIMIT")
                    payload = json.loads(raw)
                    captured = {"response_bytes": raw.hex(), "cache_control": response.headers.get("Cache-Control", "")}
                else:
                    payload = json.load(response)
        except urllib.error.HTTPError as exc:
            if require_no_store and not _no_store(exc.headers):
                raise PanelAPIError(409, "SCENE_ACK_CACHE_POLICY_INVALID") from None
            try:
                payload = json.loads(exc.read())
            except (ValueError, OSError):
                payload = {}
            error = payload.get("error", payload) if isinstance(payload, dict) else {}
            code = str(error.get("code", "HTTP_ERROR"))
            if not code.replace("_", "").replace("-", "").isalnum():
                code = "HTTP_ERROR"
            protected = [
                body.get(key)
                for key in ("lease_token", "scene_recovery_token", "recovery_token", "next_recovery_token", "nonce")
            ]
            if any(isinstance(secret, str) and secret and secret in code for secret in protected):
                code = "HTTP_ERROR"
            raise PanelAPIError(exc.code, code) from None
        except (urllib.error.URLError, OSError, ValueError):
            raise PanelAPIError(None, "NETWORK_OR_RESPONSE_ERROR") from None
        if not isinstance(payload, dict):
            raise PanelAPIError(None, "INVALID_RESPONSE")
        if envelope_only and ("data" not in payload or not isinstance(payload.get("meta"), dict)):
            raise PanelAPIError(409, "SCENE_ENVELOPE_INVALID")
        data = payload.get("data", payload)
        if not isinstance(data, dict):
            raise PanelAPIError(None, "INVALID_RESPONSE")
        return {"data": data, **captured} if capture_response else data

    def scene_recovery_commitment(self, work, recovery_token):
        """R15: read original enrollment while L/R and lease are still current.

        Only this parent client receives R. The captured response, not the
        request credentials, is persisted before any paid scene is started.
        """
        from task_source.scene_commitment import commitment_receipt

        if not isinstance(recovery_token, str) or not 32 <= len(recovery_token) <= 200:
            raise PanelAPIError(409, "SCENE_RECOVERY_CREDENTIAL_REQUIRED")
        run = urllib.parse.quote(work["run_id"], safe="")
        path = f"/api/v1/task/evaluation/{run}/scene-recovery-commitment"
        body = {**self._owner(work), "recovery_token": recovery_token}
        try:
            captured = self.request(path, body, envelope_only=True, require_no_store=True, capture_response=True)
        except PanelAPIError as exc:
            if exc.code == "SCENE_ACK_CACHE_POLICY_INVALID":
                raise PanelAPIError(exc.status, "SCENE_RECOVERY_COMMITMENT_CACHE_POLICY_INVALID") from None
            raise
        if contains_recovery_material(captured, [recovery_token, work["lease_token"]]):
            raise PanelAPIError(409, "SCENE_RECOVERY_MATERIAL_EXPOSED")
        from task_source.scene_views.identity import decode

        if contains_recovery_material(
            decode(bytes.fromhex(captured["response_bytes"])), [recovery_token, work["lease_token"]]
        ):
            raise PanelAPIError(409, "SCENE_RECOVERY_MATERIAL_EXPOSED")
        return commitment_receipt(self, work, captured)

    def claim(self, competition_id: int, *, lease_token: str, scene_recovery_token: str | None = None):
        payload = {
            "competition_id": competition_id,
            "worker_id": self.worker_id,
            "node_id": self.node_id,
            "lease_token": lease_token,
        }
        if scene_recovery_token is not None:
            if (
                not isinstance(scene_recovery_token, str)
                or not 32 <= len(scene_recovery_token) <= 200
                or scene_recovery_token == lease_token
            ):
                raise ValueError("SCENE_RECOVERY_CREDENTIAL_INVALID")
            payload["scene_recovery_token"] = scene_recovery_token
        work = self.request(
            "/api/v1/task/evaluation/claim",
            payload,
        ).get("work")
        if work is not None:
            if not isinstance(work, dict) or not isinstance(work.get("task"), dict):
                raise PanelAPIError(409, "CLAIM_SHAPE_INVALID")
            from task_source.scene_dispatch import is_scene_task

            if is_scene_task(work.get("task", {})):
                from task_source.scene_adapter import normalize_scene_work
                from task_source.scene_transport import SceneTransportError

                try:
                    if contains_recovery_material(work, [scene_recovery_token] if scene_recovery_token else []):
                        raise ValueError("recovery material in execution metadata")
                    work = normalize_scene_work(work)
                    assignment = work["task"]["assignment"]
                    if (
                        assignment["worker_id"] != self.worker_id
                        or assignment["node_id"] != self.node_id
                        or work["task"]["competition_id"] != competition_id
                    ):
                        raise ValueError("scene owner mismatch")
                except (SceneTransportError, ValueError, KeyError, TypeError):
                    raise PanelAPIError(409, "SCENE_METADATA_INVALID") from None
        return work

    def scene_resume(self, work, pending):
        """Send the exact precommitted transaction. Never generate tokens here."""
        from task_source.scene_recovery import validate_request

        validate_request(work, pending, worker_id=self.worker_id, node_id=self.node_id)
        run = urllib.parse.quote(work["run_id"], safe="")
        data = self.request(f"/api/v1/task/evaluation/{run}/scene-resume", dict(pending), envelope_only=True)
        if isinstance(data, Mapping) and contains_recovery_material(
            data, [pending[key] for key in ("recovery_token", "next_recovery_token", "nonce")]
        ):
            raise PanelAPIError(409, "SCENE_RECOVERY_MATERIAL_EXPOSED")
        return data

    def report_ack(self, work, expected):
        """Current owner authentication, read-only original-byte ACK only."""
        from task_source.scene_report_ack import validate_expected, validate_ack

        validate_expected(expected)
        run = urllib.parse.quote(work["run_id"], safe="")
        data = self.request(
            f"/api/v1/task/evaluation/{run}/report-ack",
            {**self._owner(work), "expected": dict(expected)},
            envelope_only=True,
            require_no_store=True,
        )
        try:
            return validate_ack(data, work, expected, worker_id=self.worker_id, node_id=self.node_id)
        except (ValueError, KeyError, TypeError):
            raise PanelAPIError(409, "SCENE_REPORT_ACK_INVALID") from None

    def progress(self, work: Mapping, stage: str, detail: Mapping):
        run = urllib.parse.quote(work["run_id"], safe="")
        return self.request(
            f"/api/v1/task/evaluation/{run}/progress",
            {
                "worker_id": self.worker_id,
                "node_id": self.node_id,
                "lease_token": work["lease_token"],
                "stage": stage,
                "detail": dict(detail),
            },
        )

    def report(self, work: Mapping, payload: Mapping):
        return self.request(
            "/api/v1/task/discrimination",
            {**payload, "worker_id": self.worker_id, "lease_token": work["lease_token"]},
            timeout_s=self.report_timeout_s,
        )

    def _owner(self, work):
        return {"worker_id": self.worker_id, "node_id": self.node_id, "lease_token": work["lease_token"]}

    def scene_context(self, work):
        """Read current registered trust for this existing run; never claim/renew."""
        from task_source.scene_adapter import refreshed_context
        from task_source.scene_transport import SceneTransportError

        run = urllib.parse.quote(work["run_id"], safe="")
        data = self.request(f"/api/v1/task/evaluation/{run}/scene-context", self._owner(work), envelope_only=True)
        try:
            data = refreshed_context(work, data)
        except (SceneTransportError, ValueError, KeyError, TypeError):
            raise PanelAPIError(409, "SCENE_METADATA_INVALID") from None
        if (
            data.get("run_id") != work["run_id"]
            or data.get("worker_id") != self.worker_id
            or data.get("node_id") != self.node_id
        ):
            raise PanelAPIError(409, "SCENE_CONTEXT_OWNER_MISMATCH")
        return data

    def archive_file(self, work, path, checkpoint, *, kind, metadata=None, uploader=None):
        from task_source.panel_transfer import ResumableUpload, file_identity

        run = urllib.parse.quote(work["run_id"], safe="")
        if kind not in ("report", "videos"):
            raise ValueError("unsupported A archive kind")
        body = {**self._owner(work), **(metadata or {}), **file_identity(path)}
        base = f"/api/v1/task/evaluation/{run}/{kind}"

        def presign(identity):
            if any(identity[key] != body[key] for key in ("sha256", "bytes_len", "md5_b64")):
                raise PanelAPIError(None, "UPLOAD_CONTENT_CHANGED")
            return self.request(base + "/presign", body)

        (uploader or ResumableUpload()).upload(path, checkpoint, presign=presign)
        return self.request(base + "/commit", body, timeout_s=self.report_timeout_s)

    def report_archive(self, work, path, checkpoint):
        return self.archive_file(work, path, checkpoint, kind="report")

    def video_archive(self, work, path, checkpoint, metadata):
        return self.archive_file(work, path, checkpoint, kind="videos", metadata=metadata)
