"""真实物理子步驱动的目标程序；过程违规锁存、阶段不追认、不跨reset。"""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Mapping

from openroboto_protocol.tabletop_assets import canonical_digest
from openroboto_protocol.tabletop_v2 import profile_catalog

from .tabletop_geometry import assets, pose_error, projection_radius, valid_state


def _robot(name):
    return name == "robot" or name.startswith("franka/")


def _contact_pairs(state, first, second):
    for c in state["contacts"]:
        a, b = c["a"], c["b"]
        if a == first and (b == second or second == "robot" and _robot(b)):
            yield c, 1
        elif b == first and (a == second or second == "robot" and _robot(a)):
            yield c, -1


def evaluate_predicate(predicate, state, definition, *, resolver=None):
    """只从受信运行时实际状态求值；未知谓词抛错，坏状态fail closed。"""
    kind = predicate.get("type")
    known = {"all", "any", "not", "in_zone", "pose", "stable", "released", "supported_by", "no_contact", "matching"}
    if kind not in known:
        raise ValueError(f"unknown predicate {kind!r}")
    if not valid_state(state, definition) or resolver is not None and not resolver.valid(state, definition):
        return False
    return _evaluate(predicate, state, definition, resolver)


def _evaluate(p, state, definition, resolver=None):
    if resolver is not None:
        return resolver.evaluate(p, state, definition)
    kind = p["type"]
    if kind == "all":
        return all(_evaluate(c, state, definition) for c in p["children"])
    if kind == "any":
        return any(_evaluate(c, state, definition) for c in p["children"])
    if kind == "not":
        return not _evaluate(p["child"], state, definition)
    catalog = assets()
    objects = {o["id"]: o for o in definition["objects"]}
    zones = {z["id"]: z for z in definition["zones"]}
    if kind == "matching":
        # Capacity slots plus augmenting paths avoid greedy matching false rejects.
        slots = [z for z in p["zone_ids"] for _ in range(zones[z]["capacity"])]
        assigned = {}

        def place(name, visited):
            for i, z in enumerate(slots):
                if i in visited or not _evaluate(
                    {"type": "in_zone", "object_id": name, "zone_id": z}, state, definition
                ):
                    continue
                visited.add(i)
                if i not in assigned or place(assigned[i], visited):
                    assigned[i] = name
                    return True
            return False

        return all(place(name, set()) for name in p["object_ids"])
    name = p["object_id"]
    asset = catalog[objects[name]["asset_id"]]
    success = _SUCCESS
    if kind == "in_zone":
        zone = zones[p["zone_id"]]
        return (
            asset["id"] in zone["accepts"]
            and projection_radius(asset, state["positions"][name], state["orientations"][name], zone["position"])
            <= zone["radius_m"]
        )
    if kind == "pose":
        return pose_error(asset, state["orientations"][name], p["quaternion"]) <= success["pose_tolerance_rad"]
    if kind == "stable":
        return (
            math.sqrt(sum(v * v for v in state["linear_velocities"][name])) <= success["max_linear_speed_m_s"]
            and math.sqrt(sum(v * v for v in state["angular_velocities"][name])) <= success["max_angular_speed_rad_s"]
        )
    if kind == "released":
        fingers = [state.get("joints", {}).get(f"franka/panda_finger_joint{i}", -1) for i in [1, 2]]
        return all(
            type(v) in (float, int) and math.isfinite(v) and v >= success["finger_open_min_m"] for v in fingers
        ) and _evaluate({"type": "no_contact", "object_id": name, "other_id": "robot"}, state, definition)
    if kind == "no_contact":
        return not any(
            c.get("distance_m", 0) <= 0
            or math.sqrt(sum(v * v for v in c["force_on_b"])) > success["contact_force_min_n"]
            for c, _ in _contact_pairs(state, name, p["other_id"])
        )
    if kind == "supported_by":
        # force_on_b points into body b. Support must carry the object's weight
        # upward, with a contact point below its measured centre of mass.
        center = state.get("centers_of_mass", {}).get(name, state["positions"][name])
        vertical = 0.0
        for contact, sign in _contact_pairs(state, name, p["support_id"]):
            upward = -sign * contact["force_on_b"][2]
            normal = contact.get("normal_on_b", [0, 0, 0])
            if upward > 0 and -sign * normal[2] >= 0.5 and contact["point"][2] <= center[2]:
                vertical += upward
        return vertical >= asset["mass_kg"] * 9.81 * success["support_min_weight_fraction"]
    raise ValueError(f"unknown predicate {kind!r}")


_SUCCESS = profile_catalog()["success"]


class ProgramMonitor:
    """一个env/reset一个状态机；只接受连续tick和实际状态，无作者过程输入。"""

    def __init__(self, definition: Mapping[str, Any], *, resolver=None):
        self.definition = definition
        self.resolver = resolver
        self.digest = canonical_digest(definition)
        dependencies = {r for s in definition["stages"] for r in s["requires"]}
        self.leaves = {s["id"] for s in definition["stages"] if s["id"] not in dependencies}
        self.reset()

    def reset(self):
        self.tick = -1
        self.completed = {}
        self.holds = {s["id"]: 0 for s in self.definition["stages"]}
        self.violation = None
        self.root = "0" * 64
        self.passed = False

    def update(self, state, tick):
        if type(tick) is not int or tick != self.tick + 1:
            raise ValueError("program samples must use consecutive integer physics ticks")
        self.tick = tick
        physical_valid = valid_state(state, self.definition) and (
            self.resolver is None or self.resolver.valid(state, self.definition)
        )
        if not physical_valid:
            self.violation = self.violation or {"tick": tick, "reason": "invalid_physical_state"}
        if not self.violation:

            def invariant(p, scope):
                if not _evaluate(p, state, self.definition, self.resolver):
                    self.violation = self.violation or {
                        "tick": tick,
                        "reason": "invariant",
                        "scope": scope,
                        "predicate": p,
                    }

            for p in self.definition["invariants"]:
                invariant(p, "episode")
            previous = dict(self.completed)
            for stage in self.definition["stages"]:
                name = stage["id"]
                active = all(r in previous and previous[r] < tick for r in stage["requires"])
                good = _evaluate(stage["goal"], state, self.definition, self.resolver)
                if stage["reject_early"] and not active and good:
                    self.violation = self.violation or {"tick": tick, "reason": "early_stage", "stage": name}
                if active:
                    if name not in previous:
                        for p in stage["invariants"]:
                            invariant(p, name)
                    # Tick zero validates reset invariants but contributes no elapsed time.
                    self.holds[name] = self.holds[name] + 1 if good and tick > 0 else 0
                    if self.holds[name] >= stage["hold_ticks"] and name not in previous:
                        self.completed[name] = tick
                else:
                    self.holds[name] = 0
            self.passed = (
                not self.violation
                and len(self.completed) == len(self.definition["stages"])
                and all(
                    self.holds[s["id"]] >= s["hold_ticks"] for s in self.definition["stages"] if s["id"] in self.leaves
                )
            )
        else:
            self.passed = False
        # The independent replay can reproduce every substep digest from actions.
        encoded = (
            json.dumps({"tick": tick, "physical": state}, sort_keys=True, separators=(",", ":"), allow_nan=False)
            if physical_valid
            else f"invalid:{tick}"
        )
        self.root = hashlib.sha256((self.root + encoded).encode()).hexdigest()
        return self.snapshot()

    def snapshot(self):
        return {
            "schema_version": 1,
            "definition_digest": self.digest,
            "tick": self.tick,
            "passed": bool(self.passed),
            "completed": dict(self.completed),
            "holds": dict(self.holds),
            "violation": self.violation,
            "trace_digest": self.root,
        }
