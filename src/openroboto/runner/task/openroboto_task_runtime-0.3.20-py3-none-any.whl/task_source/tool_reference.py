"""可信准入端在公开工具、冻结权限与预算内重放参考操作。

输入只含 JSON 动作；不运行题包代码。证明原文放在签名准入 verdict 中，
题包仍然由原始内容摘要标识，证明不会写回题包形成摘要自引用。
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import time
from contextlib import nullcontext
from collections.abc import Mapping
from typing import Any

from .execution_contract import execution_contract_digest, parse_execution_contract, verify_execution_runtime
from .package import package_digest


def _digest(raw: Any) -> str:
    text = json.dumps(raw, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(text.encode()).hexdigest()


def _is_finite_number(raw: Any) -> bool:
    if type(raw) not in (int, float):
        return False
    try:
        return math.isfinite(float(raw))
    except (OverflowError, ValueError):
        return False


def _tool_action(raw: Any) -> tuple[str, dict[str, Any]]:
    from agent_harness.tools import TOOL_SPECS

    if not isinstance(raw, Mapping) or set(raw) != {"name", "args"}:
        raise ValueError("reference tool action must contain exactly name and args")
    name, args = raw["name"], raw["args"]
    specs = {entry["name"]: entry["input_schema"] for entry in TOOL_SPECS}
    if not isinstance(name, str) or name not in specs or not isinstance(args, Mapping):
        raise ValueError("reference tool action must name a published tool with object arguments")
    schema = specs[name]
    properties = schema["properties"]
    if set(args) - set(properties) or set(schema["required"]) - set(args):
        raise ValueError("reference tool arguments do not match the published tool")
    for key, value in args.items():
        rule = properties[key]
        kind = rule["type"]
        if kind == "integer" and type(value) is not int:
            raise ValueError(f"{name}.{key} must be an integer")
        if kind == "number" and (not _is_finite_number(value)):
            raise ValueError(f"{name}.{key} must be finite numeric")
        if kind == "array" and (
            not isinstance(value, list) or not value or any(not _is_finite_number(x) for x in value)
        ):
            raise ValueError(f"{name}.{key} must be a finite numeric array")
        if "minimum" in rule and value < rule["minimum"] or "maximum" in rule and value > rule["maximum"]:
            raise ValueError(f"{name}.{key} is outside the published range")
    return name, dict(args)


def verify_tool_reference(task: Any, source: Any, options: Any, *, deadline: float = math.inf) -> dict[str, Any]:
    """缺合同或失败只撤销难题资格，不把运行错误当模型失败或改写原准入结果。"""
    proof: dict[str, Any] = {
        "version": 1,
        "task_id": task.task_id,
        "required_instances": [entry.instance for entry in task.instances],
        "instances": [],
        "verified": False,
        "reason": "unverified",
    }
    scene = "imported_scene" in task.metadata

    def deadline_failure(message):
        if scene:
            from .scene_env import SceneDeadlineExceeded

            raise SceneDeadlineExceeded(message)
        raise ValueError(message)

    try:
        if task.source != "axis":
            raise ValueError("tool reference proof supports only the registered AXIS runtime")
        if not isinstance(options, Mapping) or set(options) != {"config_digest", "execution_contract"}:
            raise ValueError("tool_reference requires config_digest and execution_contract")
        config_digest = options["config_digest"]
        if not isinstance(config_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", config_digest):
            raise ValueError("config_digest must be 64 lowercase hex characters")
        contract = parse_execution_contract(options["execution_contract"])
        from agent_harness.manifest import agent_binding
        from agent_harness.runtimes import AxisToolRuntime
        from agent_harness.tools import execute_tool

        if contract["agent"] != agent_binding():
            raise ValueError("reference contract does not match the loaded harness/tools/prompt identity")
        proof.update({
            "config_digest": config_digest,
            "execution_contract": contract,
            "contract_digest": execution_contract_digest(contract),
            "package_digest": package_digest(task.package_dir),
        })
        required = proof["required_instances"]
        if not required or len(set(required)) != len(required):
            raise ValueError("reference proof requires a nonempty unique instance set")
        budget = contract["budget"]
        for entry in task.instances:
            if time.monotonic() > deadline:
                deadline_failure("admission deadline reached before tool reference replay")
            reference = task.reference_for(entry.instance) or {}
            actions = reference.get("tool_actions")
            if not isinstance(actions, list) or not actions or len(actions) > budget["max_api_calls"]:
                raise ValueError(f"instance {entry.instance}: missing tool actions or max_api_calls exceeded")
            parsed = [_tool_action(action) for action in actions]
            started = time.monotonic()
            if scene:
                from .scene_authoring import source_deadline

                guard = source_deadline(source, min(deadline, started + budget["wall_seconds"]))
            else:
                guard = nullcontext()
            with guard:
                runtime = AxisToolRuntime(task, entry.instance, source, max_steps=budget["max_steps"])
            if not scene:
                # Preserve the original v1/v2 proof wall-clock boundary:
                # constructor/reset cost was not part of the per-instance timer.
                started = time.monotonic()
            recorded = []
            attempted_control = None
            completed_tools = 0
            original_step = runtime.env.step

            def capture(action):
                nonlocal attempted_control
                value = [float(v) for v in action]
                attempted_control = value
                result = original_step(action)
                recorded.append(value)
                attempted_control = None
                return result

            if scene:
                runtime.env.step = capture
            try:
                execution_runtime = verify_execution_runtime(contract, runtime)
                if "execution_runtime" in proof and proof["execution_runtime"] != execution_runtime:
                    raise ValueError("reference instances have different physical execution runtimes")
                proof["execution_runtime"] = execution_runtime
                if not scene:
                    runtime.reset()
                for name, args in parsed:
                    if time.monotonic() - started > budget["wall_seconds"] or time.monotonic() > deadline:
                        deadline_failure(f"instance {entry.instance}: wall budget exceeded")
                    execute_tool(runtime, name, args)
                    completed_tools += 1
                    if runtime.step_count > budget["max_steps"]:
                        raise ValueError(f"instance {entry.instance}: physical step budget exceeded")
                success, _ = runtime.success()
                wall_s = time.monotonic() - started
                final = dict(runtime.env.state())
                row = {
                    "instance": entry.instance,
                    "tool_actions": [{"name": name, "args": args} for name, args in parsed],
                    "steps": runtime.step_count,
                    "success": success is True,
                    "wall_s": wall_s,
                    "final_state": final,
                    "final_state_digest": _digest(final),
                }
                row["tool_actions_digest"] = _digest(row["tool_actions"])
                if scene:
                    row["actions"] = recorded
                    row["actions_digest"] = _digest(recorded)
                proof["instances"].append(row)
                if scene and (recorded != reference.get("actions") or final != reference.get("final_state")):
                    raise ValueError(f"instance {entry.instance}: tool replay differs from private raw recording")
                if scene and wall_s > budget["wall_seconds"]:
                    deadline_failure(f"instance {entry.instance}: wall budget exceeded")
                if success is not True or runtime.step_count <= 0 or wall_s > budget["wall_seconds"]:
                    raise ValueError(f"instance {entry.instance}: reference did not solve within the frozen budget")
            except Exception as exc:
                if scene and not any(row["instance"] == entry.instance for row in proof["instances"]):
                    proof["instances"].append({
                        "instance": entry.instance,
                        "success": False,
                        "steps": runtime.step_count,
                        "completed_controls": len(recorded),
                        "completed_tool_calls": completed_tools,
                        "tool_actions": [{"name": name, "args": args} for name, args in parsed],
                        "actions": recorded,
                        "attempted_control_action": attempted_control,
                        "final_state": dict(runtime.env.state()),
                        "wall_s": time.monotonic() - started,
                        "failure_type": type(exc).__name__,
                        "failure_reason": str(exc),
                    })
                raise
            finally:
                runtime.close() if hasattr(runtime, "close") else runtime.env.close()
        proof["verified"] = True
        proof["reason"] = "all_instances_solved_under_frozen_tools_permissions_and_budget"
    except Exception as exc:  # noqa: BLE001 - proof failures never mint H
        proof["reason"] = f"{type(exc).__name__}: {exc}"
        if scene:
            from .scene_env import SceneDeadlineExceeded

            if isinstance(exc, SceneDeadlineExceeded):
                proof["resource_error"] = {"code": "runtime.timeout", "capability": "resource_unavailable"}
    return proof
