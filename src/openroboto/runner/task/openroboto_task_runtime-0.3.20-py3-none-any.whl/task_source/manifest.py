"""准入证据 manifest（OPE-118）。

一次准入除了结论，还要留下**可独立验证的输入 / 输出摘要**。manifest 把散在
``Verdict.checks`` 里的检查归到固定的八项，每项带：

- ``input_hash``：这项检查读到了什么（题包摘要 + 题目规格 + 该项参数）；
- ``output_hash``：这项检查算出了什么（判定 + 完整 detail 的 canonical 哈希）；
- ``detail``：给人看的精简摘要（完整数据靠 output_hash 锁定，不重复存）。

八项名称是后端与 validator 的公共契约（顺序固定）：

``hash`` / ``solvable`` / ``deterministic`` / ``noise`` / ``nop`` /
``instruction`` / ``visibility`` / ``dedup``。

**不存原始轨迹**：回放帧、动作序列、仿真状态都在 ``output_hash`` 里，manifest
只留摘要。需要复现判定时用 :mod:`task_source.manifest_cli`（``verify-manifest``）
拿题包重跑，比对每项的 ``input_hash`` / ``output_hash``。

签名：validator 私钥对 **去掉 ``signature`` 的 canonical JSON** 做 Ed25519 签名。
``verdict_hash`` 绑定 ``POST /task/admit`` 的 ``verdict`` 字段 —— 否则一份有效
manifest 可以被配上另一个结论提交。后端按 ``node_id + key_id`` 查登记的
公钥验签，验不过就不落库。
"""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Iterable, Mapping, Sequence

from .base import AdmissionCheck, TaskSpec
from .package import TaskPackage

__all__ = [
    "CHECK_NAMES",
    "MANIFEST_VERSION",
    "build_manifest",
    "canonical_json",
    "manifest_hash",
    "manifest_inputs",
    "sign_manifest",
    "signing_payload",
    "verify_manifest",
]

MANIFEST_VERSION = 1

#: 八项准入检查。顺序是 manifest 的契约，后端按同一顺序校验。
CHECK_NAMES: tuple[str, ...] = (
    "hash",
    "solvable",
    "deterministic",
    "noise",
    "nop",
    "instruction",
    "visibility",
    "dedup",
)

#: 现有 check 名称 → manifest 八项。没列出的名字（``package_download``、
#: ``runtime.timeout`` 这类失败路径）归到它语义最接近的一项；完全不认识的
#: 名字归 ``hash``（它们都是「题包能不能被信任」这一层）。
_GROUPED: dict[str, str] = {
    "package": "hash",
    "task_load": "hash",
    "checker_registered": "solvable",
    "reference_covers_instances": "solvable",
    "solvable": "solvable",
    "runtime.solvable": "solvable",
    "deterministic": "deterministic",
    "runtime.deterministic": "deterministic",
    "runtime.noise": "noise",
    "not_freebie": "nop",
    "runtime.nop": "nop",
    "instruction_consistency": "instruction",
    "runtime.visibility": "visibility",
    "dedup": "dedup",
}
_PREFIX_GROUPS: tuple[tuple[str, str], ...] = (
    ("axis.", "hash"),
    ("robodojo.", "hash"),
    ("runtime.timeout", "hash"),
    ("runtime", "hash"),
    ("admission", "hash"),
    ("package_download", "hash"),
)

#: 精简 detail 里每条子检查的 JSON 上限（字符）。完整 detail 只在 output_hash
#: 里；这里的上限只是让人能直接看懂「哪一项错了」。
_DETAIL_LIMIT = 400


def canonical_json(value: Any) -> str:
    """确定性的 JSON 文本 —— 与后端 ``domain/admission_manifest.py`` 逐字相同。"""
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def _sha256_hex(value: str | bytes) -> str:
    if isinstance(value, str):
        value = value.encode("utf-8")
    return hashlib.sha256(value).hexdigest()


def canonical_sha256(value: Any) -> str:
    return _sha256_hex(canonical_json(_json_safe(value)))


def _json_safe(value: Any) -> Any:
    """把 ``inf`` / ``nan`` 换成字符串。

    ``compare_states`` 在形状不一致时返回 ``float("inf")``，而 canonical JSON
    禁止非有限浮点。哈希不能因此抛异常 —— 那会让一次已经跑完的准入丢掉证据。
    """
    if isinstance(value, float) and not math.isfinite(value):
        return "inf" if value > 0 else "-inf" if value < 0 else "nan"
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value


def _group_of(name: str) -> str:
    if name in _GROUPED:
        return _GROUPED[name]
    for prefix, group in _PREFIX_GROUPS:
        if name.startswith(prefix):
            return group
    return "hash"


def dedup_input(
    *,
    submitted_at: str | None = None,
    commit_block: int | None = None,
    submission_id: str | None = None,
) -> dict[str, Any]:
    """去重检查的提交侧输入。

    队列的 `submitted_at` / `commit_block` / `submission_id` 会改变
    `_dedup_check` 的匹配结果和 detail，必须进 ``dedup`` 项的 `input_hash`，
    否则同一份题包在不同提交上下文里会算出不同的 `output_hash`，而
    `input_hash` 看起来一样 —— 复现时只报 output 不一致，查不出原因。
    """
    return {
        "submitted_at": submitted_at,
        "commit_block": commit_block,
        "submission_id": submission_id,
    }


def manifest_inputs(
    task: TaskSpec,
    *,
    profile: Mapping[str, Any] | None = None,
    package: TaskPackage | None = None,
    submitted_at: str | None = None,
    commit_block: int | None = None,
    submission_id: str | None = None,
) -> dict[str, str]:
    """八项检查各自的输入摘要。

    输入是「这道题的冻结定义」：checker 结构、实例的 payload / 初始状态哈希、
    参考解哈希、指令文本，以及 profile 里影响检查的配置。题包摘要由调用方
    （worker）在下载后单独算，``build_manifest`` 再把它并进来。

    ``dedup`` 项额外包含提交侧的三项（见 :func:`dedup_input`）。
    """
    instance_digests = [
        {
            "instance": item.instance,
            "payload_sha256": item.payload_sha256,
            "checker_sha256": item.checker_sha256,
            "initial_state_sha256": item.initial_state_sha256,
        }
        for item in task.instances
    ]
    base = {
        "task_id": task.task_id,
        "source": task.source,
        "checker": canonical_sha256(task.checker_config),
        "instances": instance_digests,
        "reference": canonical_sha256(task.reference or {}),
        "instruction": _sha256_hex(task.instruction or ""),
        "profile": canonical_sha256(profile or {}),
    }
    if package is not None:
        base["package"] = {"source": package.source, "task_id": package.task_id}
    submission = dedup_input(
        submitted_at=submitted_at,
        commit_block=commit_block,
        submission_id=submission_id,
    )
    return {
        name: canonical_sha256(
            {
                **base,
                "check": name,
                **({"dedup_input": submission} if name == "dedup" else {}),
            }
        )
        for name in CHECK_NAMES
    }


def _detail_summary(checks: Sequence[AdmissionCheck]) -> dict[str, Any]:
    """精简 detail：只留子检查名字 / 结论 / 截断后的原 detail。"""
    sources: list[dict[str, Any]] = []
    for check in checks:
        text = json.dumps(_json_safe(check.detail), ensure_ascii=False, sort_keys=True, default=str)
        if len(text) > _DETAIL_LIMIT:
            text = text[: _DETAIL_LIMIT - 3] + "..."
        sources.append({
            "name": check.name,
            "ok": check.passed,
            "kind": check.kind,
            "detail": text,
        })
    return {"status": "run", "checks": sources}


def _not_run_summary(names: Iterable[str]) -> dict[str, Any]:
    return {"status": "not_run", "skipped_checks": list(names)}


def _build_check(
    name: str,
    checks: Sequence[AdmissionCheck],
    *,
    base_input: str,
    inputs: Mapping[str, str],
) -> dict[str, Any]:
    if not checks:
        return {
            "name": name,
            "ok": None,
            "input_hash": inputs.get(name) or canonical_sha256({"base": base_input, "check": name}),
            "output_hash": canonical_sha256({"check": name, "status": "not_run"}),
            "detail": _not_run_summary([name]),
        }
    ok = all(check.passed for check in checks)
    output = {
        "check": name,
        "ok": ok,
        "sources": [
            {
                "name": check.name,
                "ok": check.passed,
                "detail": _json_safe(check.detail),
            }
            for check in checks
        ],
    }
    return {
        "name": name,
        "ok": ok,
        "input_hash": inputs.get(name) or canonical_sha256({"base": base_input, "check": name}),
        "output_hash": canonical_sha256(output),
        "detail": _detail_summary(checks),
    }


def build_manifest(
    *,
    verdict: Any,
    package_digest: str,
    attempt: int,
    node_id: str,
    policy_version: str | int,
    started_at: str,
    finished_at: str,
    inputs: Mapping[str, str] | None = None,
    verdict_payload: Mapping[str, Any] | None = None,
    submission: Mapping[str, Any] | None = None,
    key_id: str = "",
    algorithm: str = "ed25519",
    task_id: str | None = None,
) -> dict[str, Any]:
    """把一次 ``Verdict`` 组装成 manifest（**未签名**）。

    ``package_digest`` 会并进每项的 ``input_hash`` —— 同一个 task_id 的两份
    不同字节的题包不能有相同的输入摘要。

    ``task_id`` 覆盖 manifest 顶层的题身份。生产 worker 必须传**后端队列的**
    ``task_id``（``task_<hotkey>_r<赛事>_v<n>``），因为后端用
    ``manifest.task_id == POST /task/admit 的 task_id`` 判断这份证据是不是
    这次回报的。题包 ``task.json`` 里的 ``task_id`` 是题源内部标识，不是
    提交身份；两者在本地 `--fetcher local` 和 HF 题包上都不保证相等。
    检查项自己的 ``input_hash`` 仍按题包身份计算（它们描述的是「读到了什么」）。
    """
    by_group: dict[str, list[AdmissionCheck]] = {name: [] for name in CHECK_NAMES}
    for check in verdict.checks:
        by_group[_group_of(check.name)].append(check)

    # 空的 ``inputs``（旧调用 / 失败路径）也要有稳定的输入摘要。
    resolved = dict(inputs or getattr(verdict, "manifest_inputs", {}) or {})
    base_input = canonical_sha256({
        "task_id": verdict.task_id,
        "source": verdict.source,
        "package_digest": package_digest,
    })

    checks = []
    for name in CHECK_NAMES:
        item = _build_check(
            name,
            by_group[name],
            base_input=base_input,
            inputs=resolved,
        )
        item["input_hash"] = canonical_sha256({"package_digest": package_digest, "check_input": item["input_hash"]})
        checks.append(item)

    return {
        "version": MANIFEST_VERSION,
        "task_id": task_id if task_id is not None else verdict.task_id,
        "source": verdict.source,
        "package_digest": package_digest,
        "attempt": int(attempt),
        "node_id": node_id,
        "key_id": key_id,
        "algorithm": algorithm,
        "policy_version": str(policy_version),
        "outcome": "admitted" if verdict.accepted else "rejected",
        "code": verdict.code,
        "reason": verdict.reason,
        # 绑定 POST /task/admit 的 verdict 字段：改结论会让签名失效。
        # 调用方传的是**实际要发出去的** payload（可能带 fingerprint）。
        "verdict_hash": canonical_sha256(
            verdict_payload if verdict_payload is not None else verdict.verdict()
        ),
        # 去重检查的提交侧输入。进签名：复现时必须拿来比对，而不是靠猜。
        "dedup_input": dedup_input(
            submitted_at=None if submission is None else submission.get("submitted_at"),
            commit_block=None if submission is None else submission.get("commit_block"),
            submission_id=None if submission is None else submission.get("submission_id"),
        ),
        "checks": checks,
        "started_at": started_at,
        "finished_at": finished_at,
    }


def signing_payload(manifest: Mapping[str, Any]) -> bytes:
    """签名消息：去掉 ``signature`` 的 canonical JSON。"""
    body = {key: value for key, value in manifest.items() if key != "signature"}
    return canonical_json(_json_safe(body)).encode("utf-8")


def manifest_hash(manifest: Mapping[str, Any]) -> str:
    """签名消息的 sha256。后端用同一算法重算，作为签名的可读锚点。"""
    return _sha256_hex(signing_payload(manifest))


def sign_manifest(manifest: Mapping[str, Any], signer: Any) -> dict[str, Any]:
    """用 validator 私钥签 manifest，返回带 ``signature`` 的新 dict。"""
    signed = dict(manifest)
    signed["algorithm"] = "ed25519"
    signed["signature"] = signer.sign_hex(signing_payload(manifest))
    return signed


def _verify_signature(manifest: Mapping[str, Any], public_key_hex: str) -> tuple[bool, str]:
    from agent_evidence import ed25519

    signature = manifest.get("signature")
    if not isinstance(signature, str) or not signature:
        return False, "manifest has no signature"
    try:
        signature_bytes = bytes.fromhex(signature)
        public_key = bytes.fromhex(public_key_hex)
    except ValueError as exc:
        return False, f"signature/public key is not hex: {exc}"
    if len(signature_bytes) != 64:
        return False, "signature must be 64 bytes"
    if len(public_key) != 32:
        return False, "public key must be 32 bytes"
    if not ed25519.verify(public_key, signing_payload(manifest), signature_bytes):
        return False, "signature does not match the manifest"
    return True, "ok"


def verify_manifest(
    manifest: Mapping[str, Any],
    *,
    public_key_hex: str | None = None,
    expected: Mapping[str, Any] | None = None,
) -> list[str]:
    """离线校验 manifest 的结构、签名和可选期望值。返回错误列表，空 = 通过。

    ``expected`` 可以带 ``task_id`` / ``package_digest`` / ``attempt`` /
    ``node_id`` / ``verdict_hash``，用于确认「这是不是我要复现的那一次」。
    """
    errors: list[str] = []
    version = manifest.get("version")
    if version != MANIFEST_VERSION:
        errors.append(f"unsupported manifest version {version!r}")

    checks = manifest.get("checks")
    if not isinstance(checks, list):
        errors.append("manifest.checks must be a list")
        return errors
    names = [item.get("name") for item in checks if isinstance(item, Mapping)]
    if tuple(names) != CHECK_NAMES:
        errors.append(f"manifest.checks must be the eight checks in order, got {names!r}")
    for item in checks:
        if not isinstance(item, Mapping):
            errors.append("manifest.checks contains a non-object entry")
            continue
        name = item.get("name")
        for field in ("input_hash", "output_hash"):
            value = item.get(field)
            if not isinstance(value, str) or len(value) != 64 or any(ch not in "0123456789abcdef" for ch in value):
                errors.append(f"check {name!r}: {field} must be 64 lowercase hex")
        if item.get("ok") not in (True, False, None):
            errors.append(f"check {name!r}: ok must be true, false, or null")

    for field in (
        "task_id",
        "package_digest",
        "attempt",
        "node_id",
        "policy_version",
        "started_at",
        "finished_at",
        "verdict_hash",
    ):
        if manifest.get(field) in (None, ""):
            errors.append(f"manifest.{field} is required")
    digest = manifest.get("package_digest")
    if isinstance(digest, str) and (len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest)):
        errors.append("manifest.package_digest must be 64 lowercase hex")

    submission = manifest.get("dedup_input")
    if not isinstance(submission, Mapping):
        errors.append("manifest.dedup_input must be an object")
    else:
        if set(submission) != {"submitted_at", "commit_block", "submission_id"}:
            errors.append(
                "manifest.dedup_input must contain submitted_at, commit_block, "
                "submission_id (null is allowed)"
            )
        if submission.get("submitted_at") is not None and not isinstance(
            submission.get("submitted_at"), str
        ):
            errors.append("manifest.dedup_input.submitted_at must be a string or null")
        if submission.get("commit_block") is not None and (
            isinstance(submission.get("commit_block"), bool)
            or not isinstance(submission.get("commit_block"), int)
        ):
            errors.append("manifest.dedup_input.commit_block must be an integer or null")
        if submission.get("submission_id") is not None and not isinstance(
            submission.get("submission_id"), str
        ):
            errors.append("manifest.dedup_input.submission_id must be a string or null")

    if expected:
        for field, value in expected.items():
            if manifest.get(field) != value:
                errors.append(f"manifest.{field} is {manifest.get(field)!r}, expected {value!r}")

    if public_key_hex is not None:
        ok, reason = _verify_signature(manifest, public_key_hex)
        if not ok:
            errors.append(reason)
    return errors
