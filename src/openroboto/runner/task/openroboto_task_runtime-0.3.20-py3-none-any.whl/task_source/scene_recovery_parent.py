"""Root helper's immutable originals and read-only recovery operations.

No scoring/native/model or recovery credentials enter this module. The child
archives an ALREADY P03-validated binding before READY and the original started
bytes before execution. A cold parent restores that exact operationally signed
snapshot; it does not run an expired lease through a relaxed P03 validator.
"""

from __future__ import annotations

import base64
from contextlib import contextmanager
import fcntl
import hashlib
import os
from pathlib import Path
import re
import stat
import sys
import time
from types import MappingProxyType, SimpleNamespace

from task_source.panel_state import read, write
from task_source.scene_episode_launcher import MAX_FRAME, digest, trusted_file, validate_receipt
from task_source.scene_episode_scope import EpisodeScopePlan, LinuxScopeKernel, require
from task_source.scene_views.identity import decode, encoded

ORIGINAL_DOMAIN = "openroboto:scene-recovery-original:v1"
OP_DOMAIN = "openroboto:scene-recovery-parent:v1"


def private_directory(path):
    path = Path(path)
    require(path.is_absolute() and path.resolve() == path, "SCENE_RECOVERY_PRIVATE_DIRECTORY_INVALID")
    info = path.lstat()
    require(
        stat.S_ISDIR(info.st_mode) and info.st_uid == 0 and stat.S_IMODE(info.st_mode) == 0o700,
        "SCENE_RECOVERY_PRIVATE_DIRECTORY_INVALID",
    )
    for parent in path.parents:
        info = parent.lstat()
        require(
            stat.S_ISDIR(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022,
            "SCENE_RECOVERY_PRIVATE_DIRECTORY_INVALID",
        )
    return path


def private_file(path):
    raw = trusted_file(path, limit=MAX_FRAME, private=True)
    require(Path(path).stat().st_nlink == 1, "SCENE_RECOVERY_PRIVATE_FILE_INVALID")
    return raw


def private_descriptor(fd):
    info = os.fstat(fd)
    require(
        stat.S_ISREG(info.st_mode) and info.st_uid == 0 and stat.S_IMODE(info.st_mode) == 0o600 and info.st_nlink == 1,
        "SCENE_RECOVERY_PRIVATE_FILE_INVALID",
    )


def archive_path(deployment, run_id):
    base = private_directory(deployment["recovery_archive_root"])
    # This path is independently registered as private, outside the native E.
    roots = [Path(p) for p in deployment["episode_policy"]["protected_roots"]]
    require(any(base == p or base.is_relative_to(p) for p in roots), "SCENE_RECOVERY_ARCHIVE_NOT_PROTECTED")
    return base / hashlib.sha256(run_id.encode()).hexdigest()[:24]


@contextmanager
def archive_guard(deployment, work, *, create=False):
    require(sys.platform == "linux" and os.geteuid() == 0, "SCENE_RECOVERY_PRIVILEGED_PARENT_REQUIRED")
    root = archive_path(deployment, work["run_id"])
    if create and not root.exists():
        root.mkdir(mode=0o700)
    private_directory(root)
    flags = os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC | (os.O_CREAT if create else 0)
    fd = os.open(root / "run.lock", flags, 0o600)
    try:
        private_descriptor(fd)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            require(False, "SCENE_RECOVERY_PARENT_STILL_ACTIVE")
        yield root
    finally:
        os.close(fd)


def root_sign(deployment, payload):
    from benchmark_worker.reference_panel.manifest import sign_manifest
    from agent_evidence.signing import Signer

    data = decode(trusted_file(deployment["launcher_key_file"], private=True))
    require(data.get("algorithm", "ed25519") == "ed25519", "SCENE_RECOVERY_PARENT_KEY_INVALID")
    signer = Signer(data["party"], data["key_id"], bytes.fromhex(data["seed"]))
    require(signer.key_id == deployment["key_id"] and signer.public_key_hex == deployment["public_key_hex"])
    return sign_manifest({**payload, "key_id": signer.key_id, "algorithm": "ed25519"}, signer.seed)


def root_verify(deployment, document, *, kind):
    from benchmark_worker.reference_panel.manifest import verify_manifest

    fields = {
        "commitment": {"work_binding", "commitment"},
        "prepared": {
            "request",
            "request_digest",
            "work_binding",
            "spec_bytes",
            "binding_document",
            "binding_receipt_bytes",
        },
        "started": {"request_digest", "started_bytes"},
        "unstarted-reconciled": {"work_binding", "origin_digest", "checkpoint_digest"},
    }
    require(
        kind in fields
        and type(document) is dict
        and set(document) == {"domain", "kind", "deployment_digest", "key_id", "algorithm", "signature", *fields[kind]}
        and document.get("domain") == ORIGINAL_DOMAIN
        and document.get("kind") == kind,
        "SCENE_RECOVERY_ORIGINAL_INVALID",
    )
    require(
        document.get("key_id") == deployment["key_id"]
        and document.get("algorithm") == "ed25519"
        and document.get("deployment_digest") == digest(deployment)
        and verify_manifest(document, deployment["public_key_hex"]),
        "SCENE_RECOVERY_ORIGINAL_SIGNATURE_INVALID",
    )
    return document


def seal_once(path, payload, deployment):
    document = root_sign(deployment, {"domain": ORIGINAL_DOMAIN, "deployment_digest": digest(deployment), **payload})
    if path.exists():
        require(decode(private_file(path)) == document, "SCENE_RECOVERY_ORIGINAL_CHANGED")
    else:
        require(
            sum(p.stat().st_size for p in path.parent.iterdir() if p.is_file()) + len(encoded(document)) <= 64_000_000,
            "SCENE_RECOVERY_ORIGINAL_LIMIT",
        )
        write(path, document, exclusive=True)  # Root-owned 0600, never chown to daemon/native.
    return document


def operation_work(work, deployment):
    from task_source.panel_worker import validate_work

    config = validate_work(work)
    require(
        work["task"].get("package_layout") == "scene" and work["task"].get("source") == "axis",
        "SCENE_RECOVERY_WORK_REQUIRED",
    )
    require(
        work["config"] == deployment["panel_config"] and config.digest == deployment["episode_policy"]["config_digest"],
        "SCENE_RECOVERY_CONFIG_CHANGED",
    )
    assignment = work["task"]["assignment"]
    require(
        assignment["run_id"] == work["run_id"]
        and assignment["worker_id"] == deployment["worker_id"]
        and assignment["node_id"] == deployment["node_id"]
        and work["task"]["competition_id"] in deployment["competition_ids"],
        "SCENE_RECOVERY_OWNER_MISMATCH",
    )
    root = Path(deployment["work_root"]) / "runs" / hashlib.sha256(work["run_id"].encode()).hexdigest()[:24]
    return config, root


def remember_commitment(request, deployment, archive):
    from task_source.scene_commitment import validate_receipt as validate_commitment
    from task_source.scene_adapter import epoch
    from task_source.scene_recovery import stable_work

    work = request["work"]
    operation_work(work, deployment)
    require(epoch(work["lease_expires_at"]) > time.time(), "SCENE_RECOVERY_COMMITMENT_LEASE_EXPIRED")
    data = validate_commitment(
        request["commitment"],
        work,
        backend=deployment["backend_url"],
        worker_id=deployment["worker_id"],
        node_id=deployment["node_id"],
    )
    if data["recovery_generation"]:
        require(
            data["binding_digest"] == initial_binding(work, deployment, archive), "SCENE_RECOVERY_COMMITMENT_CHANGED"
        )
    seal_once(
        archive / f"commitment-{data['recovery_generation']}.json",
        {
            "kind": "commitment",
            "work_binding": digest(stable_work(work)),
            "commitment": request["commitment"],
        },
        deployment,
    )
    return {"stored": True, "commitment_digest": digest(request["commitment"]), "execution_authorized": False}


def initial_binding(work, deployment, archive):
    from task_source.scene_commitment import validate_receipt
    from task_source.scene_recovery import stable_work

    initial_path = archive / "commitment-0.json"
    if not initial_path.exists():
        from task_source.scene_unstarted_recovery import first_binding

        return first_binding(work, deployment, archive)
    initial = root_verify(deployment, decode(private_file(initial_path)), kind="commitment")
    require(initial["work_binding"] == digest(stable_work(work)), "SCENE_RECOVERY_WORK_CHANGED")
    return validate_receipt(
        initial["commitment"],
        work,
        backend=deployment["backend_url"],
        worker_id=deployment["worker_id"],
        node_id=deployment["node_id"],
        generation=0,
    )["binding_digest"]


def archive_prepared(request, context, deployment):
    """Only called after real P02/P03 preflight in the SAME dedicated child."""
    from task_source.scene_recovery import stable_work

    prepared = context.prepared_scene_episode
    from task_source.scene_episode_delegate import SceneEpisodeRequest

    registered_trust(deployment)  # Independent public trust must exist before paid READY.

    require(
        type(prepared) is SceneEpisodeRequest
        and not prepared._used
        and prepared.parent.factory is context.gateway_factory
        and prepared.spec_bytes == context.spec_path.read_bytes(),
        "SCENE_RECOVERY_PREFLIGHT_REQUIRED",
    )
    archive = private_directory(archive_path(deployment, context.work["run_id"]))
    generation = request["commitment"]["data"]["recovery_generation"]
    original_commit = root_verify(
        deployment, decode(private_file(archive / f"commitment-{generation}.json")), kind="commitment"
    )
    require(original_commit["commitment"] == request["commitment"], "SCENE_RECOVERY_COMMITMENT_CHANGED")
    stem = f"{context.member.id}-{context.trial}"
    payload = {
        "kind": "prepared",
        "request": request,
        "request_digest": digest(request),
        "work_binding": digest(stable_work(context.work)),
        "spec_bytes": base64.b64encode(context.spec_path.read_bytes()).decode(),
        "binding_document": prepared.binding.document,
        "binding_receipt_bytes": base64.b64encode(prepared.binding.receipt_bytes).decode(),
    }
    require(len(encoded(payload)) + 1024 <= MAX_FRAME, "SCENE_RECOVERY_ORIGINAL_LIMIT")
    seal_once(archive / f"prepared-{stem}.json", payload, deployment)


def archive_started(request, context, deployment, raw):
    archive = private_directory(archive_path(deployment, context.work["run_id"]))
    stem = f"{context.member.id}-{context.trial}"
    seal_once(
        archive / f"started-{stem}.json",
        {
            "kind": "started",
            "request_digest": digest(request),
            "started_bytes": base64.b64encode(raw).decode(),
        },
        deployment,
    )


def registered_trust(deployment):
    from task_source.scene_views import ReceiptTrust
    from agent_evidence.signing import TrustStore

    data = deployment["receipt_trust"]
    receipt = ReceiptTrust(**{
        k: data[k] for k in ("node_id", "key_id", "public_key_hex", "runtime", "policy_version", "provenance")
    })
    executor = TrustStore(deployment["recovery_executor_trust"]["keys"])
    require(
        executor.public_key_hex("executor", deployment["registration"]["key_id"])
        == deployment["registration"]["public_key_hex"],
        "SCENE_RECOVERY_EXECUTOR_TRUST_REQUIRED",
    )
    return receipt, executor


def verify_quiescence(plans, deployment, run_root):
    """Read-only kernel fact, never kill/reap/adopt an unknown old scope."""
    from task_source.scene_adapter import epoch

    require(sys.platform == "linux" and os.geteuid() == 0, "SCENE_RECOVERY_PRIVILEGED_PARENT_REQUIRED")
    require(len(list(Path("/proc/self/task").iterdir())) == 1, "SCENE_RECOVERY_PARENT_NOT_DEDICATED")
    lease = read(run_root / "lease.json")
    require(epoch(lease["expires_at"]) <= time.time(), "SCENE_RECOVERY_NOT_EXPIRED")
    LinuxScopeKernel().preflight((Path(deployment["cgroup_base"]),))
    for plan in plans:
        # Successful original manager removes the WHOLE accounting subtree.
        # Even an empty unknown leftover is held for independent Operator work.
        require(not plan.accounting.exists(), "SCENE_RECOVERY_SCOPE_NOT_QUIESCENT")


def prepare_reader(request, deployment, archive):
    from agent_harness.spec import parse_spec
    from task_source.panel_worker import validate_episode_spec, validate_host
    from task_source.panel_report import episode_row
    from task_source.scene_local_recovery import LocalARecoveryReader, original_tree
    from task_source.scene_recovery import stable_work
    from task_source.scene_views import ExecutionView
    from task_source.scene_views.episode import EpisodeBinding
    from task_source.scene_views.episode_gateway import SceneAGatewayFactory

    work, generation = request["work"], request["base_generation"]
    require(type(generation) is int and generation >= 0, "SCENE_RECOVERY_GENERATION_INVALID")
    config, root = operation_work(work, deployment)
    # An unaccepted local report may require explicit R8 solely for retransmit.
    # Its raw file is frozen below; daemon preflight verifies the original full
    # signed report before any resume HTTP. ACK always precedes this path.
    consumed = 0
    end = time.monotonic() + deployment["recovery_timeout_s"]

    def archived(name, kind):
        nonlocal consumed
        require(time.monotonic() < end, "SCENE_RECOVERY_PARENT_TIMEOUT")
        value = private_file(archive / name)
        consumed += len(value)
        require(consumed <= 64_000_000, "SCENE_RECOVERY_ORIGINAL_LIMIT")
        return root_verify(deployment, decode(value), kind=kind)

    commitment = archived(f"commitment-{generation}.json", "commitment")
    require(commitment["work_binding"] == digest(stable_work(work)), "SCENE_RECOVERY_WORK_CHANGED")
    from task_source.scene_commitment import validate_receipt as validate_commitment

    data = validate_commitment(
        commitment["commitment"],
        work,
        backend=deployment["backend_url"],
        worker_id=deployment["worker_id"],
        node_id=deployment["node_id"],
        generation=generation,
    )
    if generation:
        require(
            data["binding_digest"] == initial_binding(work, deployment, archive), "SCENE_RECOVERY_COMMITMENT_CHANGED"
        )
    host = read(root / "model-host.json")
    validate_host(host, config)
    require(digest(host) == deployment["host_digest"], "SCENE_RECOVERY_HOST_CHANGED")
    receipt_trust, executor = registered_trust(deployment)
    raw = original_tree(root)
    started = {Path(name).stem for name in raw if name.startswith("started/")}
    require(started and len(started) <= 512, "SCENE_RECOVERY_JOURNAL_REQUIRED")
    specs, bindings, factories, plans = {}, {}, {}, []
    members = {m.id: m for m in config.settlement.members}
    instances = read(root / "package.json")["instance_ids"]
    public = {k: deployment[k] for k in ("key_id", "public_key_hex")}
    public["deployment_digest"] = digest(deployment)
    for stem in sorted(started):
        prepared = archived(f"prepared-{stem}.json", "prepared")
        original = prepared["request"]
        require(
            prepared["request_digest"] == digest(original)
            and prepared["work_binding"] == digest(stable_work(work)) == digest(stable_work(original["work"])),
            "SCENE_RECOVERY_WORK_CHANGED",
        )
        spec_raw = base64.b64decode(prepared["spec_bytes"], validate=True)
        require(raw[f"specs/{stem}.json"] == spec_raw, "SCENE_RECOVERY_ORIGINAL_CHANGED")
        spec = parse_spec(decode(spec_raw))
        member, trial = members[spec.panel_binding["member"]], spec.episode
        require(stem == f"{member.id}-{trial}", "SCENE_RECOVERY_PARTIAL_TRIAL")
        validate_episode_spec(
            spec.raw,
            work,
            config,
            member,
            trial,
            instances,
            root / "episodes" / f"{config.settlement_panel}-{stem}.jsonl",
            host["providers"][member.provider],
        )
        start = archived(f"started-{stem}.json", "started")
        marker = raw[f"started/{stem}.json"]
        require(
            base64.b64decode(start["started_bytes"], validate=True) == marker
            and start["request_digest"] == prepared["request_digest"],
            "SCENE_RECOVERY_ORIGINAL_CHANGED",
        )
        sha = hashlib.sha256(spec_raw).hexdigest()
        require(
            decode(marker)["spec_sha256"] == sha
            and decode(marker)["launcher_request_digest"] == prepared["request_digest"],
            "SCENE_RECOVERY_ORIGINAL_CHANGED",
        )
        validate_receipt(
            decode(raw[f"launches/{stem}.json"]),
            request_digest=prepared["request_digest"],
            spec_sha256=sha,
            public=public,
        )
        original_root = decode(raw[Path(spec.evidence_path).relative_to(root).as_posix() + ".root.json"])
        key_id = original_root["key_id"]
        pub = executor.public_key_hex("executor", key_id)
        require(pub is not None, "SCENE_RECOVERY_EXECUTOR_TRUST_REQUIRED")
        episode_row(spec.raw, decode(raw[f"results/{stem}.json"]), SimpleNamespace(key_id=key_id, public_key_hex=pub))
        contents = {
            name: base64.b64decode(value, validate=True) for name, value in original["execution_contents"].items()
        }
        view = ExecutionView(
            MappingProxyType(contents),
            encoded(original["submission_manifest"]),
            contents["task.json"],
            encoded(original["metadata"]["execution_contract"]),
            encoded(original["metadata"]["identity"]),
        )
        # Restore ONLY a root-signed historical P03 validation result. No new
        # reference format, judgement, clock injection or expired authorization.
        binding = EpisodeBinding(
            view,
            encoded(prepared["binding_document"]),
            base64.b64decode(prepared["binding_receipt_bytes"], validate=True),
            receipt_trust,
        )
        specs[stem], bindings[stem] = spec, binding
        model = {**member.model_config(), **host["providers"][member.provider]}
        factories[member.id] = SceneAGatewayFactory.from_registered_config(
            host,
            expected_host_digest=deployment["host_digest"],
            frozen_model=model,
            expected_model_digest=deployment["model_digests"][member.id],
            config_digest=config.digest,
            expected_factory_digest=deployment["episode_policy"]["gateway_factory_digest"],
            lease_file=root / "lease.json",
            ledger_directory=root / "subscription",
            provider_policy=deployment["provider_policies"][member.id],
            expected_provider_policy_digest=deployment["provider_policy_digests"][member.id],
            native_registration=deployment.get("native_provider_registrations", {}).get(member.id),
        )
        plans.append(
            EpisodeScopePlan.registered(
                deployment,
                episode={
                    k: binding.document[k]
                    for k in ("run_id", "attempt_id", "member_id", "worker_id", "node_id", "trial", "instance")
                },
                submission_digest=work["task"]["submission_digest"],
                config_digest=config.digest,
            )
        )
    require(
        {p.stem.removeprefix("prepared-") for p in archive.glob("prepared-*.json")} == started,
        "SCENE_RECOVERY_PARTIAL_TRIAL",
    )
    require({Path(name).stem for name in raw if name.startswith("results/")} == started, "SCENE_RECOVERY_PARTIAL_TRIAL")
    verify_quiescence(plans, deployment, root)
    progress = decode(raw["recovery-progress.json"])
    require(
        progress["schema_version"] == "scene-accepted-progress-v1"
        and progress["local_binding_digest"] == digest(stable_work(work)),
        "SCENE_RECOVERY_PROGRESS_INVALID",
    )
    checkpoint_state = {"progress": progress["progress"], "artifacts": [], "report_digest": None}
    from task_source.scene_recovery import checkpoint

    checkpoint({
        "binding_digest": data["binding_digest"],
        **checkpoint_state,
        **{
            name: {"count": 0, "digest": digest([])}
            for name in ("calls", "budget_reservations", "subscription_reservations")
        },
    })
    reader = LocalARecoveryReader(
        work=work,
        factories=factories,
        expected_specs=specs,
        episode_bindings=bindings,
        executor_trust=executor,
        checkpoint_state=checkpoint_state,
        server_binding_digest=data["binding_digest"],
        recovery_generation=generation + 1,
        quiescent=True,
    )
    journal = reader.scene_recovery_journal(work, directory=root)
    require(time.monotonic() < end, "SCENE_RECOVERY_PARENT_TIMEOUT")
    return journal


def operate(frame, deployment):
    """One fixed root helper, owner-locked operation, no new runner or claim."""
    request, action = frame["request"], frame["stage"]
    require(set(frame) == {"stage", "request", "deployment_digest"})
    require(frame["deployment_digest"] == digest(deployment))
    require(
        type(request) is dict
        and isinstance(request.get("challenge"), str)
        and re.fullmatch("[0-9a-f]{64}", request["challenge"])
    )
    require(type(deployment["recovery_timeout_s"]) in (int, float) and 0 < deployment["recovery_timeout_s"] <= 180)
    from task_source.panel_client import contains_recovery_material

    require(not contains_recovery_material(request), "SCENE_RECOVERY_MATERIAL_EXPOSED")
    operation_work(request["work"], deployment)  # Validate owner/config BEFORE creating any archive directory.
    with archive_guard(
        deployment, request["work"], create=action in {"recovery-commitment", "recovery-unstarted-prepare"}
    ) as archive:
        if action == "recovery-commitment":
            require(set(request) == {"work", "commitment", "challenge"})
            result = {"result": remember_commitment(request, deployment, archive)}
        else:
            require(
                action
                in {
                    "recovery-prepare",
                    "recovery-reconcile",
                    "recovery-unstarted-prepare",
                    "recovery-unstarted-reconcile",
                }
            )
            prepare = action in {"recovery-prepare", "recovery-unstarted-prepare"}
            unstarted = action in {"recovery-unstarted-prepare", "recovery-unstarted-reconcile"}
            require(
                set(request)
                == (
                    {"work", "base_generation", "challenge"}
                    if prepare
                    else {"work", "base_generation", "challenge", "journal_digest", "checkpoint"}
                )
            )
            if unstarted:
                from task_source.scene_unstarted_recovery import prepare_unstarted

                journal = prepare_unstarted(request, deployment, archive)
            else:
                journal = prepare_reader(request, deployment, archive)
            if prepare:
                result = {"journal": journal.document}
            else:
                require(digest(journal.document) == request["journal_digest"], "SCENE_RECOVERY_JOURNAL_CHANGED")
                if unstarted:
                    from task_source.scene_unstarted_recovery import reconcile_unstarted

                    matched = reconcile_unstarted(
                        journal.document, request["checkpoint"], request["work"], deployment, archive
                    )
                else:
                    from task_source.scene_checkpoint import reconcile

                    matched = reconcile(
                        journal.document,
                        request["checkpoint"],
                        run_id=request["work"]["run_id"],
                        generation=request["base_generation"] + 1,
                        local_a=journal._local_a,
                    )
                result = {"reconciliation": matched}
    return root_sign(
        deployment,
        {
            "domain": OP_DOMAIN,
            "action": action,
            "request_digest": digest(request),
            "deployment_digest": digest(deployment),
            **result,
        },
    )
