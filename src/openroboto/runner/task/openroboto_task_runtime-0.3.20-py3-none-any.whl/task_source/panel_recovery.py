"""Explicit recovery for a signed quota refusal with provably zero wire attempts."""

from __future__ import annotations

import copy
import hashlib
import json
import pathlib
from datetime import UTC, datetime

from agent_eval.subscription_gateway import FORMAT, MixedModelPolicy, _sha
from agent_evidence import verify_chain, verify_root
from agent_evidence.signing import Signer, TrustStore, build_bundle
from task_source.panel_state import read, write, sync_directory

FLOOR_MESSAGE = "weekly subscription quota is below the frozen floor"


def _state_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def _fail():
    from task_source.panel_worker import WorkRejected

    raise WorkRejected("UNSPENT_RECOVERY_REFUSED")


def inventory(directory):
    if not directory.is_dir() or directory.is_symlink():
        _fail()
    result = {}
    for path in sorted(directory.rglob("*")):
        if path.is_symlink():
            _fail()
        if path.is_file():
            result[str(path.relative_to(directory))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def verify_unspent(directory, original, work, config, host, signer):
    """Verify original terminal refusal, not an operator's 'no spend' assertion."""
    from task_source.panel_worker import validate_episode_spec

    if host.get("mode") != "subscription" or list((directory / "results").glob("*.json")):
        _fail()
    if (directory / "report.json").exists() or (directory / "report-response.json").exists():
        _fail()
    prefix = "a-" + hashlib.sha256((work["worker_id"] + work["run_id"]).encode()).hexdigest()[:24]
    if read(directory / "model-host.json") != {**host, "session_prefix": prefix}:
        _fail()
    specs = {path.stem: path for path in (directory / "specs").glob("*.json")}
    markers = {path.stem: path for path in (directory / "started").glob("*.json")}
    if not specs or specs.keys() != markers.keys():
        _fail()
    members = {member.id: member for member in config.settlement.members}
    seen_members = set()
    expected_events = set()
    instances = read(directory / "package.json")["instance_ids"]
    trust = TrustStore()
    trust.add("executor", signer.key_id, signer.public_key_hex)
    for stem, path in specs.items():
        raw = read(path)
        binding = raw.get("panel_binding", {})
        member = members.get(binding.get("member"))
        trial = binding.get("trial")
        if member is None or type(trial) is not int or not 0 <= trial < work["trials_per_member"]:
            _fail()
        if stem != f"{member.id}-{trial}":
            _fail()
        filename = f"{config.settlement_panel}-{member.id}-{trial}.jsonl"
        validate_episode_spec(
            raw,
            work,
            config,
            member,
            trial,
            instances,
            original / "episodes" / filename,
            host["providers"][member.provider],
        )
        if read(markers[stem]).get("spec_sha256") != hashlib.sha256(path.read_bytes()).hexdigest():
            _fail()
        events = [json.loads(line) for line in (directory / "episodes" / filename).read_text().splitlines()]
        root = read(directory / "episodes" / (filename + ".root.json"))
        checked = verify_chain(
            events,
            expected_root=root["root"],
            party="executor",
            job_id=raw["binding"]["job_id"],
            attempt_id=raw["attempt_id"],
            episode=raw["episode"],
            job_nonce=raw["binding"]["nonce"],
            require_payload=True,
        )
        if not checked.ok or not verify_root(root, trust).ok or root.get("job_digest") != raw["evidence"]["job_digest"]:
            _fail()
        if read(directory / "episodes" / (filename + ".bundle.json")) != build_bundle([root], mode="single"):
            _fail()
        if [event.get("type") for event in events] != ["run_start", "observation", "error", "usage_summary", "run_end"]:
            _fail()
        terminal = events[-1]["payload"]
        if (
            terminal.get("success") is not False
            or type(terminal.get("steps")) is not int
            or terminal["steps"] != 0
            or terminal.get("error") != "model_error"
            or terminal.get("status") != "error"
            or terminal.get("turns") != 1
        ):
            _fail()
        if events[2]["payload"].get("error") != "SubscriptionRejected: " + FLOOR_MESSAGE:
            _fail()
        calls = [
            json.loads(line) for line in (directory / "episodes" / (filename + ".calls.jsonl")).read_text().splitlines()
        ]
        if len(calls) != 1:
            _fail()
        call = calls[0]
        error = call.get("error") or {}
        if (
            call.get("status") != "error"
            or call.get("provider") != raw["model"]["provider"]
            or call.get("model") != raw["model"]["model"]
            or call.get("effort") != raw["model"].get("effort")
            or error.get("type") != "SubscriptionRejected"
            or error.get("message") != FLOOR_MESSAGE
            or error.get("status") is not None
            or error.get("request_id") is not None
            or error.get("retryable") is not False
            or call.get("raw_response_sha256") is not None
            or call.get("raw_response_bytes") != 0
            or call.get("run_id") != work["run_id"]
            or call.get("attempt_id") != raw["attempt_id"]
            or error.get("retry", {}).get("attempts") != 1
            or error.get("retry", {}).get("retries") != 0
        ):
            _fail()
        expected_events.update({
            filename,
            filename + ".root.json",
            filename + ".calls.jsonl",
            filename + ".bundle.json",
        })
        seen_members.add(member.id)
    if {p.name for p in (directory / "episodes").iterdir()} != expected_events:
        _fail()
    ledgers = list((directory / "subscription").glob("*.jsonl"))
    if {path.stem for path in ledgers} != seen_members:
        _fail()
    for path in ledgers:
        content = path.read_text()
        if not content.endswith("\n"):
            _fail()
        rows = [json.loads(line) for line in content.splitlines()]
        if len(rows) != 1:
            _fail()
        row = rows[0]
        policy = MixedModelPolicy(**row["policy"])
        member = members[path.stem]
        sub = host["subscription"]
        if (
            row.get("format") != FORMAT
            or row.get("type") != "policy"
            or row.get("seq") != 0
            or row.get("prev_sha256") is not None
            or row.get("sha256") != _sha({k: v for k, v in row.items() if k != "sha256"})
            or row.get("policy_sha256") != policy.sha256
            or policy.ledger_path != original / "subscription" / path.name
            or policy.run_id != work["run_id"]
            or policy.session_prefix != prefix
            or policy.max_calls != sub["max_calls_per_member"]
            or policy.per_episode_calls != sub["max_calls_per_episode"]
            or policy.min_remaining != sub["min_remaining"]
            or policy.codex_model != member.model
            or policy.codex_effort != member.effort
            or policy.codex_endpoint != host["providers"][member.provider]["endpoint"]
        ):
            _fail()


def _directory(worker, state):
    return worker.root / "runs" / hashlib.sha256(state["work"]["run_id"].encode()).hexdigest()[:24]


def _verified_archives(worker, state, config, signer):
    work = {**state["work"], "worker_id": state["binding"]["worker_id"]}
    expected = set()
    for index, item in enumerate(state.get("recovery_history", []), 1):
        archive = worker.root / "recovery_archives" / _directory(worker, state).name / f"{index:04d}"
        if item["directory"] != str(archive.relative_to(worker.root)) or archive.is_symlink():
            _fail()
        audit = read(archive / "audit.json")
        if _sha(audit) != item["audit_sha256"] or audit["binding"] != state["binding"]:
            _fail()
        original_state = read(archive / "state.json")
        if (
            hashlib.sha256((archive / "state.json").read_bytes()).hexdigest() != audit["state_sha256"]
            or original_state["work"] != state["work"]
            or audit["run_id"] != state["work"]["run_id"]
            or audit["original_directory"] != str(_directory(worker, state))
        ):
            _fail()
        if inventory(archive / "run") != audit["inventory"]:
            _fail()
        verify_unspent(
            archive / "run", pathlib.Path(audit["original_directory"]), work, config, audit["old_host"], signer
        )
        expected.add(str(archive.relative_to(worker.root)))
    return expected


def finish_recovery(worker, state):
    """Finish an already authorized filesystem transaction after a process loss."""
    from task_source.panel_worker import validate_work
    from task_source.scene_dispatch import is_scene_task

    if is_scene_task(state.get("work", {}).get("task", {})):
        _fail()

    item = state["recovery_pending"]
    archive = (
        worker.root
        / "recovery_archives"
        / _directory(worker, state).name
        / f"{len(state.get('recovery_history', [])) + 1:04d}"
    )
    if item["directory"] != str(archive.relative_to(worker.root)) or archive.is_symlink():
        _fail()
    audit = item["audit"]
    original_state = item["original_state"]
    config = validate_work(state["work"])
    signer = Signer.from_keyfile(worker.signing_key)
    _verified_archives(worker, state, config, signer)
    if (
        _sha(audit) != item["audit_sha256"]
        or _sha(read(worker.model_config)) != audit["new_host_sha256"]
        or _state_sha(original_state) != audit["state_sha256"]
        or original_state["work"] != state["work"]
        or original_state["binding"] != state["binding"]
        or audit["binding"] != state["binding"]
        or original_state.get("recovery_history", []) != state.get("recovery_history", [])
        or audit["run_id"] != state["work"]["run_id"]
        or audit["original_directory"] != str(_directory(worker, state))
    ):
        _fail()
    archive.mkdir(parents=True, mode=0o700, exist_ok=True)
    for name, expected in (("state.json", original_state), ("audit.json", audit)):
        path = archive / name
        if path.exists():
            if path.is_symlink() or read(path) != expected:
                _fail()
        else:
            write(path, expected, exclusive=True)
    directory = _directory(worker, state)
    if not (archive / "run").exists():
        if inventory(directory) != audit["inventory"]:
            _fail()
        directory.rename(archive / "run")
        sync_directory(directory.parent)
        sync_directory(archive)
    if inventory(archive / "run") != audit["inventory"]:
        _fail()
    verify_unspent(
        archive / "run",
        directory,
        {**state["work"], "worker_id": state["binding"]["worker_id"]},
        config,
        audit["old_host"],
        signer,
    )
    directory.mkdir(mode=0o700, exist_ok=True)
    if any(directory.iterdir()):
        _fail()
    state = copy.deepcopy(state)
    state.setdefault("recovery_history", []).append({key: item[key] for key in ("directory", "audit_sha256")})
    state.pop("recovery_pending")
    state.pop("error_code", None)
    state.update(phase="claimed", authorized_host_sha256=audit["new_host_sha256"])
    worker._state(state)
    return state


def resume_unspent(worker, reason):
    from task_source.panel_worker import validate_host, validate_work

    if not isinstance(reason, str) or not 1 <= len(reason.strip()) <= 300:
        _fail()
    state = read(worker.root / "state.json")
    from task_source.scene_dispatch import is_scene_task

    if is_scene_task(state.get("work", {}).get("task", {})):
        _fail()
    if state["phase"] == "recovering":
        return finish_recovery(worker, state)
    if state["phase"] != "held" or state.get("progress", {}).get("completed_trials") != 0:
        _fail()
    if hashlib.sha256((worker.root / "state.json").read_bytes()).hexdigest() != _state_sha(state):
        _fail()
    if (
        state["binding"]["backend"] != worker.client.base_url
        or state["binding"]["worker_id"] != worker.client.worker_id
        or state["binding"]["node_id"] != worker.client.node_id
    ):
        _fail()
    work = state["work"]
    config = validate_work(work)
    directory = _directory(worker, state)
    inventory(directory)
    old = read(directory / "model-host.json")
    old.pop("session_prefix")
    host = read(worker.model_config)
    validate_host(host, config)
    comparable = copy.deepcopy(host)
    comparable["subscription"]["min_remaining"] = old["subscription"]["min_remaining"]
    if comparable != old or host["subscription"]["min_remaining"] > old["subscription"]["min_remaining"]:
        _fail()
    signer = Signer.from_keyfile(worker.signing_key)
    history = _verified_archives(worker, state, config, signer)
    work_for_check = {**work, "worker_id": worker.client.worker_id}
    verify_unspent(directory, directory, work_for_check, config, old, signer)
    base = worker.root / "recovery_archives" / directory.name
    if base.exists() and {str(path.relative_to(worker.root)) for path in base.iterdir()} != history:
        _fail()
    # The backend validates owner, credential, active grading config, and frozen total.
    response = worker.client.progress(work, "held", state["progress"])
    if response.get("status") != "held" or response.get("run_id", work["run_id"]) != work["run_id"]:
        _fail()
    archive = base / f"{len(history) + 1:04d}"
    audit = {
        "format": "a-worker-unspent-recovery/v1",
        "at": datetime.now(UTC).isoformat(),
        "reason": reason.strip(),
        "binding": state["binding"],
        "run_id": work["run_id"],
        "original_directory": str(directory),
        "inventory": inventory(directory),
        "old_host": old,
        "new_host_sha256": _sha(host),
        "wire_reservations": 0,
        "state_sha256": _state_sha(state),
    }
    pending = copy.deepcopy(state)
    pending["phase"] = "recovering"
    pending["recovery_pending"] = {
        "directory": str(archive.relative_to(worker.root)),
        "audit_sha256": _sha(audit),
        "audit": audit,
        "original_state": state,
    }
    worker._state(pending)
    return finish_recovery(worker, pending)
