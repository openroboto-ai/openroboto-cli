"""题源适配层的公共契约。

上层（准入、评测、结算、前端同步任务）只认这里的东西：一个 ``TaskSource``
给出任务清单、任务规格、环境、判定器；一个 ``Checker`` 只回答「这个状态是不
是成功了」。具体是 AXIS 的 MuJoCo payload 还是 RoboDojo 的 Isaac Sim 官方判据，
都藏在注册表的另一侧，上层代码里不出现题源名字。

约定：

- 状态（``Env.state()`` / ``Checker.evaluate()`` 的入参）是**可 JSON 序列化的
  Mapping**。这样跨进程、跨题源、跨 worker 都能传，不需要 import 对方的类。
- ``Checker.evaluate()`` 必须是纯函数：同一个状态求值两次结果相同，不读时钟、
  不写磁盘。准入的「确定性」检查直接依赖这一点。
- 环境不可用时抛 ``RuntimeUnavailable``，不要静默返回空状态。上层据此把任务
  标成 ``infra`` 重试，而不是判题不合格。
"""

from __future__ import annotations

import abc
import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol, Sequence, runtime_checkable

#: 题源词表。``task.json`` 的 ``source`` 字段只允许这两个值；新增题源时
#: 同时改这里、注册表配置和格式文档，三处由测试对账。
TASK_SOURCES = ("axis", "robodojo")


class TaskSourceError(Exception):
    """题包或题源配置本身有问题（业务拒绝）。"""


class UnknownTask(TaskSourceError):
    """题包里没有这个 task_id。"""


class RuntimeUnavailable(TaskSourceError):
    """本机没有这道题需要的运行时（MuJoCo / Isaac Sim）。属于基础设施问题。"""


class MissingReferenceTrajectory(TaskSourceError):
    """题包声明了参考解，但没有可回放的动作轨迹。属于业务拒绝（不可解）。"""


@dataclass(frozen=True)
class CheckResult:
    passed: bool
    detail: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Space:
    """动作 / 观测空间的最小描述，够上层做校验和展示。"""

    kind: str
    shape: tuple[int, ...] = ()
    dtype: str = "float32"
    low: tuple[float, ...] | None = None
    high: tuple[float, ...] | None = None
    meta: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "shape": list(self.shape),
            "dtype": self.dtype,
            "low": list(self.low) if self.low is not None else None,
            "high": list(self.high) if self.high is not None else None,
            "meta": dict(self.meta),
        }


@dataclass(frozen=True)
class InstanceSpec:
    """一个可执行实例（AXIS 的一次 payload / RoboDojo 的一个 layout seed）。"""

    instance: int
    initial_state: Mapping[str, Any]
    payload_path: str | None = None
    payload_sha256: str | None = None
    checker_sha256: str | None = None
    initial_state_sha256: str | None = None
    seed: int | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TaskSpec:
    task_id: str
    source: str
    instruction: str
    package_dir: str
    action_space: Space
    observation_space: Space
    checker_config: Mapping[str, Any]
    instances: tuple[InstanceSpec, ...]
    reference: Mapping[str, Any] | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def reference_for(self, instance: int) -> Mapping[str, Any] | None:
        if not self.reference:
            return None
        return (self.reference.get("instances") or {}).get(str(instance))


@runtime_checkable
class Checker(Protocol):
    """统一判定器接口。上层只调这两个方法。"""

    checker_type: str

    def evaluate(self, state: Mapping[str, Any]) -> CheckResult: ...

    def describe(self) -> Mapping[str, Any]: ...


@dataclass(frozen=True)
class ReplayResult:
    """一次动作轨迹回放的结果。

    ``final_state`` 是回放结束时的可 JSON 序列化状态，直接喂给 ``Checker``；
    ``state_digest`` 是它的 canonical SHA-256，用于「同一 worker 上逐位可复现」
    的确定性检查（同一个二进制、同一个输入 → 同一个 digest）。
    ``visibility`` 是题源能提供的目标物可见性（``{body: {"visible": bool, ...}}``）；
    题源不提供时为 ``None``，准入把这一项标 ``runtime`` 而不是冒充通过。
    ``state_verified=False`` 表示 ``final_state`` 只有判据结果、没有真实物理状态；
    确定性检查会 fail-closed，而不是拿成绩相同当物理可复现。
    """

    final_state: Mapping[str, Any]
    initial_state: Mapping[str, Any] | None = None
    state_digest: str = ""
    actions: int = 0
    visibility: Mapping[str, Mapping[str, Any]] | None = None
    detail: Mapping[str, Any] = field(default_factory=dict)
    #: ``final_state`` 是否包含来自执行器的**真实物理状态**（qpos/qvel 等），
    #: 而不只是 success/score 这类判定结果。没有真实状态时确定性检查必须
    #: fail-closed；不能拿「两次成绩相同」冒充物理可复现。
    state_verified: bool = True
    #: 真实状态的来源/证据名（例如 ``official_result.final_state``）；没有时
    #: 为 ``None``。
    state_source: str | None = None


@runtime_checkable
class EpisodeRunner(Protocol):
    """题源自己的整集执行器（RoboDojo 官方 client 这类）。

    上层只认 ``run()``：给实例和模式（oracle / noise / nop），拿回最终状态。
    判据仍然由 ``Checker.evaluate()`` 做，runner 不返回 ``passed`` —— 否则
    同一道题会出现两个判据。
    """

    def run(
        self,
        task: TaskSpec,
        instance: int,
        *,
        mode: str = "oracle",
        seed: int = 0,
        noise: Mapping[str, Any] | None = None,
    ) -> ReplayResult: ...


@runtime_checkable
class Env(Protocol):
    """统一环境接口。``state()`` 的返回值直接喂给 ``Checker.evaluate()``。"""

    def reset(self) -> Mapping[str, Any]: ...

    def step(self, action: Any) -> Mapping[str, Any]: ...

    def state(self) -> Mapping[str, Any]: ...

    def close(self) -> None: ...

    #: 全程不动的动作（nop 检查用）。不实现的题源在准入里会把 nop 标
    #: ``runtime``，而不是猜一个零向量（AXIS 的零向量会把机械臂拉回零位）。
    def null_action(self) -> Any: ...


#: 可见性检查传给 ``Env.visibility()`` 的 profile 选项。只转发这一份白名单，
#: 避免 profile 里的无关字段让不支持的环境 ``TypeError``。
VISIBILITY_OPTION_KEYS = (
    "width",
    "height",
    "frame_margin",
    "min_pixels",
    "min_pixel_ratio",
    "min_visible_fraction",
)


def _visibility_kwargs(options: Mapping[str, Any] | None) -> dict[str, Any]:
    if not options:
        return {}
    return {key: options[key] for key in VISIBILITY_OPTION_KEYS if key in options}


def canonical_sha256(value: Any) -> str:
    """与题包哈希同一条规则：canonical JSON 的 UTF-8 SHA-256。"""
    encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def state_digest(state: Mapping[str, Any]) -> str:
    return canonical_sha256(state)


class TaskSource(abc.ABC):
    """题源实现。所有方法都按 ``task_id`` 工作，不认识上层。

    ``load_task`` 的 ``instance`` 为 ``None`` 时返回整道题（所有实例）；
    指定实例时只返回那个实例的规格，便于 worker 逐实例派发。

    运行期准入只调 ``replay()``：默认实现拿题包里的动作轨迹逐步喂给
    ``make_env()``；题源自己执行整集的（RoboDojo 官方 client）覆盖 ``replay()``。
    上层不判断题源名字。
    """

    source: str

    @abc.abstractmethod
    def list_tasks(self) -> list[str]: ...

    @abc.abstractmethod
    def load_task(self, task_id: str, instance: int | None = None) -> TaskSpec: ...

    @abc.abstractmethod
    def make_env(self, task: TaskSpec, instance: int | None = None) -> Env: ...

    @abc.abstractmethod
    def checker(self, task: TaskSpec) -> Checker: ...

    @property
    @abc.abstractmethod
    def action_space(self) -> Space: ...

    @property
    @abc.abstractmethod
    def observation_space(self) -> Space: ...

    #: 题源自己声明「额外的静态准入检查」。返回 ``(name, passed, detail)``；
    #: 上层统一收集，不在 admission 里写题源分支。
    def static_checks(self, task: TaskSpec) -> list[tuple[str, bool, Mapping[str, Any]]]:
        return []

    #: 运行时可用的状态。``ready`` / ``unavailable`` / ``not_run``，只做记录，
    #: 不参与准入的收/拒 —— 运行机没装运行时是基础设施问题，不是题的错。
    def runtime_status(self) -> tuple[str, Mapping[str, Any]]:
        return "not_run", {}

    #: 一次准入开始前的钩子。题源如果跨实例缓存了运行期结果（RoboDojo 的
    #: batch），必须在这里清掉，否则下一次 attempt 会复用上一次的物理运行，
    #: 把「重跑」变成「读缓存」。
    def begin_admission(self) -> None:
        return None

    #: 释放题源持有的运行时资源（RoboDojo 的官方 server 子进程）。默认无资源。
    def close(self) -> None:
        return None

    #: 参考解的动作轨迹。默认读 ``reference.json`` 的
    #: ``instances.<n>.actions``；题源自己提供官方参考的（RoboDojo）覆盖它。
    #: 返回 ``None`` = 这个实例没有可回放的轨迹（不是「零动作」）。
    def reference_actions(self, task: TaskSpec, instance: int) -> Sequence[Any] | None:
        reference = task.reference_for(instance)
        if not isinstance(reference, Mapping):
            return None
        actions = reference.get("actions")
        return actions if isinstance(actions, list) and actions else None

    def replay_step_limit(self, task: TaskSpec) -> int | None:
        """Frozen control-step budget, when the source defines one."""
        return None

    #: 全程不动的动作。默认取环境自己的 ``null_action()``；读不到返回 ``None``。
    def null_action(self, task: TaskSpec, instance: int) -> Any | None:
        env = self.make_env(task, instance)
        try:
            return env.null_action()
        except (AttributeError, NotImplementedError):
            return None
        finally:
            env.close()

    #: 判定器关心的目标 body（可见性检查用）。默认从 checker 配置里收集
    #: 题源声明过的 body 名；题源可以覆盖。
    def target_bodies(self, task: TaskSpec) -> list[str]:
        return checker_body_names(task.checker_config)

    #: 回放一个实例。默认实现：reset → 逐步 step → 最终状态交给 Checker。
    def perturb_reference_actions(
        self,
        task: TaskSpec,
        instance: int,
        actions: Sequence[Sequence[float]],
        noise: Mapping[str, Any],
        *,
        seed: int,
    ) -> list[list[float]]:
        """Sources with joint controls must translate Cartesian noise explicitly."""
        return perturb_actions(actions, noise, seed=seed)

    def replay(
        self,
        task: TaskSpec,
        instance: int,
        *,
        mode: str = "oracle",
        seed: int = 0,
        noise: Mapping[str, Any] | None = None,
        visibility_options: Mapping[str, Any] | None = None,
    ) -> ReplayResult:
        step_limit = self.replay_step_limit(task)
        reference_actions = self.reference_actions(task, instance)
        if step_limit is not None and reference_actions is not None and len(reference_actions) > step_limit:
            raise TaskSourceError(
                f"{task.source} task {task.task_id!r} instance {instance}: reference actions "
                f"{len(reference_actions)} exceed frozen control-step budget {step_limit}"
            )
        if mode == "oracle":
            actions = reference_actions
            if actions is None:
                raise MissingReferenceTrajectory(
                    f"{self.source} task {task.task_id!r} instance {instance}: "
                    "reference.json has no 'actions' trajectory to replay"
                )
            actions = list(actions)
        elif mode == "noise":
            actions = reference_actions
            if actions is None:
                raise MissingReferenceTrajectory(
                    f"{self.source} task {task.task_id!r} instance {instance}: "
                    "reference.json has no 'actions' trajectory to perturb"
                )
            actions = self.perturb_reference_actions(task, instance, list(actions), noise or {}, seed=seed)
        elif mode == "nop":
            action = self.null_action(task, instance)
            if action is None:
                raise RuntimeUnavailable(
                    f"{self.source} task {task.task_id!r} instance {instance}: "
                    "the environment does not provide a null action"
                )
            horizon = len(reference_actions or [])
            actions = [action] * max(1, horizon)
        else:
            raise TaskSourceError(f"unknown replay mode {mode!r}")

        # Time-warped noise may need more control steps than the submitted
        # reference. Like the worker, stop at the frozen episode budget; the
        # checker must judge the physical state reached within that budget.
        if step_limit is not None:
            actions = actions[:step_limit]

        env = self.make_env(task, instance)
        try:
            initial = env.reset()
            # 「开局可见性」必须在 reset 之后、任何动作之前采样 —— 回放结束后
            # 手可能正挡在目标物前面，那时测的是「搬运后还看得见吗」。
            visibility = None
            targets = self.target_bodies(task)
            if targets:
                try:
                    visibility = env.visibility(  # type: ignore[attr-defined]
                        targets, **_visibility_kwargs(visibility_options)
                    )
                except (AttributeError, NotImplementedError):
                    visibility = None
            detail = {"mode": mode}
            observation_audit = getattr(self, "replay_observation_evidence", None)
            if callable(observation_audit):
                evidence = observation_audit(task, env, initial)
                if evidence is not None:
                    detail["scene_observation"] = evidence
            final = initial
            for action in actions:
                final = env.step(action)
            return ReplayResult(
                final_state=final,
                initial_state=initial,
                state_digest=state_digest(final),
                actions=len(actions),
                visibility=visibility,
                detail=detail,
            )
        finally:
            env.close()


#: checker 配置里表示「body 名字」的键。可见性检查和指纹都读这一份，
#: 不各写一套。
CHECKER_BODY_KEYS = (
    "object_id",
    "objName",
    "refName",
    "bodyName",
    "sampleBodyName",
    "cabinetName",
    "frameName",
)


def checker_body_names(config: Mapping[str, Any]) -> list[str]:
    """递归收集 checker 里出现过的 body 名，保持声明顺序、去重。"""
    found: list[str] = []

    def visit(node: Any) -> None:
        if isinstance(node, Mapping):
            for key in CHECKER_BODY_KEYS:
                value = node.get(key)
                if isinstance(value, str) and value and value not in found:
                    found.append(value)
            for value in node.values():
                visit(value)
        elif isinstance(node, (list, tuple)):
            for value in node:
                visit(value)

    visit(config)
    return found


def perturb_actions(
    actions: Sequence[Sequence[float]],
    noise: Mapping[str, Any],
    *,
    seed: int = 0,
) -> list[list[float]]:
    """按预登记的幅度扰动动作轨迹。确定性：同一个 seed 逐位一致。

    幅度来自准入 profile（按 checker 类别预登记），这里不按题目调参：
    ``position_amplitude_m`` / ``orientation_amplitude_deg`` 是均匀分布的半宽，
    ``speed_scale`` 是时间缩放的取值范围（<1 更快、>1 更慢）。哪些动作维度
    是位置、哪些是朝向由 profile 的 ``position_indices`` / ``orientation_indices``
    声明 —— 上层不理解动作语义。

    扰动是**整条轨迹一个偏移量**（不是逐步白噪声）：参考解换了一个稍偏的
    抓取 / 落点、快慢也变一档，这正是「不是刀刃题」要测的东西。逐步 5 Hz
    白噪声会把位置伺服和焊接约束打出高频抖动，测到的是控制器带宽而不是题
    的鲁棒性。
    """
    import random

    if not actions:
        return []
    rng = random.Random(int(seed))
    position_indices = [int(index) for index in noise.get("position_indices") or []]
    orientation_indices = [int(index) for index in noise.get("orientation_indices") or []]
    position_amplitude = float(noise.get("position_amplitude_m") or 0.0)
    orientation_amplitude = float(noise.get("orientation_amplitude_deg") or 0.0)
    orientation_amplitude = orientation_amplitude * 3.141592653589793 / 180.0
    scale_range = noise.get("speed_scale") or [1.0, 1.0]
    low, high = float(scale_range[0]), float(scale_range[1])
    speed = rng.uniform(low, high) if high > low else low
    speed = max(1e-3, speed)

    width = len(actions[0])
    source = [[float(value) for value in action] for action in actions]
    target_length = max(1, round(len(source) / speed))
    warped: list[list[float]] = []
    for step in range(target_length):
        if target_length == 1:
            position = 0.0
        else:
            position = step * (len(source) - 1) / (target_length - 1)
        left = min(int(position), len(source) - 1)
        right = min(left + 1, len(source) - 1)
        fraction = position - left
        warped.append([
            source[left][index] * (1.0 - fraction) + source[right][index] * fraction for index in range(width)
        ])

    offsets = [0.0] * width
    for index in position_indices:
        if 0 <= index < width and position_amplitude:
            offsets[index] = rng.uniform(-position_amplitude, position_amplitude)
    for index in orientation_indices:
        if 0 <= index < width and orientation_amplitude:
            offsets[index] = rng.uniform(-orientation_amplitude, orientation_amplitude)
    for action in warped:
        for index in range(width):
            if offsets[index]:
                action[index] += offsets[index]
    return warped


@dataclass(frozen=True)
class AdmissionCheck:
    name: str
    passed: bool
    detail: Mapping[str, Any] = field(default_factory=dict)
    kind: str = "structural"  # structural | runtime


@dataclass(frozen=True)
class AdmitResult:
    source: str
    task_id: str
    accepted: bool
    checks: tuple[AdmissionCheck, ...]
    runtime_status: str = "not_run"

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "task_id": self.task_id,
            "accepted": self.accepted,
            "runtime_status": self.runtime_status,
            "checks": [
                {"name": c.name, "passed": c.passed, "kind": c.kind, "detail": dict(c.detail)} for c in self.checks
            ],
        }
