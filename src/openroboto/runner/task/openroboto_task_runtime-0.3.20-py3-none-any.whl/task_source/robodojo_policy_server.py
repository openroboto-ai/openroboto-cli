"""RoboDojo 准入用的策略服务：null（nop）与 noise（动作扰动代理）。

官方 client 启动时一定会连 ``--policy-port`` 上的策略 WebSocket 服务
（``client_server.ws.protocol``，msgpack 帧）。两个模式共用同一套协议：

- ``null``：不依赖任何模型；对每个 ``infer`` 返回观测里的 ``action``
  （官方 ``ObsManager`` 已经按动作空间归一化过），语义是「保持当前关节
  目标不动」。官方判据仍由 Isaac Sim 端求值，本服务不猜 success。
- ``noise``：把 ``infer`` 转发给上游官方策略服务，在返回的动作 chunk 上
  按 profile 的幅度加关节扰动，再回给 client。

协议帧（pinned RoboDojo/XPolicyLab）::

    {"message_type": "infer", "message_id": "...", "evaluation_id": "...",
     "action_case_id": ..., "trial_id": ..., "repeat_index": ..., "step": 0,
     "sent_at": "...", "payload": {...}}

响应必须把 ``message_id`` 原样带回，消息类型按 request/response 配对。

依赖 ``websockets`` / ``msgpack`` / ``msgpack-numpy``；缺失时以退出码 2
失败，runner 会把 server 退出当作 ``RuntimeUnavailable``（fail closed）。
"""

from __future__ import annotations

import argparse
import asyncio
import datetime
import json
import sys
from typing import Any, Mapping

RESPONSES = {
    "hello": "hello_ack",
    "prepare_case": "prepare_case_ack",
    "reset": "reset_result",
    "infer": "infer_result",
    "trial_end": "trial_end_ack",
    "heartbeat": "heartbeat_ack",
}


def _utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def _require_deps():
    try:
        import msgpack  # noqa: F401
        import numpy  # noqa: F401
        import websockets  # noqa: F401
    except ImportError as exc:  # pragma: no cover - 由 GPU 机安装决定
        print(
            "RoboDojo policy server dependencies missing "
            f"({exc.name}); run with: uv run --with websockets --with msgpack "
            "--with msgpack-numpy python3 -m task_source.robodojo_policy_server ...",
            file=sys.stderr,
        )
        raise SystemExit(2) from exc


def _decode_numpy(obj: dict[Any, Any]) -> Any:
    import numpy as np

    if obj.get(b"nd") is True:
        if obj.get(b"kind") == b"O":
            raise ValueError("object dtype numpy arrays are not supported")
        dtype = np.dtype(obj[b"type"].decode("ascii") if isinstance(obj[b"type"], bytes) else obj[b"type"])
        shape = obj.get(b"shape") or ()
        data = obj.get(b"data") or b""
        return np.frombuffer(data, dtype=dtype).reshape(shape)
    return obj


def decode_frame(data: bytes) -> dict[str, Any]:
    import msgpack

    obj = msgpack.unpackb(data, raw=False, object_hook=_decode_numpy)
    if not isinstance(obj, dict):
        raise ValueError("frame must be a msgpack map")
    return obj


def encode_frame(frame: Mapping[str, Any]) -> bytes:
    import msgpack

    return msgpack.packb(dict(frame), use_bin_type=True)


def _reply(request: Mapping[str, Any], message_type: str, payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return {
        "message_type": message_type,
        "message_id": request.get("message_id"),
        "evaluation_id": request.get("evaluation_id"),
        "action_case_id": request.get("action_case_id"),
        "trial_id": request.get("trial_id"),
        "repeat_index": request.get("repeat_index"),
        "step": int(request.get("step", 0) or 0),
        "sent_at": _utc_now(),
        "payload": dict(payload or {}),
    }


# ---------------------------------------------------------------------------
# null policy
# ---------------------------------------------------------------------------


def hold_action(observation: Mapping[str, Any]) -> Mapping[str, Any] | None:
    """从官方观测取当前动作（保持不动）。

    ``ObsManager`` 在 ``obs["action"]`` 里给出按动作空间归一化的关节目标；
    没有它时退回 ``obs["state"]``，只填 *_joint_state 键。
    """
    # 只保留动作空间里的 target arm / gripper；support arm 由环境自己控制，
    # 放进 action 会被官方 validate_action_dict 判成 unexpected key。
    def _target_only(mapping: Mapping[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in mapping.items() if not str(key).startswith("support_")}

    action = observation.get("action")
    if isinstance(action, Mapping) and action:
        filtered = _target_only(action)
        if filtered:
            return filtered
    state = observation.get("state")
    if not isinstance(state, Mapping):
        return None
    fallback = {
        key: value
        for key, value in state.items()
        if key.endswith("_joint_state")
        and not key.endswith("_ee_joint_state")
        and not key.startswith("support_")
    }
    if not fallback:
        return None
    for key, value in state.items():
        if key.endswith("_ee_joint_state") and not key.startswith("support_"):
            fallback[key] = [float(value[0])] if isinstance(value, (list, tuple)) and value else value
    return fallback


# ---------------------------------------------------------------------------
# upstream proxy
# ---------------------------------------------------------------------------


class UpstreamPolicyClient:
    def __init__(self, host: str, port: int, evaluation_id: str) -> None:
        self.url = f"ws://{host}:{port}"
        self.evaluation_id = evaluation_id
        self._ws = None
        self._sequence = 0

    async def connect(self, request: Mapping[str, Any] | None = None) -> None:
        import websockets

        if request is not None and request.get("evaluation_id"):
            self.evaluation_id = str(request["evaluation_id"])
        self._ws = await websockets.connect(self.url, max_size=None)
        await self._handshake()

    async def _handshake(self) -> None:
        """官方 server 要求先 hello；代理同样走一次握手。"""
        assert self._ws is not None
        message_id = "proxy-hello"
        frame = {
            "message_type": "hello",
            "message_id": message_id,
            "evaluation_id": self.evaluation_id,
            "action_case_id": None,
            "trial_id": None,
            "repeat_index": None,
            "step": 0,
            "sent_at": _utc_now(),
            "payload": {},
        }
        await self._ws.send(encode_frame(frame))
        while True:
            raw = await self._ws.recv()
            if not isinstance(raw, (bytes, bytearray)):
                continue
            incoming = decode_frame(bytes(raw))
            if incoming.get("message_id") != message_id:
                continue
            if incoming.get("message_type") == "error":
                raise RuntimeError(f"upstream policy server hello failed: {incoming.get('payload')}")
            if incoming.get("message_type") != "hello_ack":
                raise RuntimeError(
                    f"upstream policy server answered hello with {incoming.get('message_type')!r}"
                )
            return

    async def close(self) -> None:
        if self._ws is not None:
            await self._ws.close()
            self._ws = None

    async def request(
        self,
        message_type: str,
        payload: Mapping[str, Any],
        request: Mapping[str, Any],
    ) -> dict[str, Any]:
        if self._ws is None:
            await self.connect(request)
        self._sequence += 1
        message_id = f"proxy-{self._sequence}"
        frame = {
            "message_type": message_type,
            "message_id": message_id,
            "evaluation_id": self.evaluation_id,
            "action_case_id": request.get("action_case_id"),
            "trial_id": request.get("trial_id"),
            "repeat_index": request.get("repeat_index"),
            "step": int(request.get("step", 0) or 0),
            "sent_at": _utc_now(),
            "payload": dict(payload),
        }
        await self._ws.send(encode_frame(frame))
        expected = RESPONSES[message_type]
        while True:
            raw = await self._ws.recv()
            if not isinstance(raw, (bytes, bytearray)):
                continue
            incoming = decode_frame(bytes(raw))
            if incoming.get("message_id") != message_id:
                continue
            if incoming.get("message_type") == "error":
                raise RuntimeError(f"upstream policy server error: {incoming.get('payload')}")
            if incoming.get("message_type") != expected:
                raise RuntimeError(
                    f"upstream policy server answered {incoming.get('message_type')!r}, expected {expected!r}"
                )
            payload = incoming.get("payload") or {}
            return dict(payload) if isinstance(payload, Mapping) else {}


# ---------------------------------------------------------------------------
# noise
# ---------------------------------------------------------------------------


def _joint_noise(profile: Mapping[str, Any], seed: int, step: int, arm_index: int) -> list[float]:
    """按 profile + seed 生成 6 个机械臂关节的扰动。

    AXIS 的 profile 单位是米/度；RoboDojo 动作是关节弧度，这里做显式映射：
    前 3 个关节用 ``position_amplitude_m``（当作 rad），后 3 个用
    ``orientation_amplitude_deg`` 转 rad。RNG 由 ``(seed, step, arm)`` 决定，
    同一 seed 可复算，不同 seed/trial 产生不同扰动。这是本适配器声明的近似，
    不是 AXIS 的物理量。
    """
    import math
    import random

    position = float(profile.get("position_amplitude_m") or 0.015)
    orientation = math.radians(float(profile.get("orientation_amplitude_deg") or 8.0))
    amplitudes = [position, position, position, orientation, orientation, orientation]
    rng = random.Random((int(seed) & 0x7FFFFFFF) * 1_000_003 + int(step) * 1009 + int(arm_index))
    return [rng.uniform(-amplitude, amplitude) for amplitude in amplitudes]


def perturb_actions(
    actions: Any,
    profile: Mapping[str, Any],
    step: int,
    seed: int = 0,
) -> Any:
    if not isinstance(actions, list):
        return actions
    out = []
    for chunk_index, action in enumerate(actions):
        if not isinstance(action, Mapping):
            out.append(action)
            continue
        item = dict(action)
        arm_index = 0
        for key, value in list(item.items()):
            if not key.endswith("_arm_joint_state"):
                continue
            try:
                values = [float(v) for v in value]
            except (TypeError, ValueError):
                arm_index += 1
                continue
            offsets = _joint_noise(profile, seed, step + chunk_index, arm_index)
            item[key] = [v + o for v, o in zip(values, offsets)]
            arm_index += 1
        out.append(item)
    return out


# ---------------------------------------------------------------------------
# server
# ---------------------------------------------------------------------------


class Handler:
    def __init__(
        self,
        mode: str,
        profile: Mapping[str, Any],
        upstream: UpstreamPolicyClient | None,
        seed: int = 0,
    ) -> None:
        self.mode = mode
        self.profile = dict(profile)
        self.upstream = upstream
        self.seed = int(seed)

    async def __call__(self, websocket, path: str | None = None) -> None:
        async for raw in websocket:
            if not isinstance(raw, (bytes, bytearray)):
                continue
            try:
                request = decode_frame(bytes(raw))
            except Exception as exc:  # noqa: BLE001 - 坏帧只记录，不拖垮服务
                print(f"[robodojo-policy-server] bad frame: {exc}", file=sys.stderr)
                continue
            message_type = str(request.get("message_type") or "")
            payload = request.get("payload") or {}
            if not isinstance(payload, Mapping):
                payload = {}
            response_type = RESPONSES.get(message_type)
            if response_type is None:
                # CLOSE 没有响应配对。
                continue
            response_payload: dict[str, Any] = {}
            try:
                if message_type == "infer":
                    response_payload = await self._infer(request, payload)
                elif message_type in {"reset", "trial_end", "prepare_case"} and self.upstream is not None:
                    upstream_payload = await self.upstream.request(
                        message_type,
                        payload,
                        request,
                    )
                    response_payload = upstream_payload
                elif message_type == "reset":
                    response_payload = {"result": None}
            except Exception as exc:  # noqa: BLE001
                await websocket.send(
                    encode_frame(
                        _reply(request, "error", {"code": "INTERNAL", "message": f"{type(exc).__name__}: {exc}"})
                    )
                )
                continue
            await websocket.send(encode_frame(_reply(request, response_type, response_payload)))

    async def _infer(self, request: Mapping[str, Any], payload: Mapping[str, Any]) -> dict[str, Any]:
        observation = payload.get("observation")
        if not isinstance(observation, Mapping):
            observation = {}
        if self.mode == "null":
            action = hold_action(observation)
            if action is None:
                raise RuntimeError("observation has no 'action' or '*_joint_state' to hold")
            return {"actions": [action]}
        if self.upstream is None:
            raise RuntimeError("noise mode requires an upstream policy server")
        upstream = await self.upstream.request("infer", payload, request)
        actions = upstream.get("actions")
        step = int(request.get("step", 0) or 0)
        return {**upstream, "actions": perturb_actions(actions, self.profile, step, self.seed)}


async def serve(
    mode: str,
    host: str,
    port: int,
    profile: Mapping[str, Any],
    upstream: UpstreamPolicyClient | None,
    seed: int = 0,
) -> None:
    import websockets

    handler = Handler(mode, profile, upstream, seed)
    async with websockets.serve(handler, host, port, max_size=None):
        print(
            f"[robodojo-policy-server] mode={mode} seed={int(seed)} listening on {host}:{port}",
            flush=True,
        )
        await asyncio.Future()


def main(argv: list[str] | None = None) -> int:
    _require_deps()
    parser = argparse.ArgumentParser(description="RoboDojo admission policy server (null / noise proxy)")
    parser.add_argument("--mode", choices=("null", "noise"), required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--upstream-host", default="127.0.0.1")
    parser.add_argument("--upstream-port", type=int, default=None)
    parser.add_argument("--noise-json", default="{}")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--evaluation-id", default="robodojo-admission")
    args = parser.parse_args(argv)

    try:
        profile = json.loads(args.noise_json or "{}")
    except ValueError as exc:
        print(f"invalid --noise-json: {exc}", file=sys.stderr)
        return 2
    if not isinstance(profile, dict):
        print("--noise-json must be an object", file=sys.stderr)
        return 2
    upstream = None
    if args.mode == "noise":
        if args.upstream_port is None:
            print("noise mode requires --upstream-port", file=sys.stderr)
            return 2
        upstream = UpstreamPolicyClient(args.upstream_host, args.upstream_port, args.evaluation_id)

    try:
        asyncio.run(serve(args.mode, args.host, args.port, profile, upstream, args.seed))
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["hold_action", "main", "perturb_actions", "serve"]
