"""Pure preparation for P08's existing panel spec, with no launcher/provider.

This module prepares the real formal spec format. It does not provide the
registered scene admission bundle or the isolated business-model gateway.
"""

from __future__ import annotations

import json
import secrets

from agent_harness import agent_binding, build_spec, parse_spec
from openroboto_protocol import scene_contract

from .base import TaskSourceError
from .execution_contract import execution_contract_digest
from .scene_instruction_runtime import require
from .scene_observation import require_policy_scope
from .scene_views import ExecutionView


def build_scene_spec(view: ExecutionView, *, context) -> dict:
    """P08 SceneEpisodeContext -> frozen-spec candidate, without native/reset.

    The trusted parent owns context/config/host. No E/P path, checker or private
    reference is placed in model messages. P08 writes the returned spec once.
    Execution still requires the separately registered isolated gateway.
    """
    from .panel_worker import validate_episode_spec, validate_host
    from .scene_adapter import same_environment
    from .scene_runtime import registry_refs

    if type(view) is not ExecutionView:
        raise TaskSourceError("verified_execution_view_required")
    task, contract = view.task, view.contract
    work, config, member = context.work, context.config, context.member
    instance, trial = context.instance, context.trial
    profile = scene_contract.profile_ref()
    refs = registry_refs()
    registration = context.registration
    if (
        task["execution_profile"] != profile
        or not same_environment(task["environment"], refs["environment"])
        or contract != config.execution_contract
        or contract["agent"] != agent_binding()
        or registration.get("execution_profile") != profile
        or not any(
            same_environment(environment, refs["environment"])
            for environment in registration.get("environments", ())
        )
    ):
        raise TaskSourceError("scene_panel_identity_mismatch")
    require(task)
    require_policy_scope(task)
    count = len(task["scene"]["initial_states"])
    if type(trial) is not int or trial < 0 or type(instance) is not int or instance != trial % count:
        raise TaskSourceError("scene_panel_instance_mismatch")
    pin = work["task"]
    if (
        pin.get("package_digest") != view.manifest["execution_package_digest"]
        or pin.get("submission_digest") != view.manifest["submission_digest"]
        or not pin.get("task_id")
        or pin.get("source") != task["source"]
        or pin.get("execution_profile") != profile
        or work.get("config_digest") != config.digest
    ):
        raise TaskSourceError("scene_panel_work_mismatch")
    host = json.loads(context.host_config.read_bytes())
    validate_host(host, config)
    provider = host["providers"][member.provider]
    raw = build_spec(
        source=task["source"],
        # The frozen spec identifies the backend-registered task, not the package's
        # own id, so the panel binding and the score report share one identifier.
        task_id=pin["task_id"],
        instance=instance,
        episode=trial,
        version_digest=pin["package_digest"],
        package_repo=pin["package_repo"],
        package_commit=pin["package_commit"],
        model={**member.model_config(), **provider},
        instruction=task["instruction"],
        mode=contract["permissions"]["mode"],
        sensors=contract["permissions"]["allowed_sensors"],
        run_id=work["run_id"],
        max_turns=contract["budget"]["max_api_calls"],
        max_steps=contract["budget"]["max_steps"],
        wall_seconds=contract["budget"]["wall_seconds"],
        timing=contract["timing"],
        evidence_path=str(context.evidence_path),
        binding={"job_id": work["run_id"], "nonce": secrets.token_hex(16)},
        assurance_profile="isolated",
        signing_mode="single",
        panel_binding={
            "run_id": work["run_id"],
            "panel": config.settlement_panel,
            "member": member.id,
            "kind": member.kind,
            "trial": trial,
            "package_digest": pin["package_digest"],
            "version_digest": pin["package_digest"],
            "config_version": config.version,
            "config_digest": config.digest,
            "settlement": True,
            "execution_contract": contract,
            "execution_contract_digest": execution_contract_digest(contract),
        },
    )
    raw["attempt_id"] = f"{work['run_id']}:{member.id}:{trial}"
    raw["task"]["execution_profile"] = profile
    raw["evidence"]["job_digest"] = parse_spec(raw).job_digest
    validate_episode_spec(raw, work, config, member, trial, list(range(count)), context.evidence_path, provider)
    return raw


def prepare_scene_episode(view: ExecutionView, *, context) -> dict:
    """Reject missing parent data before generating/saving a started candidate."""
    from .scene_episode_delegate import require_parent_context, validate_candidate_spec

    parent = require_parent_context(context)
    raw = build_scene_spec(view, context=context)
    validate_candidate_spec(view, context=context, raw_spec=raw, parent=parent)
    return raw
