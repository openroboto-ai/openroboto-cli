"""Build a signed A report only from complete original per-episode artifacts."""

from __future__ import annotations
import json
from decimal import Decimal, localcontext
from pathlib import Path
from agent_evidence import verify_chain
from agent_evidence.signing import TrustStore
from agent_evidence import verify_root
from benchmark_worker.reference_panel.manifest import build_manifest, canonical_sha256, sign_manifest


class PanelEvidenceError(ValueError):
    pass


def signed_wall_ms(events):
    if len(events) < 2:
        raise PanelEvidenceError("episode lacks signed clock span")
    clocks = []
    for event in events:
        value = event.get("ts_monotonic")
        if type(value) not in (int, float):
            raise PanelEvidenceError("episode signed clock must be numeric")
        clock = Decimal(str(value))
        if not clock.is_finite() or clock < 0 or (clocks and clock < clocks[-1]):
            raise PanelEvidenceError("episode signed clock must be finite, nonnegative and monotonic")
        clocks.append(clock)
    with localcontext() as context:
        integer_places = max(clock.adjusted() for clock in clocks)
        fractional_places = -min(clock.as_tuple().exponent for clock in clocks)
        context.prec = max(28, integer_places + fractional_places + 5)
        return int(round((clocks[-1] - clocks[0]) * 1000))


def episode_row(spec: dict, result: dict, signer) -> dict:
    path = Path(spec["evidence"]["path"])
    events = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    wall_ms = signed_wall_ms(events)
    root = json.loads(Path(str(path) + ".root.json").read_text())
    trust = TrustStore()
    trust.add("executor", signer.key_id, signer.public_key_hex)
    checked = verify_chain(
        events,
        expected_root=root["root"],
        party="executor",
        job_id=spec["binding"]["job_id"],
        attempt_id=spec["attempt_id"],
        episode=spec["episode"],
        job_nonce=spec["binding"]["nonce"],
        require_payload=True,
    )
    if not checked.ok or not verify_root(root, trust).ok:
        raise PanelEvidenceError("episode chain or root signature invalid")
    if root.get("job_digest") != spec["evidence"]["job_digest"]:
        raise PanelEvidenceError("episode root spec binding differs")
    if not events or events[0].get("type") != "run_start" or events[-1].get("type") != "run_end":
        raise PanelEvidenceError("episode lacks ordered terminal evidence")
    terminal = events[-1]["payload"]
    start = events[0]["payload"]
    for key in ("task_id", "package_digest", "config_version", "config_digest", "panel", "member", "trial"):
        expected = spec["task"]["task_id"] if key == "task_id" else spec["panel_binding"][key]
        if start.get(key) != expected:
            raise PanelEvidenceError(f"episode {key} binding differs")
    if type(terminal.get("success")) is not bool or type(terminal.get("steps")) is not int:
        raise PanelEvidenceError("invalid terminal types")
    if result.get("success") != terminal["success"] or result.get("steps") != terminal["steps"]:
        raise PanelEvidenceError("result conflicts with terminal")
    if "error" not in terminal:
        raise PanelEvidenceError("terminal error missing")
    return {
        "trial": spec["panel_binding"]["trial"],
        "success": terminal["success"],
        "steps": terminal["steps"],
        "model_calls": sum(e.get("type") == "model_call" for e in events),
        "wall_ms": wall_ms,
        "child_root": root["root"],
        "error": terminal["error"],
        "instance": spec["task"]["instance"],
        "events": events,
        "events_digest": canonical_sha256(events),
    }


def build_report(work: dict, config, directory: Path, signer, node_id: str) -> dict:
    panel = config.settlement
    members = []
    for member in panel.members:
        rows = []
        for trial in range(work["trials_per_member"]):
            stem = f"{member.id}-{trial}"
            spec = json.loads((directory / "specs" / f"{stem}.json").read_text())
            result = json.loads((directory / "results" / f"{stem}.json").read_text())
            rows.append(episode_row(spec, result, signer))
        members.append({"member": member.id, "member_kind": member.kind, "trials": rows})
    task = work["task"]
    body = {
        "task_id": task["task_id"],
        "run_id": work["run_id"],
        "panel": config.settlement_panel,
        "task_source": task["source"],
        "package_digest": task["package_digest"],
        "roles": dict(panel.roles),
        "members": members,
        "config_version": config.version,
        "config_digest": config.digest,
        "node_id": node_id,
    }
    manifest = build_manifest(
        task_id=task["task_id"],
        run_id=work["run_id"],
        package_digest=task["package_digest"],
        config_version=config.version,
        config_digest=config.digest,
        panel=config.settlement_panel,
        settlement=True,
        node_id=node_id,
        key_id=signer.key_id,
        roles=panel.roles,
        members=members,
    )
    body["manifest"] = sign_manifest(manifest, signer.seed)
    return body
