"""Installed daemon -> fixed root helper recovery bootstrap, no injected hook.

P03 sealed local objects never cross the privilege boundary. The daemon gets
only a signed expectation; reconciliation is re-run inside the parent using
the same original files and independent registration after the HTTP response.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import secrets

from task_source.panel_state import read
from task_source.scene_episode_launcher import digest, SceneParentSession
from task_source.scene_episode_scope import require
from task_source.scene_views.identity import decode, encoded

DOMAIN = "openroboto:scene-recovery-parent:v1"


def verify_operation(receipt, public, action, request):
    from benchmark_worker.reference_panel.manifest import verify_manifest

    payload = (
        "journal"
        if action in {"recovery-prepare", "recovery-unstarted-prepare"}
        else "reconciliation"
        if action in {"recovery-reconcile", "recovery-unstarted-reconcile"}
        else "result"
    )
    require(
        type(receipt) is dict
        and set(receipt)
        in (
            {"domain", "action", "request_digest", "deployment_digest", payload, "key_id", "algorithm", "signature"},
            {"domain", "action", "request_digest", "deployment_digest", "error", "key_id", "algorithm", "signature"},
        ),
        "SCENE_RECOVERY_PARENT_RECEIPT_INVALID",
    )
    require(
        receipt["domain"] == DOMAIN
        and receipt["action"] == action
        and receipt["request_digest"] == digest(request)
        and receipt["deployment_digest"] == public["deployment_digest"]
        and receipt["key_id"] == public["key_id"]
        and receipt["algorithm"] == "ed25519"
        and verify_manifest(receipt, public["public_key_hex"]),
        "SCENE_RECOVERY_PARENT_SIGNATURE_INVALID",
    )
    if "error" in receipt:
        from task_source.scene_recovery import SceneRecoveryError
        import re

        error = receipt["error"]
        require(
            type(error) is dict
            and set(error) == {"status", "code"}
            and error["status"] == "held"
            and re.fullmatch("SCENE_RECOVERY_[A-Z0-9_]{1,64}", error["code"]),
            "SCENE_RECOVERY_PARENT_RECEIPT_INVALID",
        )
        raise SceneRecoveryError(error["code"])
    return receipt[payload]


class RegisteredRecoveryReader:
    """Installed by PanelWorker construction for its registered scene launcher."""

    def __init__(self, launcher, worker):
        self.launcher, self.worker = launcher, worker

    def operation(self, action, body):
        public = self.launcher.public_document()
        request = decode(encoded({**body, "challenge": secrets.token_hex(32)}))
        with SceneParentSession(public, request, stage=action) as parent:
            reply = parent.receive("recovery", public["recovery_timeout_s"])
            require(set(reply) == {"stage", "request_digest", "receipt"})
            require(parent.process.wait(timeout=public["cleanup_timeout_s"]) == 0, "SCENE_RECOVERY_PARENT_FAILED")
            result = verify_operation(reply["receipt"], public, action, request)
        return result, reply["receipt"], public, request

    def remember_commitment(self, work, commitment):
        result, _, _, _ = self.operation("recovery-commitment", {"work": work, "commitment": commitment})
        require(
            result == {"stored": True, "commitment_digest": digest(commitment), "execution_authorized": False},
            "SCENE_RECOVERY_COMMITMENT_CHANGED",
        )

    def scene_recovery_journal(self, work, *, directory):
        return self._journal(work, directory=directory, action="recovery-prepare")

    def scene_unstarted_recovery_journal(self, work, *, directory):
        return self._journal(work, directory=directory, action="recovery-unstarted-prepare")

    def _journal(self, work, *, directory, action):
        from task_source.scene_recovery import RecoveryJournal, directory as expected_directory

        state = read(self.worker.root / "state.json")
        require(
            state["work"] == work and expected_directory(self.worker, state) == directory, "SCENE_RECOVERY_WORK_CHANGED"
        )
        generation = state.get("scene_recovery_generation")
        require(type(generation) is int and generation >= 0, "SCENE_RECOVERY_GENERATION_INVALID")
        body = {"work": work, "base_generation": generation}
        doc, proof, public, request = self.operation(action, body)
        handle = ParentRecoveryJournal(
            self, encoded(body), encoded(doc), encoded(proof), encoded(public), encoded(request)
        )
        handle.verify(doc)
        return RecoveryJournal(encoded(doc), _remote=handle)


@dataclass(frozen=True)
class ParentRecoveryJournal:
    reader: RegisteredRecoveryReader = field(repr=False)
    body_bytes: bytes = field(repr=False)
    journal_bytes: bytes = field(repr=False)
    proof_bytes: bytes = field(repr=False)
    public_bytes: bytes = field(repr=False)
    request_bytes: bytes = field(repr=False)

    @property
    def proof(self):
        return decode(self.proof_bytes)

    def verify(self, doc):
        action = (
            "recovery-unstarted-prepare"
            if doc.get("schema_version") == "scene-unstarted-recovery-journal-v1"
            else "recovery-prepare"
        )
        observed = verify_operation(self.proof, decode(self.public_bytes), action, decode(self.request_bytes))
        require(encoded(doc) == self.journal_bytes == encoded(observed), "SCENE_RECOVERY_JOURNAL_CHANGED")

    def reconcile(self, doc, checkpoint):
        self.verify(doc)
        result, proof, public, _ = self.reader.operation(
            "recovery-unstarted-reconcile"
            if doc.get("schema_version") == "scene-unstarted-recovery-journal-v1"
            else "recovery-reconcile",
            {
                **decode(self.body_bytes),
                "journal_digest": digest(doc),
                "checkpoint": checkpoint,
            },
        )
        require(public == decode(self.public_bytes), "SCENE_RECOVERY_PARENT_REGISTRATION_CHANGED")
        require(
            result.get("matched") is True
            and result.get("execution_authorized") is False
            and result.get("rerun_authorized") is False,
            "SCENE_RECOVERY_PARENT_RECEIPT_INVALID",
        )
        return {**result, "parent_proof": proof}
