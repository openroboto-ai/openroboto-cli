"""Captured R15 authenticated commitment, never inferred from resume or ZIP."""

from __future__ import annotations

import re
import urllib.parse

from task_source.panel_state import read, write
from task_source.scene_views.identity import decode

FIELDS = {
    "schema_version",
    "run_id",
    "worker_id",
    "node_id",
    "recovery_generation",
    "binding_digest",
    "execution_authorized",
}


def need(value, code="SCENE_RECOVERY_COMMITMENT_INVALID"):
    if not value:
        raise ValueError(code)


def validate_data(data, work, *, worker_id, node_id, generation=None):
    need(type(data) is dict and set(data) == FIELDS)
    need(data["schema_version"] == "scene-recovery-commitment-v1" and data["execution_authorized"] is False)
    need((data["run_id"], data["worker_id"], data["node_id"]) == (work["run_id"], worker_id, node_id))
    need(type(data["recovery_generation"]) is int and data["recovery_generation"] >= 0)
    need(type(data["binding_digest"]) is str and re.fullmatch("[0-9a-f]{64}", data["binding_digest"]))
    if generation is not None:
        need(data["recovery_generation"] == generation, "SCENE_RECOVERY_GENERATION_INVALID")
    return data


def commitment_receipt(client, work, captured):
    from task_source.scene_recovery import digest, stable_work

    result = {
        "schema_version": "scene-commitment-receipt-v1",
        "backend": client.base_url,
        "path": f"/api/v1/task/evaluation/{urllib.parse.quote(work['run_id'], safe='')}/scene-recovery-commitment",
        "local_binding_digest": digest(stable_work(work)),
        **captured,
    }
    validate_receipt(result, work, backend=client.base_url, worker_id=client.worker_id, node_id=client.node_id)
    return result


def validate_receipt(receipt, work, *, backend, worker_id, node_id, generation=None):
    from task_source.panel_client import _no_store, contains_recovery_material
    from task_source.scene_recovery import digest, stable_work

    need(
        type(receipt) is dict
        and set(receipt)
        == {"schema_version", "backend", "path", "local_binding_digest", "data", "response_bytes", "cache_control"}
    )
    need(receipt["schema_version"] == "scene-commitment-receipt-v1" and receipt["backend"] == backend)
    need(
        receipt["path"]
        == f"/api/v1/task/evaluation/{urllib.parse.quote(work['run_id'], safe='')}/scene-recovery-commitment"
    )
    need(receipt["local_binding_digest"] == digest(stable_work(work)))
    need(type(receipt["response_bytes"]) is str and len(receipt["response_bytes"]) <= 131072)
    raw = bytes.fromhex(receipt["response_bytes"])
    envelope = decode(raw)
    need(type(envelope) is dict and set(envelope) == {"data", "meta"} and type(envelope["meta"]) is dict)
    need(envelope["data"] == receipt["data"] and _no_store({"Cache-Control": receipt["cache_control"]}))
    need(not contains_recovery_material(envelope))
    return validate_data(receipt["data"], work, worker_id=worker_id, node_id=node_id, generation=generation)


def ensure_commitment(worker, state, directory):
    """CLI control-plane path: capture/save first, root-pin second, then pay.

    Failed/lost reads never create another run. Old expired runs without this
    pre-submitted source stay held; they cannot call resume to backfill it.
    """
    work = state["work"]
    generation = state.get("scene_recovery_generation")
    need(type(generation) is int and generation >= 0, "SCENE_RECOVERY_GENERATION_INVALID")
    target = directory / "commitments" / f"generation-{generation}.json"
    original = None
    if generation:
        first = directory / "commitments" / "generation-0.json"
        need(first.is_file(), "SCENE_RECOVERY_FIRST_COMMITMENT_REQUIRED")
        original = validate_receipt(
            read(first),
            work,
            backend=worker.client.base_url,
            worker_id=worker.client.worker_id,
            node_id=worker.client.node_id,
            generation=0,
        )

    def validate_current(receipt):
        data = validate_receipt(
            receipt,
            work,
            backend=worker.client.base_url,
            worker_id=worker.client.worker_id,
            node_id=worker.client.node_id,
            generation=generation,
        )
        need(
            original is None or data["binding_digest"] == original["binding_digest"],
            "SCENE_RECOVERY_COMMITMENT_CHANGED",
        )

    if target.exists():
        receipt = read(target)
    else:
        receipt = worker.client.scene_recovery_commitment(work, state.get("scene_recovery_token"))
        validate_current(receipt)
        write(target, receipt, exclusive=True)  # Original full response, 0600/fsync BEFORE helper or paid marker.
    validate_current(receipt)
    if worker.scene_recovery_reader is not None:
        worker.scene_recovery_reader.remember_commitment(work, receipt)
    return receipt


def observe_progress(work, directory, stage, detail):
    """Record the exact sent ProgressDetail only AFTER its HTTP acknowledgement."""
    from task_source.scene_recovery import digest, stable_work

    fields = {"completed_trials", "total_trials", "current_member", "current_trial", "last_status", "error_code"}
    need(set(detail) <= fields, "SCENE_RECOVERY_PROGRESS_INVALID")
    progress = {key: detail.get(key) for key in fields}
    write(
        directory / "recovery-progress.json",
        {
            "schema_version": "scene-accepted-progress-v1",
            "local_binding_digest": digest(stable_work(work)),
            "stage": stage,
            "progress": progress,
        },
    )
