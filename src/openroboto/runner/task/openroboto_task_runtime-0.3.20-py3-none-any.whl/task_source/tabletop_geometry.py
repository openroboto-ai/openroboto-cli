"""逐受控资产的真实投影与对称姿态；不使用方块替代曲面。"""

from __future__ import annotations

import math
from functools import lru_cache
from typing import Any, Mapping

import numpy as np
from openroboto_protocol.tabletop_assets import asset_catalog, rotate_vector, support_local


@lru_cache(maxsize=1)
def assets() -> dict[str, dict[str, Any]]:
    return {a["id"]: a for a in asset_catalog()}


def rotation(quaternion):
    return np.array([rotate_vector(quaternion, axis) for axis in np.eye(3).tolist()]).T


def support_world(asset, quaternion, direction):
    local = rotation(quaternion).T @ np.asarray(direction)
    return support_local(asset["geometry"], local.tolist())


def _ellipse_radius(center, a, b):
    """椭圆到原点最远距离：枚举导数四次多项式全部实根与无穷点。"""
    aa, bb, ab = float(a @ a), float(b @ b), float(a @ b)
    A, B, C, D = -2 * float(center @ a), 2 * float(center @ b), -(aa - bb), 2 * ab
    coefficients = np.array([-B + D, 2 * A - 4 * C, -6 * D, 2 * A + 4 * C, B + D])
    coefficients = np.trim_zeros(coefficients, "f")
    roots = np.roots(coefficients) if len(coefficients) > 1 else []
    angles = [0.0, math.pi] + [2 * math.atan(float(r.real)) for r in roots if abs(r.imag) < 1e-7]
    return max(float(np.linalg.norm(center + a * math.cos(t) + b * math.sin(t))) for t in angles)


def projection_radius(asset, position, quaternion, target_xy):
    """任意姿态下整个刚体XY投影的最远半径，单位米。"""
    geometry = asset["geometry"]
    rot = rotation(quaternion)
    center = np.asarray(position[:2]) - np.asarray(target_xy)
    kind = geometry["type"]
    if kind == "mesh":
        vertices = geometry["vertices"]
    elif kind == "box":
        import itertools

        vertices = list(itertools.product(*[(-s, s) for s in geometry["size"]]))
    else:
        size = geometry["size"]
        if kind == "sphere":
            return float(np.linalg.norm(center)) + size[0]
        if kind == "capsule":
            return max(float(np.linalg.norm(center + sign * size[1] * rot[:2, 2])) for sign in [-1, 1]) + size[0]
        return max(
            _ellipse_radius(center + sign * size[1] * rot[:2, 2], size[0] * rot[:2, 0], size[0] * rot[:2, 1])
            for sign in [-1, 1]
        )
    return max(float(np.linalg.norm(center + (rot @ np.asarray(v))[:2])) for v in vertices)


def pose_error(asset, current, target):
    """对资产的真实旋转对称性取最小角误差，不考不可观测自由度。"""
    first, second = rotation(current), rotation(target)
    symmetry = asset["symmetry"]
    if symmetry == "isotropic":
        return 0.0
    if symmetry == "axial_unsigned":
        return math.acos(np.clip(abs(float(first[:, 2] @ second[:, 2])), -1, 1))
    if symmetry == "box":
        rotations = [np.asarray(r) for r in asset["symmetry_rotations"]]
    elif symmetry == "prism":
        rotations = [np.eye(3), np.diag([-1, 1, -1])]
    else:
        rotations = [
            np.array([[math.cos(a), -math.sin(a), 0], [math.sin(a), math.cos(a), 0], [0, 0, 1]])
            for a in [2 * math.pi * k / 64 for k in range(64)]
        ]
    cosine = max((float(np.trace(first.T @ second @ s)) - 1) / 2 for s in rotations)
    return math.acos(np.clip(cosine, -1, 1))


def valid_state(state: Mapping[str, Any], definition: Mapping[str, Any]) -> bool:
    """缺失、非有限或非单位姿态使整个程序失败，不能被NOT变成通过。"""
    try:
        for obj in definition["objects"]:
            name = obj["id"]
            for field, size in [
                ("positions", 3),
                ("orientations", 4),
                ("linear_velocities", 3),
                ("angular_velocities", 3),
            ]:
                values = state[field][name]
                if len(values) != size or not all(type(v) in (float, int) and math.isfinite(v) for v in values):
                    return False
            if abs(sum(v * v for v in state["orientations"][name]) - 1) > 1e-6:
                return False
        if not isinstance(state["contacts"], list):
            return False
        for contact in state["contacts"]:
            if not isinstance(contact["a"], str) or not isinstance(contact["b"], str):
                return False
            for field in ["point", "force_on_b"]:
                if len(contact[field]) != 3 or not all(
                    type(v) in (float, int) and math.isfinite(v) for v in contact[field]
                ):
                    return False
            if not math.isfinite(contact.get("distance_m", 0)):
                return False
        return True
    except (KeyError, TypeError, ValueError, OverflowError):
        return False
