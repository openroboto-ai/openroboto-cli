"""用 manifest 复现一次准入判定（OPE-118 / OPE-113）。

``quarantine`` 之后，运营拿到当时那份 manifest 和同一份题包，在 validator 上
重跑准入，逐项比对：

- ``input_hash`` 不一致 = 这次读到的题包 / 配置已经不是当时那份；
- ``output_hash`` 不一致 = 同样的输入算出了不同的判定，需要人来看。

签名用 ``--public-key`` 单独验；没有公钥时只做格式和复现比较。
"""

from __future__ import annotations

import json
import pathlib
from typing import Any, Mapping

from .manifest import CHECK_NAMES, build_manifest, verify_manifest
from .runtime import get_profile, run_admission
from .worker import package_digest

__all__ = ["verify_against_package"]


def _load_manifest(path: str | pathlib.Path) -> dict[str, Any]:
    data = json.loads(pathlib.Path(path).expanduser().read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path}: manifest must be a JSON object")
    return data


def verify_against_package(
    manifest_path: str | pathlib.Path,
    package_dir: str | pathlib.Path,
    *,
    profile_name: str = "axis-cpu",
    profile_config: str | pathlib.Path | None = None,
    profile: Mapping[str, Any] | None = None,
    dedup_index: str | pathlib.Path | None = None,
    instruction_mode: str | None = None,
    public_key_hex: str | None = None,
    expected_attempt: int | None = None,
    submitted_at: str | None = None,
    commit_block: int | None = None,
    submission_id: str | None = None,
    source: Any | None = None,
) -> dict[str, Any]:
    """重跑准入并逐项比对。返回可 JSON 序列化的报告（``errors`` 为空 = 一致）。

    去重检查的提交侧输入（``submitted_at`` / ``commit_block`` /
    ``submission_id``）默认从 manifest 的 ``dedup_input`` 取 —— 生产 worker
    签出的 manifest 自己记录过。显式传入时以调用方为准，并与记录值比对：
    拿错一次提交的输入复现，应该报 ``dedup_input`` 不一致，而不是给出
    一份看似可信的 MISMATCH。
    """
    manifest = _load_manifest(manifest_path)
    expected: dict[str, Any] = {}
    if expected_attempt is not None:
        expected["attempt"] = expected_attempt
    errors = verify_manifest(manifest, public_key_hex=public_key_hex, expected=expected or None)

    recorded_submission = manifest.get("dedup_input")
    if not isinstance(recorded_submission, Mapping):
        recorded_submission = {}
    replay_submission = {
        "submitted_at": (
            submitted_at if submitted_at is not None else recorded_submission.get("submitted_at")
        ),
        "commit_block": (
            commit_block if commit_block is not None else recorded_submission.get("commit_block")
        ),
        "submission_id": (
            submission_id if submission_id is not None else recorded_submission.get("submission_id")
        ),
    }
    for field, value in replay_submission.items():
        if recorded_submission.get(field) != value:
            errors.append(
                f"dedup_input.{field} changed: manifest {recorded_submission.get(field)!r} "
                f"vs replay {value!r}"
            )

    resolved_profile = dict(profile) if profile is not None else get_profile(profile_name, profile_config)
    if dedup_index:
        resolved_profile["dedup"] = {"index": str(dedup_index)}
    if instruction_mode:
        instruction = dict(resolved_profile.get("instruction") or {})
        instruction["mode"] = instruction_mode
        resolved_profile["instruction"] = instruction
    verdict = run_admission(
        package_dir,
        profile=resolved_profile,
        source=source,
        submitted_at=replay_submission["submitted_at"],
        commit_block=replay_submission["commit_block"],
        submission_id=replay_submission["submission_id"],
    )
    actual = build_manifest(
        verdict=verdict,
        package_digest=package_digest(package_dir),
        attempt=int(manifest.get("attempt") or 1),
        node_id=str(manifest.get("node_id") or ""),
        policy_version=str(manifest.get("policy_version") or 1),
        started_at=str(manifest.get("started_at") or ""),
        finished_at=str(manifest.get("finished_at") or ""),
        submission=replay_submission,
        key_id=str(manifest.get("key_id") or ""),
        # 复现时用 manifest 自己记录的提交身份 —— worker 写的是后端队列的
        # task_id，不是题包 task.json 里的题源标识。不传的话，同一份题包
        # 重跑会被误报成 task_id changed。
        task_id=str(manifest.get("task_id") or "") or None,
    )

    if actual["package_digest"] != manifest.get("package_digest"):
        errors.append(
            f"package_digest changed: manifest {manifest.get('package_digest')} vs replay {actual['package_digest']}"
        )
    if actual["task_id"] != manifest.get("task_id"):
        errors.append(f"task_id changed: manifest {manifest.get('task_id')} vs replay {actual['task_id']}")
    if actual["verdict_hash"] != manifest.get("verdict_hash"):
        errors.append("verdict_hash changed: the outcome or its reason differs from the recorded run")

    expected_checks = {
        item["name"]: item
        for item in manifest.get("checks", [])
        if isinstance(item, dict) and item.get("name") in CHECK_NAMES
    }
    comparison: list[dict[str, Any]] = []
    for item in actual["checks"]:
        name = item["name"]
        recorded = expected_checks.get(name, {})
        match = (
            recorded.get("ok") == item["ok"]
            and recorded.get("input_hash") == item["input_hash"]
            and recorded.get("output_hash") == item["output_hash"]
        )
        if not match and recorded:
            if recorded.get("input_hash") != item["input_hash"]:
                errors.append(f"check {name}: input_hash differs")
            if recorded.get("output_hash") != item["output_hash"]:
                errors.append(f"check {name}: output_hash differs")
            if recorded.get("ok") != item["ok"]:
                errors.append(f"check {name}: ok {recorded.get('ok')!r} != replay {item['ok']!r}")
        comparison.append({
            "name": name,
            "match": match,
            "expected_ok": recorded.get("ok"),
            "replayed_ok": item["ok"],
            "input_hash": item["input_hash"],
            "output_hash": item["output_hash"],
        })

    return {
        "task_id": actual["task_id"],
        "attempt": actual["attempt"],
        "package_digest": actual["package_digest"],
        "outcome": actual["outcome"],
        "signed": bool(manifest.get("signature")),
        "errors": errors,
        "checks": comparison,
    }
