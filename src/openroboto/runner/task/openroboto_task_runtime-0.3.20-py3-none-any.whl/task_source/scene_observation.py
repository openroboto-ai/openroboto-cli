"""Versioned scene observation admission; never turns state into image visibility."""

from __future__ import annotations

import base64
from collections.abc import Mapping
import hashlib
import io
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image

from openroboto_protocol import scene_contract
from openroboto_protocol.tabletop_assets import canonical_digest
from .base import RuntimeUnavailable

_DATA = Path(__file__).with_name("data")
POLICY_FILE = _DATA / "scene_observation_admission_v2.json"
_POLICIES = {
    "scene-observation-admission/1": {
        "file": "scene_observation_admission_v1.json",
        "sha256": "ac6272aa4166b6fe27a97e54c80435065f747ab4df61cbe60d7078523ec0b539",
        "digest": "3e6052eda8ddcdf8c591ce286a2d451d3dede0b5987058838037e0dfd53dba03",
        "profile": {
            "id": "panda-open-scene-v1",
            "version": "2.0.0",
            "digest": "052ede59310a10eecdaefb43584f06340bc3ad461dbca8579cdb23b8ec4ad3d5",
        },
    },
    "scene-observation-admission/2": {
        "file": "scene_observation_admission_v2.json",
        "sha256": "efe5762047dc8516f3d5f63c8d5a6a7d000018051412cb2458225cde82d35966",
        "digest": "6ce135f8c6c7d18680e598c0c1ef817e0052cf1fcf7c2fde724d93718c2d4336",
        "profile": {
            "id": "panda-open-scene-v1",
            "version": "2.1.0",
            "digest": "9badf61d742ed5787e7af4ad19adc90b616147ee4c62159915bddeff53f9a1a2",
        },
    },
}


class SceneObservationPolicyError(RuntimeUnavailable):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def _installation_binding():
    """Authenticate the selected installed document, never submitted config."""
    try:
        raw = POLICY_FILE.read_bytes()
        document = json.loads(raw)
        spec = _POLICIES[document["id"]]
        expected_scope = {
            "profile_id": spec["profile"]["id"],
            "profile_version": spec["profile"]["version"],
            "profile_digest": spec["profile"]["digest"],
            "task_schema": 3,
            "execution_version": 3,
        }
        if (
            POLICY_FILE.is_symlink()
            or POLICY_FILE.resolve().parent != _DATA.resolve()
            or POLICY_FILE.name != spec["file"]
            or hashlib.sha256(raw).hexdigest() != spec["sha256"]
            or canonical_digest(document) != spec["digest"]
            or document["scope"] != expected_scope
            or type(document["scope"]["task_schema"]) is not int
            or type(document["scope"]["execution_version"]) is not int
        ):
            raise ValueError("unregistered installed policy")
        return document, spec
    except (OSError, ValueError, TypeError, KeyError) as exc:
        raise SceneObservationPolicyError("scene_observation_policy_unavailable") from exc


def policy_document():
    return _installation_binding()[0]


def policy_identity():
    document, spec = _installation_binding()
    return {"id": document["id"], "digest": spec["digest"], "document_sha256": spec["sha256"]}


def policy_scope_matches(reference, *, task_schema=3, execution_version=3):
    try:
        scope = policy_document()["scope"]
        return (
            type(task_schema) is int
            and task_schema == scope["task_schema"]
            and type(execution_version) is int
            and execution_version == scope["execution_version"]
            and reference
            == {"id": scope["profile_id"], "version": scope["profile_version"], "digest": scope["profile_digest"]}
        )
    except SceneObservationPolicyError:
        return False


def _task_scope_matches(task):
    try:
        if isinstance(task, Mapping):
            profile, contract = task["execution_profile"], task["execution_contract"]
            return (
                profile == scene_contract.profile_ref() == contract["execution_profile"]
                and task["task_definition"]["observation"] == contract["observation_contract"]
                and policy_scope_matches(
                    profile, task_schema=task["schema_version"], execution_version=contract["version"]
                )
            )
        meta = task.metadata
        actual = meta["imported_scene"].task
        profile = actual.execution_profile
        if not isinstance(profile, Mapping):
            profile = profile.model_dump(mode="json")
        declared, contract = actual.execution_contract, meta["execution_contract"]
        return (
            profile == meta["execution_profile"] == scene_contract.profile_ref()
            and declared["execution_profile"] == contract["execution_profile"] == profile
            and type(declared["version"]) is int
            and declared["version"] == contract["version"]
            and actual.task_definition.observation
            == meta["observation_contract"]
            == contract["observation_contract"]
            == declared["observation_contract"]
            and policy_scope_matches(profile, task_schema=actual.schema_version, execution_version=contract["version"])
        )
    except (AttributeError, KeyError, TypeError, ValueError):
        return False


def require_policy_scope(task=None):
    # Authenticate first so changed/missing installed bytes have a distinct
    # unavailable finding. An unknown/mismatched task never falls back to axis.
    policy_document()
    matches = policy_scope_matches(scene_contract.profile_ref()) if task is None else _task_scope_matches(task)
    if not matches:
        raise SceneObservationPolicyError("scene_observation_policy_scope_unregistered")


def scene_state_policy(task):
    return _task_scope_matches(task) and task.metadata.get("observation_contract") == "state"


def validate_observation(task, env, observation):
    """Inspect the actual formal observe projection on the same native MjData.

    No reset/step or synthetic observation is performed. Missing/extra fields,
    mismatched calibration and unavailable images fail closed. The returned
    evidence is private; it contains identities and findings, never new model
    sensor permissions or rewritten segmentation results.
    """
    require_policy_scope(task)
    from .scene_import.validation import matrix
    from .scene_instruction_runtime import check

    imported, issues = task.metadata["imported_scene"], []
    camera = imported.task.scene.camera
    bindings = imported.bindings
    expected_entities = set(bindings["bodies"])
    expected_joints = set(bindings["joints"]) | set(bindings["robot"]["joint_order"])
    actual = env.state()
    instruction_finding = check(task.metadata["package"].task, delivered_instruction=observation.get("instruction"))
    if not instruction_finding.accepted or not instruction_finding.delivery_checked:
        issues.append(instruction_finding.code)

    def fail(code):
        if code not in issues:
            issues.append(code)

    try:
        allowed = {"step", "instruction", "image", "proprioception", "objects", "state", "success", "detail"}
        if set(observation) - allowed or observation.get("detail"):
            fail("unapproved_observation_field")
        if type(observation.get("step")) is not int or type(observation.get("success")) is not bool:
            fail("observation_shape")
        if observation.get("instruction") != task.instruction:
            fail("instruction_identity")
        proprio = observation["proprioception"]
        if set(proprio) != {"tcp", "gripper"}:
            fail("proprioception_fields")
        if len(proprio["tcp"]) != 3 or not all(math.isfinite(float(v)) for v in [*proprio["tcp"], proprio["gripper"]]):
            fail("proprioception_finite")
        image = observation["image"]
        with Image.open(io.BytesIO(base64.b64decode(image["data_base64"], validate=True))) as rgb:
            if rgb.format != "PNG" or list(rgb.size) != list(camera.image_size) or rgb.mode != "RGB":
                fail("camera_image")
            rgb.verify()
        cid = bindings["camera"]["id"]
        actual_pose = np.eye(4)
        actual_pose[:3, :3] = env.data.cam_xmat[cid].reshape(3, 3)
        actual_pose[:3, 3] = env.data.cam_xpos[cid]
        expected_pose = np.asarray(imported.manifest["frames"][camera.frame]) @ matrix(camera.pose_in_frame)
        if (
            env.mujoco.mj_id2name(env.model, env.mujoco.mjtObj.mjOBJ_CAMERA, cid) != camera.name
            or bindings["camera"]["calibration_digest"] != camera.digest
            or list(bindings["camera"]["image_size"]) != list(camera.image_size)
            or [env.model.vis.global_.offwidth, env.model.vis.global_.offheight] != list(camera.image_size)
            or not np.allclose(actual_pose, expected_pose, rtol=1e-7, atol=2e-7)
            or not math.isclose(float(env.model.cam_fovy[cid]), camera.vertical_fov_deg, rel_tol=1e-7, abs_tol=2e-7)
        ):
            fail("camera_calibration")
        vision = task.metadata["observation_contract"] == "vision"
        state, objects = observation.get("state", {}), observation.get("objects", {})
        if vision:
            if state or objects:
                fail("vision_ground_truth")
        else:
            fields = {"positions": 3, "orientations": 4, "linear_velocities": 3, "angular_velocities": 3}
            if set(state) != set(fields) | {"joints"}:
                fail("state_fields")
            for key, size in fields.items():
                values = state.get(key, {})
                if set(values) != expected_entities:
                    fail("state_entity_coverage")
                for name, vector in values.items():
                    if len(vector) != size or not np.isfinite(vector).all():
                        fail("state_finite")
                    elif name not in actual[key] or not np.array_equal(vector, actual[key][name]):
                        fail("state_native_mapping")
            joints = state.get("joints", {})
            if set(joints) != expected_joints:
                fail("state_joint_coverage")
            for name, value in joints.items():
                if type(value) not in (int, float) or not math.isfinite(value):
                    fail("joint_finite")
                elif name not in actual["joints"] or value != actual["joints"][name]:
                    fail("joint_native_mapping")
            if set(objects) != expected_entities:
                fail("object_sensor_coverage")
            for name, entry in objects.items():
                if set(entry) != {"pos", "center", "rot"}:
                    fail("object_sensor_fields")
                for key, value in entry.items():
                    if (
                        key not in {"pos", "center", "rot"}
                        or len(value) != (4 if key == "rot" else 3)
                        or not np.isfinite(value).all()
                    ):
                        fail("object_sensor_finite")
                if name in actual["positions"]:
                    expected = {
                        "pos": actual["positions"][name],
                        "center": env.object_center(name),
                        "rot": actual["orientations"][name],
                    }
                    for key, value in entry.items():
                        if key in expected and not np.allclose(value, expected[key], rtol=0, atol=6e-7):
                            fail("object_sensor_native_mapping")
    except Exception:
        fail("observation_unavailable")
    try:
        projection_digest = canonical_digest(observation)
    except (TypeError, ValueError):
        projection_digest = None
        fail("observation_finite_json")
    return {
        "policy": policy_identity(),
        "instruction": instruction_finding.to_dict(),
        "passed": not issues,
        "issues": issues,
        "observation_contract": task.metadata["observation_contract"],
        "camera": camera.model_dump(mode="json"),
        "entities": sorted(expected_entities),
        "joints": sorted(expected_joints),
        "entity_frame": "world",
        "joint_units": {
            **{name: "rad" for name in expected_joints if "finger" not in name},
            **{name: "m" for name in expected_joints if "finger" in name},
            **{joint.id: joint.unit for joint in imported.task.scene.joints},
        },
        "projection_digest": projection_digest,
    }


def runtime_policy(base, *, task=None):
    """Snapshot the actual inherited physics settings plus the new semantics."""
    require_policy_scope(task)
    result = json.loads(json.dumps(base, allow_nan=False))
    if result.get("visibility") is False:
        raise ValueError("scene admission requires real camera and observation checks")
    result["scene_observation_policy"] = {**policy_identity(), "configuration": policy_document()}
    from .scene_instruction_runtime import policy_identity as instruction_identity

    result["scene_instruction_policy"] = instruction_identity()
    return result
