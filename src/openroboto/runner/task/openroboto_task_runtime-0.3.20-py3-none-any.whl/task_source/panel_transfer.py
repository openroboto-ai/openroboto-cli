"""Private resumable object uploads. Session capability URLs never enter logs."""

from __future__ import annotations

import base64
import hashlib
import re
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from task_source.panel_client import PanelAPIError, _NoRedirect
from task_source.panel_state import read, write


def file_identity(path):
    sha, md5 = hashlib.sha256(), hashlib.md5(usedforsecurity=False)
    size = 0
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            sha.update(block)
            md5.update(block)
            size += len(block)
    return {"sha256": sha.hexdigest(), "bytes_len": size, "md5_b64": base64.b64encode(md5.digest()).decode()}


def _allowed_session(url):
    parsed = urllib.parse.urlsplit(url)
    return (
        parsed.scheme == "https"
        and not parsed.username
        and not parsed.password
        and not parsed.fragment
        and (parsed.hostname == "storage.googleapis.com" or (parsed.hostname or "").endswith(".storage.googleapis.com"))
    )


class ResumableUpload:
    def __init__(self, *, timeout_s=120, chunk_bytes=8 * 1024 * 1024, request=None):
        if chunk_bytes <= 0 or chunk_bytes % 262144:
            raise ValueError("upload chunks must align to 262144 bytes")
        self.timeout_s, self.chunk_bytes = timeout_s, chunk_bytes
        self._request = request or self._put

    def _put(self, url, data, headers):
        if not _allowed_session(url):
            raise PanelAPIError(None, "UPLOAD_SESSION_ORIGIN_INVALID")
        request = urllib.request.Request(url, data=data, headers=headers, method="PUT")
        try:
            with urllib.request.build_opener(_NoRedirect()).open(request, timeout=self.timeout_s) as response:
                return response.status, dict(response.headers)
        except urllib.error.HTTPError as error:
            return error.code, dict(error.headers)
        except (urllib.error.URLError, OSError):
            raise PanelAPIError(None, "OBJECT_UPLOAD_NETWORK_ERROR") from None

    @staticmethod
    def _offset(status, headers, total):
        if status in (200, 201):
            return total
        if status != 308:
            raise PanelAPIError(status, "OBJECT_UPLOAD_REJECTED")
        value = next((value for key, value in headers.items() if key.lower() == "range"), None)
        if value is None:
            return 0
        match = re.fullmatch(r"bytes=0-(\d+)", value)
        if not match or int(match.group(1)) >= total:
            raise PanelAPIError(None, "OBJECT_UPLOAD_RANGE_INVALID")
        return int(match.group(1)) + 1

    def upload(self, path, checkpoint, *, presign, retry_expired=True):
        identity = file_identity(path)
        if identity["bytes_len"] <= 0:
            raise PanelAPIError(None, "EMPTY_UPLOAD")
        state = read(checkpoint) if checkpoint.exists() else None
        if state and state["identity"] != identity:
            raise PanelAPIError(None, "UPLOAD_CONTENT_CHANGED")
        if state is None:
            target = presign(identity)
            if (
                target.get("already_available") is True or target.get("already_uploaded") is True
            ) and target.get("upload_url") is None:
                return identity
            if (
                target.get("method") != "PUT"
                or target.get("resumable") is not True
                or target.get("chunk_alignment") != 262144
                or not _allowed_session(target.get("upload_url", ""))
                or set(target.get("headers", {})) != {"Content-Type"}
            ):
                raise PanelAPIError(None, "UPLOAD_PRESIGN_INVALID")
            state = {"identity": identity, "target": target}
            write(checkpoint, state, exclusive=True)
        target = state["target"]
        total = identity["bytes_len"]
        status, headers = self._request(
            target["upload_url"], b"", {"Content-Length": "0", "Content-Range": f"bytes */{total}"}
        )
        if status in (404, 410) and retry_expired:
            sequence = 1
            while checkpoint.with_name(checkpoint.name + f".expired-{sequence}").exists():
                sequence += 1
            checkpoint.rename(checkpoint.with_name(checkpoint.name + f".expired-{sequence}"))
            return self.upload(path, checkpoint, presign=presign, retry_expired=False)
        offset = self._offset(status, headers, total)
        with Path(path).open("rb") as stream:
            while offset < total:
                stream.seek(offset)
                block = stream.read(min(self.chunk_bytes, total - offset))
                end = offset + len(block) - 1
                status, headers = self._request(
                    target["upload_url"],
                    block,
                    {
                        **target["headers"],
                        "Content-Length": str(len(block)),
                        "Content-Range": f"bytes {offset}-{end}/{total}",
                    },
                )
                new_offset = self._offset(status, headers, total)
                if new_offset <= offset or new_offset > end + 1:
                    raise PanelAPIError(None, "OBJECT_UPLOAD_NO_PROGRESS")
                offset = new_offset
        write(checkpoint.with_suffix(".uploaded.json"), identity)
        return identity
