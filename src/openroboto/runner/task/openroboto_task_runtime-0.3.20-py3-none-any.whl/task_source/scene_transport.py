"""Worker-only scene transport for backend 726da616 (migration 0109).

No polling loop, claim/lease creation, physical runner or model API. Operator
configuration supplies signing identity and receipt trust; downloaded bytes never
select a verification key. Public worker/panel integration is a separate change.
"""

from __future__ import annotations

import io
import http.client
import math
import os
import re
import stat
import struct
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
import zlib
from dataclasses import dataclass, field
from pathlib import PurePosixPath
from types import MappingProxyType
from typing import Callable, Mapping

from openroboto_protocol.scene_contract import SubmissionIdentity, profile_catalog

from agent_evidence.signing import Signer
from task_source.scene_views import (
    AdmissionView,
    ExecutionView,
    ReceiptTrust,
    SceneViewError,
    verify_admission_view,
    verify_execution_view,
)
from task_source.scene_views.identity import decode, encoded

_ID = re.compile(r"[A-Za-z0-9_.:-]{1,200}\Z")
_TASK = re.compile(r"[A-Za-z0-9_-]{1,200}\Z")
_REPO = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,95}/[A-Za-z0-9][A-Za-z0-9_.-]{0,95}\Z")
_HEX = re.compile(r"[0-9a-f]{64}\Z")
_SHA = re.compile(r"[0-9a-f]{40}\Z")


class SceneTransportError(Exception):
    """Stable internal classification, never raw server/ZIP/private diagnostics."""

    def __init__(self, code: str, *, category="invalid_package", retryable=False, status=None):
        self.code, self.category, self.retryable, self.status = code, category, retryable, status
        super().__init__(code)


def _require(condition, code, **kwargs):
    if not condition:
        raise SceneTransportError(code, **kwargs)


def _id(value, pattern=_ID):
    return isinstance(value, str) and pattern.fullmatch(value) is not None


def _future(value, now):
    return type(value) in (int, float) and math.isfinite(value) and value > now


@dataclass(frozen=True, repr=False)
class NodeIdentity:
    """From the operator's registered, non-retired node/key configuration.

    valid_until is the operator-selected registration refresh deadline. This
    object does not register a node or prove that a backend has accepted it.
    """

    node_id: str
    signer: Signer = field(repr=False)
    registered_public_key_hex: str
    valid_until: float

    def validate(self, now):
        _require(
            _id(self.node_id) and type(self.signer) is Signer and _id(self.signer.key_id),
            "node_identity_invalid",
            category="authorization",
        )
        _require(
            self.signer.public_key_hex == self.registered_public_key_hex,
            "node_key_not_registered",
            category="authorization",
        )
        _require(_future(self.valid_until, now), "node_registration_expired", category="authorization")

    def proof(self, task_id, role, now):
        self.validate(now)
        _require(
            role in {"queue", "admission_worker", "progress:running", "progress:failed"},
            "node_role_invalid",
            category="authorization",
        )
        body = {
            "domain": "openroboto:scene-download:v1",
            "task_id": task_id,
            "role": role,
            "node_id": self.node_id,
            "timestamp": int(now),
        }
        return {
            "node_id": self.node_id,
            "key_id": self.signer.key_id,
            "timestamp": int(now),
            "signature": self.signer.sign_hex(encoded(body)),
        }


@dataclass(frozen=True)
class ReceiptAuthority:
    """Independent operator trust/expiry, never constructed from receipt fields."""

    trust: ReceiptTrust = field(repr=False)
    valid_until: float
    retired: bool = False

    def validate(self, now):
        _require(
            type(self.trust) is ReceiptTrust and self.trust.document["provenance"] == "server_registered",
            "receipt_registered_trust_required",
            category="authorization",
        )
        _require(
            self.retired is False and _future(self.valid_until, now),
            "receipt_authority_expired",
            category="authorization",
        )


@dataclass(frozen=True)
class SceneTask:
    """Immutable copy of the authenticated queue's exact transport/content pin."""

    _bytes: bytes = field(repr=False)

    @classmethod
    def from_queue(cls, item: Mapping, *, competition_id: int):
        return cls(cls._validated_bytes(item, competition_id=competition_id))

    def __post_init__(self):
        try:
            _require(type(self._bytes) is bytes, "scene_task_invalid")
            row = decode(self._bytes)
            _require(
                isinstance(row, dict)
                and self._bytes == self._validated_bytes(row, competition_id=row.get("competition_id")),
                "scene_task_invalid",
            )
        except (ValueError, TypeError, RecursionError):
            raise SceneTransportError("scene_task_invalid") from None

    @staticmethod
    def _validated_bytes(item, *, competition_id):
        _require(isinstance(item, Mapping), "queue_item_invalid")
        fields = {
            "task_id",
            "competition_id",
            "package_repo",
            "package_commit",
            "execution_package_digest",
            "private_package_digest",
            "submission_digest",
            "execution_profile",
            "environment",
            "attempt",
            "package_url",
        }
        row = {k: item.get(k) for k in fields}
        _require(
            type(competition_id) is int
            and competition_id > 0
            and type(row["competition_id"]) is int
            and row["competition_id"] == competition_id,
            "queue_competition_mismatch",
        )
        _require(
            _id(row["task_id"], _TASK) and _id(row["package_repo"], _REPO) and _id(row["package_commit"], _SHA),
            "queue_transport_pin_invalid",
        )
        _require(
            all(_id(row[k], _HEX) for k in ("execution_package_digest", "private_package_digest", "submission_digest")),
            "queue_digest_invalid",
        )
        _require(
            SubmissionIdentity(row["execution_package_digest"], row["private_package_digest"]).digest
            == row["submission_digest"],
            "queue_joint_digest_invalid",
        )
        _require(row["execution_profile"] == profile_catalog()["execution_profile"], "queue_profile_unsupported")
        env = row["environment"]
        _require(
            isinstance(env, dict)
            and set(env) == {"id", "version", "digest"}
            and _id(env.get("id"))
            and _id(env.get("version"))
            and _id(env.get("digest"), _HEX),
            "queue_environment_invalid",
        )
        _require(type(row["attempt"]) is int and row["attempt"] >= 0, "queue_attempt_invalid")
        expected = f"/api/v1/tasks/{row['task_id']}/scene-package/admission"
        _require(row["package_url"] == expected, "queue_package_url_invalid")
        return encoded(row)

    @property
    def document(self):
        return decode(self._bytes)


@dataclass(frozen=True, repr=False)
class EvaluationLease:
    """Existing panel lease supplied by its owner; no new claim protocol."""

    task_id: str
    execution_package_digest: str
    run_id: str
    worker_id: str
    node_id: str
    package_repo: str
    package_commit: str
    lease_token: str = field(repr=False)
    expires_at: float

    def payload(self, task, node_id, now):
        row = task.document
        _require(
            self.task_id == row["task_id"]
            and self.execution_package_digest == row["execution_package_digest"]
            and self.node_id == node_id
            and self.package_repo == row["package_repo"]
            and self.package_commit == row["package_commit"],
            "evaluation_assignment_mismatch",
            category="authorization",
        )
        _require(_future(self.expires_at, now), "evaluation_lease_expired", category="authorization")
        _require(
            _id(self.run_id)
            and _id(self.worker_id)
            and isinstance(self.lease_token, str)
            and 20 <= len(self.lease_token) <= 200,
            "evaluation_lease_invalid",
            category="authorization",
        )
        return {k: getattr(self, k) for k in ("run_id", "worker_id", "node_id", "lease_token")}


@dataclass(frozen=True)
class ZipLimits:
    max_archive_bytes: int = 24_000_000
    max_total_bytes: int = 21_000_000
    max_file_bytes: int = 20_000_000
    max_files: int = 514
    max_path_bytes: int = 512

    def __post_init__(self):
        _require(all(type(v) is int and 0 < v <= 64_000_000 for v in vars(self).values()), "zip_limits_invalid")
        _require(self.max_files <= 4096 and self.max_path_bytes <= 4096, "zip_limits_invalid")


@dataclass(frozen=True)
class ScenePackage:
    role: str
    task: SceneTask
    view: AdmissionView | ExecutionView = field(repr=False)
    receipt_bytes: bytes | None = field(default=None, repr=False)


def _zip_files(blob: bytes, role: str, limits: ZipLimits):
    """Accept the backend's regular-file, non-ZIP64, seekable ZIP format only.

    Check EOCD/count/central size BEFORE ZipFile creates its entry objects. No
    extract()/extractall(), filesystem paths, links or archive-supplied modes.
    """
    _require(type(blob) is bytes and 22 <= len(blob) <= limits.max_archive_bytes, "zip_archive_limit")
    end = blob.rfind(b"PK\x05\x06", max(0, len(blob) - 65557))
    _require(end >= 0 and end + 22 <= len(blob), "zip_directory_invalid")
    _, disk, cd_disk, disk_count, count, cd_size, cd_offset, comment = struct.unpack_from("<4s4H2IH", blob, end)
    _require(
        disk == cd_disk == 0
        and disk_count == count
        and 0 < count <= limits.max_files
        and count < 65535
        and cd_offset + cd_size == end
        and end + 22 + comment == len(blob),
        "zip_directory_invalid",
    )
    # ZipFile ignores EOCD's entry count while constructing its object list.
    # Count the actual directory records first; a forged small count must not
    # turn a bounded archive into hundreds of thousands of Python objects.
    cursor, actual_count = cd_offset, 0
    while cursor < end:
        _require(
            actual_count < count and cursor + 46 <= end and blob[cursor : cursor + 4] == b"PK\x01\x02",
            "zip_directory_invalid",
        )
        name_size, extra_size, comment_size, entry_disk = struct.unpack_from("<4H", blob, cursor + 28)
        _require(0 < name_size <= limits.max_path_bytes, "zip_path_invalid")
        _require(extra_size == 0 and entry_disk == 0, "zip_format_unsupported")
        cursor += 46 + name_size + extra_size + comment_size
        _require(cursor <= end, "zip_directory_invalid")
        actual_count += 1
    _require(actual_count == count, "zip_directory_invalid")
    files, aliases, ranges, total = {}, set(), [], 0
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        entries = archive.infolist()
        _require(len(entries) == count, "zip_directory_invalid")
        for info in entries:
            name = info.orig_filename
            path = PurePosixPath(name)
            _require(
                name == info.filename
                and 0 < len(name.encode("utf-8")) <= limits.max_path_bytes
                and not path.is_absolute()
                and len(path.parts) <= 64
                and path.as_posix() == name
                and not any(p in {".", ".."} for p in name.split("/"))
                and not any(ord(c) < 32 or ord(c) == 127 or c in "\\:" for c in name),
                "zip_path_invalid",
            )
            _require(name.casefold() not in aliases, "zip_duplicate_entry")
            aliases.add(name.casefold())
            allowed = name == "submission.json" or name == "receipt.json" or name.startswith("execution/")
            if role == "admission":
                allowed = allowed or name.startswith("private/")
            _require(allowed, "zip_role_violation", category="authorization")
            mode = stat.S_IFMT(info.external_attr >> 16)
            _require(
                mode in {0, stat.S_IFREG} and not info.is_dir() and not info.external_attr & 0x10, "zip_special_file"
            )
            _require(
                info.flag_bits & ~0x800 == 0
                and not info.extra
                and info.compress_type in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED},
                "zip_format_unsupported",
            )
            _require(
                0 <= info.file_size <= limits.max_file_bytes and info.header_offset + 30 <= cd_offset, "zip_file_limit"
            )
            header = struct.unpack_from("<4s5H3I2H", blob, info.header_offset)
            sig, _, flags, method, _, _, crc, compressed, size, name_size, extra_size = header
            start = info.header_offset + 30
            local_name = blob[start : start + name_size]
            _require(
                sig == b"PK\x03\x04"
                and flags == info.flag_bits
                and method == info.compress_type
                and crc == info.CRC
                and compressed == info.compress_size
                and size == info.file_size
                and extra_size == 0
                and local_name == name.encode("utf-8" if flags & 0x800 else "cp437"),
                "zip_local_header_invalid",
            )
            stop = start + name_size + compressed
            _require(stop <= cd_offset, "zip_overlap")
            ranges.append((info.header_offset, stop))
            total += info.file_size
            _require(total <= limits.max_total_bytes, "zip_total_limit")
        for name in aliases:
            _require(not any(str(parent) in aliases for parent in PurePosixPath(name).parents), "zip_path_conflict")
        previous = 0
        for start, stop in sorted(ranges):
            _require(start == previous, "zip_overlap")
            previous = stop
        _require(previous == cd_offset, "zip_overlap")
        for info in entries:
            data = bytearray()
            with archive.open(info) as source:
                while chunk := source.read(min(65536, limits.max_file_bytes - len(data) + 1)):
                    data.extend(chunk)
                    _require(len(data) <= min(info.file_size, limits.max_file_bytes), "zip_file_limit")
            _require(len(data) == info.file_size, "zip_size_mismatch")
            files[info.filename] = bytes(data)
    _require("submission.json" in files and any(k.startswith("execution/") for k in files), "zip_material_missing")
    if role == "admission":
        _require(any(k.startswith("private/") for k in files), "zip_material_missing")
    else:
        _require("receipt.json" in files, "zip_receipt_missing")
    return MappingProxyType(files)


def _materialize(root, files):
    """Private 0700 staging with exclusive, no-follow openat writes."""
    for name, content in files.items():
        fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            parts = name.split("/")
            for part in parts[:-1]:
                try:
                    os.mkdir(part, mode=0o700, dir_fd=fd)
                except FileExistsError:
                    pass
                next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                os.close(fd)
                fd = next_fd
            target = os.open(parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
            with os.fdopen(target, "wb") as output:
                output.write(content)
        finally:
            os.close(fd)


def decode_scene_zip(blob, task, role, *, authority=None, limits=ZipLimits(), now=None):
    """Verify a role ZIP into P03 immutable views, without importing a simulator."""
    _require(type(task) is SceneTask and role in {"admission", "evaluation"}, "package_role_invalid")
    _require(type(limits) is ZipLimits, "zip_limits_invalid")
    now = time.time() if now is None else now
    if role == "evaluation":
        _require(type(authority) is ReceiptAuthority, "receipt_registered_trust_required", category="authorization")
        authority.validate(now)
    try:
        files = _zip_files(blob, role, limits)
        manifest = decode(files["submission.json"])
        _require(isinstance(manifest, dict), "submission_manifest_invalid")
        row = task.document
        _require(
            all(
                manifest.get(k) == row[k]
                for k in ("execution_package_digest", "private_package_digest", "submission_digest")
            ),
            "queue_submission_mismatch",
        )
        with tempfile.TemporaryDirectory(prefix="openroboto-scene-transport-") as root:
            _materialize(root, files)
            if role == "admission":
                view = verify_admission_view(
                    f"{root}/execution",
                    f"{root}/private",
                    manifest,
                    expected_submission_digest=row["submission_digest"],
                )
                execution = view.execution
            else:
                view = verify_execution_view(
                    f"{root}/execution",
                    manifest,
                    decode(files["receipt.json"]),
                    expected_submission_digest=row["submission_digest"],
                    trust=authority.trust,
                )
                execution = view
        _require(
            execution.identity["execution_profile"] == row["execution_profile"]
            and execution.identity["environment"] == row["environment"],
            "queue_environment_mismatch",
        )
        return ScenePackage(role, task, view, files.get("receipt.json"))
    except SceneTransportError:
        raise
    except SceneViewError as exc:
        raise SceneTransportError(
            "view_" + exc.code, category="infra" if exc.status == "resource_unavailable" else "invalid_package"
        ) from None
    except OSError:
        raise SceneTransportError("scene_staging_unavailable", category="infra", retryable=True) from None
    except (
        ValueError,
        TypeError,
        KeyError,
        RuntimeError,
        RecursionError,
        zipfile.BadZipFile,
        struct.error,
        zlib.error,
    ):
        raise SceneTransportError("scene_zip_invalid") from None


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _http_send(request, *, timeout_s, max_bytes):
    opener = urllib.request.build_opener(_NoRedirect())
    deadline = time.monotonic() + timeout_s
    with opener.open(request, timeout=timeout_s) as response:
        length = response.headers.get("Content-Length")
        if length is not None:
            _require(0 <= int(length) <= max_bytes, "http_body_limit")
        out = bytearray()
        read = getattr(response, "read1", response.read)
        while chunk := read(min(65536, max_bytes - len(out) + 1)):
            _require(time.monotonic() <= deadline, "http_read_timeout", category="infra", retryable=True)
            out.extend(chunk)
            _require(len(out) <= max_bytes, "http_body_limit")
        _require(time.monotonic() <= deadline, "http_read_timeout", category="infra", retryable=True)
        return bytes(out)


class SceneTransportClient:
    """Operator-owned parent client; do not pass to a model/tool process."""

    def __init__(
        self,
        backend_url,
        api_key,
        identity,
        *,
        limits=ZipLimits(),
        timeout_s=30,
        clock=time.time,
        sender: Callable = _http_send,
    ):
        try:
            _require(
                isinstance(backend_url, str) and not any(ord(c) < 33 or ord(c) == 127 for c in backend_url),
                "backend_origin_invalid",
            )
            url = urllib.parse.urlsplit(backend_url)
            url.port  # Validate malformed/out-of-range ports before constructing a request.
        except ValueError:
            raise SceneTransportError("backend_origin_invalid") from None
        _require(
            url.scheme == "https"
            and url.hostname
            and not url.username
            and not url.password
            and url.path in {"", "/"}
            and not url.query
            and not url.fragment,
            "backend_origin_invalid",
        )
        _require(
            isinstance(api_key, str) and api_key and not any(ord(c) < 32 for c in api_key),
            "api_key_invalid",
            category="authorization",
        )
        _require(type(identity) is NodeIdentity and type(limits) is ZipLimits, "client_configuration_invalid")
        _require(
            type(timeout_s) in (int, float) and math.isfinite(timeout_s) and 0 < timeout_s <= 120,
            "http_timeout_invalid",
        )
        self._base, self._key, self._identity = backend_url.rstrip("/"), api_key, identity
        self._limits, self._timeout, self._clock, self._sender = limits, timeout_s, clock, sender

    def _request(self, method, path, *, body=None, headers=None, archive=False):
        self._identity.validate(self._clock())
        request = urllib.request.Request(
            self._base + path,
            method=method,
            data=None if body is None else encoded(body),
            headers={
                "X-API-Key": self._key,
                "Accept": "application/zip" if archive else "application/json",
                **(headers or {}),
            },
        )
        if body is not None:
            request.add_header("Content-Type", "application/json")
        maximum = self._limits.max_archive_bytes if archive else 1_000_000
        try:
            raw = self._sender(request, timeout_s=self._timeout, max_bytes=maximum)
            _require(type(raw) is bytes and len(raw) <= maximum, "http_body_limit")
            self._identity.validate(self._clock())
            return raw
        except urllib.error.HTTPError as exc:
            status = exc.code
            exc.close()
            category = (
                "infra"
                if status == 429 or status >= 500
                else "authorization"
                if status in {401, 403}
                else "request_rejected"
            )
            raise SceneTransportError(
                f"http_{status}", category=category, retryable=category == "infra", status=status
            ) from None
        except (urllib.error.URLError, OSError, TimeoutError, http.client.HTTPException):
            raise SceneTransportError("network_unavailable", category="infra", retryable=True) from None
        except ValueError:
            raise SceneTransportError("http_response_invalid", category="infra", retryable=True) from None

    def _json(self, *args, **kwargs):
        try:
            data = decode(self._request(*args, **kwargs))
            _require(isinstance(data, dict), "response_shape_invalid")
            result = data.get("data", data)
            _require(isinstance(result, dict), "response_shape_invalid")
            return result
        except (ValueError, TypeError, RecursionError):
            raise SceneTransportError("response_json_invalid") from None

    def list_queue(self, competition_id, limit=1):
        _require(
            type(competition_id) is int and competition_id > 0 and type(limit) is int and 1 <= limit <= 4,
            "queue_request_invalid",
        )
        proof = self._identity.proof(f"competition:{competition_id}", "queue", self._clock())
        headers = {
            "X-Scene-Node": proof["node_id"],
            "X-Scene-Key-Id": proof["key_id"],
            "X-Scene-Timestamp": str(proof["timestamp"]),
            "X-Scene-Signature": proof["signature"],
        }
        query = urllib.parse.urlencode({"track": "task", "competition": competition_id, "limit": limit})
        data = self._json("GET", "/api/v1/benchmark/queue?" + query, headers=headers)
        tasks = data.get("tasks")
        _require(
            isinstance(tasks, list)
            and len(tasks) <= limit
            and type(data.get("queue_size")) is int
            and data["queue_size"] == len(tasks),
            "queue_response_invalid",
        )
        result = tuple(SceneTask.from_queue(item, competition_id=competition_id) for item in tasks)
        _require(len({t.document["task_id"] for t in result}) == len(result), "queue_duplicate_task")
        return result

    def download_admission(self, task):
        _require(type(task) is SceneTask, "scene_task_required")
        row = task.document
        proof = self._identity.proof(row["task_id"], "admission_worker", self._clock())
        raw = self._request("POST", row["package_url"], body=proof, archive=True)
        return decode_scene_zip(raw, task, "admission", limits=self._limits, now=self._clock())

    def download_evaluation(self, task, lease, authority):
        _require(type(task) is SceneTask and type(lease) is EvaluationLease, "evaluation_assignment_required")
        _require(type(authority) is ReceiptAuthority, "receipt_registered_trust_required", category="authorization")
        authority.validate(self._clock())
        proof = lease.payload(task, self._identity.node_id, self._clock())
        path = f"/api/v1/tasks/{task.document['task_id']}/scene-package/evaluation"
        raw = self._request("POST", path, body=proof, archive=True)
        lease.payload(task, self._identity.node_id, self._clock())
        package = decode_scene_zip(raw, task, "evaluation", authority=authority, limits=self._limits, now=self._clock())
        authority.validate(self._clock())
        lease.payload(task, self._identity.node_id, self._clock())
        return package

    def report_progress(self, task, stage):
        _require(type(task) is SceneTask and stage in {"running", "failed"}, "progress_stage_invalid")
        task_id = task.document["task_id"]
        proof = self._identity.proof(task_id, "progress:" + stage, self._clock())
        result = self._json("POST", f"/api/v1/tasks/{task_id}/scene-progress", body={**proof, "stage": stage})
        _require(result.get("task_id") == task_id, "progress_task_mismatch")
        return result


__all__ = [
    "EvaluationLease",
    "NodeIdentity",
    "ReceiptAuthority",
    "ScenePackage",
    "SceneTask",
    "SceneTransportClient",
    "SceneTransportError",
    "ZipLimits",
    "decode_scene_zip",
]
