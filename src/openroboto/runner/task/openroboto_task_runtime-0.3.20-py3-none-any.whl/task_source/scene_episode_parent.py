"""Installed root-only per-trial launcher; never run by pure validation.

The sudoers wrapper has no arguments and selects this fixed deployment file.
It must use an operator-installed root-owned interpreter/package. One manager
stays outside the fresh resource domain; its sole child prepares and executes
P02/P03 in that domain. No daemon or heartbeat thread is moved into it.
"""

from __future__ import annotations

import ctypes
from dataclasses import replace
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import select
import subprocess
import sys
import time
import threading
import signal
import stat

from task_source.panel_state import read, write, sync_directory
from task_source.scene_episode_launcher import MAX_FRAME, RECEIPT_DOMAIN, digest, trusted_file
from task_source.scene_episode_scope import EpisodeScopePlan, FreshEpisodeScope, require
from task_source.scene_views.identity import decode, encoded

DEPLOYMENT = Path("/etc/openroboto/scene-parent.json")
PYTHON_PATCH = (3, 12, 4)


def terminate_requested(*unused):
    # An ordinary stop unwinds manage() and kills/reaps only its own fresh
    # domains. SIGKILL still requires the documented independent reconciliation.
    from task_source.scene_episode_scope import SceneLaunchError

    raise SceneLaunchError("scene_episode_parent_terminated")


class ChildLeaseCancellation:
    """Transport the daemon's latched lease failure to this child's Event.

    This never renews or extends the frozen assignment. P03 and the A gateway
    retain their own deadline/current-lease checks as well.
    """

    def __init__(self, context):
        self.context = context
        self.stop = threading.Event()

    def check(self):
        from task_source.scene_views.episode_authority import wire_epoch

        if self.context.cancellation.is_set():
            return False
        try:
            lease = read(Path(self.context.lease_file))
            allowed = lease.get("allowed") is True and wire_epoch(lease["expires_at"]) > time.time()
        except Exception:
            allowed = False
        if not allowed:
            self.context.cancellation.set()
        return allowed

    def __enter__(self):
        require(self.check(), "scene_episode_lease_cancelled")

        def watch():
            while not self.stop.wait(0.05):
                if not self.check():
                    return

        self.thread = threading.Thread(target=watch, name="scene-child-lease", daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *exc):
        self.stop.set()
        self.thread.join(timeout=1)
        require(not self.thread.is_alive(), "scene_episode_lease_monitor_unavailable")


def emit(value):
    raw = encoded(value) + b"\n"
    require(len(raw) <= MAX_FRAME)
    sys.stdout.buffer.write(raw)
    sys.stdout.buffer.flush()


def receive(timeout):
    # Read exactly one frame; do not buffer a later GO away from the child.
    deadline, raw = time.monotonic() + timeout, bytearray()
    while not raw.endswith(b"\n"):
        left = deadline - time.monotonic()
        require(left > 0 and select.select([0], [], [], left)[0], "scene_episode_parent_timeout")
        data = os.read(0, 1)
        require(data and len(raw) < MAX_FRAME, "scene_episode_parent_lost")
        raw.extend(data)
    value = decode(bytes(raw[:-1]))
    require(type(value) is dict)
    return value


def frozen_paths(request, deployment):
    work, caller = request["work"], request["caller"]
    run = work["run_id"]
    root = Path(deployment["work_root"]) / "runs" / hashlib.sha256(run.encode()).hexdigest()[:24]
    member, trial = caller["member_id"], caller["trial"]
    require(type(member) is str and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", member))
    require(type(trial) is int and 0 <= trial < work["trials_per_member"])
    config = work["config"]
    panel = config["settlement_panel"]
    require(type(panel) is str and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", panel))
    require(member in {m["id"] for m in config["panels"][panel]["members"]})
    stem = f"{member}-{trial}"
    expected = {
        "spec_path": root / "specs" / f"{stem}.json",
        "result_path": root / "results" / f"{stem}.json",
        "evidence_path": root / "episodes" / f"{panel}-{stem}.jsonl",
        "host_config": root / "model-host.json",
        "lease_file": root / "lease.json",
    }
    for name, path in expected.items():
        require(caller[name] == str(path) and path.resolve() == path)
        for parent in (path.parent, *path.parent.parents):
            info = parent.lstat()
            require(info.st_uid in {0, deployment["control_uid"]} and not info.st_mode & 0o022)
    require(not expected["result_path"].exists(), "scene_episode_already_executed")
    return root, root / "started" / f"{stem}.json", root / "launches" / f"{stem}.json"


def private_memfd(value):
    fd = os.memfd_create("scene-parent-input", os.MFD_ALLOW_SEALING)
    raw = encoded(value)
    require(len(raw) <= MAX_FRAME)
    offset = 0
    while offset < len(raw):
        offset += os.write(fd, raw[offset:])
    os.lseek(fd, 0, os.SEEK_SET)
    fcntl.fcntl(fd, fcntl.F_ADD_SEALS, fcntl.F_SEAL_SEAL | fcntl.F_SEAL_SHRINK | fcntl.F_SEAL_GROW | fcntl.F_SEAL_WRITE)
    return fd


def manage(begin, deployment, *, scope_factory=FreshEpisodeScope):
    from task_source.scene_recovery_parent import archive_guard, operation_work

    require(begin.keys() == {"stage", "deployment_digest", "request"} and begin["stage"] == "begin")
    require(begin["deployment_digest"] == digest(deployment))
    request = begin["request"]
    require(type(request) is dict and request.get("schema_version") == "scene-parent-request-v1")
    operation_work(request["work"], deployment)  # Reject owner/config before opening or creating the root archive.
    with archive_guard(deployment, begin["request"]["work"], create=True):
        return _manage(begin, deployment, scope_factory=scope_factory)


def _manage(begin, deployment, *, scope_factory=FreshEpisodeScope):
    """Real manager; unit tests replace process/kernel boundaries explicitly."""
    require(sys.platform == "linux" and os.geteuid() == 0)
    require(sys.version_info[:3] == PYTHON_PATCH, "scene_episode_python_unavailable")
    require(begin.keys() == {"stage", "deployment_digest", "request"} and begin["stage"] == "begin")
    require(begin["deployment_digest"] == digest(deployment))
    request = begin["request"]
    require(type(request) is dict and request.get("schema_version") == "scene-parent-request-v1")
    work, caller, metadata = request["work"], request["caller"], request["metadata"]
    require(work["config_digest"] == deployment["episode_policy"]["config_digest"])
    root, started, receipt_path = frozen_paths(request, deployment)
    require(not started.exists() and not receipt_path.exists(), "scene_episode_already_started")
    episode = {
        "run_id": work["run_id"],
        "attempt_id": f"{work['run_id']}:{caller['member_id']}:{caller['trial']}",
        "member_id": caller["member_id"],
        "worker_id": metadata["worker_id"],
        "node_id": metadata["node_id"],
        "trial": caller["trial"],
        "instance": caller["instance"],
    }
    plan = EpisodeScopePlan.registered(
        deployment,
        episode=episode,
        submission_digest=work["task"]["submission_digest"],
        config_digest=work["config_digest"],
    )
    python = deployment["python"]
    require(hashlib.sha256(trusted_file(python, limit=64_000_000)).hexdigest() == deployment["python_sha256"])
    # The installed source and ancestry must be root controlled. The wrapper's
    # measured environment/release tuple owns its full package/dependency pin.
    trusted_file(Path(__file__), limit=1_000_000)
    require(Path(__file__).resolve().is_relative_to(Path(deployment["source_prefix"])))
    # A usable root-authenticated cleanup witness is required before paying
    # for a trial, not discovered after its result already exists.
    from agent_evidence.signing import Signer
    from benchmark_worker.reference_panel.manifest import sign_manifest

    signer_doc = decode(trusted_file(deployment["launcher_key_file"], private=True))
    require(signer_doc.get("algorithm", "ed25519") == "ed25519")
    signer = Signer(signer_doc["party"], signer_doc["key_id"], bytes.fromhex(signer_doc["seed"]))
    require(signer.key_id == deployment["key_id"] and signer.public_key_hex == deployment["public_key_hex"])
    # Adopt/reap P03 watchdog grandchildren if the episode parent is killed.
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0)
    resources = scope_factory(plan).create()
    fd = gate_r = gate_w = enrollment_fd = None
    child = None
    success = False
    try:
        fd = private_memfd({"begin": begin, "deployment": deployment, "episode_policy": plan.policy})
        gate_r, gate_w = os.pipe()
        enrollment_fd = os.open(plan.scope / "parent/cgroup.procs", os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC)

        def enter_scope_before_exec():
            # Root manager is verified single-threaded. Only enrollment runs
            # between fork/exec, with no imports or locks; bootstrap imports
            # then count against this fresh episode's aggregate CPU domain.
            os.write(enrollment_fd, str(os.getpid()).encode())
            os.close(enrollment_fd)

        # Child is blocked before any runtime/E/provider loading. It may read
        # the sealed input only after manager-enforced PID enrollment.
        child = subprocess.Popen(
            [python, "-I", "-B", "-m", "task_source.scene_episode_parent", "--child", str(fd), str(gate_r)],
            stdin=0,
            stdout=1,
            stderr=subprocess.DEVNULL,
            env={"LANG": "C.UTF-8", "PATH": "/nonexistent"},
            cwd="/",
            pass_fds=(fd, gate_r, enrollment_fd),
            preexec_fn=enter_scope_before_exec,
            close_fds=True,
            start_new_session=True,
        )
        resources.enroll(child.pid)
        require(os.write(gate_w, b"1") == 1)
        os.close(gate_w)
        gate_w = None
        timeout = deployment["prepare_timeout_s"] + deployment["episode_timeout_s"] + deployment["cleanup_timeout_s"]
        require(child.wait(timeout=timeout) == 0, "scene_episode_parent_failed")
        require(started.is_file() and not started.is_symlink(), "scene_episode_started_missing")
        spec_sha256 = hashlib.sha256(Path(caller["spec_path"]).read_bytes()).hexdigest()
        marker = read(started)
        require(marker["spec_sha256"] == spec_sha256 and marker["launcher_request_digest"] == digest(request))
        stats = resources.close()
        success = True
    finally:
        for descriptor in (fd, gate_r, gate_w, enrollment_fd):
            if descriptor is not None:
                os.close(descriptor)
        if not success:
            try:
                resources.close(failed=True)
            finally:
                if child is not None:
                    child.wait(timeout=deployment["cleanup_timeout_s"])
        # Root manager has no unrelated children. Reap adopted watchdogs; a
        # surviving/unreapable child makes the overall helper fail closed.
        deadline = time.monotonic() + deployment["cleanup_timeout_s"]
        while True:
            try:
                pid, _ = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            if pid == 0:
                require(time.monotonic() < deadline, "scene_episode_parent_reap_pending")
                time.sleep(0.01)

    # Persist root-authenticated cleanup BEFORE returning success to daemon.
    # This record survives lost stdout/daemon restart and is never a score.
    receipt = sign_manifest(
        {
            "domain": RECEIPT_DOMAIN,
            "request_digest": digest(request),
            "spec_sha256": spec_sha256,
            "deployment_digest": begin["deployment_digest"],
            **stats,
            "key_id": signer.key_id,
            "algorithm": "ed25519",
        },
        signer.seed,
    )
    receipt_path.parent.mkdir(mode=0o750, exist_ok=True)
    write(receipt_path, receipt, exclusive=True)
    os.chown(receipt_path, deployment["control_uid"], deployment["control_gid"])
    emit({"stage": "closed", "request_digest": digest(request), "receipt": receipt})


def child_main(fd, gate):
    require(sys.platform == "linux" and os.geteuid() == 0)
    require(sys.version_info[:3] == PYTHON_PATCH, "scene_episode_python_unavailable")
    require(os.read(gate, 1) == b"1")
    os.close(gate)
    seals = fcntl.F_SEAL_SEAL | fcntl.F_SEAL_SHRINK | fcntl.F_SEAL_GROW | fcntl.F_SEAL_WRITE
    require(fcntl.fcntl(fd, fcntl.F_GET_SEALS) & seals == seals and os.fstat(fd).st_size <= MAX_FRAME)
    with os.fdopen(fd, "rb") as stream:
        bundle = decode(stream.read(MAX_FRAME + 1))
    from task_source import scene_runtime

    return run_child_session(bundle, scene_runtime)


def _set_spec_owner(fd, deployment):
    """Transfer only our newly created inode, never chown a mutable pathname."""
    os.fchown(fd, deployment["control_uid"], deployment["control_gid"])
    os.fchmod(fd, 0o600)


def save_candidate_spec(path, raw, deployment):
    """Same exclusive serialization as panel_state.write, in the trusted child.

    A collision or partial prior file is held; no overwrite or fallback prepare.
    The daemon can read its own 0600 spec after candidate, without root access.
    """
    content = json.dumps(raw, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()
    require(len(content) <= MAX_FRAME, "scene_episode_spec_unavailable")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
        _set_spec_owner(stream.fileno(), deployment)
        os.fsync(stream.fileno())
    sync_directory(path.parent)


def _hand_back_evidence(root, deployment):
    """Root-written results must be readable by the unprivileged controller.

    The controller verifies and reports the episode after this child exits, and
    it never runs as root. Only the file itself is handed over, never a mutable
    path: links are refused and the inode is identified before the chown.
    """
    target = Path(root) / "results"
    if not target.is_dir():
        return
    for path in target.iterdir():
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        except (FileNotFoundError, OSError):
            continue
        try:
            info = os.fstat(fd)
            if stat.S_ISREG(info.st_mode) and info.st_uid == 0 and info.st_nlink == 1:
                os.fchown(fd, deployment["control_uid"], deployment["control_gid"])
                os.fchmod(fd, 0o600)
        finally:
            os.close(fd)
    sync_directory(target)


def read_candidate_spec(path, deployment):
    """Bounded, no-symlink read of the daemon-owned private spec inode."""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        require(
            stat.S_ISREG(info.st_mode)
            and info.st_nlink == 1
            and info.st_uid == deployment["control_uid"]
            and stat.S_IMODE(info.st_mode) == 0o600
            and 0 < info.st_size <= MAX_FRAME,
            "scene_episode_spec_unavailable",
        )
        content = stream.read(MAX_FRAME + 1)
        require(len(content) == info.st_size, "scene_episode_spec_changed")
        return content


def run_child_session(bundle, runtime, *, recv=receive, send=emit):
    """Same child protocol with explicit in-memory I/O for pure tests."""
    begin, deployment, policy = bundle["begin"], bundle["deployment"], bundle["episode_policy"]
    request = begin["request"]
    require(digest(deployment) == begin["deployment_digest"])

    from task_source.scene_episode_caller import load_scene_episode_caller as loader

    view, context = loader(request, deployment=deployment, episode_policy=policy)
    spec_path = Path(context.spec_path)
    if not spec_path.exists():
        save_candidate_spec(spec_path, runtime.prepare_scene_episode(view, context=context), deployment)
    spec_bytes = read_candidate_spec(spec_path, deployment)
    raw = decode(spec_bytes)
    spec_sha256 = hashlib.sha256(spec_bytes).hexdigest()
    send({"stage": "candidate", "request_digest": digest(request), "spec": raw})
    saved = recv(deployment["prepare_timeout_s"])
    require(
        saved == {"stage": "saved", "request_digest": digest(request), "spec_sha256": spec_sha256},
        "scene_episode_spec_ack_mismatch",
    )
    require(read_candidate_spec(spec_path, deployment) == spec_bytes, "scene_episode_spec_changed")
    token = runtime.validate_scene_episode_context(view, context=context)
    require(token.spec_bytes == spec_bytes, "scene_episode_spec_changed")
    context = replace(context, prepared_scene_episode=token)
    # Validate actual scope/factory before allowing the daemon's paid marker.
    from task_source.scene_views.episode import EpisodeClock, EpisodePolicy
    from task_source.scene_views.episode_scope import EpisodeParentScope
    from task_source.scene_views.episode_authority import wire_epoch

    clock = EpisodeClock(
        context.prepared_scene_episode.spec.wall_seconds,
        wire_epoch(context.frozen_task["assignment"]["lease_expires_at"]),
        cancellation=context.cancellation,
        started=time.monotonic(),
        parent_cpu_started=time.process_time(),
    )
    EpisodeParentScope(
        EpisodePolicy.from_registered_config(policy), clock, parent_cpu_started=clock.parent_cpu_started
    ).preflight()
    from task_source.scene_recovery_parent import archive_prepared, archive_started

    archive_prepared(request, context, deployment)  # Root-private, validated binding, BEFORE READY/paid marker.
    send({"stage": "ready", "request_digest": digest(request), "spec_sha256": spec_sha256})
    go = recv(deployment["prepare_timeout_s"])
    require(go == {"stage": "go", "request_digest": digest(request), "spec_sha256": spec_sha256})
    _, started, _ = frozen_paths(request, deployment)
    marker = read(started)
    require(marker["spec_sha256"] == spec_sha256 and marker["launcher_request_digest"] == digest(request))
    archive_started(request, context, deployment, started.read_bytes())
    root, _, _ = frozen_paths(request, deployment)
    try:
        with ChildLeaseCancellation(context):
            runtime.execute_scene_episode(view, context=context)
    finally:
        # The controller reads and reports the result after this child exits.
        try:
            _hand_back_evidence(root, deployment)
        except OSError as exc:
            print("scene_episode_evidence_handback_failed:", exc, file=sys.stderr)


def dispatch(frame, deployment, *, scope_factory=FreshEpisodeScope):
    if frame["stage"] == "begin":
        return manage(frame, deployment, scope_factory=scope_factory)
    from task_source.scene_recovery_parent import operate, root_sign, OP_DOMAIN
    from task_source.scene_episode_scope import SceneLaunchError
    from task_source.scene_views.identity import SceneViewError
    from task_source.scene_recovery import SceneRecoveryError

    try:
        receipt = operate(frame, deployment)
    except (SceneLaunchError, SceneViewError, OSError, ValueError, KeyError, TypeError) as exc:
        code = "SCENE_RECOVERY_PARENT_UNAVAILABLE"
        if isinstance(exc, FileNotFoundError):
            code = "SCENE_RECOVERY_ORIGINAL_MISSING"
        elif isinstance(exc, (SceneLaunchError, SceneViewError, SceneRecoveryError)):
            candidate = getattr(exc, "code", str(exc))
            if re.fullmatch(r"(?:SCENE_RECOVERY_|local_|scene_episode_)[A-Za-z0-9_]{1,70}", candidate):
                code = (
                    candidate.upper()
                    if candidate.startswith("SCENE_RECOVERY_")
                    else "SCENE_RECOVERY_" + candidate.upper()
                )
        receipt = root_sign(
            deployment,
            {
                "domain": OP_DOMAIN,
                "action": frame["stage"],
                "request_digest": digest(frame["request"]),
                "deployment_digest": digest(deployment),
                "error": {"status": "held", "code": code},
            },
        )
    emit({"stage": "recovery", "request_digest": digest(frame["request"]), "receipt": receipt})


def main():
    try:
        signal.signal(signal.SIGTERM, terminate_requested)
        if len(sys.argv) == 4 and sys.argv[1] == "--child":
            child_main(int(sys.argv[2]), int(sys.argv[3]))
        else:
            require(len(sys.argv) == 1)
            deployment = decode(trusted_file(DEPLOYMENT, private=True))
            require(int(os.environ.get("SUDO_UID", "-1")) == deployment["control_uid"], "SCENE_RECOVERY_OWNER_MISMATCH")
            dispatch(receive(deployment["prepare_timeout_s"]), deployment)
        return 0
    except BaseException:
        # Errors/private runtime details never enter stdout, argv or logs.
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
