"""出题赛事的准入 worker（OPE-99）。

一个进程按 profile 领一种题源的活，跑完八项准入后回报
``POST /api/v1/task/admit``。AXIS 用 CPU profile，RoboDojo 用 GPU profile；
两者可以共用同一台 validator，也可以分开跑，按题源过滤队列条目。

租约与恢复
==========

后端的出题队列**没有 claim 端点**：题停在 ``submitted``，直到 validator
回报结论；``admitting`` 只是状态词表里预留的一档，今天没有任何写路径。
所以「卡在 admitting」不会发生在后端，只会发生在本地账本：

- 领取后先把本地条目写成 ``admitting``，再跑仿真；
- 进程被杀时本地条目留在 ``admitting``；下次启动 ``recover()`` 把它改回
  ``claimed`` 并重跑（幂等：同一 ``attempt`` 回报两次，后端返回第一次的结论）；
- 结果算完但回报失败时写成 ``ready_to_report``，下一轮只重发、不重跑。

基础设施失败（``infra_*``）**先本地重试一次**，仍失败就照实回报；后端把题
放回队列，下一次是新的 attempt。
"""

from __future__ import annotations

import argparse
from contextlib import nullcontext
import fcntl
import json
import os
import pathlib
import shutil
import uuid
import socket
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Mapping, Protocol

from agent_evidence.canonical import isoformat, utcnow
from agent_evidence.signing import Signer

from .base import AdmissionCheck, TaskSourceError
from .hf_snapshot import SnapshotError, download_materialized_snapshot
from .manifest import build_manifest, sign_manifest
from .package import TASK_FILE, package_digest, read_json
from .runtime import Verdict, get_profile, run_admission

USER_AGENT = "openroboto-admission-worker/0.1"
QUEUE_PATH = "/api/v1/benchmark/queue"
REPORT_PATH = "/api/v1/task/admit"
MAX_INFRA_RETRIES = 1


class BackendError(Exception):
    def __init__(self, message: str, status: int | None = None, *, retryable: bool | None = None):
        super().__init__(message)
        self.status = status
        self._retryable = retryable

    @property
    def retryable(self) -> bool:
        if self._retryable is not None:
            return self._retryable
        if self.status is None:
            return True
        if self.status in (401, 403, 429):
            return True
        return self.status >= 500


class FetchError(Exception):
    """题包下载 / 定位失败。属于 ``infra_download``。"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# 后端 HTTP
# ---------------------------------------------------------------------------


class QueueClient(Protocol):
    def fetch_queue(self, competition: int, limit: int) -> list[dict[str, Any]]: ...

    def report_admission(self, payload: Mapping[str, Any]) -> dict[str, Any]: ...


class HttpQueueClient:
    """只用标准库；读队列和回报都用 validator 身份的 key。"""

    def __init__(self, base_url: str, api_key: str, *, timeout_s: float = 30.0, scene_transport=None):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout_s = timeout_s
        self.scene_transport = scene_transport

    def _request(self, method: str, path: str, *, body: Mapping[str, Any] | None = None) -> dict[str, Any]:
        headers = {"User-Agent": USER_AGENT, "X-API-Key": self.api_key}
        data = None
        if body is not None:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(f"{self.base_url}{path}", data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_s) as response:
                payload = json.loads(response.read().decode() or "{}")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace")[:300]
            raise BackendError(f"{method} {path} -> HTTP {exc.code}: {detail}", status=exc.code) from exc
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            raise BackendError(f"{method} {path} -> {exc}") from exc
        if isinstance(payload, Mapping) and isinstance(payload.get("data"), Mapping):
            payload = payload["data"]
        return dict(payload) if isinstance(payload, Mapping) else {}

    def fetch_queue(self, competition: int, limit: int) -> list[dict[str, Any]]:
        payload = self._request("GET", f"{QUEUE_PATH}?competition={int(competition)}&limit={int(limit)}")
        tasks = payload.get("tasks")
        return [dict(item) for item in tasks if isinstance(item, Mapping)] if isinstance(tasks, list) else []

    def report_admission(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        if self.scene_transport is not None:
            from .scene_transport import SceneTransportError

            try:
                return self.scene_transport._json("POST", REPORT_PATH, body=payload)
            except SceneTransportError as exc:
                raise BackendError(exc.code, status=exc.status, retryable=exc.retryable) from None
        return self._request("POST", REPORT_PATH, body=payload)


# ---------------------------------------------------------------------------
# 题包下载
# ---------------------------------------------------------------------------


class PackageFetcher(Protocol):
    def fetch(self, item: Mapping[str, Any]) -> pathlib.Path: ...


class HuggingFaceFetcher:
    def __init__(self, root: str | pathlib.Path, *, token: str | None = None):
        self.root = pathlib.Path(root).expanduser()
        self.token = token or os.environ.get("HF_TOKEN")

    def fetch(self, item: Mapping[str, Any]) -> pathlib.Path:
        repo_id = str(item.get("hf_repo_id") or "")
        commit = str(item.get("hf_commit") or "")
        task_id = str(item.get("task_id") or "")
        source = str(item.get("source") or "").strip()
        expected_digest = item.get("package_digest")
        if not source:
            raise FetchError("queue item has no source; cannot select a task package")
        if not repo_id:
            raise FetchError("queue item has no hf_repo_id")
        if len(commit) != 40 or any(char not in "0123456789abcdef" for char in commit.lower()):
            raise FetchError(f"hf_commit is not a full 40-char SHA: {commit!r}")
        destination = self.root / f"package-{uuid.uuid4().hex}"
        try:
            download_materialized_snapshot(repo_id, commit, destination, token=self.token)
            return _select_package(destination, task_id, source=source, expected_digest=expected_digest)
        except (SnapshotError, OSError) as exc:
            raise FetchError(str(exc)) from exc
        except FetchError:
            shutil.rmtree(destination, ignore_errors=True)
            raise


class LocalFetcher:
    """测试 / 离线验收：队列里的 task_id 直接映射到本地题包目录。"""

    def __init__(self, root: str | pathlib.Path):
        self.root = pathlib.Path(root).expanduser()

    def fetch(self, item: Mapping[str, Any]) -> pathlib.Path:
        task_id = str(item.get("task_id") or "")
        candidate = self.root / task_id
        if candidate.is_dir() and (candidate / TASK_FILE).is_file():
            return candidate
        return _select_package(self.root, task_id)


def _select_package(
    root: pathlib.Path,
    task_id: str,
    *,
    source: str | None = None,
    expected_digest: Any = None,
) -> pathlib.Path:
    # Root and nested packages use the same selection rules. A backend's
    # business task_id need not equal the source id inside task.json.
    directories = {root} if (root / TASK_FILE).is_file() else set()
    for depth in (1, 2):
        directories.update(path.parent for path in root.glob("*/" * depth + TASK_FILE) if path.is_file())
    candidates: list[tuple[pathlib.Path, str]] = []
    for directory in sorted(directories):
        try:
            task = read_json(directory / TASK_FILE)
        except TaskSourceError:
            continue
        if not isinstance(task, Mapping):
            continue
        if source is not None and task.get("source") != source:
            continue
        candidates.append((directory, str(task.get("task_id") or "")))
    if expected_digest is not None:
        if (
            not isinstance(expected_digest, str)
            or len(expected_digest) != 64
            or any(char not in "0123456789abcdef" for char in expected_digest)
        ):
            raise FetchError("queue package_digest must be a 64-character lowercase SHA-256")
        matches = [directory for directory, _ in candidates if package_digest(directory) == expected_digest]
    else:
        matches = [directory for directory, inner_id in candidates if inner_id == task_id]
        if not matches and source is not None:
            matches = [directory for directory, _ in candidates]
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise FetchError(f"package for task {task_id!r} not found under {root} for source {source!r}")
    raise FetchError(f"multiple packages for task {task_id!r} under {root}: {matches}")


# ---------------------------------------------------------------------------
# 本地账本
# ---------------------------------------------------------------------------


class Ledger:
    """崩溃安全的小账本。键 = ``task_id@commit[:12]``。"""

    def __init__(self, path: str | pathlib.Path):
        self.path = pathlib.Path(path).expanduser()
        self._data: dict[str, dict[str, Any]] = {"tasks": {}}
        if self.path.is_file():
            text = self.path.read_text(encoding="utf-8")
            if text.strip():
                data = json.loads(text)
                if isinstance(data, Mapping) and isinstance(data.get("tasks"), Mapping):
                    self._data = {"tasks": dict(data["tasks"])}

    def get(self, key: str) -> dict[str, Any] | None:
        entry = self._data["tasks"].get(key)
        return dict(entry) if isinstance(entry, Mapping) else None

    def pending_reports(self):
        return [
            (key, dict(entry))
            for key, entry in self._data["tasks"].items()
            if isinstance(entry, Mapping) and entry.get("status") == "ready_to_report"
        ]

    def update(self, key: str, **fields: Any) -> dict[str, Any]:
        entry = self._data["tasks"].setdefault(key, {})
        entry.update(fields)
        entry["updated_at"] = now_iso()
        self._save()
        return dict(entry)

    def recover(self) -> int:
        """把上次崩溃留下的 ``admitting`` 改回 ``claimed``。"""
        recovered = 0
        for entry in self._data["tasks"].values():
            if entry.get("status") == "admitting":
                entry["status"] = "claimed"
                entry["recovered_at"] = now_iso()
                recovered += 1
        if recovered:
            self._save()
        return recovered

    def _save(self) -> None:
        from .panel_state import write

        write(self.path, self._data)


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------


@dataclass
class Report:
    key: str
    task_id: str
    attempt: int
    outcome: str
    code: str | None
    reason: str | None


class AdmissionWorker:
    def __init__(
        self,
        *,
        profile_name: str,
        profile: Mapping[str, Any],
        competitions: list[int],
        client: QueueClient,
        fetcher: PackageFetcher,
        ledger: Ledger,
        node_id: str,
        signer: Signer,
        chat_fn: Callable[..., Mapping[str, Any]] | None = None,
        scene_adapter=None,
    ):
        self.profile_name = profile_name
        self.profile = dict(profile)
        self.competitions = competitions
        self.client = client
        self.fetcher = fetcher
        self.ledger = ledger
        self.node_id = node_id
        #: 准入证据的签名身份。没有它就不该产出「可审计的结论」——
        #: 构造时强制要求，避免一批题在无签名状态下悄悄进池。
        self.signer = signer
        self.chat_fn = chat_fn
        self.scene = scene_adapter
        if self.scene is not None:
            self.scene.registration.identity(node_id, signer).validate(self.scene.transport._clock())
            if self.scene.transport._identity.node_id != node_id:
                raise BackendError("scene transport node differs from the report signer", status=409)
        sources = profile.get("sources")
        self.sources = set(str(value) for value in sources) if isinstance(sources, list) else set()

    def recover(self) -> int:
        return self.ledger.recover()

    def poll_once(self, limit: int) -> list[Report]:
        reports: list[Report] = []
        recovered_keys = set()
        if self.scene is not None:
            # The backend can already have accepted a lost response and removed
            # the task from GET, or advanced its attempt after an infra result.
            # Flush local signed originals first; never depend on queue presence.
            for key, entry in self.ledger.pending_reports():
                if (
                    not key.startswith("scene:")
                    or entry.get("scene_task", {}).get("competition_id") not in self.competitions
                ):
                    continue
                if len(recovered_keys) >= limit:
                    break
                recovered_keys.add(key)
                try:
                    task = self.scene.admission_task(entry["scene_task"])
                    scope = {
                        "backend": self.scene.transport._base,
                        "node_id": self.node_id,
                        "key_id": self.signer.key_id,
                    }
                    if entry.get("scene_scope") != scope:
                        raise BackendError("scene ledger scope mismatch", status=409)
                    self._check_scene_cached(task, entry)
                    reports.append(self._report(key, task.document["task_id"], entry["attempt"], entry["verdict"]))
                except Exception:
                    self.ledger.update(key, status="held", error_code="scene_cached_report_unavailable")
            if len(recovered_keys) >= limit:
                return reports
        for competition in self.competitions:
            try:
                if self.scene is not None:
                    items = [task.document for task in self.scene.list_queue(competition, limit)]
                else:
                    items = self.client.fetch_queue(competition, limit)
            except BackendError as exc:
                print(f"[worker] queue fetch failed for competition {competition}: {exc}", file=sys.stderr)
                continue
            except Exception as exc:
                if self.scene is None:
                    raise
                from .scene_transport import SceneTransportError

                if not isinstance(exc, SceneTransportError):
                    raise
                print(f"[worker] scene queue unavailable: {exc.code}", file=sys.stderr)
                continue
            for item in items:
                if self.scene is not None:
                    scene_key = (
                        f"scene:{item.get('task_id')}@{item.get('package_commit')}:{item.get('submission_digest')}"
                    )
                    if scene_key in recovered_keys:
                        continue
                if self.scene is None and self.sources and str(item.get("source")) not in self.sources:
                    # 按题源分队列：留给另一个 profile 的进程。
                    continue
                try:
                    report = self.process(item)
                except Exception as exc:  # noqa: BLE001 —— 单条不能拖垮整个 worker
                    print(f"[worker] task {item.get('task_id')} failed unexpectedly: {exc}", file=sys.stderr)
                    continue
                if report is not None:
                    reports.append(report)
        return reports

    def process(self, item: Mapping[str, Any]) -> Report | None:
        from .scene_dispatch import is_scene_task

        if self.scene is not None or is_scene_task(item):
            if self.scene is None:
                raise BackendError("scene profile is not registered on this worker", status=409)
            return self._process_scene(item)
        # A single authoritative host owns an index. Hold the same lock across
        # validation, backend acknowledgment and insertion, not merely file save.
        dedup = self.profile.get("dedup")
        raw_path = dedup.get("index") if isinstance(dedup, Mapping) else None
        if not raw_path:
            return self._process(item)
        from .registry import VALIDATOR_ROOT

        path = pathlib.Path(str(raw_path)).expanduser()
        if not path.is_absolute():
            path = VALIDATOR_ROOT / path
        if not path.parent.is_dir():
            return self._process(item)  # admission reports infra_dedup; do not initialize implicitly
        with path.with_name(path.name + ".authority.lock").open("a") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                return None
            try:
                if item.get("expected_execution_profile") is not None and not path.is_file():
                    # Also refuse resending an old successful verdict after the authority vanished.
                    raise BackendError("authoritative dedup index disappeared; restore it before processing")
                return self._process(item)
            finally:
                fcntl.flock(lock, fcntl.LOCK_UN)

    def _process_scene(self, item):
        """Same submitted/attempt ledger; scene never enters v1 template/dedup."""
        from .scene_adapter import SceneAdmissionContext
        from .scene_transport import SceneTransportError

        task = self.scene.admission_task(item)
        row = task.document
        task_id = row["task_id"]
        key = f"scene:{task_id}@{row['package_commit']}:{row['submission_digest']}"
        entry = self.ledger.get(key) or {}
        scope = {"backend": self.scene.transport._base, "node_id": self.node_id, "key_id": self.signer.key_id}
        if entry and entry.get("scene_scope") != scope:
            raise BackendError("scene ledger scope mismatch", status=409)
        attempt = self._next_attempt(item, entry)
        if entry.get("status") in {"failed", "held"}:
            return None
        if entry.get("status") == "reported" and int(entry.get("attempt") or 0) >= attempt:
            return None
        if entry.get("status") == "ready_to_report":
            self._check_scene_cached(task, entry)
            return self._report(key, task_id, entry["attempt"], entry["verdict"])
        self.ledger.update(key, status="admitting", attempt=attempt, scene_task=row, scene_scope=scope)
        try:
            package = self.scene.transport.download_admission(task)
            self.scene.transport.report_progress(task, "running")
        except SceneTransportError as exc:
            # Without a verified view there is no honest detached receipt to
            # submit. Keep the same attempt; bounded retry then operator hold.
            retries = int(entry.get("download_retries") or 0) + 1
            self.ledger.update(
                key,
                status="claimed" if exc.retryable and retries <= MAX_INFRA_RETRIES else "held",
                download_retries=retries,
                error_code=exc.code,
                error_category=exc.category,
            )
            return Report(key, task_id, attempt, "unavailable", "infra_scene_download", exc.code)
        started = isoformat(utcnow())
        context = SceneAdmissionContext(
            task,
            self.profile,
            self.node_id,
            attempt,
            self.scene.registration.document["config_digest"],
            self.scene.registration.document,
        )
        callback = None
        try:
            callback = self.scene.admission_runtime
            if callback is None:
                from .scene_adapter import scene_runtime

                callback = scene_runtime().run_scene_admission
        except Exception:
            pass
        retries = int(entry.get("infra_retries") or 0) if entry.get("attempt") == attempt else 0
        while True:
            verdict = self._failed_verdict(
                task_id=task_id,
                source="axis",
                code="infra_scene_runtime_unavailable",
                reason="Registered scene admission runtime is unavailable",
                error="scene_runtime_unavailable",
            )
            if callback is not None:
                try:
                    verdict = callback(package.view, context=context)
                    if type(verdict) is not Verdict:
                        raise ValueError("scene_runtime_result_invalid")
                except Exception:
                    verdict = self._failed_verdict(
                        task_id=task_id,
                        source="axis",
                        code="infra_scene_runtime_failed",
                        reason="Scene runtime did not produce a verified result",
                        error="scene_runtime_failed",
                    )
            if callback is None or not _is_infra(verdict.verdict()) or retries >= MAX_INFRA_RETRIES:
                break
            retries += 1
            self.ledger.update(key, infra_retries=retries)
        try:
            payload, manifest = self._scene_manifest(task, package.view, verdict, attempt, started)
        except Exception:
            verdict = self._failed_verdict(
                task_id=task_id,
                source="axis",
                code="infra_scene_evidence_invalid",
                reason="Scene runtime evidence could not be bound to the registered submission",
                error="scene_evidence_invalid",
            )
            payload, manifest = self._scene_manifest(task, package.view, verdict, attempt, started)
        return self._report_verdict(
            key, task_id, attempt, payload, digest=row["execution_package_digest"], manifest=manifest
        )

    def _scene_manifest(self, task, view, verdict, attempt, started):
        from openroboto_protocol.tabletop_assets import canonical_digest
        from .scene_views import reference_identity, sign_scene_receipt

        row, registration = task.document, self.scene.registration.document
        payload = verdict.verdict()
        payload["execution_profile"] = row["execution_profile"]
        payload["public_summary"] = view.execution.task["public_summary"]
        payload["scene_reference_binding"] = reference_identity(view)
        manifest = build_manifest(
            verdict=verdict,
            verdict_payload=payload,
            package_digest=row["execution_package_digest"],
            attempt=attempt,
            node_id=self.node_id,
            policy_version=registration["policy_version"],
            started_at=started,
            finished_at=isoformat(utcnow()),
            task_id=row["task_id"],
            key_id=self.signer.key_id,
        )
        infra = _is_infra(payload)
        result = {
            "schema_version": 1,
            "submission_digest": row["submission_digest"],
            "capability": {
                "status": "resource_unavailable" if infra else "supported",
                "issues": [{"code": payload["code"], "path": "runtime", "message": "Scene runtime is unavailable"}]
                if infra
                else [],
            },
            "admission": "not_run" if infra else "admitted" if verdict.accepted else "physical_failed",
            "reward_status": "not_evaluated",
            "evidence_digest": canonical_digest({"checks": manifest["checks"], "verdict": payload}),
        }
        payload["scene_receipt"] = sign_scene_receipt(
            view,
            checks=manifest["checks"],
            verdict=payload,
            result=result,
            trust=self.scene.registration.receipt_trust(),
            seed=self.signer.seed,
            config_digest=registration.get("config_digest"),
        )
        manifest["verdict_hash"] = canonical_digest(payload)
        return payload, sign_manifest(manifest, self.signer)

    def _check_scene_cached(self, task, entry):
        from .manifest import canonical_sha256, verify_manifest

        row = task.document
        expected = {
            "task_id": row["task_id"],
            "attempt": entry["attempt"],
            "package_digest": row["execution_package_digest"],
            "node_id": self.node_id,
            "key_id": self.signer.key_id,
            "policy_version": self.scene.registration.document["policy_version"],
            "verdict_hash": canonical_sha256(entry["verdict"]),
        }
        receipt = entry["verdict"].get("scene_receipt", {})
        if (
            receipt.get("runtime") != self.scene.registration.document["runtime"]
            or verify_manifest(entry.get("manifest", {}), public_key_hex=self.signer.public_key_hex, expected=expected)
            or any(
                receipt.get(k) != row[k]
                for k in ("execution_package_digest", "private_package_digest", "submission_digest")
            )
        ):
            raise BackendError("cached scene report identity is invalid", status=409)

    def _process(self, item: Mapping[str, Any]) -> Report | None:
        task_id = str(item.get("task_id") or "")
        commit = str(item.get("hf_commit") or "")
        key = f"{task_id}@{commit[:12]}"
        entry = self.ledger.get(key) or {}
        if item.get("expected_execution_profile") is not None or (entry.get("verdict") or {}).get("execution_profile"):
            from .fingerprint import DedupIndex
            from .registry import VALIDATOR_ROOT

            dedup = self.profile.get("dedup")
            configured = dedup.get("index") if isinstance(dedup, Mapping) else None
            if not configured:
                raise BackendError("new-profile admission requires a configured authoritative dedup index")
            path = pathlib.Path(str(configured)).expanduser()
            if not path.is_absolute():
                path = VALIDATOR_ROOT / path
            DedupIndex(path, strict=True)  # also guards cached verdict resubmission
        attempt = self._next_attempt(item, entry)

        if entry.get("status") == "failed":
            # 永久拒绝（摘要冲突 / 请求体不合法）等人处理；重跑只会重复同一件事。
            return None
        if entry.get("status") == "reported" and int(entry.get("attempt") or 0) >= attempt:
            return None
        if entry.get("status") == "ready_to_report" and int(entry.get("attempt") or 0) == attempt:
            return self._report(key, task_id, attempt, entry.get("verdict") or {})

        self.ledger.update(
            key,
            status="admitting",
            attempt=attempt,
            competition=item.get("competition_id"),
            submitted_at=_as_text(item.get("submitted_at")),
            commit_block=_as_int(item.get("commit_block")),
        )
        try:
            directory = self.fetcher.fetch(item)
        except FetchError:
            # 下载失败重试一次；仍失败按 infra_download 回报（后端会再排）。
            try:
                directory = self.fetcher.fetch(item)
            except FetchError as second:
                payload, manifest = self._unavailable(
                    task_id=task_id,
                    source=str(item.get("source") or "unknown"),
                    attempt=attempt,
                    code="infra_download",
                    reason=f"cannot fetch the task package: {second}",
                    check_name="package_download",
                    error=str(second),
                    submission=_submission_of(item),
                )
                return self._report_verdict(key, task_id, attempt, payload, digest=None, manifest=manifest)

        digest = package_digest(directory)
        payload, manifest = self._admit(directory, item, digest=digest, attempt=attempt)
        # 基础设施失败 / 超时：本地重试一次，仍失败就照实回报。
        if _is_infra(payload) and int(entry.get("infra_retries") or 0) < MAX_INFRA_RETRIES:
            self.ledger.update(key, infra_retries=int(entry.get("infra_retries") or 0) + 1)
            payload, manifest = self._admit(directory, item, digest=digest, attempt=attempt)
        return self._report_verdict(key, task_id, attempt, payload, digest=digest, manifest=manifest)

    def _admit(
        self,
        directory: pathlib.Path,
        item: Mapping[str, Any],
        *,
        digest: str,
        attempt: int,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        started_at = isoformat(utcnow())
        try:
            profile = dict(self.profile)
            if item.get("expected_execution_profile") is not None:
                profile["expected_execution_profile"] = item["expected_execution_profile"]
            verdict = run_admission(
                directory,
                profile=profile,
                chat_fn=self.chat_fn,
                submitted_at=_as_text(item.get("submitted_at")),
                commit_block=_as_int(item.get("commit_block")),
                submission_id=_as_text(item.get("task_id")),
            )
        except TaskSourceError as exc:
            verdict = self._failed_verdict(
                task_id=str(item.get("task_id") or ""),
                source=str(item.get("source") or "unknown"),
                code="reject_drift",
                reason=str(exc),
                error=str(exc),
            )
        except Exception as exc:  # noqa: BLE001
            verdict = self._failed_verdict(
                task_id=str(item.get("task_id") or ""),
                source=str(item.get("source") or "unknown"),
                code="infra_crash",
                reason=f"{type(exc).__name__}: {exc}",
                error=str(exc),
            )
        payload = verdict.verdict()
        fingerprint = next(
            (check.detail.get("fingerprint") for check in verdict.checks if check.name == "dedup" and check.passed),
            None,
        )
        manifest = self._manifest(
            verdict=verdict,
            payload=payload,
            digest=digest,
            attempt=attempt,
            started_at=started_at,
            finished_at=isoformat(utcnow()),
            submission=_submission_of(item),
            fingerprint=fingerprint,
            task_id=str(item.get("task_id") or "") or None,
        )
        return payload, manifest

    def _unavailable(
        self,
        *,
        task_id: str,
        source: str,
        attempt: int,
        code: str,
        reason: str,
        check_name: str,
        error: str,
        submission: Mapping[str, Any] | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """题包都拿不到时也产出 manifest —— 八项都在，没跑的是 not_run。"""
        started_at = isoformat(utcnow())
        verdict = self._failed_verdict(
            task_id=task_id,
            source=source,
            code=code,
            reason=reason,
            error=error,
            check_name=check_name,
        )
        payload = verdict.verdict()
        # 下载失败时没有可算的题包摘要；用零摘要而不是漏掉字段，后端仍能
        # 按 (task_id, attempt) 归档这次失败。
        manifest = self._manifest(
            verdict=verdict,
            payload=payload,
            digest="0" * 64,
            attempt=attempt,
            started_at=started_at,
            finished_at=isoformat(utcnow()),
            submission=submission,
            task_id=task_id or None,
        )
        return payload, manifest

    @staticmethod
    def _failed_verdict(
        *,
        task_id: str,
        source: str,
        code: str,
        reason: str,
        error: str,
        check_name: str = "admission",
    ) -> Verdict:
        return Verdict(
            source=source,
            task_id=task_id,
            accepted=False,
            code=code,
            reason=reason,
            checks=(AdmissionCheck(check_name, False, {"error": error}),),
            runtime_status="not_run",
        )

    def _manifest(
        self,
        *,
        verdict: Verdict,
        payload: Mapping[str, Any],
        digest: str,
        attempt: int,
        started_at: str,
        finished_at: str,
        submission: Mapping[str, Any] | None = None,
        fingerprint: str | None = None,
        task_id: str | None = None,
    ) -> dict[str, Any]:
        manifest = build_manifest(
            verdict=verdict,
            verdict_payload=payload,
            package_digest=digest,
            attempt=attempt,
            node_id=self.node_id,
            policy_version=str(self.profile.get("version") or 1),
            started_at=started_at,
            finished_at=finished_at,
            submission=submission,
            key_id=self.signer.key_id,
            # 后端队列的提交身份，不是题包 task.json 里的题源标识。
            task_id=task_id,
        )
        if fingerprint:
            # 指纹不属于 verdict 的语义（放进去会让 verdict_hash 取决于 worker
            # 的本地账本），但它是本题去重证据的索引，单独进 manifest 并由签名覆盖。
            manifest["fingerprint"] = fingerprint
        return sign_manifest(manifest, self.signer)

    def _report_verdict(
        self,
        key: str,
        task_id: str,
        attempt: int,
        verdict: Mapping[str, Any],
        *,
        digest: str | None = None,
        manifest: Mapping[str, Any] | None = None,
    ) -> Report:
        digest = digest or "0" * 64
        self.ledger.update(
            key,
            status="ready_to_report",
            attempt=attempt,
            verdict=dict(verdict),
            manifest=dict(manifest or {}),
            digest=digest,
        )
        return self._report(key, task_id, attempt, verdict, digest=digest, manifest=manifest)

    def _report(
        self,
        key: str,
        task_id: str,
        attempt: int,
        verdict: Mapping[str, Any],
        *,
        digest: str | None = None,
        manifest: Mapping[str, Any] | None = None,
    ) -> Report:
        entry = self.ledger.get(key) or {}
        digest = digest or str(entry.get("digest") or "0" * 64)
        signed = manifest or entry.get("manifest")
        payload = {
            "task_id": task_id,
            "package_digest": digest,
            "attempt": attempt,
            "verdict": dict(verdict),
            "manifest": dict(signed or {}),
            "node_id": self.node_id,
        }
        try:
            response = self.client.report_admission(payload)
        except BackendError as exc:
            if not exc.retryable:
                # 400/404/409/413/422：重试不会变成功（例如题包摘要与后端已存的
                # 不一致）。停在本地账本里等人看，不要每一轮都重发。
                self.ledger.update(key, status="failed", error=str(exc), failed_at=now_iso())
                print(f"[worker] report rejected for {task_id}: {exc}", file=sys.stderr)
                return Report(key, task_id, attempt, "failed", _code_of(verdict), _reason_of(verdict))
            print(f"[worker] report failed for {task_id} attempt {attempt}: {exc}", file=sys.stderr)
            return Report(key, task_id, attempt, "unreported", _code_of(verdict), _reason_of(verdict))
        if key.startswith("scene:") and (
            response.get("task_id") != task_id
            or response.get("attempt") != attempt
            or response.get("outcome") not in {"admitted", "rejected", "retry"}
        ):
            return Report(key, task_id, attempt, "unreported", "infra_scene_report_invalid", "scene_report_ack_invalid")
        outcome = str(response.get("outcome") or ("admitted" if verdict.get("passed") else "rejected"))
        if outcome == "admitted" and not key.startswith("scene:"):
            self._remember_fingerprint(
                signed or {},
                task_id,
                entry.get("submitted_at"),
                entry.get("commit_block"),
                strict=bool(verdict.get("execution_profile")),
            )
        # If the local authority write fails, retain ready_to_report for an
        # idempotent backend retry instead of silently losing the fingerprint.
        self.ledger.update(key, status="reported", outcome=outcome, reported_at=now_iso())
        return Report(key, task_id, attempt, outcome, _code_of(verdict), _reason_of(verdict))

    def _remember_fingerprint(
        self,
        manifest: Mapping[str, Any],
        task_id: str,
        submitted_at: Any = None,
        commit_block: Any = None,
        *,
        strict: bool = False,
    ) -> None:
        dedup = self.profile.get("dedup")
        path = dedup.get("index") if isinstance(dedup, Mapping) else None
        fingerprint = manifest.get("fingerprint")
        if not path or not isinstance(fingerprint, str):
            return
        from .fingerprint import DedupIndex

        from pathlib import Path

        candidate = Path(str(path)).expanduser()
        if not candidate.is_absolute():
            from .registry import VALIDATOR_ROOT

            candidate = VALIDATOR_ROOT / candidate
        DedupIndex(candidate, strict=strict).add(
            fingerprint,
            task_id=task_id,
            submitted_at=submitted_at if isinstance(submitted_at, str) else None,
            commit_block=_as_int(commit_block),
        )

    def _next_attempt(self, item: Mapping[str, Any], entry: Mapping[str, Any]) -> int:
        backend_attempt = int(item.get("attempt") or 0)
        local_attempt = int(entry.get("attempt") or 0)
        reported = entry.get("status") == "reported"
        return max(backend_attempt + 1, local_attempt if not reported else backend_attempt + 1)


def _is_infra(verdict: Mapping[str, Any]) -> bool:
    code = verdict.get("code")
    return isinstance(code, str) and code.startswith("infra_")


def _code_of(verdict: Mapping[str, Any]) -> str | None:
    code = verdict.get("code")
    return code if isinstance(code, str) else None


def _reason_of(verdict: Mapping[str, Any]) -> str | None:
    reason = verdict.get("reason")
    return reason if isinstance(reason, str) else None


def _submission_of(item: Mapping[str, Any]) -> dict[str, Any]:
    """队列条目的提交侧输入 —— 去重检查和复现都靠它。"""
    return {
        "submitted_at": _as_text(item.get("submitted_at")),
        "commit_block": _as_int(item.get("commit_block")),
        "submission_id": _as_text(item.get("task_id")),
    }


def _as_text(value: Any) -> str | None:
    return value if isinstance(value, str) else None


def _as_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="出题赛事准入 worker")
    parser.add_argument("--profile", required=True, help="admission profile，如 axis-cpu / robodojo-gpu")
    parser.add_argument("--task-kind", choices=["legacy", "scene"], default="legacy")
    parser.add_argument(
        "--scene-registration", help="operator registered scene identity/profile JSON; required for scene"
    )
    parser.add_argument(
        "--profile-config", default=None, help="profile JSON 路径（默认 configs/admission_profiles.json）"
    )
    parser.add_argument("--competition", action="append", type=int, required=True, help="要领取的赛事 id，可重复")
    parser.add_argument("--backend-url", default=os.environ.get("BACKEND_URL", "http://localhost:8001"))
    parser.add_argument(
        "--validator-api-key",
        default=os.environ.get("VALIDATOR_API_KEY"),
        help="validator 身份的 X-API-Key（默认读 VALIDATOR_API_KEY）",
    )
    parser.add_argument("--node-id", default=None, help="回报里的 node_id（默认 hostname:profile）")
    parser.add_argument(
        "--signing-key",
        default=os.environ.get("ADMISSION_SIGNING_KEY"),
        help="validator 的 Ed25519 私钥文件（默认读 ADMISSION_SIGNING_KEY）；"
        "没有它不能启动 —— 每次准入都要产出签名 manifest",
    )
    parser.add_argument("--state-file", default="var/admission_worker_state.json")
    parser.add_argument("--download-root", default="var/task_packages")
    parser.add_argument("--fetcher", choices=["hf", "local"], default="hf")
    parser.add_argument("--local-root", default=None, help="--fetcher local 时的题包根目录")
    parser.add_argument("--limit", type=int, default=4)
    parser.add_argument("--poll-interval", type=float, default=60.0)
    parser.add_argument("--once", action="store_true", help="轮询一次就退出")
    parser.add_argument(
        "--instruction-mode",
        choices=["profile", "llm", "disabled"],
        default="profile",
        help="覆盖 profile 里的 instruction.mode（disabled 只给离线调试用）",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if not args.validator_api_key:
        print("--validator-api-key or VALIDATOR_API_KEY is required", file=sys.stderr)
        return 2
    if args.fetcher == "local" and not args.local_root:
        print("--fetcher local requires --local-root", file=sys.stderr)
        return 2
    if not args.signing_key:
        print(
            "--signing-key or ADMISSION_SIGNING_KEY is required: every admission must carry a signed manifest",
            file=sys.stderr,
        )
        return 2
    try:
        signer = Signer.from_keyfile(args.signing_key)
    except (OSError, ValueError, KeyError) as exc:
        print(f"cannot load the admission signing key: {exc}", file=sys.stderr)
        return 2

    profile = get_profile(args.profile, args.profile_config)
    scene = None
    node_id = args.node_id or f"{socket.gethostname()}:{args.profile}"
    from .scene_dispatch import is_scene_task

    if args.task_kind == "scene":
        from .scene_adapter import load_scene_adapter
        from .scene_transport import SceneTransportError

        if not args.scene_registration:
            print("scene requires --scene-registration", file=sys.stderr)
            return 2
        try:
            scene = load_scene_adapter(
                args.scene_registration,
                backend_url=args.backend_url,
                api_key=args.validator_api_key,
                signer=signer,
                node_id=node_id,
            )
            if profile.get("execution_profile") != scene.registration.document["execution_profile"]:
                raise ValueError("scene profile registration mismatch")
        except (OSError, ValueError, SceneTransportError) as exc:
            print(f"scene registration unavailable: {type(exc).__name__}", file=sys.stderr)
            return 2
    elif args.scene_registration or is_scene_task(profile):
        print("scene profile requires explicit --task-kind scene", file=sys.stderr)
        return 2
    if args.instruction_mode != "profile":
        instruction = dict(profile.get("instruction") or {})
        instruction["mode"] = args.instruction_mode
        profile["instruction"] = instruction

    client = HttpQueueClient(
        args.backend_url, args.validator_api_key, scene_transport=scene.transport if scene else None
    )
    fetcher: PackageFetcher = (
        None
        if scene
        else LocalFetcher(args.local_root)
        if args.fetcher == "local"
        else HuggingFaceFetcher(args.download_root)
    )
    worker = AdmissionWorker(
        profile_name=args.profile,
        profile=profile,
        competitions=args.competition,
        client=client,
        fetcher=fetcher,
        ledger=Ledger(args.state_file),
        node_id=node_id,
        signer=signer,
        scene_adapter=scene,
    )
    from .panel_state import single_owner

    owner = (
        single_owner(pathlib.Path(args.state_file).with_name(pathlib.Path(args.state_file).name + ".owner"))
        if scene
        else nullcontext()
    )
    with owner:
        recovered = worker.recover()
        if recovered:
            print(f"[worker] recovered {recovered} interrupted admission(s) back to claimed")

        while True:
            reports = worker.poll_once(args.limit)
            for report in reports:
                print(
                    f"[worker] {report.task_id} attempt={report.attempt} outcome={report.outcome} "
                    f"code={report.code} reason={report.reason}"
                )
            if args.once:
                return 0
            time.sleep(max(1.0, args.poll_interval))


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
