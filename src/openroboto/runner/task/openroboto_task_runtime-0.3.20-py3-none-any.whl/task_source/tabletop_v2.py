"""候选v2的唯一物理场景展开与逐文件核验；v1生成器保持原样。"""

from __future__ import annotations

import copy
import hashlib
import math
import random
import xml.etree.ElementTree as ET
from typing import Mapping

from openroboto_protocol import tabletop_v2 as contract
from openroboto_protocol.tabletop_assets import canonical_digest, support_local
from openroboto_protocol.task_contract import TaskContractError
from openroboto_protocol.task_profiles import parse_public_summary

from .base import CheckResult, TaskSourceError
from .package import canonical_json_sha256, read_json
from .tabletop import DATA, INITIAL_ARM, JOINT_ORDER, RUNTIME, _numbers, verify_platform_assets
from .tabletop_geometry import assets

CHECKER_TYPE = "TabletopProgramChecker"
PALETTE = [
    ("orange", (0.95, 0.4, 0.1, 1)),
    ("blue", (0.15, 0.35, 0.9, 1)),
    ("green", (0.15, 0.75, 0.25, 1)),
    ("red", (0.85, 0.12, 0.12, 1)),
    ("purple", (0.65, 0.2, 0.8, 1)),
    ("cyan", (0.1, 0.8, 0.85, 1)),
    ("yellow", (0.95, 0.85, 0.1, 1)),
    ("pink", (0.95, 0.45, 0.7, 1)),
    ("brown", (0.4, 0.2, 0.05, 1)),
    ("white", (0.95, 0.95, 0.95, 1)),
    ("black", (0.08, 0.08, 0.08, 1)),
    ("grey", (0.5, 0.5, 0.5, 1)),
    ("lime", (0.6, 0.9, 0.2, 1)),
    ("navy", (0.05, 0.1, 0.35, 1)),
    ("maroon", (0.4, 0.05, 0.15, 1)),
    ("teal", (0.05, 0.4, 0.35, 1)),
]
ASSET_NOTICE = (
    "OpenRoboto composed tabletop assets v2\n"
    "Procedural primitives and fixed convex meshes: OpenRoboto, Apache-2.0.\n"
    "Visual and collision geometry share the exact catalog geometry.\n"
    "Panda attribution and Apache-2.0 terms remain in NOTICE and LICENSE.\n"
)


def _check(definition):
    issues = contract.validate_definition(definition)
    if issues:
        raise TaskSourceError("; ".join(f"{i.path}: {i.code}: {i.message}" for i in issues))


def _scene(definition):
    _check(definition)
    root = ET.fromstring((DATA / "scene.xml").read_text())
    root.set("model", "openroboto-panda-tabletop-v2")
    width, height = contract.profile_catalog()["camera"]["image_size"][definition["observation"]]
    visual = ET.SubElement(root, "visual")
    ET.SubElement(visual, "global", offwidth=str(width), offheight=str(height))
    world, scene_assets = root.find("worldbody"), root.find("asset")
    for i, obj in enumerate(definition["objects"]):
        asset = assets()[obj["asset_id"]]
        shape = asset["geometry"]
        qx, qy, qz, qw = obj["quaternion"]
        body = ET.SubElement(
            world, "body", name=obj["id"], pos=_numbers(obj["position"]), quat=_numbers([qw, qx, qy, qz])
        )
        ET.SubElement(body, "freejoint", name=obj["id"] + "_free")
        attrs = {
            "name": obj["id"] + "_geom",
            "type": shape["type"],
            "mass": str(asset["mass_kg"]),
            "friction": _numbers(asset["friction"]),
            "condim": str(asset["contact_dimension"]),
            "solref": _numbers(asset["solref"]),
            "solimp": _numbers(asset["solimp"]),
            "contype": "2",
            "conaffinity": "3",
            "rgba": _numbers(PALETTE[i][1]),
        }
        if shape["type"] == "mesh":
            mesh_id = "controlled_" + asset["id"]
            if scene_assets.find(f"mesh[@name='{mesh_id}']") is None:
                ET.SubElement(
                    scene_assets,
                    "mesh",
                    name=mesh_id,
                    vertex=" ".join(_numbers(v) for v in shape["vertices"]),
                    face=" ".join(" ".join(str(v) for v in face) for face in shape["faces"]),
                )
            attrs["mesh"] = mesh_id
        else:
            attrs["size"] = _numbers(shape["size"])
        ET.SubElement(body, "geom", attrs)
    for i, zone in enumerate(definition["zones"]):
        body = ET.SubElement(world, "body", name=f"zone_{zone['id']}", pos=_numbers([*zone["position"], 0.7505]))
        ET.SubElement(
            body,
            "geom",
            type="cylinder",
            size=_numbers([zone["radius_m"], 0.0005]),
            contype="0",
            conaffinity="0",
            rgba=_numbers([*PALETTE[i % len(PALETTE)][1][:3], 0.5]),
        )
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="unicode") + "\n"


def definition_instruction(definition):
    """唯一受控题面；视觉合同不注入对象或目标真值坐标。"""
    objects = {obj["id"]: f"the {PALETTE[i][0]} object" for i, obj in enumerate(definition["objects"])}
    zones = {z["id"]: f"the {PALETTE[i % len(PALETTE)][0]} marked zone" for i, z in enumerate(definition["zones"])}
    if definition["observation"] == "state":
        objects = {key: f"object {key}" for key in objects}
        zones = {
            z["id"]: f"zone {z['id']} at ({z['position'][0]:g}, {z['position'][1]:g}) metres"
            for z in definition["zones"]
        }

    def describe(p):
        kind = p["type"]
        if kind in ("all", "any"):
            return "(" + (" AND " if kind == "all" else " OR ").join(describe(c) for c in p["children"]) + ")"
        if kind == "not":
            return "NOT (" + describe(p["child"]) + ")"
        if kind == "matching":
            return (
                "assign "
                + ", ".join(objects[n] for n in p["object_ids"])
                + " completely into "
                + ", ".join(zones[n] for n in p["zone_ids"])
                + " respecting listed asset classes and each zone's capacity"
            )
        obj = objects[p["object_id"]]
        if kind == "in_zone":
            return obj + " completely inside " + zones[p["zone_id"]]
        if kind == "pose":
            return (
                obj
                + " oriented to xyzw "
                + str(p["quaternion"])
                + " modulo its geometric symmetries (5 degree tolerance)"
            )
        if kind == "stable":
            return obj + " at rest (linear speed <=0.05 m/s, angular speed <=0.2 rad/s)"
        if kind == "released":
            return obj + " released with both fingers open and no robot contact"
        other = p.get("support_id", p.get("other_id"))
        other = objects.get(other, other)
        return obj + (" actually supported by " if kind == "supported_by" else " with no contact with ") + str(other)

    parts = ["Use the fixed Panda and the published world coordinate system. Each physics tick is 0.002 seconds."]
    if definition["observation"] == "state":
        for obj in definition["objects"]:
            parts.append(f"Object {obj['id']} uses registered asset {obj['asset_id']}.")
    for i, stage in enumerate(definition["stages"]):
        parts.append(
            f"Stage {stage['id']} (requires {stage['requires']}): "
            f"hold {describe(stage['goal'])} for {stage['hold_ticks']} physics ticks."
        )
        if stage["reject_early"]:
            parts.append("Achieving this stage before its dependencies is a permanent violation.")
        for p in stage["invariants"]:
            parts.append("Throughout this active stage require: " + describe(p) + ".")
    for p in definition["invariants"]:
        parts.append(
            "Throughout the episode require: " + describe(p) + "; any violation remains a failure even after recovery."
        )
    parts.append(
        "All stages must complete; all terminal stage goals must still hold. "
        "Dependencies cannot complete on the same tick."
    )
    if definition["observation"] == "vision":
        parts.append(
            "Infer object/zone positions from the image; simulator object positions and full state are unavailable. "
            "Camera: position [0.58,-0.35,1.8]m, vertical FOV 47deg, image 1280x720, "
            "world camera xyaxes [1,0,0,0,0.956,0.293], tabletop z=0.75m."
        )
    # Capacity and allowed types are part of the actual task, not private answers.
    for zone in definition["zones"]:
        descriptions = []
        for name in zone["accepts"]:
            asset = assets()[name]
            axes = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
            dimensions = [
                1000 * (support_local(asset["geometry"], axis) + support_local(asset["geometry"], [-v for v in axis]))
                for axis in axes
            ]
            descriptions.append(
                asset["category"] + " with dimensions " + " x ".join(f"{v:g}" for v in dimensions) + " mm"
            )
        categories = sorted(set(descriptions))
        allowed = zone["accepts"] if definition["observation"] == "state" else categories
        parts.append(f"{zones[zone['id']]}: capacity {zone['capacity']}; allowed classes {allowed}.")
    return " ".join(parts)


def _initial(definition, instance):
    rng = random.Random(definition["seed"] * 1009 + instance)
    randomization = definition["randomization"]
    objects = {}
    for obj in definition["objects"]:
        pos = list(obj["position"])
        pos[0] += rng.uniform(-randomization["xy_m"], randomization["xy_m"])
        pos[1] += rng.uniform(-randomization["xy_m"], randomization["xy_m"])
        angle = rng.uniform(-randomization["yaw_rad"], randomization["yaw_rad"]) / 2
        x, y, z, w = obj["quaternion"]
        s, c = math.sin(angle), math.cos(angle)
        quaternion = [c * x - s * y, c * y + s * x, c * z + s * w, c * w - s * z]
        if not (0.30 <= pos[0] <= 0.85 and -0.25 <= pos[1] <= 0.25):
            raise TaskSourceError(
                f"initial_state_out_of_bounds: instance {instance}, object {obj['id']}; no clipping or resampling"
            )
        objects[obj["id"]] = {"pos": pos, "rot": quaternion}
    return {"objects": objects, "robots": {"franka": {"dof_pos": dict(zip(JOINT_ORDER, (0.04, 0.04, *INITIAL_ARM)))}}}


def package_documents(task_id, title, definition, *, public_summary=None):
    _check(definition)
    verify_platform_assets()
    instruction = definition_instruction(definition)
    checker = {"checker": {"type": CHECKER_TYPE, "definition": copy.deepcopy(definition)}}
    runtime = {**RUNTIME, "tabletop_v2_definition": copy.deepcopy(definition)}
    task = {
        "schema_version": 1,
        "source": "axis",
        "task_id": task_id,
        "title": title,
        "instruction": instruction,
        "checker": checker,
        "runtime": runtime,
        "execution_profile": contract.profile_ref(),
        "task_definition": copy.deepcopy(definition),
        "reference_solution": "reference.json",
    }
    if public_summary is not None:
        try:
            task["public_summary"] = parse_public_summary(public_summary, expected_profile=contract.profile_ref())
        except TaskContractError as exc:
            raise TaskSourceError(str(exc)) from exc
    docs, variants = {"task.json": task, "runtime/asset_catalog.json": {"assets": contract.asset_catalog()}}, []
    for i in range(definition["instance_count"]):
        payload = {
            "id": task_id,
            "name": instruction,
            "instance": i,
            "seed": definition["seed"] * 1009 + i,
            "initial_state": _initial(definition, i),
            "checker_config": checker,
            "scene": "runtime/scene.xml",
        }
        path = f"payloads/{i:02d}.json"
        docs[path] = payload
        variants.append({
            "instance": i,
            "payload_path": path,
            "seed": payload["seed"],
            "payload_canonical_sha256": canonical_json_sha256(payload),
            "checker_sha256": canonical_json_sha256(checker),
            "initial_state_sha256": canonical_json_sha256(payload["initial_state"]),
        })
    first = docs["payloads/00.json"]
    resource = contract.resource_catalog()[definition["resource_profile"]]
    docs["benchmark.json"] = {
        "schema_version": 1,
        "name": "openroboto-panda-tabletop-v2",
        "runtime": runtime,
        "protocol": {"max_control_steps_per_trial": resource["max_control_steps_per_trial"]},
        "tasks": [
            {
                "task_id": task_id,
                "instruction": instruction,
                "checker_sha256": canonical_json_sha256(checker),
                "initial_state_sha256": canonical_json_sha256(first["initial_state"]),
            }
        ],
    }
    docs["randomization.json"] = {"schema_version": 1, "tasks": [{"task_id": task_id, "variants": variants}]}
    return docs


def validate_package(package, *, expected_execution_profile=None):
    from openroboto_protocol.task_profiles import validate_task_document

    issues = validate_task_document(
        package.task, expected_execution_profile=expected_execution_profile, require_profile=True
    )
    if issues:
        raise TaskSourceError("; ".join(f"{i.code}: {i.message}" for i in issues))
    definition = package.task["task_definition"]
    expected = package_documents(
        package.task_id,
        str(package.task.get("title") or ""),
        definition,
        public_summary=package.task.get("public_summary"),
    )
    for path, value in expected.items():
        if read_json(package.path(path)) != value:
            raise TaskSourceError(f"execution-profile: generated v2 document differs: {path}")
    if package.path("runtime/scene.xml").read_text() != _scene(definition):
        raise TaskSourceError("execution-profile: v2 scene differs from exact controlled generation")
    if package.path("runtime/ASSET_NOTICE").read_text() != ASSET_NOTICE:
        raise TaskSourceError("execution-profile: missing or changed v2 asset attribution")
    allowed = set(expected) | {"reference.json", "runtime/scene.xml", "runtime/ASSET_NOTICE", ".gitattributes"}
    for path, sha in verify_platform_assets().items():
        if path == "scene.xml":
            continue
        path = "runtime/" + path
        allowed.add(path)
        if hashlib.sha256(package.path(path).read_bytes()).hexdigest() != sha:
            raise TaskSourceError(f"execution-profile: unapproved robot asset {path}")
    total = 0
    for path in package.directory.rglob("*"):
        if path.is_symlink():
            raise TaskSourceError("execution-profile: symlinks are forbidden")
        if path.is_file():
            name = path.relative_to(package.directory).as_posix()
            if name not in allowed or name == ".gitattributes" and path.stat().st_size > 8192:
                raise TaskSourceError(f"execution-profile: undeclared or oversized file {name}")
            total += path.stat().st_size
    if total > contract.resource_catalog()[definition["resource_profile"]]["max_package_bytes"]:
        raise TaskSourceError("execution-profile: v2 package exceeds resource envelope")
    return {
        "execution_profile": contract.profile_ref(),
        "public_summary": package.task.get("public_summary"),
        "observation_contract": definition["observation"],
        "resource_profile": definition["resource_profile"],
    }


def program_condition(config, state, *, resolver=None):
    """判定只消费真实env监测结果，定义摘要必须相同，旧/缺失快照不通过。"""
    snapshot = state.get("tabletop_program") or {}
    passed = (
        snapshot.get("schema_version") == 1
        and snapshot.get("definition_digest") == canonical_digest(config["definition"])
        and snapshot.get("passed") is True
        and snapshot.get("violation") is None
    )
    from .tabletop_program import evaluate_predicate

    definition = config["definition"]
    diagnostics = []

    def visit(predicate, path):
        diagnostics.append({
            "path": path,
            "predicate": predicate,
            "satisfied_now": evaluate_predicate(predicate, state, definition, resolver=resolver),
        })
        for i, child in enumerate(predicate.get("children", [])):
            visit(child, f"{path}.children[{i}]")
        if "child" in predicate:
            visit(predicate["child"], f"{path}.child")

    for i, predicate in enumerate(definition["invariants"]):
        visit(predicate, f"invariants[{i}]")
    for i, stage in enumerate(definition["stages"]):
        visit(stage["goal"], f"stages[{i}].goal")
        for j, predicate in enumerate(stage["invariants"]):
            visit(predicate, f"stages[{i}].invariants[{j}]")
    return CheckResult(
        passed,
        {
            "checker_type": CHECKER_TYPE,
            **snapshot,
            "passed": bool(passed),
            "predicate_diagnostics": diagnostics,
        },
    )


class ProgramChecker:
    def __init__(self, config, *, resolver=None):
        self.config = config
        self.resolver = resolver

    def evaluate(self, state):
        return program_condition(self.config, state.get("current", state), resolver=self.resolver)

    def describe(self):
        return {"source": "axis", "checker_type": CHECKER_TYPE, "config": self.config}


def build_package(definition_path, output, *, task_id, title, public_summary=None):
    import shutil

    from .package import package_digest, write_json

    document = read_json(definition_path)
    if (
        not isinstance(document, Mapping)
        or type(document.get("schema_version")) is not int
        or document.get("schema_version") != 1
        or set(document) - {"schema_version", "execution_profile", "task_definition", "public_summary"}
    ):
        raise TaskSourceError(
            "v2 authoring wrapper requires schema 1 and only execution_profile/task_definition/public_summary"
        )
    issues = contract.validate_document(document)
    if issues:
        raise TaskSourceError("; ".join(f"{i.code}: {i.message}" for i in issues))
    definition = document["task_definition"]
    if public_summary is None:
        public_summary = document.get("public_summary")
    docs = package_documents(task_id, title, definition, public_summary=public_summary)
    output.mkdir(parents=True, exist_ok=False)
    for relative, value in docs.items():
        write_json(output / relative, value, indent=2)
    for relative in verify_platform_assets():
        if relative == "scene.xml":
            continue
        target = output / "runtime" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(DATA / relative, target)
    (output / "runtime/scene.xml").write_text(_scene(definition))
    (output / "runtime/ASSET_NOTICE").write_text(ASSET_NOTICE)
    write_json(
        output / "reference.json",
        {
            "schema_version": 1,
            "task_id": task_id,
            "instances": {str(i): {"actions": [], "final_state": {}} for i in range(definition["instance_count"])},
        },
        indent=2,
    )
    return {
        "path": str(output),
        "execution_profile": contract.profile_ref(),
        "package_digest": package_digest(output),
        "reference_ready": False,
        "status": "development_candidate",
    }
