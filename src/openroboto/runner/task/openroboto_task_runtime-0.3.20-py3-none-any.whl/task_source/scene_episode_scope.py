"""Fresh cgroup domain for one trusted scene parent, never the daemon PID.

Only the separately installed root launcher calls LinuxScopeKernel. Importing
or building a plan does not probe the host. Policy comes from its root-owned
operator deployment; E and model output cannot select limits or filesystem
roots. P03 still performs its own unchanged kernel checks in the child.
"""

from __future__ import annotations

import os
from pathlib import Path
import stat
import sys
import time
from dataclasses import dataclass

from task_source.scene_views.identity import decode, encoded

CONTROLLERS = {"cpu", "memory", "pids"}


class SceneLaunchError(ValueError):
    pass


def require(condition, code="scene_episode_launcher_unavailable"):
    if not condition:
        raise SceneLaunchError(code)


def _base(value):
    require(type(value) is str)
    path = Path(value)
    require(
        path.is_absolute()
        and ".." not in path.parts
        and str(path) == value
        and path.is_relative_to("/sys/fs/cgroup")
        and path != Path("/sys/fs/cgroup")
    )
    return path


@dataclass(frozen=True)
class EpisodeScopePlan:
    scope: Path
    watch: Path
    policy_bytes: bytes

    @property
    def policy(self):
        return decode(self.policy_bytes)

    @property
    def accounting(self):
        return self.scope.parent

    @classmethod
    def registered(cls, deployment, *, episode, submission_digest, config_digest):
        """Pure derivation from registered deployment + frozen identity only."""
        from task_source.scene_views.episode import EpisodePolicy
        from task_source.scene_views.episode_scope import episode_scope_name

        require(set(episode) == {"run_id", "attempt_id", "member_id", "worker_id", "node_id", "trial", "instance"})
        require(type(episode["trial"]) is int and episode["trial"] >= 0)
        require(type(episode["instance"]) is int and episode["instance"] >= 0)
        require(episode["attempt_id"] == f"{episode['run_id']}:{episode['member_id']}:{episode['trial']}")
        base = _base(deployment["cgroup_base"])
        require("watchdog_base" not in deployment, "scene_episode_legacy_accounting_layout")
        template = deployment["episode_policy"]
        require(
            type(template) is dict
            and not {"accounting_scope", "parent_scope", "cgroup_parent", "watchdog_parent"} & set(template)
        )
        require(template["config_digest"] == config_digest)
        require(
            type(deployment["control_uid"]) is int
            and deployment["control_uid"] > 0
            and type(deployment["control_gid"]) is int
            and deployment["control_gid"] > 0,
            "scene_episode_control_identity_unavailable",
        )
        require(
            template["uid"] != deployment["control_uid"] and template["gid"] != deployment["control_gid"],
            "scene_episode_native_identity_overlap",
        )
        name = episode_scope_name(episode=episode, submission_digest=submission_digest, config_digest=config_digest)
        require(type(name) is str and len(name) == 70 and name.startswith("scene-") and "/" not in name)
        accounting = base / name
        scope, watch = accounting / "episode", accounting / "watchdogs"
        policy = {
            **template,
            "accounting_scope": str(accounting),
            "parent_scope": str(scope),
            "cgroup_parent": str(scope / "native"),
            "watchdog_parent": str(watch),
        }
        # Exact P03 policy validation, no local weak policy/parser substitute.
        EpisodePolicy.from_registered_config(policy)
        return cls(scope, watch, encoded(policy))


class LinuxScopeKernel:
    """Actual privileged writes; never used by software-only validation."""

    def preflight(self, bases):
        require(sys.platform == "linux" and os.geteuid() == 0)
        # This root launcher is dedicated, with no LeaseKeeper/worker threads.
        require(len(list(Path("/proc/self/task").iterdir())) == 1)
        membership = Path("/proc/self/cgroup").read_text()
        for base in bases:
            require(str(base.relative_to("/sys/fs/cgroup")) not in membership)
            for part in (base, *base.parents):
                metadata = part.lstat()
                require(stat.S_ISDIR(metadata.st_mode) and metadata.st_uid == 0 and not metadata.st_mode & 0o022)
            require(base.resolve() == base)
            require(CONTROLLERS <= set(self.read(base / "cgroup.subtree_control").split()))
            descriptor = os.open(base / "cgroup.kill", os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            os.close(descriptor)  # Availability only, never kill the shared base.

    def mkdir(self, path):
        path.mkdir(mode=0o700)  # No exist_ok: never adopt another episode's group.

    def read(self, path):
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            return os.read(fd, 65536).decode()
        finally:
            os.close(fd)

    def write(self, path, value):
        fd = os.open(path, os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            raw = str(value).encode()
            require(os.write(fd, raw) == len(raw))
        finally:
            os.close(fd)

    def rmdir(self, path):
        path.rmdir()

    def directories(self, path):
        return [p for p in path.iterdir() if p.is_dir()]

    def pause(self):
        time.sleep(0.01)


def counters(raw):
    return {line.split()[0]: int(line.split()[1]) for line in raw.splitlines()}


class FreshEpisodeScope:
    """Manager owns creation/enrollment/reap/cleanup for exactly one child.

    The child is born blocked on a private gate, then enrolled and released.
    The manager stays outside accounting; watchdogs are outside the killable
    episode tree but share its hard accounting ancestor. Bootstrap, preparation,
    native, gateway and watchdog costs all count against the original budget.
    """

    def __init__(self, plan, kernel=None, *, clock=time.monotonic):
        self.plan = plan
        self.kernel = kernel if kernel is not None else LinuxScopeKernel()
        self.clock = clock
        self.created = []
        self.pid = None
        self.initial = None
        self.closed = False

    def create(self):
        p, k = self.plan, self.kernel
        k.preflight((p.accounting.parent,))
        policy = p.policy
        try:
            for path in (p.accounting, p.scope, p.watch):
                k.mkdir(path)
                self.created.append(path)
                k.write(path / "cgroup.subtree_control", "+cpu +memory +pids")
            for name in ("parent", "native"):
                path = p.scope / name
                k.mkdir(path)
                self.created.append(path)
            k.write(p.scope / "native/cgroup.subtree_control", "+cpu +memory +pids")
            for name, value in {
                "memory.max": policy["memory_bytes"],
                "pids.max": policy["pids"],
                "cpu.max": f"{policy['cpu_quota_us']} 100000",
                "memory.swap.max": 0,
                "memory.oom.group": 1,
            }.items():
                k.write(p.accounting / name, value)
            require(not k.read(p.accounting / "cgroup.procs").strip())
            require(not k.read(p.scope / "cgroup.procs").strip())
            require(not k.read(p.scope / "native/cgroup.procs").strip())
            self.initial = counters(k.read(p.accounting / "cpu.stat"))
            require(self.initial["usage_usec"] == 0, "scene_episode_scope_not_fresh")
            return self
        except BaseException:
            self.close(failed=True)
            raise

    def enroll(self, child_pid):
        require(type(child_pid) is int and child_pid > 0 and child_pid != os.getpid())
        require(self.initial is not None and self.pid is None and not self.closed)
        self.kernel.write(self.plan.scope / "parent/cgroup.procs", child_pid)
        require(self.kernel.read(self.plan.scope / "parent/cgroup.procs").split() == [str(child_pid)])
        self.pid = child_pid

    def close(self, *, failed=False):
        if self.closed:
            return None
        k, p = self.kernel, self.plan
        final = None
        try:
            if p.scope in self.created:
                populated = counters(k.read(p.scope / "cgroup.events"))["populated"]
                if failed or populated:
                    k.write(p.scope / "cgroup.kill", 1)
                # P03 watchdogs use this episode's separate subtree only.
                if p.watch in self.created:
                    k.write(p.watch / "cgroup.kill", 1)
                deadline = self.clock() + p.policy["cleanup_seconds"]
                while counters(k.read(p.scope / "cgroup.events"))["populated"] or (
                    p.watch in self.created and counters(k.read(p.watch / "cgroup.events"))["populated"]
                ):
                    require(self.clock() < deadline, "scene_episode_scope_cleanup_unavailable")
                    k.pause()
                if populated and not failed:
                    raise SceneLaunchError("scene_episode_scope_descendants_survived")
                # Measure after BOTH the native/parent and watchdog subtrees
                # are quiescent. Reading only episode would omit watchdog cost.
                final = counters(k.read(p.accounting / "cpu.stat"))
                if self.initial is not None:
                    require(final["usage_usec"] >= self.initial["usage_usec"], "scene_episode_scope_stats_regressed")
                require(final["usage_usec"] <= p.policy["cpu_budget_s"] * 1_000_000, "scene_episode_scope_cpu_limit")
                require(
                    counters(k.read(p.accounting / "memory.events")).get("oom_kill", 0) == 0
                    and counters(k.read(p.accounting / "pids.events")).get("max", 0) == 0,
                    "scene_episode_scope_resource_limit",
                )
        finally:
            # Only groups created by this manager may be removed. A collision
            # is held; it never grants ownership of a pre-existing scope.
            for path in reversed(self.created[:]):
                if path == p.watch:
                    for child in k.directories(path):
                        k.rmdir(child)
                k.rmdir(path)
                self.created.remove(path)
            self.closed = True
        return {
            "scope": str(p.scope),
            "watchdog_parent": str(p.watch),
            "parent_pid": self.pid,
            "initial_cpu": self.initial,
            "final_cpu": final,
            "closed": True,
        }
