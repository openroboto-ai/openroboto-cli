"""Trusted parent hook for ORIGINAL A subscription ledgers and R12 portable.

The parent supplies independently registered factories, typed episode bindings,
original frozen specs, executor public trust and a prior authenticated server
binding commitment. No response, ZIP or ledger header selects those inputs.
This hook performs local reads/verification only, never gateway, quota, model,
execution, process control or a network request. A caller must first quiesce the
original process tree. Missing independent expectations remain held.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
import stat

from task_source.scene_views.identity import decode, encoded
from task_source.scene_recovery import RecoveryJournal, digest, require, stable_work, HEX

NAMESPACE = "local-a-subscription-v1"
LIMIT = 64_000_000


def original_tree(directory):
    """Freeze the COMPLETE run directory except the separately checked lease.

    No symlinks, special/hard-linked files or partial filtering of accounting
    records. Returned original bytes are private parent data, never an HTTP DTO.
    """
    root = Path(directory)
    require(root.is_dir() and not root.is_symlink(), "SCENE_RECOVERY_JOURNAL_REQUIRED")
    require(root.resolve() == root, "SCENE_RECOVERY_JOURNAL_INVALID")
    values, total, count = {}, 0, 0
    for path in root.rglob("*"):
        count += 1
        require(count <= 8192 and not path.is_symlink(), "SCENE_RECOVERY_JOURNAL_LIMIT")
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "SCENE_RECOVERY_JOURNAL_INVALID")
        name = path.relative_to(root).as_posix()
        if name == "lease.json":
            continue  # Original lease expiry is checked by prepare_scene_resume.
        require(info.st_size <= 16_000_000 and len(values) < 4096, "SCENE_RECOVERY_JOURNAL_LIMIT")
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        with os.fdopen(fd, "rb") as stream:
            before = os.fstat(stream.fileno())
            require((before.st_dev, before.st_ino) == (info.st_dev, info.st_ino), "SCENE_RECOVERY_JOURNAL_CHANGED")
            raw = stream.read(16_000_001)
            after = os.fstat(stream.fileno())
        total += len(raw)
        require(total <= LIMIT and len(raw) == info.st_size, "SCENE_RECOVERY_JOURNAL_LIMIT")
        require(
            (before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            "SCENE_RECOVERY_JOURNAL_CHANGED",
        )
        values[name] = raw
    require(values, "SCENE_RECOVERY_JOURNAL_REQUIRED")
    return values


def episode_paths(stem, evidence_path, directory):
    root, evidence = Path(directory), Path(evidence_path)
    require(
        evidence.is_absolute() and evidence.is_relative_to(root) and ".." not in evidence.parts,
        "SCENE_RECOVERY_EVENT_JOURNAL_REQUIRED",
    )
    name = evidence.relative_to(root).as_posix()
    return {
        "spec_bytes": f"specs/{stem}.json",
        "started_bytes": f"started/{stem}.json",
        "events_bytes": name,
        "root_bytes": name + ".root.json",
        "calls_bytes": name + ".calls.jsonl",
    }


class LocalARecoveryReader:
    """The runtime's scene_recovery_journal hook, installed by trusted parent.

    Construction inputs precede HTTP and come from the original authenticated
    work + independent operator registry/P03 validation. This is deliberately
    not a worker CLI that reads those expected values from recovery responses.
    A missing prior server binding (R12 includes an internal config id) cannot
    be guessed from local work or backfilled from the first resume response.
    """

    def __init__(
        self,
        *,
        work,
        factories,
        expected_specs,
        episode_bindings,
        executor_trust,
        checkpoint_state,
        server_binding_digest,
        recovery_generation,
        quiescent,
    ):
        from agent_harness.spec import parse_spec
        from task_source.scene_views.episode_gateway import SceneAGatewayFactory

        require(
            type(server_binding_digest) is str and HEX.fullmatch(server_binding_digest),
            "SCENE_RECOVERY_SERVER_BINDING_REQUIRED",
        )
        require(type(recovery_generation) is int and recovery_generation > 0, "SCENE_RECOVERY_GENERATION_INVALID")
        require(quiescent is True, "SCENE_RECOVERY_UNRESOLVED_CALLS")
        require(type(factories) is dict and factories, "SCENE_RECOVERY_LOCAL_A_JOURNAL_REQUIRED")
        for factory in factories.values():
            require(
                type(factory) is SceneAGatewayFactory
                and factory.identity["gateway_mode"] == "a_subscription"
                and factory.identity["ledger_namespace"] == NAMESPACE,
                "SCENE_RECOVERY_LEDGER_NAMESPACE_MISMATCH",
            )
        self._work = encoded(stable_work(work))
        self._state = encoded(checkpoint_state)
        self._specs = {stem: parse_spec(decode(encoded(spec.raw))) for stem, spec in expected_specs.items()}
        self._bindings, self._factories = dict(episode_bindings), dict(factories)
        from agent_evidence.signing import TrustStore

        require(type(executor_trust) is TrustStore, "SCENE_RECOVERY_LOCAL_A_JOURNAL_REQUIRED")
        self._trust = TrustStore(executor_trust.to_dict()["keys"])
        self._binding, self._generation = server_binding_digest, recovery_generation
        require(self._specs.keys() == self._bindings.keys(), "SCENE_RECOVERY_PARTIAL_TRIAL")
        registration = work["task"]["scene_registration"]
        assignment = work["task"]["assignment"]
        for stem, spec in self._specs.items():
            binding = self._bindings[stem].document
            require(
                spec.run_id == work["run_id"] == binding["run_id"]
                and spec.panel_binding["config_digest"] == work["config_digest"] == binding["config_digest"]
                and binding["worker_id"] == assignment["worker_id"]
                and binding["node_id"] == assignment["node_id"]
                and spec.task_id == registration["task_id"] == binding["task_id"]
                and binding["package_repo"] == registration["package_repo"]
                and binding["package_commit"] == registration["package_commit"]
                and binding["identity"] == registration["identity"]
                and binding["execution_contract"] == registration["execution_contract"]
                and binding["receipt_digest"] == work["task"]["receipt_authority"]["receipt_digest"]
                and self._bindings[stem].trust.document == work["task"]["receipt_authority"]["trust"]
                and 0 <= spec.episode < work["trials_per_member"],
                "SCENE_RECOVERY_WORK_CHANGED",
            )
            for key in (
                "execution_package_digest",
                "private_package_digest",
                "submission_digest",
                "execution_contract_digest",
            ):
                require(binding[key] == registration[key], "SCENE_RECOVERY_WORK_CHANGED")

    def scene_recovery_journal(self, work, *, directory):
        from task_source.scene_views.episode_ledger import LocalAEpisodeOriginal, prepare_local_a_journal

        require(encoded(stable_work(work)) == self._work, "SCENE_RECOVERY_WORK_CHANGED")
        raw = original_tree(directory)
        require(
            all(
                Path(factory.ledger_directory) == Path(directory) / "subscription"
                for factory in self._factories.values()
            ),
            "SCENE_RECOVERY_LEDGER_NAMESPACE_MISMATCH",
        )
        started = {Path(name).stem for name in raw if name.startswith("started/") and name.endswith(".json")}
        require(started == self._specs.keys(), "SCENE_RECOVERY_PARTIAL_TRIAL")
        require(
            {name for name in raw if name.startswith("specs/")} == {f"specs/{stem}.json" for stem in self._specs},
            "SCENE_RECOVERY_PARTIAL_TRIAL",
        )
        known_jsonl = {f"subscription/{member}.jsonl" for member in self._factories}
        for stem, spec in self._specs.items():
            paths = episode_paths(stem, spec.evidence_path, directory)
            known_jsonl.update(paths[key] for key in ("events_bytes", "calls_bytes"))
        require(
            {name for name in raw if name.endswith(".jsonl")} == known_jsonl,
            "SCENE_RECOVERY_EVENT_JOURNAL_REQUIRED",
        )
        originals = {
            stem: LocalAEpisodeOriginal(**{
                field: raw[path]
                for field, path in episode_paths(stem, self._specs[stem].evidence_path, directory).items()
            })
            for stem in self._specs
        }
        subscriptions = {member: raw[f"subscription/{member}.jsonl"] for member in self._factories}
        inventory = {
            **{
                stem + "/" + key: hashlib.sha256(getattr(original, key)).hexdigest()
                for stem, original in originals.items()
                for key in original.__dataclass_fields__
            },
            **{"subscription/" + key: hashlib.sha256(value).hexdigest() for key, value in subscriptions.items()},
        }
        prepared = prepare_local_a_journal(
            factories=self._factories,
            expected_specs=self._specs,
            episode_bindings=self._bindings,
            originals=originals,
            subscription_ledgers=subscriptions,
            inventory=inventory,
            executor_trust=self._trust,
            run_id=work["run_id"],
            binding_digest=self._binding,
            recovery_generation=self._generation,
            quiescent=True,
        )
        return RecoveryJournal.create_local_a(
            work=work,
            checkpoint_state=decode(self._state),
            local_a=prepared,
            files={name: hashlib.sha256(value).hexdigest() for name, value in raw.items()},
            quiescent=True,
        )


def verify_local_parent(value, work, root, *, host, config, generation):
    """Keep the parent's full file/trial/host coverage outside P03's journal.

    P03 verifies every full chain and local call/reservation. This second check
    binds that sealed snapshot to the actual worker directory, N and host.
    """
    from task_source.scene_views.episode_ledger import LocalARecoveryJournal
    from agent_harness.spec import parse_spec

    doc = value.document
    remote = value._remote
    if remote is not None:
        from task_source.scene_recovery_bootstrap import ParentRecoveryJournal

        require(
            type(remote) is ParentRecoveryJournal and value._local_a is None, "SCENE_RECOVERY_PARENT_RECEIPT_INVALID"
        )
        remote.verify(doc)
        local = doc["local_a"]
    else:
        require(type(value._local_a) is LocalARecoveryJournal, "SCENE_RECOVERY_LOCAL_A_JOURNAL_REQUIRED")
        local = value._local_a.document
    require(local == doc["local_a"], "SCENE_RECOVERY_JOURNAL_CHANGED")
    from task_source.scene_checkpoint import VERSION, LEDGERS, expected_ledgers

    expected = {
        "schema_version": VERSION,
        "run_id": local["run_id"],
        "binding_digest": local["binding_digest"],
        "recovery_generation": generation,
        "reconciliation_required": True,
        **expected_ledgers({name: [] for name in LEDGERS}),
    }
    if remote is None:
        value._local_a.reconcile(expected)
    require(
        local["run_id"] == work["run_id"]
        and local["binding_digest"] == doc["server_binding_digest"]
        and local["recovery_generation"] == generation
        and local["ledger_namespace"] == NAMESPACE
        and local["gateway_mode"] == "a_subscription",
        "SCENE_RECOVERY_LEDGER_NAMESPACE_MISMATCH",
    )
    raw = original_tree(root)
    require(
        doc["files"] == {name: hashlib.sha256(data).hexdigest() for name, data in raw.items()},
        "SCENE_RECOVERY_JOURNAL_CHANGED",
    )
    members = {member.id: member for member in config.settlement.members}
    stems = set()
    for name, row in local["members"].items():
        require(name in members, "SCENE_RECOVERY_N_CHANGED")
        factory = row["factory"]
        model = {**members[name].model_config(), **host["providers"][members[name].provider]}
        require(
            host["mode"] == "subscription"
            and factory["host_digest"] == digest(host)
            and factory["model_digest"] == digest(model)
            and factory["config_digest"] == config.digest,
            "SCENE_RECOVERY_LEDGER_NAMESPACE_MISMATCH",
        )
        for episode in row["episodes"]:
            stem = episode["stem"]
            require(stem not in stems, "SCENE_RECOVERY_PARTIAL_TRIAL")
            stems.add(stem)
            spec = parse_spec(decode(raw[f"specs/{stem}.json"]))
            for field, path in episode_paths(stem, spec.evidence_path, root).items():
                require(
                    doc["files"].get(path) == local["inventory"][stem + "/" + field], "SCENE_RECOVERY_JOURNAL_CHANGED"
                )
        require(
            doc["files"].get(f"subscription/{name}.jsonl") == local["inventory"]["subscription/" + name],
            "SCENE_RECOVERY_JOURNAL_CHANGED",
        )
    started = {Path(name).stem for name in raw if name.startswith("started/") and name.endswith(".json")}
    require(stems == started, "SCENE_RECOVERY_PARTIAL_TRIAL")
    subscriptions = {name for name in raw if name.startswith("subscription/")}
    require(
        subscriptions == {f"subscription/{member}.jsonl" for member in local["members"]},
        "SCENE_RECOVERY_EVENT_JOURNAL_REQUIRED",
    )
