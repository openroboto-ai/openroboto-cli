"""Apply the registered centimetre/degree perturbation to Panda TCP targets.

Reference files contain two finger widths and seven *joint angles*. Their
indices are not Cartesian coordinates. FK/IK runs on private MjData; only the
resulting joint controls are sent to the unchanged physical replay.
"""

from __future__ import annotations

import math
import random
from typing import Any, Mapping, Sequence

from .base import TaskSourceError, perturb_actions


def perturb_joint_reference(env: Any, actions: Sequence[Sequence[float]], noise: Mapping[str, Any], *, seed: int):
    import mujoco
    import numpy as np
    from agent_harness.runtimes import _AxisArm

    if not actions:
        return []
    if any(len(a) != 9 or not all(math.isfinite(float(v)) for v in a) for a in actions):
        raise TaskSourceError("Panda reference requires two finger widths and seven finite joint targets")
    position = float(noise.get("position_amplitude_m") or 0)
    angle = math.radians(float(noise.get("orientation_amplitude_deg") or 0))
    if not math.isfinite(position) or not math.isfinite(angle) or min(position, angle) < 0:
        raise TaskSourceError("Cartesian perturbation amplitudes must be finite and nonnegative")
    scale = noise.get("speed_scale") or [1.0, 1.0]
    rng = random.Random(int(seed))
    if float(scale[1]) > float(scale[0]):
        rng.uniform(float(scale[0]), float(scale[1]))  # same time-warp draw as perturb_actions
    delta = np.array([rng.uniform(-position, position) for _ in range(3)])
    yaw = rng.uniform(-angle, angle)
    turn = np.array([[math.cos(yaw), -math.sin(yaw), 0], [math.sin(yaw), math.cos(yaw), 0], [0, 0, 1]])
    warped = perturb_actions(actions, {"speed_scale": scale}, seed=seed)
    arm = _AxisArm(env)
    data = arm.data  # separate from env.data
    qp = list(env.qpos_indices)
    jacp, jacr = np.zeros((3, env.model.nv)), np.zeros((3, env.model.nv))
    result = []
    check_deadline = getattr(env, "check_deadline", None)
    for action in warped:
        if check_deadline is not None:
            check_deadline()
        data.qpos[qp] = action
        mujoco.mj_kinematics(env.model, data)
        tcp, rot = arm.tcp_pose()
        target_pos, target_rot = tcp.copy() + delta, turn @ rot.copy()
        q = np.array(action[2:], dtype=float)
        for _ in range(120):
            if check_deadline is not None:
                check_deadline()
            data.qpos[arm.arm_q] = q
            mujoco.mj_kinematics(env.model, data)
            mujoco.mj_comPos(env.model, data)
            tcp, rot = arm.tcp_pose()
            er = 0.5 * sum(np.cross(rot[:, i], target_rot[:, i]) for i in range(3))
            err = np.concatenate([target_pos - tcp, er])
            if np.linalg.norm(err[:3]) <= 1e-4 and np.linalg.norm(err[3:]) <= 1e-3:
                break
            mujoco.mj_jac(env.model, data, jacp, jacr, tcp, arm.hand)
            jac = np.vstack([jacp, jacr])[:, arm.arm_dof]
            dq = jac.T @ np.linalg.solve(jac @ jac.T + 1e-5 * np.eye(6), err)
            q = np.clip(q + np.clip(dq, -0.15, 0.15), arm.lo, arm.hi)
        else:
            raise TaskSourceError(
                "registered Cartesian noise is unreachable by the frozen Panda; refusing joint-space fallback"
            )
        result.append([float(action[0]), float(action[1]), *map(float, q)])
    return result
