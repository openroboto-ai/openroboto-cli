"""统一准入：对任何题源只看 ``TaskSource`` / ``Checker``。

这里**不出现任何题源名字**。题目自己声明 ``source``，配置把它解析成实现；
通用检查（实例数、参考解覆盖、可解、不白送、确定性）对所有题源一样；
题源特有的检查（AXIS 哈希/词表、RoboDojo 官方 task/判据）由
``TaskSource.static_checks()`` 提供，准入只负责收集。

运行期检查（参考解在仿真里回放、加噪、nop、可见性）不在这里做 —— 那需要
MuJoCo / Isaac Sim，属于 OPE-99 的 worker。这里对没有参考解的题源把
``solvable`` / ``not_freebie`` 标成 ``runtime``，不冒充「已通过」。
"""

from __future__ import annotations

import json
import pathlib
from typing import Any, Mapping

from .base import (
    AdmissionCheck,
    AdmitResult,
    Checker,
    TaskSourceError,
    TaskSpec,
)
from .package import TASK_FILE, TaskPackage, discover_packages, load_package, read_json
from .registry import get_source, load_config

SUBMISSION_VERSION = 1


def _check(
    name: str,
    passed: bool,
    detail: Mapping[str, Any] | None = None,
    kind: str = "structural",
) -> AdmissionCheck:
    return AdmissionCheck(name, passed, dict(detail or {}), kind)


def _evaluate(checker: Checker, state: Mapping[str, Any]) -> tuple[bool, Mapping[str, Any]]:
    result = checker.evaluate(state)
    return result.passed, result.detail


def _stable(value: Mapping[str, Any]) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _admit_task(source: Any, task: TaskSpec) -> list[AdmissionCheck]:
    checks: list[AdmissionCheck] = []

    # 1) 判定器能通过统一接口构造出来（词表不够的在这里就已经失败）。
    try:
        checker = source.checker(task)
    except TaskSourceError as exc:
        return [_check("checker_registered", False, {"error": str(exc)})]
    checks.append(_check("checker_registered", True, checker.describe()))

    # 2) 参考解覆盖：声明了就必须每个实例都有；没声明不判错（运行期检查）。
    #    实例数量上限是题源性质（AXIS 20 / RoboDojo 官方 episode 数），由
    #    ``static_checks`` 声明，这里不按题源分派。
    instances = [str(item.instance) for item in task.instances]
    if task.reference is None:
        checks.append(
            _check(
                "reference_covers_instances",
                True,
                {"declared": False, "reason": "no reference solution in this task package"},
                kind="runtime",
            )
        )
        checks.append(
            _check("solvable", False, {"declared": False, "reason": "requires the source runtime"}, kind="runtime")
        )
        checks.append(
            _check("not_freebie", False, {"declared": False, "reason": "requires the source runtime"}, kind="runtime")
        )
    else:
        covered = sorted(str(key) for key in (task.reference.get("instances") or {}))
        missing = sorted(set(instances) - set(covered))
        extra = sorted(set(covered) - set(instances))
        checks.append(
            _check(
                "reference_covers_instances",
                not missing and not extra,
                {"declared": True, "missing": missing, "extra": extra},
            )
        )

        solvable_errors: list[dict[str, Any]] = []
        freebie_errors: list[dict[str, Any]] = []
        deterministic_errors: list[str] = []
        for item in task.instances:
            reference = task.reference_for(item.instance) or {}
            final_state = reference.get("final_state") if isinstance(reference, Mapping) else None
            if not isinstance(final_state, Mapping):
                solvable_errors.append({"instance": item.instance, "reason": "final_state missing"})
                continue
            passed, detail = _evaluate(checker, {"current": final_state, "initial": item.initial_state})
            if not passed:
                solvable_errors.append({"instance": item.instance, "detail": detail})
            passed_again, detail_again = _evaluate(checker, {"current": final_state, "initial": item.initial_state})
            if passed != passed_again or _stable(detail) != _stable(detail_again):
                deterministic_errors.append(f"instance {item.instance}: final-state verdict changed")

            opened, opened_detail = _evaluate(checker, item.initial_state)
            passed_again, opened_again = _evaluate(checker, item.initial_state)
            if opened != passed_again or _stable(opened_detail) != _stable(opened_again):
                deterministic_errors.append(f"instance {item.instance}: initial-state verdict changed")
            if opened:
                freebie_errors.append({"instance": item.instance, "detail": opened_detail})

        checks.append(_check("solvable", not solvable_errors, {"errors": solvable_errors}))
        checks.append(_check("not_freebie", not freebie_errors, {"errors": freebie_errors}))
        checks.append(_check("deterministic", not deterministic_errors, {"errors": deterministic_errors}))

    # 4) 题源自己的静态检查（哈希、官方 task、pinned ref……）。
    for name, passed, detail in source.static_checks(task):
        checks.append(_check(name, passed, detail))
    return checks


def admit_loaded(
    package: TaskPackage,
    *,
    source: Any,
    task: TaskSpec,
) -> AdmitResult:
    """对**已经加载好**的题包 / 任务跑结构准入。

    题包只读一次是 OPE-111 的硬要求：去重和运行期检查共用结构准入读到的
    同一个 ``TaskPackage`` / ``TaskSpec``，不重新 ``load_package``，也不重新
    ``TaskSource.load_task``。调用方负责解析题源。
    """
    checks = [_check("package", True, {"directory": str(package.directory), "source": package.source})]
    checks.extend(_admit_task(source, task))
    runtime_status, _ = source.runtime_status()
    accepted = all(check.passed for check in checks if check.kind == "structural")
    return AdmitResult(
        source=package.source,
        task_id=package.task_id,
        accepted=accepted,
        checks=tuple(checks),
        runtime_status=runtime_status if runtime_status != "not_run" else "not_run",
    )


def admit_package(
    directory: str | pathlib.Path,
    *,
    config: Mapping[str, Any] | None = None,
    source: Any | None = None,
) -> AdmitResult:
    """对一个题包跑准入。

    ``source`` 传实现对象时跳过配置查找（测试/worker 注入）；否则按
    ``task.json.source`` 从配置解析。
    """
    directory = pathlib.Path(directory).expanduser().resolve()
    try:
        package = load_package(directory)
    except TaskSourceError as exc:
        task_json = {}
        try:
            task_json = read_json(directory / TASK_FILE)
        except TaskSourceError:
            pass
        source_name = str(task_json.get("source") or "unknown")
        task_id = str(task_json.get("task_id") or directory.name)
        return AdmitResult(
            source=source_name,
            task_id=task_id,
            accepted=False,
            checks=(_check("package", False, {"error": str(exc)}),),
        )

    if source is None:
        config_data = dict(config) if config is not None else load_config()
        # 题包所在目录就是搜索根：准入必须读**提交上来的这一份**，不能落回
        # 配置里 samples 的缓存副本（否则改过的包会被原包“顶替”着通过）。
        resolved = get_source(package.source, config_data, root=directory)
    else:
        resolved = source

    try:
        task = resolved.load_task(package.task_id)
    except TaskSourceError as exc:
        return AdmitResult(
            source=package.source,
            task_id=package.task_id,
            accepted=False,
            checks=(_check("task_load", False, {"error": str(exc)}),),
        )

    return admit_loaded(package, source=resolved, task=task)


def admit_all(
    root: str | pathlib.Path,
    *,
    config: Mapping[str, Any] | None = None,
) -> list[AdmitResult]:
    root = pathlib.Path(root).expanduser()
    config_data = dict(config) if config is not None else load_config()
    results = []
    for directory in discover_packages(root):
        results.append(admit_package(directory, config=config_data))
    return results


def admit_submission(
    path: str | pathlib.Path,
    *,
    config: Mapping[str, Any] | None = None,
) -> AdmitResult:
    """``/task-commits`` 形状的提交 → 准入结果。

    提交文件只描述「哪个题包、哪个题源」::

        {"schema_version": 1, "source": "axis", "task_id": "9001",
         "package": "samples/axis/...", "commit": "<链上提交>"}

    ``source`` 必须与 ``task.json`` 一致。上层只读这个文件，不知道题源实现。
    """
    path = pathlib.Path(path).expanduser().resolve()
    submission = read_json(path)
    if not isinstance(submission, Mapping) or submission.get("schema_version") != SUBMISSION_VERSION:
        raise TaskSourceError(f"{path}: unsupported submission format (need schema_version={SUBMISSION_VERSION})")
    declared_source = submission.get("source")
    package_value = submission.get("package")
    if not isinstance(package_value, str) or not package_value:
        raise TaskSourceError(f"{path}: submission must contain a 'package' path")
    package_dir = pathlib.Path(package_value).expanduser()
    if not package_dir.is_absolute():
        package_dir = (path.parent / package_dir).resolve()
    result = admit_package(package_dir, config=config)
    if declared_source is not None and str(declared_source) != result.source:
        return AdmitResult(
            source=result.source,
            task_id=result.task_id,
            accepted=False,
            checks=result.checks
            + (_check("submission_source", False, {"declared": declared_source, "package": result.source}),),
            runtime_status=result.runtime_status,
        )
    checks = result.checks + (
        _check("submission_source", True, {"declared": declared_source, "package": result.source}),
    )
    accepted = all(check.passed for check in checks if check.kind == "structural")
    return AdmitResult(result.source, result.task_id, accepted, checks, result.runtime_status)


__all__ = [
    "SUBMISSION_VERSION",
    "admit_all",
    "admit_loaded",
    "admit_package",
    "admit_submission",
]
