"""后端可信网关的数据面客户端（B 赛道的唯一模型出口）。

B worker 不再按冻结 ``model.endpoint`` 直接请求 provider。所有模型请求改走
backend 的 ``POST /v1/chat``：

- 冻结目标（provider / model / endpoint / effort / max_tokens）**原样**放在
  ``request`` 覆盖块里，只用于后端逐字校验；实际转发目标永远是后端冻结的
  spec。这里不会、也不允许把 endpoint 改写成网关地址来"凑"一致。
- ``job_id`` / ``attempt_id`` / ``episode`` / ``run_id`` 都来自受控执行契约：
  job 来自后端已认证的 ``/spec.binding``，attempt/episode 来自后端
  ``start``，共同 run id 来自运营契约（见 ``agent_harness.model_transport``）。
  调用方传进来的值必须与契约一致，否则在发送前拒绝。
- bearer 凭据只从受控契约读取，**不是** provider API key。这里不读
  ``DEEPSEEK_API_KEY`` / ``ANTHROPIC_API_KEY``，也不提供任何直连 fallback。
- 后端返回的 ``provider_meta.request_id`` 是网关链里 ``model_call`` 的
  ``correlation_id``（同一个 ``trace_id``），任务链因此能与
  ``model_gateway_calls`` / ``model_gateway_roots`` 逐条对齐。

失败语义：

- 配置缺失 / 不完整 → :class:`BackendGatewayConfigError`，请求**没有发出**；
- 后端 4xx 拒绝 → :class:`GatewayRejection`（稳定 ``code``，503/429/5xx 和
  网络错误 → 可重试的 :class:`ProviderError`）；
- 成功响应缺少 ``provider_meta.request_id`` / 网关 call id → 视为契约缺口，
  按 :class:`ProviderError` 失败，不产出无法对齐的证据。
"""

from __future__ import annotations

import json
import io
import queue
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Mapping

from agent_eval.errors import GatewayRejection, ProviderError
from agent_eval.spec import ModelSpec

USER_AGENT = "validator-eval-worker/0.1"


def _deadline_response(request, *, timeout, deadline, cancellation, limit):
    """Bound the trusted caller's wait, including DNS and a trickling body.

    urllib/socket timeouts alone are per blocking operation. The daemon may
    finish an already-started remote request late; it cannot dispatch tools or
    start another request. No credentials leave this trusted parent process.
    """
    result = queue.Queue(maxsize=1)

    def remaining():
        value = deadline - time.monotonic()
        if value <= 0 or cancellation.is_set():
            raise TimeoutError("scene gateway deadline exceeded")
        return value

    def receive():
        try:
            remaining()
            try:
                response = urllib.request.urlopen(request, timeout=min(timeout, remaining()))
            except urllib.error.HTTPError as exc:
                response = exc
            try:
                data = bytearray()
                while True:
                    remaining()
                    chunk = response.read(min(65536, limit + 1 - len(data)))
                    if not chunk:
                        break
                    data.extend(chunk)
                    if len(data) > limit:
                        raise ValueError("scene gateway output limit")
                remaining()
                if isinstance(response, urllib.error.HTTPError):
                    raise urllib.error.HTTPError(
                        response.url, response.code, response.msg, response.headers, io.BytesIO(data)
                    )
                result.put((bytes(data), None))
            finally:
                response.close()
        except Exception as exc:
            result.put((None, exc))

    remaining()
    threading.Thread(target=receive, name="scene-gateway-request", daemon=True).start()
    while True:
        try:
            data, error = result.get(timeout=min(0.02, remaining()))
            remaining()
            if error:
                raise error
            return data
        except queue.Empty:
            continue


CHAT_PATH = "/v1/chat"


class BackendGatewayConfigError(ValueError):
    """网关 / 身份 / run 配置缺失或不合规。请求没有发出，调用方应 fail-closed。"""


class BackendGatewayHTTPError(ProviderError):
    """后端网关返回的 HTTP 错误（保留后端稳定 ``code``）。"""

    def __init__(
        self,
        message: str,
        *,
        code: str | None,
        status: int | None,
        retryable: bool | None = None,
        body: str | None = None,
        details: dict[str, Any] | None = None,
    ):
        super().__init__(
            message,
            provider="backend_gateway",
            status=status,
            retryable=retryable,
            body=body,
            details=details,
        )
        self.code = code


def _non_empty(value: Any, name: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise BackendGatewayConfigError(f"{name} is required for the backend model gateway")
    return text


def normalize_gateway_url(value: Any) -> str:
    text = _non_empty(value, "gateway url").rstrip("/")
    parsed = urllib.parse.urlparse(text)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise BackendGatewayConfigError("gateway url must be an absolute http(s) URL, got a non-URL value")
    return text


def _endpoint_identity(spec: ModelSpec) -> dict[str, Any]:
    """发给后端做逐字校验的冻结目标；不含任何凭据。"""

    endpoint = spec.resolved_endpoint().rstrip("/")
    return {
        "provider": spec.provider,
        "model": spec.model,
        "endpoint": endpoint,
        "effort": spec.effort,
        "max_tokens": spec.max_tokens,
    }


def _same_target(left: Mapping[str, Any], right: Mapping[str, Any]) -> bool:
    return all(left.get(key) == right.get(key) for key in left)


def _read_error_body(error: urllib.error.HTTPError) -> tuple[str, dict[str, Any] | None]:
    try:
        raw = error.read().decode("utf-8", "replace")
    except Exception:  # noqa: BLE001 - body 读不出来不能掩盖原错误
        return "", None
    try:
        payload = json.loads(raw)
    except (TypeError, ValueError):
        return raw, None
    return raw, payload if isinstance(payload, dict) else None


def _error_code(payload: Mapping[str, Any] | None, message: str) -> str | None:
    # 422 的裸形状把**违规码**写进 message: "[GATEWAY_REJECTED] budget_calls_exceeded: ..."。
    # 外层的 GATEWAY_REJECTED 只是类别，调用方需要内层稳定码分支。
    prefix = "[GATEWAY_REJECTED] "
    if message.startswith(prefix):
        remainder = message[len(prefix) :]
        inner = remainder.split(":", 1)[0].strip()
        if inner:
            return inner
    if isinstance(payload, Mapping):
        code = payload.get("code")
        if isinstance(code, str) and code:
            return code
        error = payload.get("error")
        if isinstance(error, Mapping) and isinstance(error.get("code"), str):
            return error["code"]
    return None


def _error_message(payload: Mapping[str, Any] | None, raw: str, status: int) -> str:
    if isinstance(payload, Mapping):
        for key in ("detail", "message"):
            value = payload.get(key)
            if isinstance(value, str) and value:
                return value
        error = payload.get("error")
        if isinstance(error, Mapping) and isinstance(error.get("message"), str):
            return error["message"]
    return raw[:500] or f"HTTP {status} from the backend model gateway"


@dataclass(frozen=True)
class BackendGatewayTarget:
    """受控身份 + 冻结目标。token 不进 repr / 日志。"""

    base_url: str
    token: str = field(repr=False)
    job_id: str
    attempt_id: str
    episode: int
    run_id: str
    model_spec: ModelSpec
    timeout_s: float = 600.0

    def __post_init__(self) -> None:
        normalize_gateway_url(self.base_url)
        if not self.token:
            raise BackendGatewayConfigError("gateway bearer token is required")
        if not str(self.job_id).strip():
            raise BackendGatewayConfigError("job_id is required")
        if not str(self.attempt_id).strip():
            raise BackendGatewayConfigError("attempt_id is required")
        if isinstance(self.episode, bool) or not isinstance(self.episode, int) or self.episode < 0:
            raise BackendGatewayConfigError("episode must be a non-negative integer")
        if not str(self.run_id).strip():
            raise BackendGatewayConfigError("shared run_id is required")
        if self.timeout_s <= 0:
            raise BackendGatewayConfigError("timeout_s must be positive")

    @property
    def request_override(self) -> dict[str, Any]:
        return _endpoint_identity(self.model_spec)

    def check_call_identity(self, run_id: str | None, attempt_id: str | None) -> None:
        """harness 传入的 run/attempt 不能改变受控契约。"""

        if run_id is not None and str(run_id) not in {"", self.run_id}:
            raise BackendGatewayConfigError(
                "the harness tried to override the shared run id; run ids come from the operator contract"
            )
        if attempt_id is not None and str(attempt_id) not in {"", self.attempt_id}:
            raise BackendGatewayConfigError("the harness tried to override the backend attempt id")

    def payload(
        self,
        messages: list[dict],
        tools: list[dict] | None,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        return {
            "job_id": self.job_id,
            "attempt_id": self.attempt_id,
            "episode": self.episode,
            "run_id": self.run_id,
            "messages": messages,
            "tools": tools or [],
            # 只用于后端逐字校验；后端永远用冻结 spec 转发。
            "request": self.request_override,
            "stream": bool(stream),
        }


class BackendModelGateway:
    """一次 run 复用一个实例；``chat`` 与 :class:`agent_eval.ModelGateway` 同形。"""

    def __init__(self, target: BackendGatewayTarget):
        self.target = target
        self.model_spec = target.model_spec
        self._url = target.base_url + CHAT_PATH

    def __repr__(self) -> str:  # token 永不出现
        return (
            f"BackendModelGateway(job_id={self.target.job_id!r}, "
            f"attempt_id={self.target.attempt_id!r}, episode={self.target.episode}, "
            f"run_id={self.target.run_id!r})"
        )

    def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        request_spec: Mapping[str, Any] | ModelSpec | None = None,
        *,
        recorder: Any | None = None,
        run_id: str | None = None,
        attempt_id: str | None = None,
        deadline: float | None = None,
        cancellation: Any = None,
        max_response_bytes: int = 8_000_000,
    ) -> dict[str, Any]:
        """校验身份后转发一次；任何配置问题都在 HTTP 请求之前抛出。"""

        del recorder  # 调用记录的唯一权威在后端 DB；本地不再写一份
        self.target.check_call_identity(run_id, attempt_id)
        if request_spec is not None:
            from agent_eval.spec import from_evaluation_spec

            requested = from_evaluation_spec(request_spec)
            # 冻结目标由契约固定；harness 不能在这里换成别的模型/endpoint。
            if not _same_target(_endpoint_identity(requested), self.target.request_override):
                raise BackendGatewayConfigError(
                    "the harness requested a model target that differs from the "
                    "frozen target; the gateway never switches targets"
                )

        body = json.dumps(
            self.target.payload(messages, tools, stream=self.model_spec.stream),
            ensure_ascii=False,
        ).encode("utf-8")
        request = urllib.request.Request(
            self._url,
            data=body,
            headers={
                "content-type": "application/json",
                "authorization": f"Bearer {self.target.token}",
                "user-agent": USER_AGENT,
            },
            method="POST",
        )
        try:
            if deadline is None:
                with urllib.request.urlopen(request, timeout=self.target.timeout_s) as response:
                    raw = response.read()
            else:
                raw = _deadline_response(
                    request,
                    timeout=self.target.timeout_s,
                    deadline=deadline,
                    cancellation=cancellation,
                    limit=max_response_bytes,
                )
        except urllib.error.HTTPError as error:
            raw_body, payload = _read_error_body(error)
            message = _error_message(payload, raw_body, error.code)
            code = _error_code(payload, message)
            if error.code == 422:
                raise GatewayRejection(
                    code or "gateway_rejected",
                    message,
                    provider="backend_gateway",
                    details={"http_status": 422, "backend_code": code},
                ) from None
            raise BackendGatewayHTTPError(
                message,
                code=code,
                status=error.code,
                body=raw_body,
            ) from None
        except urllib.error.URLError as error:
            raise ProviderError(
                f"network error talking to the backend model gateway: {error.reason}",
                provider="backend_gateway",
                status=None,
                retryable=True,
            ) from None
        except OSError as error:
            raise ProviderError(
                f"network error talking to the backend model gateway: {error}",
                provider="backend_gateway",
                status=None,
                retryable=True,
            ) from None

        try:
            envelope = json.loads(raw or b"{}")
        except (TypeError, ValueError) as error:
            raise ProviderError(
                f"invalid JSON from the backend model gateway: {error}",
                provider="backend_gateway",
                status=None,
                retryable=False,
            ) from None
        data = envelope.get("data") if isinstance(envelope, Mapping) else None
        if not isinstance(data, Mapping):
            raise ProviderError(
                "backend model gateway response has no data envelope",
                provider="backend_gateway",
                status=None,
                retryable=False,
            )

        provider_meta = data.get("provider_meta")
        if not isinstance(provider_meta, Mapping):
            raise ProviderError(
                "backend model gateway response has no provider_meta",
                provider="backend_gateway",
                status=None,
                retryable=False,
            )
        trace_id = provider_meta.get("request_id")
        # 数据面路由在 ``data.gateway`` 返回 call_id / decision / event_hash / root；
        # service 的 ``provider_meta.gateway`` 还带 violations。合并两者，执行链
        # 里就能同时留下判定与签名事件 hash。
        merged_gateway: dict[str, Any] = {}
        meta_gateway = provider_meta.get("gateway")
        if isinstance(meta_gateway, Mapping):
            merged_gateway.update(meta_gateway)
        route_gateway = data.get("gateway")
        if isinstance(route_gateway, Mapping):
            merged_gateway.update({key: value for key, value in route_gateway.items() if value is not None})
        call_id = merged_gateway.get("call_id")
        event_hash = merged_gateway.get("event_hash")
        # 191 只认 DB 的网关链：没有 trace / call_id 的响应无法逐条对齐，
        # 不能在执行链里留一条"看起来成功"的模型调用。
        if not isinstance(trace_id, str) or not trace_id:
            raise ProviderError(
                "backend model gateway response has no provider_meta.request_id; "
                "the model call cannot be paired with model_gateway_calls",
                provider="backend_gateway",
                status=None,
                retryable=False,
            )
        if not isinstance(call_id, str) or not call_id:
            raise ProviderError(
                "backend model gateway response has no gateway.call_id",
                provider="backend_gateway",
                status=None,
                retryable=False,
            )
        if not isinstance(event_hash, str) or not event_hash:
            raise ProviderError(
                "backend model gateway response has no gateway.event_hash",
                provider="backend_gateway",
                status=None,
                retryable=False,
            )

        tool_calls = data.get("tool_calls")
        usage = data.get("usage")
        content = data.get("content")
        if not isinstance(tool_calls, list) or not isinstance(usage, Mapping) or not isinstance(content, str):
            raise ProviderError(
                "backend model gateway response is missing content/tool_calls/usage",
                provider="backend_gateway",
                status=None,
                retryable=False,
            )
        merged_meta = dict(provider_meta)
        if merged_gateway:
            merged_meta["gateway"] = dict(merged_gateway)
        return {
            "content": content,
            "tool_calls": [dict(call) for call in tool_calls if isinstance(call, Mapping)],
            "usage": dict(usage),
            "provider_meta": merged_meta,
        }


__all__ = [
    "BackendGatewayConfigError",
    "BackendGatewayHTTPError",
    "BackendGatewayTarget",
    "BackendModelGateway",
    "CHAT_PATH",
    "normalize_gateway_url",
]
