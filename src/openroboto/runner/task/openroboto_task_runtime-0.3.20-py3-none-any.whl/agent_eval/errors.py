"""模型调用层错误类型 | Provider errors.

`ProviderError` 覆盖两类失败:
  - 请求已经发出(HTTP 错误、SSE error 事件、网络错误),此时调用记录仍要落盘;
  - 配置错误(`ProviderConfigError`),请求未发出,不属于一次调用记录。
"""

import json

RETRYABLE_STATUS = {408, 409, 425, 429}


def is_retryable_status(status: int | None) -> bool:
    if status is None:
        return True
    return status in RETRYABLE_STATUS or status >= 500


class ProviderError(RuntimeError):
    """一次模型调用失败。

    `status` 为 HTTP 状态码;网络层失败时为 None。
    `request_id` 来自响应头,失败时也可追溯。
    `details` 会并入调用记录(例如已读取部分的响应 hash)。
    """

    def __init__(
        self,
        message: str,
        *,
        provider: str | None = None,
        status: int | None = None,
        request_id: str | None = None,
        retryable: bool | None = None,
        body: str | None = None,
        details: dict | None = None,
    ):
        super().__init__(message)
        self.provider = provider
        self.status = status
        self.request_id = request_id
        self.retryable = is_retryable_status(status) if retryable is None else retryable
        self.body = body
        self.details = details or {}

    def to_record(self) -> dict:
        message = str(self)
        record = {
            "type": type(self).__name__,
            "message": message[:2000],
            "status": self.status,
            "request_id": self.request_id,
            "retryable": self.retryable,
            # 错误响应体可能包含请求回显,截断后再进记录。
            "body": (self.body or "")[:2000] or None,
        }
        retry = (self.details or {}).get("retry")
        if retry:
            record["retry"] = dict(retry)
        return record


class ProviderConfigError(ProviderError):
    """provider/model/endpoint/key 配置不完整。请求没有发出。"""

    def __init__(self, message: str, *, provider: str | None = None):
        super().__init__(message, provider=provider, retryable=False)


class GatewayRejection(ProviderError):
    """网关拒绝了一次不合格的模型请求。请求没有发出。

    `code` 是稳定的拒绝码(model_mismatch / endpoint_mismatch / reasoning_mismatch /
    tool_not_allowed / budget_* ...),`details["violations"]` 带全部违规项。
    """

    def __init__(
        self,
        code: str,
        message: str,
        *,
        provider: str | None = None,
        details: dict | None = None,
    ):
        super().__init__(message, provider=provider, retryable=False, details=details)
        self.code = code

    def to_record(self) -> dict:
        record = super().to_record()
        record["type"] = "GatewayRejection"
        record["code"] = self.code
        return record


def error_event_details(event: dict) -> tuple[str, int | None]:
    """从 Anthropic / OpenAI 的 SSE error 事件里提取 message 与 status。"""

    err = event.get("error") if isinstance(event.get("error"), dict) else event
    message = err.get("message") or json.dumps(err, ensure_ascii=False)
    status = event.get("status") or err.get("status") or err.get("code")
    if not isinstance(status, int):
        status = None
    return str(message), status
