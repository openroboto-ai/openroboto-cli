"""模型网关 | Model gateway: the single exit for every model request.

网关在发出请求前校验:

  - provider / model / endpoint / api_format 与冻结的 EvaluationSpec 一致;
  - reasoning 参数(effort / effort_param / extra_body / headers / anthropic_version)一致;
  - 工具声明合法,且在 `allowed_tools` 白名单内;
  - token 预算未超(`max_calls` / `max_tokens_per_call` / `max_total_tokens`)。

合格请求原样转发:harness 传进来的 messages / tools 不做任何改写,配置用冻结的
designated spec。不合格请求直接拒绝——不降档、不换 endpoint、不 fallback——并写
一条 `status="error"` 的调用记录,记录里带拒绝码、请求 hash 和当时的预算快照。

    gateway = ModelGateway.from_evaluation_spec(spec)   # 冻结配置
    result = gateway.chat(messages, tools)              # 用冻结配置
    result = gateway.chat(messages, tools, request_spec)  # 校验通过才转发

`mode: "record"` 是测试网简化:违规只记录(warn),不拦截。默认 `enforce`。

预算账本属于网关实例,一个 run 复用一个网关实例,cross-call 预算才有效;
`agent_eval.chat()` 每次新建网关,只做单次请求的校验。
"""

import threading
import uuid
from dataclasses import dataclass, field, replace
from typing import Any, Mapping, NoReturn

from agent_eval.errors import GatewayRejection, ProviderConfigError, ProviderError
from agent_eval.providers import CallTimer, get_adapter
from agent_eval.providers.base import canonical_sha256
from agent_eval.records import CallRecorder, NullRecorder
from agent_eval.run_budget import BudgetRejected, reject_unsupported_input
from agent_eval.spec import ModelSpec, from_evaluation_spec

# send/first-byte/complete 时间已在 CallTimer 中,调用记录直接平铺这些字段。
_RECORD_TIMING_FIELDS = ("sent_at", "first_byte_at", "completed_at", "time_to_first_byte_ms", "total_ms")

# 这些字段一旦被 harness 改动,就不是"同一个模型请求"了。
_REASONING_FIELDS = ("effort", "effort_param", "extra_body", "headers")
_PARAM_FIELDS = ("max_tokens", "stream", "anthropic_version")


def adapter_endpoint(adapter: Any, spec: ModelSpec) -> str:
    """解析并校验 endpoint;在发出请求前抛配置错误。"""

    endpoint = spec.resolved_endpoint()
    if adapter.api_format == "openai":
        from agent_eval.providers.openai_compat import chat_completions_url

        return chat_completions_url(endpoint)
    return endpoint


def _resolve_endpoint(spec: ModelSpec) -> str:
    return adapter_endpoint(get_adapter(spec), spec)


def _target_identity(spec: ModelSpec, endpoint: str | None) -> dict[str, Any]:
    """可落盘的请求配置快照;headers / extra_body 只留键名,避免把密钥写进记录。"""

    try:
        api_format = spec.resolved_api_format()
    except ProviderConfigError:
        api_format = spec.api_format
    return {
        "provider": spec.provider,
        "api_format": api_format,
        "model": spec.model,
        "endpoint": endpoint,
        "effort": spec.effort,
        "effort_param": spec.effort_param,
        "max_tokens": spec.max_tokens,
        "stream": spec.stream,
        "anthropic_version": spec.anthropic_version,
        "header_names": sorted(spec.headers),
        "extra_body_keys": sorted(spec.extra_body),
    }


def _tool_names(tools: list[dict] | None) -> list[str]:
    names: list[str] = []
    for tool in tools or []:
        if isinstance(tool, Mapping) and isinstance(tool.get("name"), str):
            names.append(tool["name"])
    return names


def _violation(code: str, field: str, message: str, **extra: Any) -> dict[str, Any]:
    return {"code": code, "field": field, "message": message, **extra}


def _tool_violations(tools: Any, allowed_tools: tuple[str, ...] | None) -> list[dict[str, Any]]:
    if tools is None:
        return []
    if not isinstance(tools, (list, tuple)):
        return [_violation("invalid_tool", "tools", "tools must be a list")]

    violations: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, tool in enumerate(tools):
        if not isinstance(tool, Mapping):
            violations.append(_violation("invalid_tool", f"tools[{index}]", "tool declaration must be an object"))
            continue
        name = tool.get("name")
        if not isinstance(name, str) or not name.strip():
            violations.append(
                _violation("invalid_tool", f"tools[{index}].name", "tool declaration needs a non-empty name")
            )
            continue
        if name in seen:
            violations.append(_violation("invalid_tool", f"tools[{index}].name", f"duplicate tool {name!r}"))
        seen.add(name)
        schema = tool.get("input_schema", tool.get("parameters"))
        if not isinstance(schema, Mapping) or schema.get("type") != "object":
            violations.append(
                _violation(
                    "invalid_tool",
                    f"tools[{index}].input_schema",
                    f"tool {name!r} needs an input_schema of type 'object'",
                )
            )
        if allowed_tools is not None and name not in allowed_tools:
            violations.append(
                _violation(
                    "tool_not_allowed",
                    f"tools[{index}].name",
                    f"tool {name!r} is not in the gateway allowlist",
                    tool=name,
                )
            )
    return violations


def _spec_violations(
    designated: ModelSpec,
    designated_endpoint: str,
    requested: ModelSpec,
    requested_endpoint: str | None,
) -> list[dict[str, Any]]:
    violations: list[dict[str, Any]] = []

    if requested.provider != designated.provider:
        violations.append(
            _violation(
                "provider_mismatch",
                "provider",
                f"requested provider {requested.provider!r} != designated {designated.provider!r}",
                designated=designated.provider,
                requested=requested.provider,
            )
        )
    if requested.model != designated.model:
        violations.append(
            _violation(
                "model_mismatch",
                "model",
                f"requested model {requested.model!r} != designated {designated.model!r}",
                designated=designated.model,
                requested=requested.model,
            )
        )
    if requested_endpoint != designated_endpoint:
        violations.append(
            _violation(
                "endpoint_mismatch",
                "endpoint",
                "requested endpoint differs from the designated endpoint; the gateway never switches endpoints",
                designated=designated_endpoint,
                requested=requested_endpoint,
            )
        )

    try:
        requested_format = requested.resolved_api_format()
    except ProviderConfigError as error:
        requested_format = None
        violations.append(_violation("invalid_api_format", "api_format", str(error)))
    if requested_format is not None and requested_format != designated.resolved_api_format():
        violations.append(
            _violation(
                "api_format_mismatch",
                "api_format",
                f"requested api_format {requested_format!r} != designated {designated.resolved_api_format()!r}",
            )
        )

    for name in _REASONING_FIELDS:
        if getattr(requested, name) != getattr(designated, name):
            violations.append(
                _violation(
                    "reasoning_mismatch",
                    name,
                    f"reasoning-related field {name!r} differs from the designated spec",
                )
            )
    for name in _PARAM_FIELDS:
        if getattr(requested, name) != getattr(designated, name):
            violations.append(
                _violation(
                    "param_mismatch",
                    name,
                    f"request field {name!r} differs from the designated spec",
                )
            )
    return violations


@dataclass(frozen=True)
class Budget:
    """一次 run 的 token / 调用次数上限。None 表示不限。"""

    max_total_tokens: int | None = None
    max_calls: int | None = None
    max_tokens_per_call: int | None = None


@dataclass(frozen=True)
class GatewayPolicy:
    """网关策略。endpoint / model / reasoning 由冻结 spec 决定,policy 只能收紧。"""

    mode: str = "enforce"  # enforce | record
    allowed_tools: tuple[str, ...] | None = None
    budget: Budget = field(default_factory=Budget)

    @classmethod
    def from_config(
        cls,
        config: Mapping[str, Any] | None,
        *,
        max_api_calls: int | None = None,
    ) -> "GatewayPolicy":
        """`max_api_calls` 来自冻结 EvaluationSpec 的 `budget` 块。"""

        if config is None:
            config = {}
        if not isinstance(config, Mapping):
            raise ProviderConfigError("model gateway config must be an object")

        unknown = set(config) - {"mode", "allowed_tools", "budget"}
        if unknown:
            raise ProviderConfigError(f"unknown model gateway options: {', '.join(sorted(unknown))}")

        mode = config.get("mode", "enforce")
        if mode not in ("enforce", "record"):
            raise ProviderConfigError(f"model gateway mode must be 'enforce' or 'record', got {mode!r}")

        allowed_tools = config.get("allowed_tools")
        if allowed_tools is not None:
            if not isinstance(allowed_tools, (list, tuple)) or not all(
                isinstance(name, str) and name.strip() for name in allowed_tools
            ):
                raise ProviderConfigError("model gateway allowed_tools must be a list of non-empty strings")
            allowed_tools = tuple(sorted(set(allowed_tools)))

        budget = _budget_from_config(config.get("budget"))
        if max_api_calls is not None:
            # 冻结 spec 的调用上限是硬上限;本地 gateway 块只能收紧,不能放宽。
            max_calls = max_api_calls if budget.max_calls is None else min(budget.max_calls, max_api_calls)
            budget = replace(budget, max_calls=max_calls)
        return cls(mode=mode, allowed_tools=allowed_tools, budget=budget)


def _max_api_calls_from_spec(evaluation_spec: Mapping[str, Any]) -> int | None:
    """冻结 EvaluationSpec 的 `budget.max_api_calls`;没有该块时返回 None。"""

    budget = evaluation_spec.get("budget")
    if budget is None:
        return None
    if not isinstance(budget, Mapping):
        raise ProviderConfigError("evaluation spec budget must be an object")
    value = budget.get("max_api_calls")
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ProviderConfigError("evaluation spec budget.max_api_calls must be a non-negative integer")
    return value


def _budget_from_config(config: Any) -> Budget:
    if config is None:
        return Budget()
    if not isinstance(config, Mapping):
        raise ProviderConfigError("model gateway budget must be an object")
    unknown = set(config) - {"max_total_tokens", "max_calls", "max_tokens_per_call"}
    if unknown:
        raise ProviderConfigError(f"unknown model gateway budget options: {', '.join(sorted(unknown))}")
    values: dict[str, int | None] = {}
    for name in ("max_total_tokens", "max_calls", "max_tokens_per_call"):
        value = config.get(name)
        if value is None:
            values[name] = None
            continue
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ProviderConfigError(f"model gateway budget.{name} must be a non-negative integer")
        values[name] = value
    return Budget(**values)


class BudgetLedger:
    """网关实例内的预算账本;跨请求累计 calls 与 tokens。"""

    def __init__(self, budget: Budget):
        self._budget = budget
        self._lock = threading.Lock()
        self._calls = 0
        self._tokens = 0

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "max_total_tokens": self._budget.max_total_tokens,
                "max_calls": self._budget.max_calls,
                "max_tokens_per_call": self._budget.max_tokens_per_call,
                "calls": self._calls,
                "tokens_used": self._tokens,
            }

    def violations(self, spec: ModelSpec) -> list[dict[str, Any]]:
        with self._lock:
            calls = self._calls
            tokens = self._tokens
        budget = self._budget
        violations: list[dict[str, Any]] = []
        if budget.max_calls is not None and calls >= budget.max_calls:
            violations.append(
                _violation(
                    "budget_calls_exceeded",
                    "budget.max_calls",
                    f"call budget exhausted: {calls} call(s) already made, limit {budget.max_calls}",
                    limit=budget.max_calls,
                    used=calls,
                )
            )
        if budget.max_tokens_per_call is not None and spec.max_tokens > budget.max_tokens_per_call:
            violations.append(
                _violation(
                    "budget_tokens_per_call_exceeded",
                    "budget.max_tokens_per_call",
                    f"requested max_tokens {spec.max_tokens} exceeds per-call budget {budget.max_tokens_per_call}",
                    limit=budget.max_tokens_per_call,
                    requested=spec.max_tokens,
                )
            )
        if budget.max_total_tokens is not None and tokens + spec.max_tokens > budget.max_total_tokens:
            # 发出前按本次请求的 max_tokens 预留,确保不会发出一个可能超预算的请求。
            violations.append(
                _violation(
                    "budget_total_exceeded",
                    "budget.max_total_tokens",
                    f"token budget would be exceeded: {tokens} used + {spec.max_tokens} requested "
                    f"> {budget.max_total_tokens}",
                    limit=budget.max_total_tokens,
                    used=tokens,
                    requested=spec.max_tokens,
                )
            )
        return violations

    def commit(self, usage: Mapping[str, Any] | None) -> None:
        """一次已发出的请求占用预算;上游失败时 usage 为空,只记调用次数。"""

        usage = usage or {}
        tokens = usage.get("total_tokens")
        if not isinstance(tokens, int):
            input_tokens = usage.get("input_tokens")
            output_tokens = usage.get("output_tokens")
            tokens = (input_tokens if isinstance(input_tokens, int) else 0) + (
                output_tokens if isinstance(output_tokens, int) else 0
            )
        with self._lock:
            self._calls += 1
            self._tokens += max(int(tokens), 0)


def _base_record(
    *,
    spec: ModelSpec,
    api_format: str,
    endpoint: str,
    call_id: str,
    run_id: str | None,
    attempt_id: str | None,
    messages_hash: str,
    tools_hash: str,
    tool_names: list[str],
    timer: CallTimer,
) -> dict[str, Any]:
    record: dict[str, Any] = {
        "call_id": call_id,
        "run_id": run_id,
        "attempt_id": attempt_id,
        "provider": spec.provider,
        "api_format": api_format,
        "model": spec.model,
        "endpoint": endpoint,
        "effort": spec.effort,
        "max_tokens": spec.max_tokens,
        "tool_names": tool_names,
        "request_id": None,
        "response_id": None,
        "response_model": None,
        "trace_id": None,
        "trace_id_source": None,
        "stop_reason": None,
        "usage": {},
        "raw_response_sha256": None,
        "raw_response_bytes": 0,
        "messages_sha256": messages_hash,
        "tools_sha256": tools_hash,
        "status": "ok",
    }
    record.update(timer.timings())
    return record


def _provider_meta(record: dict[str, Any], provider_extra: dict[str, Any] | None) -> dict[str, Any]:
    meta = {
        "provider": record["provider"],
        "api_format": record["api_format"],
        "model": record["model"],
        "response_model": record["response_model"],
        "endpoint": record["endpoint"],
        "effort": record["effort"],
        "call_id": record["call_id"],
        "run_id": record["run_id"],
        "attempt_id": record["attempt_id"],
        "request_id": record["request_id"],
        "response_id": record["response_id"],
        "trace_id": record["trace_id"],
        "trace_id_source": record["trace_id_source"],
        "stop_reason": record["stop_reason"],
        "timings": {field: record[field] for field in _RECORD_TIMING_FIELDS},
        "raw_response_sha256": record["raw_response_sha256"],
        "raw_response_bytes": record["raw_response_bytes"],
    }
    if provider_extra:
        meta["provider_extra"] = provider_extra
    return meta


class ModelGateway:
    """allow-or-reject 网关:一个实例代表一次 run 的冻结配置与预算。"""

    def __init__(
        self,
        designated: ModelSpec,
        policy: GatewayPolicy | None = None,
        *,
        recorder: Any | None = None,
        run_budget: Any | None = None,
    ):
        self.designated = designated
        self.policy = policy or GatewayPolicy()
        #: 一个 run 共用的持久预算账；None = 这次没有 run 级费用门禁。
        #: 单次 ``agent_eval.chat()`` 没有它，只做单请求校验。
        self.run_budget = run_budget
        self.adapter = get_adapter(designated)
        self.designated_endpoint = adapter_endpoint(self.adapter, designated)
        self.ledger = BudgetLedger(self.policy.budget)
        if recorder is not None:
            self.recorder = recorder
        elif designated.record_path:
            self.recorder = CallRecorder(designated.record_path)
        else:
            self.recorder = NullRecorder()

    @classmethod
    def from_evaluation_spec(
        cls,
        evaluation_spec: Mapping[str, Any] | ModelSpec,
        *,
        recorder: Any | None = None,
        run_budget: Any | None = None,
    ) -> "ModelGateway":
        if isinstance(evaluation_spec, Mapping):
            config = evaluation_spec.get("gateway")
            max_api_calls = _max_api_calls_from_spec(evaluation_spec)
        else:
            config = None
            max_api_calls = None
        policy = GatewayPolicy.from_config(config, max_api_calls=max_api_calls)
        return cls(from_evaluation_spec(evaluation_spec), policy, recorder=recorder, run_budget=run_budget)

    def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        request_spec: Mapping[str, Any] | ModelSpec | None = None,
        *,
        recorder: Any | None = None,
        run_id: str | None = None,
        attempt_id: str | None = None,
    ) -> dict[str, Any]:
        """校验一次请求,合格则原样转发;不合格写拒绝记录并抛 GatewayRejection。"""

        call_id = uuid.uuid4().hex
        timer = CallTimer()
        messages_hash = canonical_sha256(messages)
        tools_hash = canonical_sha256(tools or [])
        tool_names = _tool_names(tools)
        writer = recorder or self.recorder

        requested = self.designated
        violations: list[dict[str, Any]] = []
        requested_endpoint: str | None = self.designated_endpoint
        if request_spec is not None:
            try:
                requested = from_evaluation_spec(request_spec)
                requested_endpoint = _resolve_endpoint(requested)
            except ProviderConfigError as error:
                violations.append(_violation("invalid_request", "request", str(error)))

        if not violations:
            violations = _spec_violations(
                self.designated,
                self.designated_endpoint,
                requested,
                requested_endpoint,
            )
            violations.extend(_tool_violations(tools, self.policy.allowed_tools))
            # record 模式下实际转发的是冻结配置,预算也按它预留。
            violations.extend(self.ledger.violations(self.designated))

        if violations and self.policy.mode == "enforce":
            return self._reject(
                violations=violations,
                call_id=call_id,
                timer=timer,
                messages_hash=messages_hash,
                tools_hash=tools_hash,
                tool_names=tool_names,
                requested=requested,
                requested_endpoint=requested_endpoint,
                run_id=run_id,
                attempt_id=attempt_id,
                writer=writer,
            )

        if self.run_budget is not None:
            try:
                reject_unsupported_input(
                    messages,
                    provider=self.designated.provider,
                    model=self.designated.model,
                    api_format=self.designated.resolved_api_format(),
                )
            except BudgetRejected as error:
                self._reject(
                    violations=[error.as_violation()],
                    call_id=call_id,
                    timer=timer,
                    messages_hash=messages_hash,
                    tools_hash=tools_hash,
                    tool_names=tool_names,
                    requested=requested,
                    requested_endpoint=requested_endpoint,
                    run_id=run_id,
                    attempt_id=attempt_id,
                    writer=writer,
                )

        # 配置错误(缺 key 等)在请求发出前抛出,不算一次调用记录。
        self.designated.require_api_key()
        budget_before = self.ledger.snapshot()
        try:
            response = self.adapter.chat(messages, tools or [], self.designated, timer, budget=self.run_budget)
        except BudgetRejected as error:
            # 发送前就被 run 预算拒绝：记一条 reject 记录，请求没有发出。
            self._reject(
                violations=[error.as_violation()],
                call_id=call_id,
                timer=timer,
                messages_hash=messages_hash,
                tools_hash=tools_hash,
                tool_names=tool_names,
                requested=requested,
                requested_endpoint=requested_endpoint,
                run_id=run_id,
                attempt_id=attempt_id,
                writer=writer,
            )
        except ProviderConfigError:
            raise
        except ProviderError as error:
            timer.mark_complete()
            self.ledger.commit(None)
            record = _base_record(
                spec=self.designated,
                api_format=self.adapter.api_format,
                endpoint=self.designated_endpoint,
                call_id=call_id,
                run_id=run_id,
                attempt_id=attempt_id,
                messages_hash=messages_hash,
                tools_hash=tools_hash,
                tool_names=tool_names,
                timer=timer,
            )
            record["status"] = "error"
            record["request_id"] = error.request_id or error.details.get("request_id")
            record["raw_response_sha256"] = error.details.get("raw_response_sha256")
            record["raw_response_bytes"] = error.details.get("raw_response_bytes") or 0
            record["trace_id"] = record["request_id"] or call_id
            record["trace_id_source"] = "header" if error.request_id else "call_id"
            record["error"] = error.to_record()
            record["gateway"] = self._gateway_record(
                "warn" if violations else "allow",
                requested,
                requested_endpoint,
                violations,
                budget_before=budget_before,
                budget_after=self.ledger.snapshot(),
            )
            writer.write(record)
            raise
        finally:
            timer.mark_complete()

        record = _base_record(
            spec=self.designated,
            api_format=self.adapter.api_format,
            endpoint=self.designated_endpoint,
            call_id=call_id,
            run_id=run_id,
            attempt_id=attempt_id,
            messages_hash=messages_hash,
            tools_hash=tools_hash,
            tool_names=tool_names,
            timer=timer,
        )
        record.update({
            "request_id": response.request_id or response.response_id,
            "response_id": response.response_id,
            "response_model": response.response_model,
            "stop_reason": response.stop_reason,
            "usage": response.usage,
            "raw_response_sha256": response.raw_response_sha256,
            "raw_response_bytes": response.raw_response_bytes,
        })
        # DeepSeek 原生接口没有 request-id 响应头:统一回落到响应体 id,再不行用 call_id。
        if response.request_id:
            record["trace_id"], record["trace_id_source"] = response.request_id, "header"
        elif response.response_id:
            record["trace_id"], record["trace_id_source"] = response.response_id, "response_id"
        else:
            record["trace_id"], record["trace_id_source"] = call_id, "call_id"
        if response.provider_extra:
            record["provider_extra"] = response.provider_extra

        self.ledger.commit(response.usage)
        record["gateway"] = self._gateway_record(
            "warn" if violations else "allow",
            requested,
            requested_endpoint,
            violations,
            budget_before=budget_before,
            budget_after=self.ledger.snapshot(),
        )
        writer.write(record)

        meta = _provider_meta(record, response.provider_extra)
        meta["gateway"] = {
            "decision": record["gateway"]["decision"],
            "violations": violations,
        }
        return {
            "content": response.content,
            "tool_calls": response.tool_calls,
            "usage": response.usage,
            "provider_meta": meta,
            **({"reasoning_content": response.reasoning_content} if response.reasoning_content is not None else {}),
        }

    def _gateway_record(
        self,
        decision: str,
        requested: ModelSpec,
        requested_endpoint: str | None,
        violations: list[dict[str, Any]],
        *,
        budget_before: dict[str, Any],
        budget_after: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        budget = {"before": budget_before}
        if budget_after is not None:
            budget["after"] = budget_after
        return {
            "decision": decision,
            "mode": self.policy.mode,
            "designated": _target_identity(self.designated, self.designated_endpoint),
            "requested": _target_identity(requested, requested_endpoint),
            "violations": violations,
            "budget": budget,
        }

    def _reject(
        self,
        *,
        violations: list[dict[str, Any]],
        call_id: str,
        timer: CallTimer,
        messages_hash: str,
        tools_hash: str,
        tool_names: list[str],
        requested: ModelSpec,
        requested_endpoint: str | None,
        run_id: str | None,
        attempt_id: str | None,
        writer: Any,
    ) -> NoReturn:
        timer.mark_rejected()
        rejection = GatewayRejection(
            violations[0]["code"],
            "; ".join(violation["message"] for violation in violations),
            details={"violations": violations},
        )
        record = _base_record(
            spec=self.designated,
            api_format=self.adapter.api_format,
            endpoint=self.designated_endpoint,
            call_id=call_id,
            run_id=run_id,
            attempt_id=attempt_id,
            messages_hash=messages_hash,
            tools_hash=tools_hash,
            tool_names=tool_names,
            timer=timer,
        )
        record["status"] = "error"
        record["trace_id"] = call_id
        record["trace_id_source"] = "call_id"
        record["error"] = rejection.to_record()
        record["gateway"] = self._gateway_record(
            "reject",
            requested,
            requested_endpoint,
            violations,
            budget_before=self.ledger.snapshot(),
        )
        writer.write(record)
        raise rejection


def chat(
    messages: list[dict],
    tools: list[dict] | None,
    spec: ModelSpec | Mapping[str, Any],
    *,
    recorder: Any | None = None,
    run_id: str | None = None,
    attempt_id: str | None = None,
) -> dict[str, Any]:
    """便利入口:按 spec 建网关并转发一次(单次请求的校验)。

    需要 cross-call 预算时,复用同一个 `ModelGateway` 实例。
    """

    gateway = ModelGateway.from_evaluation_spec(spec, recorder=recorder)
    return gateway.chat(messages, tools, run_id=run_id, attempt_id=attempt_id)


__all__ = [
    "Budget",
    "BudgetLedger",
    "GatewayPolicy",
    "ModelGateway",
    "adapter_endpoint",
    "chat",
]
