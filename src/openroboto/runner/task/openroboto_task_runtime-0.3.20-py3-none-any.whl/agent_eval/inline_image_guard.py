"""Bounded inline PNG/JPEG for the authorized image-enabled subscription run.

No URL fetching, credentials, model calls, or ledger writes occur in validation.
"""

from __future__ import annotations
import base64
import binascii
import io
import json
import warnings
from collections.abc import Mapping

MAX_IMAGE_BYTES = 4 * 1024 * 1024
MAX_IMAGE_DIMENSION = 4096
MAX_IMAGE_PIXELS = 8 * 1024 * 1024
MAX_REQUEST_IMAGES = 64
MAX_REQUEST_IMAGE_BYTES = 32 * 1024 * 1024
MAX_REQUEST_JSON_BYTES = 48 * 1024 * 1024
MEDIA_LIMITS = {key: value for key, value in globals().copy().items() if key.startswith("MAX_")}


def validate_payload_size(payload, reject):
    try:
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError):
        reject("input_unsupported", "request must be finite JSON")
    if len(encoded) > MAX_REQUEST_JSON_BYTES:
        reject("image_bound", "request exceeds the frozen JSON byte limit")


def validate_content(content, *, role, totals, reject):
    if content is None or isinstance(content, str):
        return
    if not isinstance(content, list):
        reject("input_unsupported", "only text and bounded inline image blocks are allowed")
    for block in content:
        if not isinstance(block, Mapping):
            reject("input_unsupported", "content block must be an object")
        if block.get("type") == "text":
            if set(block) - {"type", "text"} or not isinstance(block.get("text"), str):
                reject("input_unsupported", "unsupported text block")
            continue
        if block.get("type") != "image_url" or set(block) != {"type", "image_url"} or role != "user":
            reject("input_unsupported", "only user inline PNG/JPEG blocks are allowed; audio/file/video is forbidden")
        image = block["image_url"]
        if not isinstance(image, Mapping) or set(image) - {"url", "detail"} or "url" not in image:
            reject("input_unsupported", "image_url has unsupported fields")
        if "detail" in image and image["detail"] not in ("auto", "low", "high"):
            reject("input_unsupported", "unsupported image detail")
        url = image["url"]
        prefixes = {"data:image/png;base64,": "PNG", "data:image/jpeg;base64,": "JPEG"}
        prefix = next((item for item in prefixes if isinstance(url, str) and url.startswith(item)), None)
        if prefix is None:
            reject("image_source", "remote URLs and non-PNG/JPEG media are forbidden")
        encoded = url[len(prefix) :]
        if not encoded or len(encoded) > 4 * ((MAX_IMAGE_BYTES + 2) // 3):
            reject("image_bound", "inline image exceeds the frozen per-image byte limit")
        try:
            data = base64.b64decode(encoded, validate=True)
        except (ValueError, binascii.Error):
            reject("image_encoding", "inline image is not canonical base64")
        if not data or len(data) > MAX_IMAGE_BYTES or base64.b64encode(data).decode("ascii") != encoded:
            reject("image_encoding", "inline image is empty, oversized, or non-canonical base64")
        totals["images"] += 1
        totals["bytes"] += len(data)
        if totals["images"] > MAX_REQUEST_IMAGES or totals["bytes"] > MAX_REQUEST_IMAGE_BYTES:
            reject("image_bound", "request exceeds frozen image count or byte limits")
        try:
            from PIL import Image

            with warnings.catch_warnings():
                warnings.simplefilter("error", Image.DecompressionBombWarning)
                with Image.open(io.BytesIO(data)) as decoded:
                    width, height = decoded.size
                    if decoded.format != prefixes[prefix] or getattr(decoded, "is_animated", False):
                        raise ValueError("media format mismatch or animated input")
                    if (
                        min(width, height) < 1
                        or max(width, height) > MAX_IMAGE_DIMENSION
                        or width * height > MAX_IMAGE_PIXELS
                    ):
                        raise ValueError("image dimensions exceed the frozen limit")
                    decoded.verify()
                with Image.open(io.BytesIO(data)) as decoded:
                    decoded.load()
        except Exception:
            reject("image_decode", "inline bytes are not a bounded decodable PNG/JPEG")
