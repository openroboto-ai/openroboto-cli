"""Opt-in absolute call scope for the owned scene A gateway.

Legacy gateways have no active scope. A scope never extends the episode clock;
it gates retries, reservations, locks, metadata and bounded response reads. A
blocked native/DNS call is not claimed cancellable: it leaves the scope dirty,
prevents a successful episode, and belongs to the external parent watchdog.
"""

from __future__ import annotations

import contextlib
import contextvars
import threading

from agent_eval.errors import ProviderError

_CURRENT = contextvars.ContextVar("scene_a_call_scope", default=None)


def current_scope():
    return _CURRENT.get()


def check_scope():
    scope = current_scope()
    if scope is not None:
        scope.check()
    return scope


class CallScope:
    def __init__(self, clock, *, max_bytes, lease_check, max_request_bytes=None):
        self.clock, self.max_bytes, self.lease_check = clock, max_bytes, lease_check
        self.bytes = 0
        self.pending = set()
        self.lock = threading.Lock()
        self.max_request_bytes = max_request_bytes

    def validate_request(self, body):
        self.check()
        if self.max_request_bytes is not None and len(body) > self.max_request_bytes:
            raise ProviderError(
                "scene gateway request limit", retryable=False, details={"code": "episode_gateway_input_limit"}
            )

    def check(self):
        self.clock.remaining()
        self.lease_check()
        return self.clock.remaining()

    def charge(self, count):
        self.bytes += count
        if self.bytes > self.max_bytes:
            raise ProviderError(
                "scene gateway response limit", retryable=False, details={"code": "episode_gateway_output_limit"}
            )

    def wait(self, duration):
        # Also used by lock/retry loops; cancellation and lease checked every 20ms.
        end = self.clock.now() + duration
        while self.clock.now() < end:
            self.clock.cancelled.wait(min(0.02, self.check(), end - self.clock.now()))
        self.check()

    def io(self, operation, *, late_close=None):
        """Bound the caller's wait, never permit a late value to be consumed.

        Underlying operations also receive a timeout <= remaining. The external
        process watchdog covers uninterruptible syscalls and any residual thread.
        """
        self.check()
        done, abandoned = threading.Event(), threading.Event()
        values = []
        context = contextvars.copy_context()

        def operation_in_scope():
            self.check()  # the I/O thread may have been scheduled after expiry
            return operation()

        def execute():
            try:
                value = context.run(operation_in_scope)
                values.append((True, value))
                if abandoned.is_set() and late_close:
                    late_close(value)
            except BaseException as exc:
                values.append((False, exc))
            finally:
                with self.lock:
                    self.pending.discard(threading.current_thread())
                done.set()

        thread = threading.Thread(target=execute, name="scene-a-io", daemon=True)
        with self.lock:
            self.pending.add(thread)
        thread.start()
        try:
            while not done.wait(min(0.02, self.check())):
                pass
            self.check()
            ok, value = values[0]
            if not ok:
                raise value
            return value
        except BaseException:
            abandoned.set()
            if done.is_set() and values and values[0][0] and late_close:
                late_close(values[0][1])
            raise

    def assert_drained(self):
        with self.lock:
            if self.pending:
                raise ProviderError(
                    "scene gateway transport has not stopped",
                    retryable=False,
                    details={"code": "episode_gateway_not_drained"},
                )

    @contextlib.contextmanager
    def activate(self):
        self.check()
        token = _CURRENT.set(self)
        try:
            yield self
        finally:
            _CURRENT.reset(token)
