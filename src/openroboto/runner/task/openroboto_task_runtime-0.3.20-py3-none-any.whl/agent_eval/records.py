"""调用记录 | Call records.

每次 `chat()` 生成一条 JSON 对象,包含 provider/model、send/first-byte/complete
时间、tokens、request_id、原始响应 hash。默认写成 JSONL,一行一次调用,供证据链
(OPE-126)按 call_id 追溯。
"""

import json
import pathlib
import threading
from typing import Any


class CallRecorder:
    """线程安全地把调用记录追加到 JSONL 文件。"""

    def __init__(self, path: str | pathlib.Path):
        self.path = pathlib.Path(path)
        self._lock = threading.Lock()

    def write(self, record: dict[str, Any]) -> None:
        line = json.dumps(record, ensure_ascii=False, separators=(",", ":"), default=str)
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")
                handle.flush()


class NullRecorder:
    """不落盘。provider_meta 仍然带有 request_id / usage / timings。"""

    def write(self, record: dict[str, Any]) -> None:  # noqa: ARG002
        return None
