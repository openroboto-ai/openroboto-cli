"""provider 注册表:只按 EvaluationSpec 里的 api_format 选择适配器。"""

from agent_eval.providers.anthropic import AnthropicAdapter
from agent_eval.providers.base import CallTimer, ProviderAdapter, ProviderResponse
from agent_eval.providers.openai_compat import OpenAICompatibleAdapter

ADAPTERS: dict[str, type[ProviderAdapter]] = {
    "anthropic": AnthropicAdapter,
    "openai": OpenAICompatibleAdapter,
}


def get_adapter(spec) -> ProviderAdapter:
    return ADAPTERS[spec.resolved_api_format()]()


__all__ = ["ADAPTERS", "CallTimer", "ProviderAdapter", "ProviderResponse", "get_adapter"]
