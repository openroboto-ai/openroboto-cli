"""provider 适配器共用部分:计时、原始响应 hash、HTTP 收发。"""

import hashlib
import json
import random
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from agent_eval.errors import ProviderError
from agent_eval.call_scope import check_scope

USER_AGENT = "validator-agent-eval/0.1"

REQUEST_ID_HEADERS = ("request-id", "x-request-id", "x-ds-request-id", "x-trace-id")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode()).hexdigest()


class CallTimer:
    """记录 send / first-byte / complete 三个时刻。"""

    def __init__(self):
        self._sent_wall: str | None = None
        self._sent_mono: float | None = None
        self._first_wall: str | None = None
        self._first_mono: float | None = None
        self._done_wall: str | None = None
        self._done_mono: float | None = None

    def mark_sent(self) -> None:
        if self._sent_mono is None:
            self._sent_wall = utc_now_iso()
            self._sent_mono = time.monotonic()

    def mark_first_byte(self) -> None:
        if self._first_mono is None:
            self.mark_sent()
            self._first_wall = utc_now_iso()
            self._first_mono = time.monotonic()

    def mark_complete(self) -> None:
        if self._done_mono is None:
            self.mark_sent()
            self._done_wall = utc_now_iso()
            self._done_mono = time.monotonic()

    def mark_rejected(self) -> None:
        """被网关拒绝:只有完成时刻,没有发送时刻。"""

        if self._done_mono is None:
            self._done_wall = utc_now_iso()
            self._done_mono = time.monotonic()

    def timings(self) -> dict[str, Any]:
        first = self._first_mono if self._first_mono is not None else self._sent_mono
        done = self._done_mono if self._done_mono is not None else self._sent_mono
        return {
            "sent_at": self._sent_wall,
            "first_byte_at": self._first_wall,
            "completed_at": self._done_wall or self._sent_wall,
            "time_to_first_byte_ms": _ms(first, self._sent_mono),
            "total_ms": _ms(done, self._sent_mono),
        }


def _ms(end: float | None, start: float | None) -> float | None:
    if end is None or start is None:
        return None
    return round((end - start) * 1000.0, 3)


class ResponseReader:
    """包装 HTTP 响应:第一次读到数据时记 first-byte,同时累积原始响应 hash。"""

    def __init__(self, response: Any, timer: CallTimer):
        self._response = response
        self._timer = timer
        self._hasher = hashlib.sha256()
        self.raw_bytes = 0

    def _record(self, data: bytes | None) -> bytes:
        scope = check_scope()
        if data:
            if scope is not None:
                scope.charge(len(data))
            self._timer.mark_first_byte()
            self._hasher.update(data)
            self.raw_bytes += len(data)
        return data or b""

    def read(self, size: int = -1) -> bytes:
        scope = check_scope()
        if scope is not None:
            chunks, remaining = [], size
            while remaining != 0:
                count = min(65536, scope.max_bytes - scope.bytes + 1,
                            remaining if remaining >= 0 else 65536)
                chunk = self._record(scope.io(lambda: self._response.read(count)))
                if not chunk:
                    break
                chunks.append(chunk)
                if remaining >= 0:
                    remaining -= len(chunk)
            return b"".join(chunks)
        # 非流式响应也先读 1 字节,让 first-byte 时间是真实的首包时间。
        if size == -1 and self.raw_bytes == 0:
            first = self._record(self._response.read(1))
            rest = self._record(self._response.read())
            return first + rest
        return self._record(self._response.read(size))

    def readline(self) -> bytes:
        scope = check_scope()
        if scope is not None:
            return self._record(scope.io(lambda: self._response.readline(scope.max_bytes - scope.bytes + 1)))
        return self._record(self._response.readline())

    def __iter__(self):
        if check_scope() is not None:
            while line := self.readline():
                yield line
            return
        for line in self._response:
            yield self._record(line)

    def digest(self) -> tuple[str, int]:
        return self._hasher.hexdigest(), self.raw_bytes


@dataclass(frozen=True)
class RetryPolicy:
    """一次模型调用的有界重试。

    只重试 ``ProviderError.retryable`` 为真的错误——连接失败、超时、
    ``UNEXPECTED_EOF_WHILE_READING``、5xx、429；400/401/403 等直接失败。
    每次调用最多 ``max_attempts`` 次尝试，指数退避带抖动；总等待（含已发出的
    请求耗时）超过 ``max_total_wait_s`` 就按失败处理。
    """

    max_attempts: int = 3
    base_delay_s: float = 0.5
    max_total_wait_s: float = 60.0
    jitter_ratio: float = 0.25


DEFAULT_RETRY_POLICY = RetryPolicy()


def guarded_attempt(budget, payload, spec, api_format: str, operation):
    """在真正发请求前预留，响应后结算；每次重试 attempt 都各占一份预算。

    预留失败（额度不足 / 未知价格 / 无法证明上界）在 ``operation`` 之前抛出，
    所以请求不会发出。``operation`` 失败时 usage 未知，预留额度保留不退款。
    """

    scope = check_scope()
    if scope is not None:
        scope.validate_request(json.dumps(payload, ensure_ascii=False).encode())
    if budget is None:
        return operation()
    reservation = budget.reserve_wire(
        payload,
        provider=spec.provider,
        model=spec.model,
        output_token_cap=spec.max_tokens,
        api_format=api_format,
        party="a",
    )
    try:
        check_scope()
        result = operation()
    except BaseException:
        budget.settle(reservation, None)
        raise
    budget.settle(reservation, getattr(result, "usage", None))
    return result


def call_with_retries(
    operation,
    *,
    provider: str,
    policy: RetryPolicy = DEFAULT_RETRY_POLICY,
    sleep=time.sleep,
    rand=random.random,
):
    """执行一次逻辑模型调用，按策略重试可回退错误。

    ``operation`` 必须自己完成「发请求 + 读响应」；重试只是同一份
    messages/tools 再发一次，不改变 agent 的决策序列。

    返回 ``(result, stats)``；``stats`` 会挂到成功响应的
    ``provider_extra["retry"]`` 和失败时的 ``error.details["retry"]``，
    这样成本账能区分「逻辑调用数」和「实际尝试数」。
    """

    started = time.monotonic()
    attempts = 0
    retries = 0
    failed_attempts = 0
    waited = 0.0
    errors: list[str] = []

    while True:
        scope = check_scope()
        attempts += 1
        try:
            result = operation()
        except ProviderError as error:
            failed_attempts += 1
            errors.append(str(error)[:300])
            delay = policy.base_delay_s * (2 ** (attempts - 1))
            delay *= 1.0 + (rand() * 2.0 - 1.0) * policy.jitter_ratio
            delay = max(0.0, delay)
            elapsed = time.monotonic() - started
            stats = {
                "attempts": attempts,
                "retries": retries,
                "failed_attempts": failed_attempts,
                "waited_s": round(waited, 3),
                "errors": errors[-3:],
            }
            if not error.retryable or attempts >= policy.max_attempts or elapsed + delay > policy.max_total_wait_s:
                error.details.setdefault("retry", stats)
                raise
            if scope is None:
                sleep(delay)
            else:
                scope.wait(delay)
            waited += delay
            retries += 1
        else:
            stats = {
                "attempts": attempts,
                "retries": retries,
                "failed_attempts": failed_attempts,
                "waited_s": round(waited, 3),
            }
            if errors:
                stats["errors"] = errors[-3:]
            return result, stats


def header_value(headers: Any, name: str) -> str | None:
    try:
        value = headers.get(name)
    except AttributeError:
        return None
    return str(value) if value else None


def request_id_from_headers(headers: Any) -> str | None:
    for name in REQUEST_ID_HEADERS:
        value = header_value(headers, name)
        if value:
            return value
    return None


def _error_body(reader: ResponseReader) -> str:
    body = reader.read()
    return body.decode("utf-8", "replace")


def _http_error(error: urllib.error.HTTPError, timer: CallTimer, provider: str) -> ProviderError:
    reader = ResponseReader(error, timer)
    body = _error_body(reader)
    digest, raw_bytes = reader.digest()
    request_id = request_id_from_headers(error.headers)
    return ProviderError(
        f"HTTP {error.code} from {provider}: {body[:300] or error.reason}",
        provider=provider,
        status=error.code,
        request_id=request_id,
        body=body,
        details={"raw_response_sha256": digest, "raw_response_bytes": raw_bytes},
    )


def open_request(
    url: str,
    headers: dict[str, str],
    payload: dict[str, Any],
    spec: Any,
    timer: CallTimer,
    provider: str,
) -> tuple[Any, ResponseReader, str | None]:
    """POST JSON 并返回 (response, reader, request_id)。

    HTTP 错误会读完响应体(计入 hash)后抛出 ProviderError。
    """

    body = json.dumps(payload, ensure_ascii=False).encode()
    request = urllib.request.Request(
        url,
        data=body,
        headers={"content-type": "application/json", "user-agent": USER_AGENT, **headers},
        method="POST",
    )
    scope = check_scope()
    if scope is not None:
        scope.validate_request(body)
    timer.mark_sent()
    try:
        if scope is None:
            response = urllib.request.urlopen(request, timeout=spec.timeout_s)
        else:
            response = scope.io(
                lambda: urllib.request.urlopen(request, timeout=min(spec.timeout_s, scope.check())),
                late_close=lambda value: value.close(),
            )
    except urllib.error.HTTPError as error:
        raise _http_error(error, timer, provider) from None
    except urllib.error.URLError as error:
        raise ProviderError(
            f"network error talking to {provider}: {error.reason}",
            provider=provider,
            status=None,
            retryable=True,
        ) from None
    except OSError as error:
        # socket.timeout / 连接被重置等不一定被 urlopen 包成 URLError。
        raise ProviderError(
            f"network error talking to {provider}: {error}",
            provider=provider,
            status=None,
            retryable=True,
        ) from None
    return response, ResponseReader(response, timer), request_id_from_headers(response.headers)


def is_event_stream(response: Any) -> bool:
    content_type = header_value(response.headers, "content-type") or ""
    return "text/event-stream" in content_type.lower()


def iter_sse_data(reader: ResponseReader):
    """逐行读取 SSE,产出 `data:` 后的字符串。"""

    for raw_line in reader:
        line = raw_line.decode("utf-8", "replace").strip()
        if not line or line.startswith(":"):
            continue
        if line.startswith("event:"):
            continue
        if line.startswith("data:"):
            yield line[len("data:") :].strip()


@dataclass
class ProviderResponse:
    content: str
    tool_calls: list[dict[str, Any]]
    usage: dict[str, Any]
    request_id: str | None
    response_id: str | None
    response_model: str | None
    stop_reason: str | None
    raw_response_sha256: str
    raw_response_bytes: int
    provider_extra: dict[str, Any] = field(default_factory=dict)
    # Protocol history for thinking + tools, separate from visible content and
    # recorded provider metadata. None means absent; an empty string is present.
    reasoning_content: str | None = None


class ProviderAdapter:
    api_format = ""

    def chat(
        self,
        messages: list[dict],
        tools: list[dict],
        spec: Any,
        timer: CallTimer,
        budget: Any | None = None,
    ) -> ProviderResponse:
        raise NotImplementedError
