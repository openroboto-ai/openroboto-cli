"""OpenAI 兼容 Chat Completions 适配器.

覆盖 DeepSeek、Pi 的 custom provider,以及自定义网关(经 OPE-125 模型网关)。同一份
canonical messages/tools 在这里转换成 OpenAI 的 system/assistant/tool 消息和
function tools。
"""

import http.client
import json
from typing import Any

from agent_eval.errors import ProviderError, error_event_details
from agent_eval.providers.base import (
    CallTimer,
    ProviderAdapter,
    ProviderResponse,
    call_with_retries,
    guarded_attempt,
    is_event_stream,
    iter_sse_data,
    open_request,
)


def chat_completions_url(endpoint: str) -> str:
    url = endpoint.rstrip("/")
    if url.endswith("/chat/completions"):
        return url
    return url + "/chat/completions"


def _text_content(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            block.get("text", "") for block in content if isinstance(block, dict) and block.get("type") == "text"
        )
    return str(content)


def _tool_result_text(block: dict) -> str:
    content = block.get("content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(item.get("text", ""))
            else:
                parts.append(str(item))
        return "".join(parts)
    return "" if content is None else str(content)


def _convert_messages(messages: list[dict]) -> list[dict]:
    converted: list[dict] = []
    for message in messages:
        role = message.get("role")
        content = message.get("content")
        if role == "system":
            converted.append({"role": "system", "content": _text_content(content)})
        elif role == "tool":
            converted.append({
                "role": "tool",
                "tool_call_id": message.get("tool_call_id"),
                "content": _text_content(content),
            })
        elif role == "assistant":
            assistant = _assistant_message(content, message.get("tool_calls") or [])
            if isinstance(message.get("reasoning_content"), str):
                assistant["reasoning_content"] = message["reasoning_content"]
            converted.append(assistant)
        elif role == "user":
            converted.extend(_user_messages(content))
        else:
            raise ProviderError(f"unsupported message role {role!r} for OpenAI-compatible provider")
    return converted


def _assistant_message(content: Any, extra_tool_calls: list[dict]) -> dict:
    texts: list[str] = []
    tool_calls: list[dict] = []
    if isinstance(content, str):
        texts.append(content)
    elif isinstance(content, list):
        for block in content:
            block_type = block.get("type") if isinstance(block, dict) else None
            if block_type == "text":
                texts.append(block.get("text", ""))
            elif block_type == "tool_use":
                tool_calls.append({
                    "id": block["id"],
                    "type": "function",
                    "function": {
                        "name": block["name"],
                        "arguments": json.dumps(block.get("input") or {}, ensure_ascii=False),
                    },
                })
            else:
                raise ProviderError(f"unsupported assistant block {block_type!r} for OpenAI-compatible provider")
    tool_calls.extend(extra_tool_calls)
    message: dict[str, Any] = {"role": "assistant", "content": "".join(texts)}
    if tool_calls:
        message["tool_calls"] = tool_calls
    return message


def _user_messages(content: Any) -> list[dict]:
    if isinstance(content, str) or content is None:
        return [{"role": "user", "content": content or ""}]
    if not isinstance(content, list):
        raise ProviderError(f"invalid user content: {content!r}")

    tool_messages: list[dict] = []
    texts: list[str] = []
    images: list[dict] = []
    for block in content:
        if not isinstance(block, dict):
            raise ProviderError(f"invalid user block: {block!r}")
        block_type = block.get("type")
        if block_type == "text":
            texts.append(block.get("text", ""))
        elif block_type == "tool_result":
            tool_messages.append({
                "role": "tool",
                "tool_call_id": block["tool_use_id"],
                "content": _tool_result_text(block),
            })
        elif block_type == "image":
            source = block.get("source") or {}
            if source.get("type") != "base64" or not source.get("data"):
                raise ProviderError("image block requires a base64 source with data")
            media_type = source.get("media_type") or "image/png"
            images.append({
                "type": "image_url",
                "image_url": {"url": f"data:{media_type};base64,{source['data']}"},
            })
        else:
            raise ProviderError(f"unsupported user block {block_type!r} for OpenAI-compatible provider")

    # OpenAI 要求 tool 消息紧跟 assistant tool_calls;文本/图片作为后续 user 消息。
    messages = list(tool_messages)
    if images:
        parts: list[dict] = []
        if texts:
            parts.append({"type": "text", "text": "".join(texts)})
        parts.extend(images)
        messages.append({"role": "user", "content": parts})
    elif texts or not tool_messages:
        messages.append({"role": "user", "content": "".join(texts)})
    return messages


def _convert_tools(tools: list[dict] | None) -> list[dict]:
    converted: list[dict] = []
    for tool in tools or []:
        schema = tool.get("input_schema") or tool.get("parameters")
        if not schema:
            raise ProviderError(f"tool {tool.get('name')!r} has no input_schema")
        function: dict[str, Any] = {"name": tool["name"], "parameters": schema}
        if tool.get("description"):
            function["description"] = tool["description"]
        if tool.get("strict") is not None:
            function["strict"] = bool(tool["strict"])
        converted.append({"type": "function", "function": function})
    return converted


def _normalize_usage(usage: dict | None) -> dict[str, Any]:
    usage = usage or {}
    input_tokens = usage.get("prompt_tokens", usage.get("input_tokens"))
    output_tokens = usage.get("completion_tokens", usage.get("output_tokens"))
    total_tokens = usage.get("total_tokens")
    out: dict[str, Any] = {}
    if input_tokens is not None:
        out["input_tokens"] = input_tokens
    if output_tokens is not None:
        out["output_tokens"] = output_tokens
    if total_tokens is not None:
        out["total_tokens"] = total_tokens
    elif isinstance(input_tokens, int) and isinstance(output_tokens, int):
        out["total_tokens"] = input_tokens + output_tokens

    details = usage.get("prompt_tokens_details") or {}
    if isinstance(details, dict) and details.get("cached_tokens") is not None:
        out["cache_read_input_tokens"] = details["cached_tokens"]
    completion_details = usage.get("completion_tokens_details") or {}
    if isinstance(completion_details, dict) and completion_details.get("reasoning_tokens") is not None:
        out["reasoning_tokens"] = completion_details["reasoning_tokens"]
    return out


def _arguments(raw: str | None) -> Any:
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return raw


def _tool_calls_from_message(message: dict) -> list[dict]:
    calls = []
    for call in message.get("tool_calls") or []:
        function = call.get("function") or {}
        calls.append({
            "id": call.get("id"),
            "name": function.get("name"),
            "arguments": _arguments(function.get("arguments")),
        })
    return calls


def _parse_json_response(data: dict, request_id: str | None) -> ProviderResponse:
    choices = data.get("choices") or []
    if not choices:
        raise ProviderError(
            f"OpenAI-compatible response has no choices: {json.dumps(data, ensure_ascii=False)[:500]}",
            request_id=request_id,
        )
    choice = choices[0]
    message = choice.get("message") or {}
    reasoning = message.get("reasoning_content")
    reasoning = reasoning if isinstance(reasoning, str) else None
    extra = {"reasoning_chars": len(reasoning)} if reasoning else {}
    return ProviderResponse(
        content=message.get("content") or "",
        tool_calls=_tool_calls_from_message(message),
        usage=_normalize_usage(data.get("usage")),
        request_id=request_id,
        response_id=data.get("id"),
        response_model=data.get("model"),
        stop_reason=choice.get("finish_reason"),
        raw_response_sha256="",
        raw_response_bytes=0,
        provider_extra=extra,
        reasoning_content=reasoning,
    )


def _parse_stream(reader, provider: str, request_id: str | None) -> ProviderResponse:
    content_parts: list[str] = []
    reasoning_parts: list[str] = []
    tool_state: dict[int, dict] = {}
    usage: dict[str, Any] = {}
    response_id: str | None = None
    response_model: str | None = None
    stop_reason: str | None = None

    for data in iter_sse_data(reader):
        if not data or data == "[DONE]":
            continue
        chunk = json.loads(data)
        if chunk.get("error") and not chunk.get("choices"):
            message, status = error_event_details(chunk)
            raise ProviderError(
                f"OpenAI-compatible stream error: {message}",
                provider=provider,
                status=status,
                request_id=request_id,
                body=json.dumps(chunk, ensure_ascii=False),
            )

        response_id = chunk.get("id") or response_id
        response_model = chunk.get("model") or response_model
        if chunk.get("usage"):
            usage = _normalize_usage(chunk["usage"])

        for choice in chunk.get("choices") or []:
            delta = choice.get("delta") or {}
            if delta.get("content"):
                content_parts.append(delta["content"])
            if isinstance(delta.get("reasoning_content"), str):
                reasoning_parts.append(delta["reasoning_content"])
            for call in delta.get("tool_calls") or []:
                index = int(call.get("index", len(tool_state)))
                state = tool_state.setdefault(index, {"id": None, "name": None, "arguments": ""})
                if call.get("id"):
                    state["id"] = call["id"]
                function = call.get("function") or {}
                if function.get("name") and not state["name"]:
                    state["name"] = function["name"]
                if function.get("arguments"):
                    state["arguments"] += function["arguments"]
            if choice.get("finish_reason"):
                stop_reason = choice["finish_reason"]

    tool_calls = [
        {
            "id": state.get("id"),
            "name": state.get("name"),
            "arguments": _arguments(state.get("arguments")),
        }
        for _, state in sorted(tool_state.items())
    ]
    reasoning = "".join(reasoning_parts) if reasoning_parts else None
    extra = {"reasoning_chars": len(reasoning)} if reasoning else {}
    return ProviderResponse(
        content="".join(content_parts),
        tool_calls=tool_calls,
        usage=_normalize_usage(usage),
        request_id=request_id,
        response_id=response_id,
        response_model=response_model,
        stop_reason=stop_reason,
        raw_response_sha256="",
        raw_response_bytes=0,
        provider_extra=extra,
        reasoning_content=reasoning,
    )


class OpenAICompatibleAdapter(ProviderAdapter):
    api_format = "openai"

    def chat(
        self,
        messages: list[dict],
        tools: list[dict],
        spec: Any,
        timer: CallTimer,
        budget: Any | None = None,
    ) -> ProviderResponse:
        key = spec.require_api_key()
        payload: dict[str, Any] = {
            "model": spec.model,
            "messages": _convert_messages(messages),
            "stream": spec.stream,
        }
        if spec.max_tokens:
            payload[spec.max_tokens_param] = spec.max_tokens
        converted_tools = _convert_tools(tools)
        if converted_tools:
            payload["tools"] = converted_tools
        if spec.stream:
            payload["stream_options"] = {"include_usage": True}
        if spec.effort and spec.effort_param:
            payload[spec.effort_param] = spec.effort
        payload.update(spec.extra_body)

        headers = dict(spec.headers)
        if key:
            headers["authorization"] = f"Bearer {key}"

        def _send() -> ProviderResponse:
            response, reader, header_request_id = open_request(
                chat_completions_url(spec.resolved_endpoint()), headers, payload, spec, timer, provider=spec.provider
            )
            try:
                if spec.stream and is_event_stream(response):
                    result = _parse_stream(reader, spec.provider, header_request_id)
                else:
                    data = json.loads(reader.read() or b"{}")
                    result = _parse_json_response(data, header_request_id)
            except ProviderError as error:
                digest, raw_bytes = reader.digest()
                error.details.setdefault("raw_response_sha256", digest)
                error.details.setdefault("raw_response_bytes", raw_bytes)
                raise
            except json.JSONDecodeError as error:
                digest, raw_bytes = reader.digest()
                raise ProviderError(
                    f"invalid JSON response from {spec.provider}: {error}",
                    provider=spec.provider,
                    status=None,
                    request_id=header_request_id,
                    details={"raw_response_sha256": digest, "raw_response_bytes": raw_bytes},
                ) from None
            except (OSError, http.client.HTTPException) as error:
                digest, raw_bytes = reader.digest()
                raise ProviderError(
                    f"network error while reading {spec.provider} response: {error}",
                    provider=spec.provider,
                    status=None,
                    request_id=header_request_id,
                    retryable=True,
                    details={"raw_response_sha256": digest, "raw_response_bytes": raw_bytes},
                ) from None
            finally:
                response.close()

            digest, raw_bytes = reader.digest()
            result.raw_response_sha256 = digest
            result.raw_response_bytes = raw_bytes
            return result

        def attempt():
            return guarded_attempt(budget, payload, spec, self.api_format, _send)

        result, retry = call_with_retries(attempt, provider=spec.provider)
        result.provider_extra = {**result.provider_extra, "retry": retry}
        return result
