"""Anthropic Messages API 适配器.

用官方 REST 接口(而不是 anthropic SDK),因为这一层要同时支持 Anthropic 与
OpenAI 兼容 provider,且本仓库保持 stdlib-only。流式解析 SSE,记录 request-id /
message id / usage / 原始响应 hash。
"""

import http.client
import json
from typing import Any

from agent_eval.errors import ProviderError, error_event_details
from agent_eval.providers.base import (
    CallTimer,
    ProviderAdapter,
    ProviderResponse,
    call_with_retries,
    guarded_attempt,
    is_event_stream,
    iter_sse_data,
    open_request,
)


def _convert_messages(messages: list[dict]) -> tuple[list[dict], str]:
    system_parts: list[str] = []
    converted: list[dict] = []
    for message in messages:
        role = message.get("role")
        content = message.get("content")
        if role == "system":
            system_parts.append(_text_content(content))
            continue
        if role not in ("user", "assistant"):
            raise ProviderError(f"unsupported message role {role!r} for Anthropic")
        converted.append({"role": role, "content": _content_blocks(content)})
    return converted, "\n\n".join(part for part in system_parts if part)


def _text_content(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            block.get("text", "") for block in content if isinstance(block, dict) and block.get("type") == "text"
        )
    return str(content)


def _content_blocks(content: Any) -> Any:
    if isinstance(content, str) or content is None:
        return content or ""
    blocks: list[dict] = []
    for block in content:
        if not isinstance(block, dict):
            raise ProviderError(f"invalid content block: {block!r}")
        block_type = block.get("type")
        if block_type == "text":
            blocks.append({"type": "text", "text": block.get("text", "")})
        elif block_type == "tool_use":
            blocks.append({
                "type": "tool_use",
                "id": block["id"],
                "name": block["name"],
                "input": block.get("input") or {},
            })
        elif block_type == "tool_result":
            item = {
                "type": "tool_result",
                "tool_use_id": block["tool_use_id"],
                "content": block.get("content", ""),
            }
            if block.get("is_error"):
                item["is_error"] = True
            blocks.append(item)
        elif block_type == "image":
            source = block.get("source") or {}
            if source.get("type") != "base64" or not source.get("data"):
                raise ProviderError("image block requires a base64 source with data")
            blocks.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": source.get("media_type") or "image/png",
                    "data": source["data"],
                },
            })
        else:
            raise ProviderError(f"unsupported content block type {block_type!r} for Anthropic")
    return blocks


def _convert_tools(tools: list[dict] | None) -> list[dict]:
    converted: list[dict] = []
    for tool in tools or []:
        schema = tool.get("input_schema") or tool.get("parameters")
        if not schema:
            raise ProviderError(f"tool {tool.get('name')!r} has no input_schema")
        item: dict[str, Any] = {"name": tool["name"], "input_schema": schema}
        if tool.get("description"):
            item["description"] = tool["description"]
        if tool.get("strict") is not None:
            item["strict"] = bool(tool["strict"])
        converted.append(item)
    return converted


def _normalize_usage(usage: dict | None) -> dict[str, Any]:
    usage = usage or {}
    out: dict[str, Any] = {}
    for key in ("input_tokens", "output_tokens", "cache_creation_input_tokens", "cache_read_input_tokens"):
        if usage.get(key) is not None:
            out[key] = usage[key]
    input_tokens = out.get("input_tokens")
    output_tokens = out.get("output_tokens")
    if isinstance(input_tokens, int) and isinstance(output_tokens, int):
        out["total_tokens"] = input_tokens + output_tokens
    return out


def _tool_call(block: dict, partial_json: str) -> dict[str, Any]:
    raw = partial_json or ""
    arguments: Any = block.get("input") or {}
    if raw:
        try:
            arguments = json.loads(raw)
        except json.JSONDecodeError:
            arguments = raw
    return {
        "id": block.get("id"),
        "name": block.get("name"),
        "arguments": arguments,
    }


def _parse_json_response(data: dict, request_id: str | None) -> ProviderResponse:
    content_parts: list[str] = []
    tool_calls: list[dict] = []
    thinking_chars = 0
    for block in data.get("content", []) or []:
        block_type = block.get("type")
        if block_type == "text":
            content_parts.append(block.get("text", ""))
        elif block_type == "tool_use":
            tool_calls.append(_tool_call(block, ""))
        elif block_type == "thinking":
            thinking_chars += len(block.get("thinking", "") or "")
    extra = {"thinking_chars": thinking_chars} if thinking_chars else {}
    return ProviderResponse(
        content="".join(content_parts),
        tool_calls=tool_calls,
        usage=_normalize_usage(data.get("usage")),
        request_id=request_id,
        response_id=data.get("id"),
        response_model=data.get("model"),
        stop_reason=data.get("stop_reason"),
        raw_response_sha256="",
        raw_response_bytes=0,
        provider_extra=extra,
    )


def _parse_stream(reader, provider: str, request_id: str | None) -> ProviderResponse:
    blocks: dict[int, dict] = {}
    usage: dict[str, Any] = {}
    response_id: str | None = None
    response_model: str | None = None
    stop_reason: str | None = None
    thinking_chars = 0

    for data in iter_sse_data(reader):
        if not data or data == "[DONE]":
            continue
        event = json.loads(data)
        event_type = event.get("type")
        if event_type == "message_start":
            message = event.get("message") or {}
            response_id = message.get("id") or response_id
            response_model = message.get("model") or response_model
            usage.update(_normalize_usage(message.get("usage")))
        elif event_type == "content_block_start":
            index = int(event.get("index", len(blocks)))
            block = event.get("content_block") or {}
            if block.get("type") == "text":
                blocks[index] = {"type": "text", "text": block.get("text", "")}
            elif block.get("type") == "tool_use":
                blocks[index] = {
                    "type": "tool_use",
                    "id": block.get("id"),
                    "name": block.get("name"),
                    "input": block.get("input") or {},
                    "partial_json": "",
                }
            elif block.get("type") == "thinking":
                blocks[index] = {"type": "thinking", "thinking": block.get("thinking", "")}
        elif event_type == "content_block_delta":
            index = int(event.get("index", 0))
            delta = event.get("delta") or {}
            block = blocks.setdefault(index, {"type": delta.get("type", "text")})
            delta_type = delta.get("type")
            if delta_type == "text_delta":
                block["type"] = "text"
                block["text"] = block.get("text", "") + delta.get("text", "")
            elif delta_type == "input_json_delta":
                block["partial_json"] = block.get("partial_json", "") + delta.get("partial_json", "")
            elif delta_type == "thinking_delta":
                block["type"] = "thinking"
                block["thinking"] = block.get("thinking", "") + delta.get("thinking", "")
        elif event_type == "message_delta":
            delta = event.get("delta") or {}
            stop_reason = delta.get("stop_reason") or stop_reason
            usage.update({k: v for k, v in _normalize_usage(event.get("usage")).items() if k != "total_tokens"})
        elif event_type == "error":
            message, status = error_event_details(event)
            raise ProviderError(
                f"Anthropic stream error: {message}",
                provider=provider,
                status=status,
                request_id=request_id,
                body=json.dumps(event, ensure_ascii=False),
            )

    content_parts: list[str] = []
    tool_calls: list[dict] = []
    for index in sorted(blocks):
        block = blocks[index]
        if block.get("type") == "text":
            content_parts.append(block.get("text", ""))
        elif block.get("type") == "tool_use":
            tool_calls.append(_tool_call(block, block.get("partial_json", "")))
        elif block.get("type") == "thinking":
            thinking_chars += len(block.get("thinking", "") or "")

    usage = _normalize_usage(usage)
    extra = {"thinking_chars": thinking_chars} if thinking_chars else {}
    return ProviderResponse(
        content="".join(content_parts),
        tool_calls=tool_calls,
        usage=usage,
        request_id=request_id,
        response_id=response_id,
        response_model=response_model,
        stop_reason=stop_reason,
        raw_response_sha256="",
        raw_response_bytes=0,
        provider_extra=extra,
    )


class AnthropicAdapter(ProviderAdapter):
    api_format = "anthropic"

    def chat(
        self,
        messages: list[dict],
        tools: list[dict],
        spec: Any,
        timer: CallTimer,
        budget: Any | None = None,
    ) -> ProviderResponse:
        key = spec.require_api_key()
        converted_messages, system = _convert_messages(messages)
        payload: dict[str, Any] = {
            "model": spec.model,
            "max_tokens": spec.max_tokens,
            "messages": converted_messages,
            "stream": spec.stream,
        }
        if system:
            payload["system"] = system
        converted_tools = _convert_tools(tools)
        if converted_tools:
            payload["tools"] = converted_tools
        if spec.effort:
            payload["output_config"] = {"effort": spec.effort}
        payload.update(spec.extra_body)

        headers = {"anthropic-version": spec.anthropic_version, **spec.headers}
        if key:
            headers["x-api-key"] = key

        def _send() -> ProviderResponse:
            response, reader, header_request_id = open_request(
                spec.resolved_endpoint(), headers, payload, spec, timer, provider=spec.provider
            )
            try:
                if spec.stream and is_event_stream(response):
                    result = _parse_stream(reader, spec.provider, header_request_id)
                else:
                    data = json.loads(reader.read() or b"{}")
                    result = _parse_json_response(data, header_request_id)
            except ProviderError as error:
                digest, raw_bytes = reader.digest()
                error.details.setdefault("raw_response_sha256", digest)
                error.details.setdefault("raw_response_bytes", raw_bytes)
                raise
            except json.JSONDecodeError as error:
                digest, raw_bytes = reader.digest()
                raise ProviderError(
                    f"invalid JSON response from {spec.provider}: {error}",
                    provider=spec.provider,
                    status=None,
                    request_id=header_request_id,
                    details={"raw_response_sha256": digest, "raw_response_bytes": raw_bytes},
                ) from None
            except (OSError, http.client.HTTPException) as error:
                digest, raw_bytes = reader.digest()
                raise ProviderError(
                    f"network error while reading {spec.provider} response: {error}",
                    provider=spec.provider,
                    status=None,
                    request_id=header_request_id,
                    retryable=True,
                    details={"raw_response_sha256": digest, "raw_response_bytes": raw_bytes},
                ) from None
            finally:
                response.close()

            digest, raw_bytes = reader.digest()
            result.raw_response_sha256 = digest
            result.raw_response_bytes = raw_bytes
            return result

        def attempt():
            return guarded_attempt(budget, payload, spec, self.api_format, _send)

        result, retry = call_with_retries(attempt, provider=spec.provider)
        result.provider_extra = {**result.provider_extra, "retry": retry}
        return result
