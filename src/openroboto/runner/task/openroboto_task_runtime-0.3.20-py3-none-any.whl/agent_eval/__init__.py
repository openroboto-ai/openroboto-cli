"""统一的模型调用层 | Unified model call layer for the agent-eval harness.

    result = chat(messages, tools, spec)
    # -> {"content", "tool_calls", "usage", "provider_meta"}

`spec` 是 EvaluationSpec(dict)或 `ModelSpec`。provider / model / endpoint /
effort 全部来自配置,harness 只调用 `chat()`,换 provider 不改 harness 代码。

所有模型请求都经过模型网关(`agent_eval.gateway.ModelGateway`,OPE-125):
发请求前校验 provider / model / endpoint / reasoning 参数 / 工具声明 / 预算,
不合格直接拒绝,不降档、不换 endpoint、不 fallback。需要跨请求预算时,在 run
开始时建一个 `ModelGateway` 并复用。

每次调用都会生成一条 CallRecord 并交给 recorder;provider_meta 里带
call_id / request_id / response_id / trace_id / usage / send-first-byte-complete
时间 / 原始响应 hash,可直接接证据链(OPE-126)。
"""

from agent_eval.errors import GatewayRejection, ProviderConfigError, ProviderError
from agent_eval.gateway import Budget, BudgetLedger, GatewayPolicy, ModelGateway, adapter_endpoint, chat
from agent_eval.records import CallRecorder, NullRecorder
from agent_eval.spec import ModelSpec, from_evaluation_spec, normalize_provider

__all__ = [
    "Budget",
    "BudgetLedger",
    "CallRecorder",
    "GatewayPolicy",
    "GatewayRejection",
    "ModelGateway",
    "ModelSpec",
    "NullRecorder",
    "ProviderConfigError",
    "ProviderError",
    "adapter_endpoint",
    "chat",
    "from_evaluation_spec",
    "normalize_provider",
]
