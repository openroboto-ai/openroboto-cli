"""Shared run-level model budget: pre-send reservation and usage settlement.

这本账是 **A/B 共同的 run 预算权威**：backend gateway 与 validator A 侧用同一份
``openroboto-run-budget`` 文件格式、同一个 ``run_id``、同一份价表摘要。两边在
发送前都通过这把文件锁原子占用同一个总额；任何一侧都不能另开一份满额账。

不可变身份
    ``config_sha256`` 绑定 format/version、run_id、共同总额、调用数上限、
    价表摘要与版本。文件已存在但重开配置不一致 → fail-closed，不能用新价表
    把旧预留重新结算。

每项价格快照
    每条 reservation 落盘时存下当时的 input/output/cache 单价；``settle`` 只用
    这项快照对账，不再读当前进程的价表。同一 reservation 带不同 usage 重放
    → ``budget_replay_conflict``，不静默覆盖。

计费规则
    只对登记过的 provider/model 放行。图片按对应厂商规则算 token（OpenAI 的
    base + tile/detail、Anthropic 的 28px patch）；没有证明规则、图片类型
    不支持、或输出上限不能证明覆盖 reasoning 的模型一律在发送前拒绝。
"""

from __future__ import annotations

import base64
import binascii
import fcntl
import json
import math
import os
import struct
import threading
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import ROUND_CEILING, Decimal, InvalidOperation
from pathlib import Path
from typing import Any

USD_QUANTUM = Decimal("0.000001")
_TOKENS_PER_UNIT = Decimal(1_000_000)
_SUPPORTED_CURRENCY = "USD"
_SUPPORTED_UNIT = "per_million_tokens"
_FORMAT = "openroboto-run-budget"
_FORMAT_VERSION = 1

#: 计费规则版本。改规则必须升版本，旧账行仍按自己的价格快照复算。
RULES_VERSION = "vision-2026-11-05"

_TEXT_BLOCK_TYPES = frozenset({"text", "tool_use", "tool_result"})


class BudgetConfigError(ValueError):
    """显式预算配置缺失或不合规；调用方应 fail-closed。"""


class BudgetRejected(Exception):
    """发送前拒绝：额度不足或无法证明上界。"""

    def __init__(self, code: str, message: str, **details: Any):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details

    def as_violation(self) -> dict[str, Any]:
        return {"code": self.code, "field": "budget", "message": self.message, **self.details}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _canonical_sha256(value: Any) -> str:
    import hashlib

    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode()).hexdigest()


def _non_negative_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise BudgetConfigError(f"{name} must be a non-negative integer")
    return value


def _positive_int(value: Any, name: str) -> int:
    parsed = _non_negative_int(value, name)
    if parsed <= 0:
        raise BudgetConfigError(f"{name} must be positive")
    return parsed


def _decimal(value: Any, name: str) -> Decimal:
    if isinstance(value, bool):
        raise BudgetConfigError(f"{name} must be a decimal number")
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise BudgetConfigError(f"{name} must be a decimal number") from None
    if not parsed.is_finite() or parsed < 0:
        raise BudgetConfigError(f"{name} must be a non-negative finite number")
    return parsed


def _decimal_str(value: Decimal) -> str:
    return format(value.normalize(), "f")


def _price_or_none(value: Any, name: str) -> Decimal | None:
    if value is None:
        return None
    return _decimal(value, name)


# ─────────────────────────────────────────────────────────────────────────────
# provider / model cost rules
# ─────────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ImageRule:
    """已证明的图片 token 规则。``kind`` 决定 wire 字段与算法。"""

    kind: str  # "openai" | "anthropic"
    version: str
    base_tokens: int = 0
    tile_size: int = 512
    per_tile_tokens: int = 0
    patch_size: int = 28


@dataclass(frozen=True)
class ModelRule:
    provider: str
    api_format: str
    image: ImageRule | None
    output_cap_includes_reasoning: bool
    version: str


#: 只登记有官方计费规则可引用的模型。未登记 → 发送前拒绝。
#:
#: 规则来源（固定版本；厂商改计费规则时必须升 version 并重审）：
#:   - OpenAI vision: gpt-4o-mini 低细节 = 2833 base，与尺寸无关；高/auto =
#:     2833 + 5667 × ceil(w/512) × ceil(h/512)。gpt-4o 低细节 = 85，高细节 =
#:     85 + 170 × tiles。`detail` 未知 → 拒绝。
#:   - Anthropic vision: 图像按 28px patch 网格计费，
#:     tokens = ceil(w/28) × ceil(h/28) + 1。
#:   - 输出上限: 登记模型的 `max_tokens` / `max_completion_tokens` 必须能封顶
#:     completion（含 reasoning）；没有这个证明的模型不进表。
#:   - DeepSeek 图片计费没有可引用的公开规则 → image=None，图片输入拒绝。
#: 文本输入始终按实际 wire payload 的 UTF-8 字节数封顶（BPE token ≤ 字节）。
MODEL_RULES: dict[str, ModelRule] = {
    "openai_compatible/gpt-4o-mini": ModelRule(
        provider="openai_compatible",
        api_format="openai",
        image=ImageRule(
            kind="openai",
            version="openai-vision-2026-11-05",
            base_tokens=2833,
            tile_size=512,
            per_tile_tokens=5667,
        ),
        output_cap_includes_reasoning=True,
        version="openai-vision-2026-11-05",
    ),
    "openai_compatible/gpt-4o": ModelRule(
        provider="openai_compatible",
        api_format="openai",
        image=ImageRule(
            kind="openai",
            version="openai-vision-2026-11-05",
            base_tokens=85,
            tile_size=512,
            per_tile_tokens=170,
        ),
        output_cap_includes_reasoning=True,
        version="openai-vision-2026-11-05",
    ),
    "anthropic/claude-opus-5-5": ModelRule(
        provider="anthropic",
        api_format="anthropic",
        image=ImageRule(kind="anthropic", version="anthropic-vision-2026-11-05", patch_size=28),
        output_cap_includes_reasoning=True,
        version="anthropic-vision-2026-11-05",
    ),
    "anthropic/claude-sonnet-5-5": ModelRule(
        provider="anthropic",
        api_format="anthropic",
        image=ImageRule(kind="anthropic", version="anthropic-vision-2026-11-05", patch_size=28),
        output_cap_includes_reasoning=True,
        version="anthropic-vision-2026-11-05",
    ),
    # DeepSeek 的图片计费规则没有可引用的公开证明：文本可跑，图片一律拒绝。
    "deepseek/deepseek-v4-pro": ModelRule(
        provider="deepseek",
        api_format="openai",
        image=None,
        output_cap_includes_reasoning=True,
        version="deepseek-2026-11-05",
    ),
    "deepseek/deepseek-flash": ModelRule(
        provider="deepseek",
        api_format="openai",
        image=None,
        output_cap_includes_reasoning=True,
        version="deepseek-2026-11-05",
    ),
}


_PROVIDER_ALIASES = {
    "openai": "openai_compatible",
    "openai_compatible": "openai_compatible",
    "openai-compatible": "openai_compatible",
    "claude": "anthropic",
    "gateway": "custom",
}


def _canonical_provider(provider: str) -> str:
    return _PROVIDER_ALIASES.get(provider.strip().lower(), provider.strip().lower())


def model_rule(*, provider: str, model: str, api_format: str) -> ModelRule:
    rule = MODEL_RULES.get(f"{_canonical_provider(provider)}/{model}")
    if rule is None:
        raise BudgetRejected(
            "budget_model_unsupported",
            f"no proven cost rule for provider={provider!r} model={model!r}",
            provider=provider,
            model=model,
        )
    if rule.api_format != api_format:
        raise BudgetRejected(
            "budget_model_unsupported",
            f"model {provider}/{model} is only proven on api_format={rule.api_format!r}",
            provider=provider,
            model=model,
            api_format=api_format,
        )
    if not rule.output_cap_includes_reasoning:
        raise BudgetRejected(
            "budget_output_unprovable",
            f"max_tokens is not proven to cap reasoning tokens for {provider}/{model}",
            provider=provider,
            model=model,
        )
    return rule


def _png_dimensions(data: bytes) -> tuple[int, int]:
    if len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        raise BudgetRejected(
            "budget_input_unsupported",
            "image content is not a PNG with a readable IHDR header",
        )
    width, height = struct.unpack(">II", data[16:24])
    if width <= 0 or height <= 0:
        raise BudgetRejected("budget_input_unsupported", "image dimensions must be positive")
    return width, height


def _image_source_bytes(source: Any, where: str) -> bytes:
    if not isinstance(source, Mapping):
        raise BudgetRejected("budget_input_unsupported", f"{where} has no readable image source")
    if source.get("type") != "base64":
        raise BudgetRejected(
            "budget_input_unsupported",
            f"{where} image source must be base64; got {source.get('type')!r}",
        )
    data = source.get("data")
    if not isinstance(data, str) or not data:
        raise BudgetRejected("budget_input_unsupported", f"{where} image source has no base64 data")
    media_type = str(source.get("media_type") or "image/png").lower()
    if media_type != "image/png":
        raise BudgetRejected(
            "budget_input_unsupported",
            f"{where} image media type {media_type!r} has no proven token rule",
            content_type=media_type,
        )
    try:
        return base64.b64decode(data, validate=True)
    except (binascii.Error, ValueError):
        raise BudgetRejected("budget_input_unsupported", f"{where} image base64 is invalid") from None


def _image_tokens(rule: ImageRule, source: Any, *, where: str, detail: str | None) -> int:
    width, height = _png_dimensions(_image_source_bytes(source, where))
    if rule.kind == "openai":
        normalized = (detail or "auto").lower()
        if normalized == "low":
            return rule.base_tokens
        if normalized not in {"auto", "high"}:
            raise BudgetRejected(
                "budget_input_unsupported",
                f"{where} has unknown detail={detail!r}",
                detail=detail,
            )
        tiles = math.ceil(width / rule.tile_size) * math.ceil(height / rule.tile_size)
        return rule.base_tokens + rule.per_tile_tokens * tiles
    if rule.kind == "anthropic":
        return math.ceil(width / rule.patch_size) * math.ceil(height / rule.patch_size) + 1
    raise BudgetRejected("budget_input_unsupported", f"{where} has no image token rule kind {rule.kind!r}")


def _input_bound(container: Any, where: str, rule: ModelRule | None) -> int:
    """校验 messages/system 并返回附带的图片 token 上界。"""

    if container is None or isinstance(container, str):
        return 0
    if isinstance(container, Mapping):
        block_type = container.get("type")
        if isinstance(block_type, str):
            normalized = block_type.strip().lower()
            if normalized in {"image", "image_url"}:
                if rule is None or rule.image is None:
                    raise BudgetRejected(
                        "budget_input_unsupported",
                        f"{where} contains an image but this model has no proven image rule",
                        content_type=normalized,
                    )
                detail: str | None = None
                if normalized == "image":
                    return _image_tokens(
                        rule.image,
                        container.get("source"),
                        where=where,
                        detail=detail,
                    )
                image_url = container.get("image_url")
                if isinstance(image_url, Mapping):
                    detail = image_url.get("detail") if isinstance(image_url.get("detail"), str) else None
                    url = image_url.get("url")
                elif isinstance(image_url, str):
                    url = image_url
                else:
                    url = None
                if not isinstance(url, str) or not url.startswith("data:"):
                    raise BudgetRejected(
                        "budget_input_unsupported",
                        f"{where} image_url must be a data: URL",
                    )
                header, _, encoded = url.partition(",")
                media_type = header[len("data:") :].split(";", 1)[0] or "image/png"
                return _image_tokens(
                    rule.image,
                    {"type": "base64", "media_type": media_type, "data": encoded},
                    where=where,
                    detail=detail,
                )
            if normalized in {"document", "file", "input_file", "audio", "input_audio", "video"}:
                raise BudgetRejected(
                    "budget_input_unsupported",
                    f"{where} contains unsupported content type {normalized!r}",
                    content_type=normalized,
                )
            if normalized not in _TEXT_BLOCK_TYPES:
                raise BudgetRejected(
                    "budget_input_unsupported",
                    f"{where} contains unknown content type {normalized!r}",
                    content_type=normalized,
                )
            if normalized == "tool_result":
                return _input_bound(container.get("content"), f"{where}.content", rule)
            return 0
        if container.get("image_url") is not None:
            return _input_bound(
                {"type": "image_url", "image_url": container["image_url"]},
                where,
                rule,
            )
        if "content" in container:
            return _input_bound(container.get("content"), f"{where}.content", rule)
        return 0
    if isinstance(container, (list, tuple)):
        return sum(_input_bound(item, f"{where}[{index}]", rule) for index, item in enumerate(container))
    raise BudgetRejected(
        "budget_input_unsupported",
        f"{where} has unsupported shape {type(container).__name__}",
    )


def reject_unsupported_input(messages: Any, *, provider: str, model: str, api_format: str) -> int:
    """适配器转换前拒绝无法证明的输入；返回图片 token 附加上界。"""

    rule = model_rule(provider=provider, model=model, api_format=api_format)
    return _input_bound(messages, "messages", rule)


def wire_payload_tokens_upper_bound(
    payload: Mapping[str, Any],
    *,
    provider: str,
    model: str,
    api_format: str,
    max_input_tokens_per_call: int,
    output_token_cap: int,
    max_output_tokens_per_call: int,
) -> int:
    """实际 wire payload 的可证明输入 token 上界（文本字节 + 厂商图片规则）。"""

    if not isinstance(payload, Mapping):
        raise BudgetRejected("budget_input_unsupported", "wire payload must be an object")
    rule = model_rule(provider=provider, model=model, api_format=api_format)
    if isinstance(output_token_cap, bool) or not isinstance(output_token_cap, int) or output_token_cap <= 0:
        raise BudgetRejected(
            "budget_output_cap_missing",
            "the request must declare a positive max_tokens output cap",
        )
    if output_token_cap > max_output_tokens_per_call:
        raise BudgetRejected(
            "budget_output_cap_exceeded",
            f"requested output cap {output_token_cap} exceeds {max_output_tokens_per_call}",
            limit=max_output_tokens_per_call,
            requested=output_token_cap,
        )

    image_tokens = _input_bound(payload.get("messages"), "messages", rule) + _input_bound(
        payload.get("system"), "system", rule
    )
    try:
        wire_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise BudgetRejected("budget_input_unsupported", f"wire payload is not JSON-serializable: {exc}") from None
    upper_bound = len(wire_bytes) + image_tokens
    if upper_bound > max_input_tokens_per_call:
        raise BudgetRejected(
            "budget_input_upper_bound_exceeded",
            f"input upper bound {upper_bound} exceeds {max_input_tokens_per_call}",
            limit=max_input_tokens_per_call,
            upper_bound=upper_bound,
        )
    return upper_bound


# ─────────────────────────────────────────────────────────────────────────────
# price list / limits / config identity
# ─────────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class PriceEntry:
    input_usd_per_million_tokens: Decimal
    output_usd_per_million_tokens: Decimal
    cache_read_usd_per_million_tokens: Decimal | None = None
    cache_creation_usd_per_million_tokens: Decimal | None = None

    def input_reservation_price(self) -> Decimal:
        candidates = [self.input_usd_per_million_tokens]
        if self.cache_read_usd_per_million_tokens is not None:
            candidates.append(self.cache_read_usd_per_million_tokens)
        if self.cache_creation_usd_per_million_tokens is not None:
            candidates.append(self.cache_creation_usd_per_million_tokens)
        return max(candidates)

    def snapshot(self) -> dict[str, str | None]:
        return {
            "input_usd_per_million_tokens": _decimal_str(self.input_usd_per_million_tokens),
            "output_usd_per_million_tokens": _decimal_str(self.output_usd_per_million_tokens),
            "cache_read_usd_per_million_tokens": (
                None
                if self.cache_read_usd_per_million_tokens is None
                else _decimal_str(self.cache_read_usd_per_million_tokens)
            ),
            "cache_creation_usd_per_million_tokens": (
                None
                if self.cache_creation_usd_per_million_tokens is None
                else _decimal_str(self.cache_creation_usd_per_million_tokens)
            ),
        }


@dataclass(frozen=True)
class PriceList:
    version: str
    currency: str
    unit: str
    models: Mapping[str, PriceEntry]
    document_sha256: str

    @classmethod
    def from_document(cls, document: Mapping[str, Any], *, expected_sha256: str | None = None) -> PriceList:
        if not isinstance(document, Mapping):
            raise BudgetConfigError("price_list must be an object")
        version = document.get("version")
        if not isinstance(version, str) or not version:
            raise BudgetConfigError("price_list.version is required")
        currency = str(document.get("currency") or "").upper()
        if currency != _SUPPORTED_CURRENCY:
            raise BudgetConfigError("price_list.currency must be USD")
        if document.get("unit") != _SUPPORTED_UNIT:
            raise BudgetConfigError(f"price_list.unit must be {_SUPPORTED_UNIT!r}")
        raw_models = document.get("models")
        if not isinstance(raw_models, Mapping) or not raw_models:
            raise BudgetConfigError("price_list.models must be a non-empty object")
        sha = _canonical_sha256(document)
        if expected_sha256 is not None and sha != expected_sha256:
            raise BudgetConfigError(f"price_list digest {sha} does not match configured {expected_sha256}")
        models: dict[str, PriceEntry] = {}
        for key, value in raw_models.items():
            if not isinstance(key, str) or not key:
                raise BudgetConfigError("price_list model keys must be non-empty strings")
            if not isinstance(value, Mapping):
                raise BudgetConfigError(f"price_list.models[{key!r}] must be an object")
            models[key] = PriceEntry(
                input_usd_per_million_tokens=_decimal(
                    value.get("input_usd_per_million_tokens"),
                    f"price_list.models[{key!r}].input_usd_per_million_tokens",
                ),
                output_usd_per_million_tokens=_decimal(
                    value.get("output_usd_per_million_tokens"),
                    f"price_list.models[{key!r}].output_usd_per_million_tokens",
                ),
                cache_read_usd_per_million_tokens=_price_or_none(
                    value.get("cache_read_usd_per_million_tokens"),
                    f"price_list.models[{key!r}].cache_read_usd_per_million_tokens",
                ),
                cache_creation_usd_per_million_tokens=_price_or_none(
                    value.get("cache_creation_usd_per_million_tokens"),
                    f"price_list.models[{key!r}].cache_creation_usd_per_million_tokens",
                ),
            )
        return cls(
            version=version,
            currency=currency,
            unit=_SUPPORTED_UNIT,
            models=models,
            document_sha256=sha,
        )

    def entry_for(self, *, provider: str, model: str) -> tuple[str, PriceEntry]:
        for key in (
            f"{_canonical_provider(provider)}/{model}",
            f"{provider}/{model}",
            model,
        ):
            entry = self.models.get(key)
            if entry is not None:
                return key, entry
        raise BudgetRejected(
            "budget_price_missing",
            f"no frozen price for provider={provider!r} model={model!r}",
            provider=provider,
            model=model,
        )


@dataclass(frozen=True)
class BudgetLimits:
    max_total_cost_usd: Decimal
    max_calls: int
    max_input_tokens_per_call: int
    max_output_tokens_per_call: int

    @classmethod
    def from_config(cls, document: Mapping[str, Any]) -> BudgetLimits:
        if not isinstance(document, Mapping):
            raise BudgetConfigError("budget config must be an object")
        max_cost = _decimal(document.get("max_total_cost_usd"), "max_total_cost_usd")
        if max_cost <= 0:
            raise BudgetConfigError("max_total_cost_usd must be positive")
        return cls(
            max_total_cost_usd=max_cost,
            max_calls=_positive_int(document.get("max_calls"), "max_calls"),
            max_input_tokens_per_call=_positive_int(
                document.get("max_input_tokens_per_call"),
                "max_input_tokens_per_call",
            ),
            max_output_tokens_per_call=_positive_int(
                document.get("max_output_tokens_per_call"),
                "max_output_tokens_per_call",
            ),
        )


def _common_config(
    *,
    run_id: str,
    price_list: PriceList,
    limits: BudgetLimits,
) -> dict[str, Any]:
    return {
        "format": _FORMAT,
        "format_version": _FORMAT_VERSION,
        "run_id": run_id,
        "max_total_cost_usd": _decimal_str(limits.max_total_cost_usd),
        "max_calls": limits.max_calls,
        "price_list_sha256": price_list.document_sha256,
        "price_list_version": price_list.version,
    }


@dataclass(frozen=True)
class Reservation:
    reservation_id: str
    model_key: str
    party: str
    reserved_usd: Decimal
    input_token_upper_bound: int
    output_token_cap: int
    image_tokens: int
    api_format: str


def _usage_digest(usage: Mapping[str, Any] | None) -> tuple[str, str]:
    """返回 (usage_sha256, status)。缺失/非法也留稳定摘要用于冲突检测。"""

    if not isinstance(usage, Mapping) or not usage:
        return _canonical_sha256({"status": "usage_missing"}), "usage_missing"
    normalized = {
        "input_tokens": usage.get("input_tokens"),
        "output_tokens": usage.get("output_tokens"),
        "cache_read_input_tokens": usage.get("cache_read_input_tokens", 0),
        "cache_creation_input_tokens": usage.get("cache_creation_input_tokens", 0),
    }
    return _canonical_sha256(normalized), "recorded"


class RunBudgetLedger:
    """A/B 共用的 run 预算账；同一文件、同一 run_id、同一价表摘要。"""

    def __init__(
        self,
        path: str | os.PathLike[str],
        *,
        run_id: str,
        price_list: PriceList,
        limits: BudgetLimits,
        lock_path: str | os.PathLike[str] | None = None,
    ):
        if not isinstance(run_id, str) or not run_id:
            raise BudgetConfigError("run_id is required for the shared run budget")
        self.path = Path(path)
        self.lock_path = Path(lock_path) if lock_path is not None else self.path.with_suffix(self.path.suffix + ".lock")
        self.run_id = run_id
        self.price_list = price_list
        self.limits = limits
        self.common = _common_config(run_id=run_id, price_list=price_list, limits=limits)
        self.config_sha256 = _canonical_sha256(self.common)
        self._thread_lock = threading.Lock()

    @classmethod
    def from_config_file(cls, path: str | os.PathLike[str], *, ledger_path: str | os.PathLike[str]) -> RunBudgetLedger:
        try:
            document = json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise BudgetConfigError(f"cannot read budget config {path}: {exc}") from None
        if not isinstance(document, Mapping):
            raise BudgetConfigError("budget config must be an object")
        run_id = document.get("run_id")
        if not isinstance(run_id, str) or not run_id:
            raise BudgetConfigError("budget config needs a non-empty run_id")
        raw_price_list = document.get("price_list")
        if not isinstance(raw_price_list, Mapping):
            raise BudgetConfigError("budget config needs a price_list object")
        expected = document.get("price_list_sha256")
        if expected is not None and not isinstance(expected, str):
            raise BudgetConfigError("price_list_sha256 must be a string")
        price_list = PriceList.from_document(raw_price_list, expected_sha256=expected)
        limits = BudgetLimits.from_config(document)
        return cls(ledger_path, run_id=run_id, price_list=price_list, limits=limits)

    # ── 读写 ────────────────────────────────────────────────────────────────

    def _new_document(self) -> dict[str, Any]:
        return {
            **self.common,
            "config_sha256": self.config_sha256,
            "created_at": _utc_now(),
            "entries": [],
        }

    def _validate_document(self, document: Mapping[str, Any]) -> dict[str, Any]:
        if document.get("format") != _FORMAT:
            raise BudgetRejected(
                "budget_ledger_unreadable",
                f"run budget ledger {self.path} has unknown format {document.get('format')!r}",
            )
        if document.get("format_version") != _FORMAT_VERSION:
            raise BudgetRejected(
                "budget_ledger_unreadable",
                f"run budget ledger {self.path} has unsupported version {document.get('format_version')!r}",
            )
        if document.get("config_sha256") != self.config_sha256:
            raise BudgetRejected(
                "budget_config_mismatch",
                "this ledger was created with a different run id, budget, or price list; "
                "reopening it with a new config would re-price old reservations",
                expected_config_sha256=document.get("config_sha256"),
                actual_config_sha256=self.config_sha256,
                ledger_run_id=document.get("run_id"),
                actual_run_id=self.run_id,
            )
        if not isinstance(document.get("entries"), list):
            raise BudgetRejected(
                "budget_ledger_unreadable",
                f"run budget ledger {self.path} has no entries list",
            )
        return dict(document)

    def _read(self) -> dict[str, Any]:
        if not self.path.exists():
            return self._new_document()
        try:
            document = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise BudgetRejected(
                "budget_ledger_unreadable",
                f"run budget ledger {self.path} is unreadable: {exc}",
            ) from None
        if not isinstance(document, Mapping):
            raise BudgetRejected(
                "budget_ledger_unreadable",
                f"run budget ledger {self.path} has an unsupported shape",
            )
        return self._validate_document(document)

    def _write(self, document: Mapping[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
        temp.write_text(
            json.dumps(document, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
        )
        with temp.open("r+b") as handle:
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, self.path)

    def _locked(self):
        ledger = self

        class _Lock:
            def __enter__(self_nonlocal):
                self_nonlocal._handle = ledger.lock_path.open("a+")
                fcntl.flock(self_nonlocal._handle.fileno(), fcntl.LOCK_EX)
                return self_nonlocal._handle

            def __exit__(self_nonlocal, *exc):
                fcntl.flock(self_nonlocal._handle.fileno(), fcntl.LOCK_UN)
                self_nonlocal._handle.close()

        return _Lock()

    @staticmethod
    def _entry_spend(entry: Mapping[str, Any]) -> Decimal:
        if entry.get("state") == "settled" and entry.get("settled_usd") is not None:
            return Decimal(str(entry["settled_usd"]))
        return Decimal(str(entry["reserved_usd"]))

    def _totals(self, document: Mapping[str, Any]) -> tuple[int, Decimal]:
        entries = document.get("entries") or []
        spent = sum((self._entry_spend(entry) for entry in entries), Decimal(0))
        return len(entries), spent

    def snapshot(self) -> dict[str, Any]:
        with self._thread_lock, self._locked():
            document = self._read()
        calls, spent = self._totals(document)
        remaining = self.limits.max_total_cost_usd - spent
        return {
            "ledger": str(self.path),
            "format": _FORMAT,
            "format_version": _FORMAT_VERSION,
            "run_id": self.run_id,
            "config_sha256": self.config_sha256,
            "price_list_version": self.price_list.version,
            "price_list_sha256": self.price_list.document_sha256,
            "max_total_cost_usd": _decimal_str(self.limits.max_total_cost_usd),
            "max_calls": self.limits.max_calls,
            "max_input_tokens_per_call": self.limits.max_input_tokens_per_call,
            "max_output_tokens_per_call": self.limits.max_output_tokens_per_call,
            "calls": calls,
            "spent_usd": _decimal_str(spent),
            "remaining_usd": _decimal_str(remaining),
        }

    # ── 预留与结算 ──────────────────────────────────────────────────────────

    def reserve_wire(
        self,
        payload: Mapping[str, Any],
        *,
        provider: str,
        model: str,
        output_token_cap: int,
        api_format: str,
        party: str,
        reservation_id: str | None = None,
    ) -> Reservation:
        if party not in {"a", "b"}:
            raise BudgetConfigError("party must be 'a' or 'b'")
        rule = model_rule(provider=provider, model=model, api_format=api_format)
        model_key, entry = self.price_list.entry_for(provider=provider, model=model)
        image_tokens = _input_bound(payload.get("messages"), "messages", rule) + _input_bound(
            payload.get("system"), "system", rule
        )
        upper_bound = wire_payload_tokens_upper_bound(
            payload,
            provider=provider,
            model=model,
            api_format=api_format,
            max_input_tokens_per_call=self.limits.max_input_tokens_per_call,
            output_token_cap=output_token_cap,
            max_output_tokens_per_call=self.limits.max_output_tokens_per_call,
        )
        if _contains_cache_control(payload.get("messages")) or _contains_cache_control(payload.get("system")):
            if entry.cache_creation_usd_per_million_tokens is None:
                raise BudgetRejected(
                    "budget_cache_price_missing",
                    "payload requests cache_control but the frozen price list has no cache creation price",
                    model=model_key,
                )
        reserved = (
            Decimal(upper_bound) * entry.input_reservation_price()
            + Decimal(output_token_cap) * entry.output_usd_per_million_tokens
        ) / _TOKENS_PER_UNIT
        reserved = reserved.quantize(USD_QUANTUM, rounding=ROUND_CEILING)

        with self._thread_lock, self._locked():
            document = self._read()
            existing = next(
                (
                    item
                    for item in document["entries"]
                    if reservation_id is not None and item.get("reservation_id") == reservation_id
                ),
                None,
            )
            if existing is not None:
                if (
                    existing.get("model_key") != model_key
                    or existing.get("party") != party
                    or int(existing.get("output_token_cap") or 0) != output_token_cap
                    or int(existing.get("input_token_upper_bound") or 0) != upper_bound
                ):
                    raise BudgetRejected(
                        "budget_reservation_conflict",
                        f"reservation {reservation_id!r} was created with different terms",
                    )
                return Reservation(
                    reservation_id=reservation_id,
                    model_key=model_key,
                    party=party,
                    reserved_usd=Decimal(str(existing["reserved_usd"])),
                    input_token_upper_bound=upper_bound,
                    output_token_cap=output_token_cap,
                    image_tokens=image_tokens,
                    api_format=api_format,
                )
            calls, spent = self._totals(document)
            if calls >= self.limits.max_calls:
                raise BudgetRejected(
                    "budget_calls_exceeded",
                    f"call budget exhausted: {calls} attempt(s) already reserved, limit {self.limits.max_calls}",
                    limit=self.limits.max_calls,
                    used=calls,
                )
            remaining = self.limits.max_total_cost_usd - spent
            if reserved > remaining:
                raise BudgetRejected(
                    "budget_total_exceeded",
                    f"reservation {reserved} USD exceeds remaining {remaining} USD",
                    limit=_decimal_str(self.limits.max_total_cost_usd),
                    spent=_decimal_str(spent),
                    reserved=_decimal_str(reserved),
                    remaining=_decimal_str(remaining),
                )
            reservation_id = reservation_id or uuid.uuid4().hex
            document["entries"].append({
                "reservation_id": reservation_id,
                "party": party,
                "state": "reserved",
                "model_key": model_key,
                "api_format": api_format,
                "prices": entry.snapshot(),
                "reserved_usd": _decimal_str(reserved),
                "settled_usd": None,
                "input_token_upper_bound": upper_bound,
                "image_tokens": image_tokens,
                "output_token_cap": output_token_cap,
                "usage_sha256": None,
                "usage_status": None,
                "created_at": _utc_now(),
                "settled_at": None,
            })
            self._write(document)
        return Reservation(
            reservation_id=reservation_id,
            model_key=model_key,
            party=party,
            reserved_usd=reserved,
            input_token_upper_bound=upper_bound,
            output_token_cap=output_token_cap,
            image_tokens=image_tokens,
            api_format=api_format,
        )

    def settle(self, reservation: Reservation, usage: Mapping[str, Any] | None) -> dict[str, Any]:
        usage_sha256, usage_status = _usage_digest(usage)
        with self._thread_lock, self._locked():
            document = self._read()
            entry = next(
                (item for item in document["entries"] if item.get("reservation_id") == reservation.reservation_id),
                None,
            )
            if entry is None:
                raise BudgetRejected(
                    "budget_reservation_unknown",
                    f"reservation {reservation.reservation_id} is not in the run ledger",
                )
            recorded = entry.get("usage_sha256")
            if recorded is not None and recorded != usage_sha256:
                raise BudgetRejected(
                    "budget_replay_conflict",
                    f"reservation {reservation.reservation_id} already recorded different usage",
                    recorded_usage_sha256=recorded,
                    new_usage_sha256=usage_sha256,
                )
            if entry.get("state") in {"settled", "unsettled"}:
                return dict(entry)

            actual, reason = _settled_cost_from_prices(
                entry.get("prices") or {},
                usage,
                api_format=str(entry.get("api_format") or ""),
            )
            entry["usage_sha256"] = usage_sha256
            entry["usage_status"] = reason
            entry["settled_at"] = _utc_now()
            if actual is None:
                entry["state"] = "unsettled"
            else:
                entry["state"] = "settled"
                entry["settled_usd"] = _decimal_str(actual)
                entry["over_reserved"] = actual > Decimal(str(entry["reserved_usd"]))
            self._write(document)
            return dict(entry)

    def summary(self) -> dict[str, Any]:
        return self.snapshot()


def _contains_cache_control(value: Any) -> bool:
    if isinstance(value, Mapping):
        if "cache_control" in value:
            return True
        return any(_contains_cache_control(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(_contains_cache_control(item) for item in value)
    return False


def payload_requests_cache(payload: Mapping[str, Any]) -> bool:
    return _contains_cache_control(payload.get("messages")) or _contains_cache_control(payload.get("system"))


def _settled_cost_from_prices(
    prices: Mapping[str, Any],
    usage: Mapping[str, Any] | None,
    *,
    api_format: str,
) -> tuple[Decimal | None, str]:
    if not isinstance(usage, Mapping) or not usage:
        return None, "usage_missing"
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    if (
        isinstance(input_tokens, bool)
        or not isinstance(input_tokens, int)
        or input_tokens < 0
        or isinstance(output_tokens, bool)
        or not isinstance(output_tokens, int)
        or output_tokens < 0
    ):
        return None, "usage_invalid"
    cache_read = usage.get("cache_read_input_tokens", 0) or 0
    cache_creation = usage.get("cache_creation_input_tokens", 0) or 0
    for name, value in (
        ("cache_read_input_tokens", cache_read),
        ("cache_creation_input_tokens", cache_creation),
    ):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            return None, f"{name}_invalid"

    input_price = _price_or_none(prices.get("input_usd_per_million_tokens"), "input")
    output_price = _price_or_none(prices.get("output_usd_per_million_tokens"), "output")
    if input_price is None or output_price is None:
        return None, "price_snapshot_missing"
    if api_format == "openai":
        billable_input = input_tokens - cache_read
        if billable_input < 0:
            return None, "usage_cache_exceeds_input"
    elif api_format == "anthropic":
        billable_input = input_tokens
    else:
        return None, "api_format_unknown_for_cache_pricing"

    total = Decimal(billable_input) * input_price + Decimal(output_tokens) * output_price
    if cache_read:
        cache_read_price = _price_or_none(prices.get("cache_read_usd_per_million_tokens"), "cache_read")
        if cache_read_price is None:
            return None, "cache_read_price_missing"
        total += Decimal(cache_read) * cache_read_price
    if cache_creation:
        cache_creation_price = _price_or_none(prices.get("cache_creation_usd_per_million_tokens"), "cache_creation")
        if cache_creation_price is None:
            return None, "cache_creation_price_missing"
        total += Decimal(cache_creation) * cache_creation_price
    return (total / _TOKENS_PER_UNIT).quantize(USD_QUANTUM, rounding=ROUND_CEILING), "metered"


__all__ = [
    "BudgetConfigError",
    "BudgetLimits",
    "BudgetRejected",
    "ImageRule",
    "MODEL_RULES",
    "ModelRule",
    "PriceEntry",
    "PriceList",
    "RULES_VERSION",
    "Reservation",
    "RunBudgetLedger",
    "model_rule",
    "payload_requests_cache",
    "reject_unsupported_input",
    "wire_payload_tokens_upper_bound",
]
