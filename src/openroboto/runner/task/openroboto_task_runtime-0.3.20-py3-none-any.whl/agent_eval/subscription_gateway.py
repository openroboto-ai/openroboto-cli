"""Magpie Codex 订阅出口：冻结模型与 effort，按请求次数和剩余额度限流。

正式 worker 先 parse_spec(raw)，再调用 make_model_gateway(parsed, ...)，
把返回值的 bound ``gateway.chat`` 交给原 agent_harness.run。不要注入 runtime。
Codex 的 max_tokens 只记录请求值，不代表 native reasoning 或 USD 成本上界。
本模块不读凭据、不读取 Magpie trace、不记录 served/account 信息。
"""

from __future__ import annotations

import contextlib
import dataclasses
import fcntl
import hashlib
import json
import math
import os
import pathlib
import re
import stat
import urllib.parse
import urllib.request
import uuid
from collections.abc import Callable, Mapping
from datetime import UTC, datetime
from typing import Any

from agent_eval.inline_image_guard import validate_content, validate_payload_size
from agent_eval.call_scope import check_scope

from agent_eval import ModelGateway
from agent_eval.errors import ProviderError
from agent_eval.providers.openai_compat import OpenAICompatibleAdapter
from agent_eval.spec import from_evaluation_spec

JsonGetter = Callable[[str, float], Mapping[str, Any]]
FORMAT = "magpie-subscription-attempts/v1"


class SubscriptionRejected(ProviderError):
    """确定性门禁拒绝；不重试，不发模型请求。"""

    def __init__(self, code: str, message: str):
        super().__init__(
            message,
            provider="custom",
            retryable=False,
            details={"subscription_code": code},
        )
        self.code = code


def _reject(code: str, message: str) -> None:
    raise SubscriptionRejected(code, message)


def _canonical(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def _sha(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds")


@dataclasses.dataclass(frozen=True)
class MixedModelPolicy:
    """由运营显式提供；整份策略的摘要冻结在账本首行。"""

    run_id: str
    ledger_path: pathlib.Path
    max_calls: int
    per_episode_calls: int
    min_remaining: float
    session_prefix: str
    quota_timeout_s: float
    codex_provider: str = "custom"
    codex_model: str = "codex/gpt-5.6-luna"
    codex_api_format: str = "openai"
    codex_effort: str = "low"
    codex_endpoint: str = "http://127.0.0.1:3425/v1"
    subscription_provider: str = "codex"
    subscription_kind: str = "subscription"
    subscription_plan: str = "pro"
    quota_window: str = "7 days"
    deepseek_provider: str = "deepseek"
    deepseek_model: str = "deepseek-v4-pro"
    deepseek_endpoint: str = "https://api.deepseek.com"

    def __post_init__(self) -> None:
        if not self.run_id or not isinstance(self.run_id, str):
            raise ValueError("policy.run_id must be a non-empty string")
        for value in (self.max_calls, self.per_episode_calls):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError("attempt limits must be positive integers")
        if self.per_episode_calls > self.max_calls:
            raise ValueError("episode limit exceeds the run limit")
        if isinstance(self.min_remaining, bool) or not isinstance(self.min_remaining, (int, float)):
            raise TypeError("min_remaining must be a percentage")
        if not math.isfinite(self.min_remaining) or not 0 <= self.min_remaining <= 100:
            raise ValueError("min_remaining must be in [0, 100]")
        if not isinstance(self.quota_timeout_s, (int, float)) or isinstance(self.quota_timeout_s, bool):
            raise TypeError("quota_timeout_s must be positive")
        if not math.isfinite(self.quota_timeout_s) or self.quota_timeout_s <= 0:
            raise ValueError("quota_timeout_s must be positive")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", self.session_prefix):
            raise ValueError("session_prefix must be a safe, non-empty label")
        # 模型/effort 由后端不可变登记配置注入；每条 wire 必须逐项相等。
        if (
            not isinstance(self.codex_model, str)
            or not self.codex_model.startswith("codex/")
            or len(self.codex_model) <= 6
        ):
            raise ValueError("policy requires an explicit Codex model")
        if self.codex_effort not in ("minimal", "low", "medium", "high", "xhigh"):
            raise ValueError("policy requires an explicit supported reasoning effort")
        if (
            self.codex_provider,
            self.codex_api_format,
            self.codex_endpoint,
            self.subscription_provider,
            self.subscription_kind,
            self.subscription_plan,
            self.quota_window,
        ) != (
            "custom",
            "openai",
            "http://127.0.0.1:3425/v1",
            "codex",
            "subscription",
            "pro",
            "7 days",
        ):
            raise ValueError("policy must retain the verified Codex subscription route")
        if (self.deepseek_provider, self.deepseek_model, self.deepseek_endpoint) != (
            "deepseek",
            "deepseek-v4-pro",
            "https://api.deepseek.com",
        ):
            raise ValueError("policy must retain the official DeepSeek route")
        path = pathlib.Path(self.ledger_path)
        if not path.is_absolute():
            raise ValueError("ledger_path must be absolute")
        object.__setattr__(self, "ledger_path", path)

    def frozen(self) -> dict[str, Any]:
        document = dataclasses.asdict(self)
        document["ledger_path"] = str(self.ledger_path)
        return document

    @property
    def sha256(self) -> str:
        return _sha(self.frozen())


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        _reject("redirect_forbidden", "Magpie metadata redirects are forbidden")


def _local_get_json(url: str, timeout_s: float) -> Mapping[str, Any]:
    parsed = urllib.parse.urlsplit(url)
    if (parsed.scheme, parsed.hostname, parsed.port) != ("http", "127.0.0.1", 3425):
        _reject(
            "metadata_endpoint",
            "metadata GET must stay on the verified local Magpie origin",
        )
    if parsed.username or parsed.password or parsed.fragment:
        _reject(
            "metadata_endpoint",
            "metadata URL contains unsupported authority or fragment",
        )
    if parsed.path not in {"/v1/magpie/quotas", "/v1/magpie/route"}:
        _reject(
            "metadata_endpoint",
            "only quota and session-filtered route metadata are allowed",
        )
    if parsed.path.endswith("/route"):
        query = urllib.parse.parse_qs(parsed.query, strict_parsing=True)
        if set(query) != {"session"} or len(query["session"]) != 1 or not query["session"][0]:
            _reject("metadata_session", "route GET requires exactly one session filter")
    elif parsed.query:
        _reject("metadata_endpoint", "quota GET does not accept query parameters")
    # 禁止系统代理或重定向把本机的元数据请求送到其它服务。
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    try:
        scope = check_scope()
        request = urllib.request.Request(url, method="GET")
        response = (
            opener.open(request, timeout=timeout_s) if scope is None else
            scope.io(lambda: opener.open(request, timeout=min(timeout_s, scope.check())),
                     late_close=lambda value: value.close())
        )
        with response:
            if response.status != 200:
                _reject("metadata_status", "Magpie metadata did not return 200")
            if scope is None:
                data = json.load(response)
            else:
                from agent_eval.providers.base import CallTimer, ResponseReader

                data = json.loads(ResponseReader(response, CallTimer()).read())
    except SubscriptionRejected:
        raise
    except Exception:  # noqa: BLE001 - metadata failures must close the gate without echoing response data
        _reject(
            "metadata_unavailable",
            "Magpie metadata unavailable or invalid; no model request allowed",
        )
    if not isinstance(data, Mapping):
        _reject("metadata_shape", "Magpie metadata must be an object")
    return data


def _quota_snapshot(policy: MixedModelPolicy, getter: JsonGetter) -> dict[str, Any]:
    document = getter(policy.codex_endpoint + "/magpie/quotas", policy.quota_timeout_s)
    rows = document.get("data") if isinstance(document, Mapping) else None
    if not isinstance(rows, list):
        _reject("quota_shape", "quota response has no data array")
    codex = [row for row in rows if isinstance(row, Mapping) and row.get("provider") == policy.subscription_provider]
    if not codex or any(row.get("kind") != policy.subscription_kind for row in codex):
        _reject("quota_kind", "Codex must have only subscription quota rows")
    selected = []
    for row in codex:
        if row.get("plan") != policy.subscription_plan:
            _reject("quota_plan", "Codex subscription plan differs from the frozen policy")
        windows = row.get("windows")
        if not isinstance(windows, list):
            _reject("quota_shape", "subscription quota has no windows")
        weekly = [
            window for window in windows if isinstance(window, Mapping) and window.get("name") == policy.quota_window
        ]
        if not weekly:
            _reject("quota_window", "subscription weekly quota is missing")
        safe_windows = []
        for window in weekly:
            remaining = window.get("remaining")
            if isinstance(remaining, bool) or not isinstance(remaining, (int, float)):
                _reject("quota_remaining", "weekly remaining must be a numeric percentage")
            if not math.isfinite(remaining) or not policy.min_remaining < remaining <= 100:
                _reject("quota_floor", "weekly subscription quota is below the frozen floor")
            safe_windows.append({key: window.get(key) for key in ("name", "used", "remaining", "resetsAt")})
        selected.append({
            "provider": row["provider"],
            "kind": row["kind"],
            "plan": row["plan"],
            "windows": safe_windows,
            "readAt": row.get("readAt"),
        })
    return {"checked_at": _now(), "data": selected}


def _validate_text_tools(payload: Mapping[str, Any]) -> None:
    allowed = {
        "model",
        "messages",
        "stream",
        "stream_options",
        "max_tokens",
        "max_completion_tokens",
        "tools",
        "tool_choice",
        "parallel_tool_calls",
        "reasoning_effort",
    }
    if set(payload) - allowed:
        _reject(
            "input_unsupported",
            "subscription payload contains unsupported input/options",
        )
    validate_payload_size(payload, _reject)
    image_totals = {"images": 0, "bytes": 0}
    messages = payload.get("messages")
    if not isinstance(messages, list) or not messages:
        _reject("input_unsupported", "subscription request requires text/tool messages")
    for message in messages:
        if not isinstance(message, Mapping) or message.get("role") not in {
            "system",
            "user",
            "assistant",
            "tool",
        }:
            _reject("input_unsupported", "unsupported subscription message role")
        if set(message) - {
            "role",
            "content",
            "tool_calls",
            "tool_call_id",
            "reasoning_content",
            "name",
        }:
            _reject("input_unsupported", "unsupported subscription message fields")
        validate_content(message.get("content"), role=message["role"], totals=image_totals, reject=_reject)
        if "reasoning_content" in message and not isinstance(message["reasoning_content"], str):
            _reject("input_unsupported", "invalid reasoning history")
        calls = message.get("tool_calls", [])
        if not isinstance(calls, list):
            _reject("input_unsupported", "tool_calls must be an array")
        for call in calls:
            function = call.get("function") if isinstance(call, Mapping) else None
            if (
                not isinstance(call, Mapping)
                or call.get("type") != "function"
                or not isinstance(function, Mapping)
                or not isinstance(function.get("name"), str)
                or not isinstance(function.get("arguments"), str)
            ):
                _reject("input_unsupported", "unsupported tool call input")
    tools = payload.get("tools", [])
    if not isinstance(tools, list) or any(
        not isinstance(tool, Mapping) or tool.get("type") != "function" or not isinstance(tool.get("function"), Mapping)
        for tool in tools
    ):
        _reject("input_unsupported", "only function tools are supported")


@dataclasses.dataclass(frozen=True)
class SubscriptionReservation:
    reservation_id: str
    episode_key: str
    payload_sha256: str


class SubscriptionCallLedger:
    """单一 0600 文件；flock 内检查、追加、fsync，每个 wire attempt 永久占位。"""

    def __init__(
        self,
        policy: MixedModelPolicy,
        episode_key: str,
        *,
        get_json: JsonGetter | None = None,
    ):
        if not isinstance(episode_key, str) or not episode_key:
            raise ValueError("episode_key must be a non-empty string")
        self.policy = policy
        self.episode_key = episode_key
        self.get_json = get_json or _local_get_json
        with self._locked() as (handle, records):
            if not records:
                self._append(
                    handle,
                    records,
                    {
                        "type": "policy",
                        "policy": policy.frozen(),
                        "policy_sha256": policy.sha256,
                    },
                )
            self._state(records)

    @contextlib.contextmanager
    def _locked(self):
        path = self.policy.ledger_path
        if not path.parent.is_dir():
            _reject("ledger_directory", "ledger parent directory must already exist")
        flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
        try:
            fd = os.open(path, flags, 0o600)
            handle = os.fdopen(fd, "r+", encoding="utf-8")
        except OSError:
            _reject("ledger_open", "subscription ledger cannot be securely opened")
        try:
            scope = check_scope()
            if scope is None:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            else:
                while True:
                    scope.check()
                    try:
                        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        break
                    except BlockingIOError:
                        scope.wait(0.02)
            info = os.fstat(handle.fileno())
            if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1:
                _reject(
                    "ledger_permissions",
                    "subscription ledger must be a private 0600 regular file",
                )
            content = handle.read()
            if content and not content.endswith("\n"):
                _reject("ledger_corrupt", "subscription ledger has an incomplete record")
            records = []
            previous = None
            for line in content.splitlines():
                try:
                    row = json.loads(line)
                    unsigned = {key: value for key, value in row.items() if key != "sha256"}
                    valid = row.get("prev_sha256") == previous and row.get("sha256") == _sha(unsigned)
                except (ValueError, TypeError, AttributeError):
                    _reject(
                        "ledger_corrupt",
                        "subscription ledger record cannot be verified",
                    )
                if not valid or row.get("seq") != len(records):
                    _reject("ledger_corrupt", "subscription ledger hash chain is invalid")
                records.append(row)
                previous = row["sha256"]
            yield handle, records
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()

    def _append(self, handle, records: list[dict], value: Mapping[str, Any]) -> None:
        row = {
            **value,
            "seq": len(records),
            "prev_sha256": records[-1]["sha256"] if records else None,
            "format": FORMAT,
            "at": _now(),
        }
        row["sha256"] = _sha(row)
        handle.seek(0, os.SEEK_END)
        handle.write(_canonical(row) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
        records.append(row)

    def _state(self, records: list[dict]) -> dict[str, dict]:
        if not records or records[0].get("type") != "policy":
            _reject("ledger_policy", "subscription ledger has no policy header")
        header = records[0]
        if header.get("policy_sha256") != self.policy.sha256 or header.get("policy") != self.policy.frozen():
            _reject("ledger_policy", "subscription ledger belongs to a different run/policy")
        entries: dict[str, dict] = {}
        for row in records[1:]:
            reservation_id = row.get("reservation_id")
            if not isinstance(reservation_id, str) or not reservation_id:
                _reject("ledger_corrupt", "subscription record has no reservation id")
            if row.get("type") == "reserve" and reservation_id not in entries:
                entries[reservation_id] = dict(row)
            elif row.get("type") == "settle" and reservation_id in entries:
                if entries[reservation_id].get("usage_sha256") is not None:
                    _reject(
                        "ledger_corrupt",
                        "subscription reservation was settled more than once",
                    )
                entries[reservation_id].update(row)
            else:
                _reject(
                    "ledger_corrupt",
                    "subscription ledger contains an invalid transition",
                )
        return entries

    def reserve_wire(self, payload, *, provider, model, output_token_cap, api_format, party):
        policy = self.policy
        if (provider, model, api_format, party) != (
            policy.codex_provider,
            policy.codex_model,
            policy.codex_api_format,
            "a",
        ) or payload.get("model") != policy.codex_model:
            _reject(
                "model_mismatch",
                "subscription attempt differs from the frozen provider/model/format",
            )
        if payload.get("reasoning_effort") != policy.codex_effort:
            _reject(
                "effort_mismatch",
                "subscription wire reasoning_effort must match the frozen effort",
            )
        _validate_text_tools(payload)
        payload_sha = _sha(payload)
        with self._locked() as (handle, records):
            entries = self._state(records)
            if len(entries) >= policy.max_calls:
                _reject("run_calls_exceeded", "subscription run attempt limit exhausted")
            episode_calls = sum(entry["episode_key"] == self.episode_key for entry in entries.values())
            if episode_calls >= policy.per_episode_calls:
                _reject(
                    "episode_calls_exceeded",
                    "subscription episode attempt limit exhausted",
                )
            try:
                quota = _quota_snapshot(policy, self.get_json)
            except SubscriptionRejected:
                raise
            except Exception:  # noqa: BLE001 - injected metadata getters also fail closed
                _reject("quota_unavailable", "quota check failed; no model request allowed")
            reservation = SubscriptionReservation(uuid.uuid4().hex, self.episode_key, payload_sha)
            self._append(
                handle,
                records,
                {
                    "type": "reserve",
                    "reservation_id": reservation.reservation_id,
                    "episode_key": self.episode_key,
                    "provider": provider,
                    "model": model,
                    "api_format": api_format,
                    "reasoning_effort": payload["reasoning_effort"],
                    "payload_sha256": payload_sha,
                    "state": "reserved",
                    "usage_sha256": None,
                    "output_token_cap_requested": output_token_cap,
                    "reserved_usd": None,
                    "settled_usd": None,
                    "billing_kind": policy.subscription_kind,
                    "quota": quota,
                    "quota_sha256": _sha(quota),
                },
            )
        return reservation

    def settle(self, reservation: SubscriptionReservation, usage: Mapping[str, Any] | None):
        safe_usage = dict(usage) if isinstance(usage, Mapping) else None
        recorded = bool(safe_usage) and all(
            isinstance(safe_usage.get(key), int) and not isinstance(safe_usage[key], bool) and safe_usage[key] >= 0
            for key in ("input_tokens", "output_tokens")
        )
        usage_sha = _sha(safe_usage)
        with self._locked() as (handle, records):
            entries = self._state(records)
            entry = entries.get(reservation.reservation_id)
            if entry is None or (entry["episode_key"], entry["payload_sha256"]) != (
                self.episode_key,
                reservation.payload_sha256,
            ):
                _reject(
                    "reservation_unknown",
                    "subscription reservation does not belong to this episode",
                )
            if entry.get("usage_sha256") is not None:
                if entry["usage_sha256"] != usage_sha:
                    _reject(
                        "usage_conflict",
                        "subscription reservation already recorded different usage",
                    )
                return entry
            self._append(
                handle,
                records,
                {
                    "type": "settle",
                    "reservation_id": reservation.reservation_id,
                    "usage": safe_usage,
                    "usage_sha256": usage_sha,
                    "usage_status": "recorded" if recorded else "unknown",
                    "state": "settled" if recorded else "unknown",
                    "settled_usd": None,
                },
            )
            return self._state(records)[reservation.reservation_id]

    def snapshot(self) -> dict[str, Any]:
        with self._locked() as (_, records):
            entries = self._state(records)
            root = records[-1]["sha256"]
        return {
            "format": FORMAT,
            "run_id": self.policy.run_id,
            "policy_sha256": self.policy.sha256,
            "root_sha256": root,
            "calls": len(entries),
            "episode_calls": sum(entry["episode_key"] == self.episode_key for entry in entries.values()),
            "max_calls": self.policy.max_calls,
            "per_episode_calls": self.policy.per_episode_calls,
            "billing_kind": self.policy.subscription_kind,
            "spent_usd": None,
            "entries": list(entries.values()),
        }


def _episode_key(parsed_spec, policy: MixedModelPolicy) -> str:
    binding = parsed_spec.panel_binding
    if (
        parsed_spec.run_id != policy.run_id
        or not isinstance(binding, Mapping)
        or binding.get("run_id") != policy.run_id
        or binding.get("kind") != "agent"
        or binding.get("trial") != parsed_spec.episode
        or not isinstance(parsed_spec.episode, int)
        or isinstance(parsed_spec.episode, bool)
        or parsed_spec.episode < 0
        or any(not isinstance(binding.get(key), str) or not binding[key] for key in ("panel", "member"))
    ):
        _reject(
            "episode_identity",
            "episode must have the frozen run_id and an explicit matching panel/member/trial binding",
        )
    return _canonical({
        "run_id": parsed_spec.run_id,
        "source": parsed_spec.source,
        "task_id": parsed_spec.task_id,
        "instance": parsed_spec.instance,
        "panel": binding["panel"],
        "member": binding["member"],
        "episode": parsed_spec.episode,
    })


def session_for_episode(parsed_spec, policy: MixedModelPolicy) -> str:
    return policy.session_prefix + "-" + hashlib.sha256(_episode_key(parsed_spec, policy).encode()).hexdigest()[:24]


class SubscriptionOpenAIAdapter(OpenAICompatibleAdapter):
    def __init__(self, policy: MixedModelPolicy, ledger: SubscriptionCallLedger, session_id: str):
        self.policy, self.subscription_ledger, self.session_id = (
            policy,
            ledger,
            session_id,
        )

    def chat(self, messages, tools, spec, timer, budget=None):
        policy = self.policy
        if budget is not None:
            _reject(
                "mixed_budget",
                "Codex subscription adapter cannot consume or impersonate a USD ledger",
            )
        if (
            spec.provider,
            spec.model,
            spec.resolved_api_format(),
            spec.resolved_endpoint(),
            spec.effort,
            spec.effort_param,
        ) != (
            policy.codex_provider,
            policy.codex_model,
            policy.codex_api_format,
            policy.codex_endpoint,
            policy.codex_effort,
            "reasoning_effort",
        ):
            _reject(
                "subscription_spec",
                "subscription model/endpoint/effort differ from the frozen policy",
            )
        headers = dict(spec.headers)
        for key in list(headers):
            if key.lower() == "x-magpie-session":
                if headers[key] != self.session_id:
                    _reject(
                        "session_mismatch",
                        "Magpie session differs from the frozen episode session",
                    )
                del headers[key]
        headers["X-Magpie-Session"] = self.session_id
        wire_spec = dataclasses.replace(spec, headers=headers)
        return super().chat(messages, tools, wire_spec, timer, budget=self.subscription_ledger)


def make_model_gateway(
    parsed_spec,
    *,
    policy: MixedModelPolicy,
    deepseek_budget,
    recorder=None,
    get_json: JsonGetter | None = None,
) -> ModelGateway:
    """返回真实 ModelGateway；调用方只传 gateway.chat 给正常 harness。"""
    spec = from_evaluation_spec(parsed_spec.raw)
    _episode_key(parsed_spec, policy)
    if set(spec.extra_body) & {
        "model",
        "messages",
        "tools",
        "max_tokens",
        "max_completion_tokens",
        "stream",
        "stream_options",
    }:
        _reject(
            "wire_override",
            "extra_body cannot replace the frozen model, history, tools or output request cap",
        )
    if spec.provider == policy.deepseek_provider or deepseek_budget is not None:
        _reject("cash_disabled", "cash API routes and USD ledgers are forbidden for this run")
    if (
        spec.provider,
        spec.model,
        spec.resolved_api_format(),
        spec.resolved_endpoint(),
        spec.effort,
        spec.effort_param,
    ) != (
        policy.codex_provider,
        policy.codex_model,
        policy.codex_api_format,
        policy.codex_endpoint,
        policy.codex_effort,
        "reasoning_effort",
    ):
        _reject(
            "subscription_spec",
            "only the explicitly frozen Codex subscription member is allowed",
        )
    ledger = SubscriptionCallLedger(policy, _episode_key(parsed_spec, policy), get_json=get_json)
    gateway = ModelGateway.from_evaluation_spec(parsed_spec.raw, recorder=recorder, run_budget=None)
    gateway.adapter = SubscriptionOpenAIAdapter(policy, ledger, session_for_episode(parsed_spec, policy))
    return gateway


def confirm_session_route(policy: MixedModelPolicy, session_id: str, *, get_json: JsonGetter | None = None) -> dict:
    """只查本 session；白名单投影返回，不读取/返回 served 或其它 session trace。"""
    if not re.fullmatch(re.escape(policy.session_prefix) + r"-[0-9a-f]{24}", session_id):
        _reject("route_session", "route session does not belong to this operator policy")
    url = policy.codex_endpoint + "/magpie/route?" + urllib.parse.urlencode({"session": session_id})
    try:
        document = (get_json or _local_get_json)(url, policy.quota_timeout_s)
    except SubscriptionRejected:
        raise
    except Exception:  # noqa: BLE001 - never expose raw metadata or account labels in exceptions
        _reject("route_unavailable", "session-filtered route confirmation unavailable")
    if not isinstance(document, Mapping) or document.get("session") != session_id:
        _reject("route_session", "Magpie returned another session or an unfiltered route")
    route = document.get("route")
    if not isinstance(route, Mapping):
        _reject("route_shape", "Magpie session has no completed route")
    expected = {
        "asked": policy.codex_model,
        "asked_effort": policy.codex_effort,
        "model": policy.codex_model,
        "effort": policy.codex_effort,
        "done": True,
        "status": 200,
    }
    if any(route.get(key) != value for key, value in expected.items()):
        _reject(
            "route_mismatch",
            "Magpie session did not confirm the frozen model/effort and successful route",
        )
    tries = route.get("tries")
    if not isinstance(tries, list) or not tries:
        _reject("route_shape", "Magpie route has no attempts")
    safe_tries = []
    for attempt in tries:
        if not isinstance(attempt, Mapping) or (
            attempt.get("model"),
            attempt.get("effort"),
        ) != (
            policy.codex_model,
            policy.codex_effort,
        ):
            _reject("route_mismatch", "Magpie attempted another model or effort")
        safe_tries.append({key: attempt.get(key) for key in ("model", "effort", "done", "status", "ms")})
    safe = {"session": session_id, "route": {**expected, "tries": safe_tries}}
    return {**safe, "sha256": _sha(safe)}
