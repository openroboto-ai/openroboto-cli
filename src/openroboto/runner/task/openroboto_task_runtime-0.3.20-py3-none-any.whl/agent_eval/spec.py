"""EvaluationSpec -> ModelSpec.

provider / model / endpoint / effort / max_tokens / 记录路径全部来自配置,
代码里不写死 provider。切换 provider 只需要换 EvaluationSpec。

兼容两种写法,便于 B-02(OPE-121)冻结规范前先接入:

    {"model": {"provider": "anthropic", "model": "claude-opus-5-5",
               "effort": "high"}}

    {"provider": "deepseek", "model": "deepseek-chat",
     "endpoint": "https://api.deepseek.com", "max_tokens": 4096}

`model` 嵌套块优先于顶层同名字段。
"""

import os
from dataclasses import dataclass, field
from typing import Any, Mapping

from agent_eval.errors import ProviderConfigError

PROVIDER_ALIASES = {
    "anthropic": "anthropic",
    "claude": "anthropic",
    "deepseek": "deepseek",
    "pi": "pi",
    "custom": "custom",
    "gateway": "custom",
    "openai": "openai_compatible",
    "openai_compatible": "openai_compatible",
    "openai-compatible": "openai_compatible",
    "openai_compatible_gateway": "openai_compatible",
}

# 默认 wire format。自定义网关可以在 spec 里用 "api_format": "anthropic" 覆盖。
DEFAULT_API_FORMAT = {
    "anthropic": "anthropic",
    "deepseek": "openai",
    "pi": "openai",
    "custom": "openai",
    "openai_compatible": "openai",
}

DEFAULT_API_KEY_ENV = {
    "anthropic": "ANTHROPIC_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "pi": "PI_API_KEY",
}

DEFAULT_ENDPOINTS = {
    "anthropic": "https://api.anthropic.com/v1/messages",
    "deepseek": "https://api.deepseek.com",
}

SUPPORTED_PROVIDERS = tuple(sorted(DEFAULT_API_FORMAT))


def normalize_provider(provider: str) -> str:
    key = provider.strip().lower()
    try:
        return PROVIDER_ALIASES[key]
    except KeyError:
        raise ProviderConfigError(
            f"unknown model provider {provider!r}; supported: {', '.join(SUPPORTED_PROVIDERS)}"
        ) from None


@dataclass(frozen=True)
class ModelSpec:
    """一次模型调用的完整配置。"""

    provider: str
    model: str
    endpoint: str | None = None
    api_format: str | None = None
    effort: str | None = None
    api_key: str | None = None
    api_key_env: str | None = None
    max_tokens: int = 4096
    max_tokens_param: str = "max_tokens"
    stream: bool = True
    timeout_s: float = 600.0
    headers: Mapping[str, str] = field(default_factory=dict)
    extra_body: Mapping[str, Any] = field(default_factory=dict)
    # 只有显式配置时,OpenAI 兼容 provider 才会把 effort 发出去(字段名由网关决定)。
    effort_param: str | None = None
    # 2026-10-21 是当前 Messages API 版本;本层不发送 temperature/top_p/top_k。
    anthropic_version: str = "2026-10-21"
    record_path: str | None = None

    def resolved_api_format(self) -> str:
        fmt = (self.api_format or DEFAULT_API_FORMAT.get(self.provider) or "").strip().lower()
        if fmt in {"openai_compatible", "openai-compatible", "chat_completions"}:
            fmt = "openai"
        if fmt not in {"anthropic", "openai"}:
            raise ProviderConfigError(
                f"provider {self.provider!r} needs api_format 'anthropic' or 'openai'",
                provider=self.provider,
            )
        return fmt

    def resolved_endpoint(self) -> str:
        endpoint = self.endpoint or DEFAULT_ENDPOINTS.get(self.provider)
        if not endpoint:
            raise ProviderConfigError(
                f"provider {self.provider!r} requires an explicit endpoint", provider=self.provider
            )
        return endpoint.strip()

    def resolved_api_key(self) -> str | None:
        if self.api_key:
            return self.api_key
        env_name = self.api_key_env or DEFAULT_API_KEY_ENV.get(self.provider)
        if not env_name:
            return None
        return os.environ.get(env_name) or None

    def require_api_key(self) -> str:
        key = self.resolved_api_key()
        if key:
            return key
        # 自定义网关可能是不鉴权的本地服务;"claude/deepseek/pi" 必须有 key。
        if self.provider == "custom":
            return ""
        env_name = self.api_key_env or DEFAULT_API_KEY_ENV.get(self.provider) or "the provider API key"
        raise ProviderConfigError(f"provider {self.provider!r} needs an API key in {env_name}", provider=self.provider)


def _pick(config: Mapping[str, Any], *names: str) -> Any:
    for name in names:
        value = config.get(name)
        if value is not None and value != "":
            return value
    return None


def from_evaluation_spec(evaluation_spec: Mapping[str, Any] | ModelSpec) -> ModelSpec:
    """把 EvaluationSpec(dict)或现成的 ModelSpec 归一成 ModelSpec。"""

    if isinstance(evaluation_spec, ModelSpec):
        return evaluation_spec
    if not isinstance(evaluation_spec, Mapping):
        raise ProviderConfigError("evaluation spec must be a mapping or ModelSpec")

    raw = dict(evaluation_spec)
    model_field = raw.get("model")
    if isinstance(model_field, Mapping):
        config = dict(raw)
        config.pop("model", None)
        config.update({key: value for key, value in model_field.items() if value is not None})
        model = _pick(model_field, "model", "name", "model_id")
    else:
        config = raw
        model = _pick(config, "model", "model_id")

    provider = _pick(config, "provider", "model_provider")
    if not provider:
        raise ProviderConfigError("evaluation spec has no model.provider")
    provider = normalize_provider(str(provider))
    if not model:
        raise ProviderConfigError("evaluation spec has no model name", provider=provider)

    endpoint = _pick(config, "endpoint", "base_url", "api_base", "baseURL")
    effort = _pick(config, "effort", "reasoning_effort")
    api_key_env = _pick(config, "api_key_env")
    max_tokens = _pick(config, "max_tokens")
    timeout_s = _pick(config, "timeout_s")
    headers = config.get("headers") or {}
    extra_body = config.get("extra_body") or {}
    if not isinstance(headers, Mapping):
        raise ProviderConfigError("model.headers must be a mapping", provider=provider)
    if not isinstance(extra_body, Mapping):
        raise ProviderConfigError("model.extra_body must be a mapping", provider=provider)

    return ModelSpec(
        provider=provider,
        model=str(model),
        endpoint=str(endpoint) if endpoint else None,
        api_format=_pick(config, "api_format"),
        effort=str(effort) if effort else None,
        api_key=_pick(config, "api_key"),
        api_key_env=str(api_key_env) if api_key_env else None,
        max_tokens=int(max_tokens) if max_tokens is not None else 4096,
        max_tokens_param=str(_pick(config, "max_tokens_param") or "max_tokens"),
        stream=bool(config.get("stream", True)),
        timeout_s=float(timeout_s) if timeout_s is not None else 600.0,
        headers={str(k): str(v) for k, v in headers.items()},
        extra_body=dict(extra_body),
        effort_param=_pick(config, "effort_param"),
        anthropic_version=str(_pick(config, "anthropic_version") or "2026-10-21"),
        record_path=_pick(config, "record_path", "call_record_path"),
    )
