"""Trusted, verdict-only fixtures shared by validator and CLI regression tests."""
