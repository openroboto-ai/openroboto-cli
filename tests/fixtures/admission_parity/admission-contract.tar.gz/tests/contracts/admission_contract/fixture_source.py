"""Test-only source configuration; never loaded from a submitted task package."""

from task_source.axis import AxisSource
from task_source.base import CheckResult


class AlternatingChecker:
    def __init__(self, checker):
        self.checker = checker
        self.final_calls = 0
        self.checker_type = checker.checker_type

    def describe(self):
        return self.checker.describe()

    def evaluate(self, state):
        result = self.checker.evaluate(state)
        if "current" not in state:
            return result
        self.final_calls += 1
        # Keep detail unchanged so this also detects boolean-only instability.
        return CheckResult(result.passed and self.final_calls % 2 == 1, result.detail)


class ContractAxisSource(AxisSource):
    def __init__(self, options):
        super().__init__(options)
        self.unstable_task_ids = options["unstable_task_ids"]

    def checker(self, task):
        checker = super().checker(task)
        return AlternatingChecker(checker) if task.task_id in self.unstable_task_ids else checker

    def runtime_status(self):
        return "not_run", {"scope": "verdict-only; no physical replay"}
