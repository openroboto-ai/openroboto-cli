"""Generate the shared baseline through the public worker CLI, never copied rules."""

from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CASE_ROOT = HERE / "cases"


def json_text(value):
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"


def hash_entries(entries):
    digest = hashlib.sha256()
    for name, path in sorted(entries):
        digest.update(f"{name}\0{hashlib.sha256(path.read_bytes()).hexdigest()}\n".encode())
    return digest.hexdigest()


def content_identity():
    """Byte identity also works for a runtime wheel extraction without Git."""
    import openroboto_protocol
    import task_source
    from task_source.miner import ADMISSION_VERSION

    worker_root = Path(task_source.__file__).resolve().parent
    protocol_root = Path(openroboto_protocol.__file__).resolve().parent
    source = [(f"task_source/{p.relative_to(worker_root).as_posix()}", p) for p in worker_root.rglob("*.py")]
    source.extend((f"openroboto_protocol/{p.relative_to(protocol_root)}", p) for p in protocol_root.rglob("*.py"))
    policy_files = (
        "admission_profiles.json",
        "scene_admission_v1.json",
        "scene_instruction_runtime_v1.json",
        "scene_observation_admission_v1.json",
        "scene_observation_admission_v2.json",
        "scene_recovery_checkpoint_v1.schema.json",
        "scene_review_policy_v2.json",
    )
    source.extend((f"task_source/data/{name}", worker_root / "data" / name) for name in policy_files)
    fixture_files = [
        HERE / name for name in ("__init__.py", "fixture_source.py", "generate.py", "suite.json", "config.json")
    ]
    fixture_files.extend(p for p in CASE_ROOT.rglob("*") if p.is_file())
    return {
        "admission_version": ADMISSION_VERSION,
        "admission_source_sha256": hash_entries(source),
        "fixture_suite_sha256": hash_entries([(p.relative_to(HERE).as_posix(), p) for p in fixture_files]),
    }


def identity():
    commit = subprocess.check_output(
        ["git", "-C", str(ROOT), "log", "-1", "--format=%H", "--", "task_source"], text=True
    ).strip()
    subprocess.run(
        ["git", "-C", str(ROOT), "diff", "--exit-code", commit, "--", "task_source"], check=True, capture_output=True
    )
    untracked = subprocess.check_output(
        ["git", "-C", str(ROOT), "ls-files", "--others", "--exclude-standard", "--", "task_source"], text=True
    )
    if untracked:
        raise ValueError("production task_source tree contains uncommitted files")
    return {"validator_commit": commit, **content_identity()}


def normalize_verdict(raw, package):
    """Only physical directory locators differ across independent checkouts."""
    value = copy.deepcopy(raw)
    for check in value["checks"]:
        detail = check["detail"]
        if check["name"] == "package" and "directory" in detail:
            detail["directory"] = "<package>"
        if check["name"] in {"package", "task_load"} and isinstance(detail.get("error"), str):
            detail["error"] = detail["error"].replace(str(package.resolve()), "<package>")
    return {
        "accepted": value["accepted"],
        "code": value.get("code"),
        "checks": value["checks"],
    }


def assert_expected(case, verdict):
    if verdict["accepted"] != case["accepted"]:
        raise ValueError(f"{case['name']}: accepted={verdict['accepted']}, expected {case['accepted']}")
    checks = {check["name"]: check for check in verdict["checks"]}
    for name in case["failed"]:
        if name not in checks or checks[name]["passed"]:
            raise ValueError(f"{case['name']}: expected {name} to fail, got {checks.get(name)}")
    if case.get("pending_runtime"):
        for name in case["failed"]:
            if checks[name]["kind"] != "runtime":
                raise ValueError(f"{case['name']}: {name} must remain an unresolved runtime check")
    if not case["failed"] and any(not check["passed"] for check in checks.values()):
        raise ValueError(f"{case['name']}: positive fixture contains failed checks")


def generate(output, *, raw_output=None):
    from task_source.package import package_digest

    suite = json.loads((HERE / "suite.json").read_text())
    version = identity()
    results = []
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join([str(HERE.parent), str(ROOT)])
    environment["TASK_SOURCE_CONFIG"] = str(HERE / "config.json")
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    if raw_output is not None:
        raw_output.mkdir(parents=True, exist_ok=True)
    for case in suite["cases"]:
        package = CASE_ROOT / case["name"]
        command = [sys.executable, "-m", "task_source.cli", "admit", str(package), "--json"]
        completed = subprocess.run(command, cwd=ROOT, env=environment, text=True, capture_output=True, check=False)
        if raw_output is not None:
            (raw_output / (case["name"] + ".stdout.json")).write_text(completed.stdout)
            (raw_output / (case["name"] + ".stderr.txt")).write_text(completed.stderr)
        envelope = json.loads(completed.stdout)
        if envelope["errors"] or len(envelope["results"]) != 1:
            raise ValueError(f"{case['name']}: expected one worker result without CLI errors: {envelope}")
        worker = envelope["results"][0]
        if completed.returncode != (0 if worker["accepted"] else 1):
            raise ValueError(f"{case['name']}: worker exit status disagrees with its verdict")
        verdict = normalize_verdict(worker, package)
        assert_expected(case, verdict)
        results.append({
            "case": case["name"],
            "package_digest": package_digest(package),
            "exit_code": completed.returncode,
            "verdict": verdict,
        })
    result = {
        "schema_version": 1,
        "suite": suite["suite"],
        "scope": suite["scope"],
        "identity": version,
        "generator_commit": subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip(),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "normalization": "package.detail.directory and package/task_load error prefixes only",
        "results": results,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json_text(result))
    return result
